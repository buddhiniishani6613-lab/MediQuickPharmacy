<?php

/*
    Include the common header file.

    This page is located inside the Admin folder,
    so ../ is used to move to the main project folder
    and access the common includes folder.
*/
include '../includes/header.php';

?>

<section class="admin-section">

    <div class="admin-container">

        <div class="page-header">

            <div>

                <span class="small-title">MEDIQUICK PHARMACY</span>

                <h1>Category Management</h1>

                <p>Manage pharmacy product categories.</p>

            </div>


            <!-- Button used to open the form for adding a new category. -->
            <button
                type="button"
                class="primary-btn"
                id="addCategoryBtn">

                <i class="bi bi-plus-circle"></i>

                Add Category

            </button>

        </div>


        <div class="admin-card">

            <!-- Categories are dynamically displayed inside this grid. -->
            <div
                class="category-grid"
                id="categoryGrid">
            </div>


            <!-- This message is displayed when no categories are available. -->
            <div
                class="empty-state"
                id="emptyCategories">

                <i class="bi bi-grid"></i>

                <h3>No categories found</h3>

            </div>

        </div>

    </div>

</section>


<!-- Modal used for adding and editing pharmacy categories. -->
<div
    class="modal"
    id="categoryModal">

    <!-- Overlay closes the modal when clicked. -->
    <div class="modal-overlay"></div>


    <div class="modal-box">

        <!-- Button used to close the category modal. -->
        <button
            type="button"
            class="close-btn"
            id="closeCategoryModal">

            <i class="bi bi-x-lg"></i>

        </button>


        <h2 id="categoryModalTitle">
            Add Category
        </h2>


        <form id="categoryForm">

            <!-- Stores the index of the category currently being edited. -->
            <input
                type="hidden"
                id="categoryIndex"
                value="-1"
            >


            <label>
                Category Name
            </label>


            <input
                type="text"
                id="categoryName"
                placeholder="Enter category name"
                required
            >


            <label>
                Description
            </label>


            <textarea
                id="categoryDescription"
                rows="4"
                placeholder="Enter category description"
            ></textarea>


            <div class="modal-actions">

                <!-- Cancels the current operation and closes the modal. -->
                <button
                    type="button"
                    class="secondary-btn"
                    id="cancelCategory">

                    Cancel

                </button>


                <!-- Submits the category form for saving. -->
                <button
                    type="submit"
                    class="primary-btn">

                    Save Category

                </button>

            </div>

        </form>

    </div>

</div>


<style>

/*
    Main section styling for the category management page.
*/
.admin-section {
    background: #f6fbfd;
    min-height: 80vh;
    padding: 55px 20px;
}


/*
    Controls the maximum width of the page content.
*/
.admin-container {
    max-width: 1200px;
    margin: auto;
}


/*
    Aligns the page heading and Add Category button.
*/
.page-header {
    display: flex;
    justify-content: space-between;
    align-items: end;
    margin-bottom: 30px;
    gap: 20px;
}


/*
    Styles the small pharmacy name displayed above the heading.
*/
.small-title {
    color: #087f9b;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 2px;
}


/*
    Styles the main page heading.
*/
.page-header h1 {
    color: #174f68;
    margin: 8px 0;
}


/*
    Styles the page description.
*/
.page-header p {
    color: #777;
    margin: 0;
}


/*
    Primary button styling used for main actions.
*/
.primary-btn {
    border: 0;
    background: #087f9b;
    color: #fff;
    padding: 12px 18px;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 700;
}


/*
    Changes the primary button color when the mouse
    pointer is placed over it.
*/
.primary-btn:hover {
    background: #056b83;
}


/*
    Secondary button styling used for cancel actions.
*/
.secondary-btn {
    border: 0;
    background: #edf3f5;
    color: #174f68;
    padding: 12px 18px;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 700;
}


/*
    Main white card containing the category grid.
*/
.admin-card {
    background: #fff;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 5px 25px rgba(0, 80, 110, .08);
}


/*
    Displays categories in a responsive grid layout.
*/
.category-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
}


/*
    Individual category card styling.
*/
.category-card {
    border: 1px solid #e2edf0;
    border-radius: 12px;
    padding: 20px;
}


/*
    Icon container displayed on each category card.
*/
.category-icon {
    width: 50px;
    height: 50px;
    border-radius: 10px;
    background: #e8f7fa;
    color: #087f9b;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 23px;
}


/*
    Category name styling.
*/
.category-card h3 {
    color: #174f68;
    margin: 15px 0 6px;
}


/*
    Category description styling.
*/
.category-card p {
    color: #777;
    font-size: 13px;
    min-height: 38px;
}


/*
    Arranges category action buttons horizontally.
*/
.category-actions {
    display: flex;
    gap: 8px;
    margin-top: 15px;
}


/*
    Common styling for category action buttons.
*/
.category-actions button {
    border: 0;
    padding: 8px 11px;
    border-radius: 7px;
    cursor: pointer;
}


/*
    Styling for the Edit button.
*/
.edit-cat {
    background: #e8f5f8;
    color: #087f9b;
}


/*
    Styling for the Delete button.
*/
.delete-cat {
    background: #fdeaea;
    color: #c0392b;
}


/*
    Empty state displayed when there are no categories.
*/
.empty-state {
    text-align: center;
    padding: 50px;
    display: none;
    color: #777;
}


/*
    Icon used in the empty category state.
*/
.empty-state i {
    font-size: 45px;
    color: #087f9b;
}


/*
    Main modal container.
*/
.modal {
    position: fixed;
    inset: 0;
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    padding: 20px;
}


/*
    Displays the modal when the show class is added.
*/
.modal.show {
    display: flex;
}


/*
    Dark background displayed behind the modal box.
*/
.modal-overlay {
    position: absolute;
    inset: 0;
    background: rgba(0, 0, 0, .5);
}


/*
    White content box displayed inside the modal.
*/
.modal-box {
    position: relative;
    background: white;
    width: 100%;
    max-width: 550px;
    border-radius: 15px;
    padding: 30px;
    z-index: 1;
}


/*
    Close button displayed at the top-right
    of the modal.
*/
.close-btn {
    position: absolute;
    top: 18px;
    right: 18px;
    border: 0;
    background: #f1f5f6;
    width: 35px;
    height: 35px;
    border-radius: 7px;
    cursor: pointer;
}


/*
    Modal heading styling.
*/
.modal-box h2 {
    color: #174f68;
    margin-top: 0;
}


/*
    Form label styling inside the modal.
*/
.modal-box label {
    display: block;
    color: #174f68;
    font-weight: 600;
    font-size: 13px;
    margin: 15px 0 7px;
}


/*
    Form input and textarea styling.
*/
.modal-box input,
.modal-box textarea {
    width: 100%;
    box-sizing: border-box;
    padding: 12px;
    border: 1px solid #d8e5e9;
    border-radius: 8px;
    outline: none;
    font-family: inherit;
}


/*
    Aligns the modal action buttons to the right.
*/
.modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    margin-top: 20px;
}


/*
    Adjusts the category grid for medium-sized screens.
*/
@media (max-width: 800px) {

    .category-grid {
        grid-template-columns: 1fr 1fr;
    }

}


/*
    Adjusts the page header and category grid for mobile screens.
*/
@media (max-width: 550px) {

    .page-header {
        flex-direction: column;
        align-items: flex-start;
    }


    .category-grid {
        grid-template-columns: 1fr;
    }

}

</style>


<script>

/*
    Wait until the HTML document has loaded
    before executing the category management code.
*/
document.addEventListener("DOMContentLoaded", function () {

    /*
        Default pharmacy categories used when no category
        information has previously been stored.
    */
    const defaultCategories = [

        {
            name: "Prescription Medicines",
            description: "Medicines that require a valid prescription."
        },

        {
            name: "OTC Products",
            description: "Over-the-counter healthcare products."
        },

        {
            name: "Wellness Products",
            description: "Vitamins, supplements and wellness products."
        },

        {
            name: "Personal Care",
            description: "Personal hygiene and skincare products."
        },

        {
            name: "Medical Devices",
            description: "Healthcare and monitoring devices."
        },

        {
            name: "Baby Care",
            description: "Products for babies and young children."
        }

    ];


    /*
        Array used to store the current category data.
    */
    let categories = [];


    /*
        Read the category information saved in localStorage.

        JSON.parse() converts the stored JSON string
        into a JavaScript array.
    */
    try {

        categories =
            JSON.parse(
                localStorage.getItem("mediquickCategories")
            ) || [];

    } catch (error) {

        /*
            Use an empty array if the stored data
            cannot be read correctly.
        */
        categories = [];

    }


    /*
        Add the default categories when there are
        no previously saved categories.
    */
    if (categories.length === 0) {

        categories = defaultCategories;


        /*
            Save the default categories in localStorage
            so they are available the next time the page loads.
        */
        localStorage.setItem(
            "mediquickCategories",
            JSON.stringify(categories)
        );

    }


    /*
        Get the HTML elements required for
        category management.
    */
    const grid =
        document.getElementById("categoryGrid");

    const empty =
        document.getElementById("emptyCategories");

    const modal =
        document.getElementById("categoryModal");


    /*
        Save the current category array in localStorage.

        JSON.stringify() converts the JavaScript array
        into a JSON string before storing it.
    */
    function save() {

        localStorage.setItem(
            "mediquickCategories",
            JSON.stringify(categories)
        );

    }


    /*
        Display all categories in the category grid.
    */
    function render() {

        /*
            Clear existing category cards
            before rendering the updated data.
        */
        grid.innerHTML = "";


        /*
            Display the empty state when there
            are no categories available.
        */
        if (categories.length === 0) {

            empty.style.display = "block";

            return;

        }


        /*
            Hide the empty state when categories exist.
        */
        empty.style.display = "none";


        /*
            Loop through each category and create
            a category card dynamically.
        */
        categories.forEach(function (cat, index) {

            const card =
                document.createElement("div");


            /*
                Apply the category card CSS class.
            */
            card.className = "category-card";


            /*
                Add the category information and
                action buttons to the card.
            */
            card.innerHTML = `

                <div class="category-icon">

                    <i class="bi bi-grid"></i>

                </div>


                <h3>
                    ${escapeHtml(cat.name)}
                </h3>


                <p>
                    ${escapeHtml(cat.description || "")}
                </p>


                <div class="category-actions">

                    <button
                        type="button"
                        class="edit-cat"
                        data-index="${index}">

                        <i class="bi bi-pencil"></i>

                        Edit

                    </button>


                    <button
                        type="button"
                        class="delete-cat"
                        data-index="${index}">

                        <i class="bi bi-trash"></i>

                        Delete

                    </button>

                </div>

            `;


            /*
                Add the completed card to the category grid.
            */
            grid.appendChild(card);

        });


        /*
            Add click events to all Edit buttons.
        */
        document
            .querySelectorAll(".edit-cat")
            .forEach(function (button) {

                button.onclick = function () {

                    editCategory(
                        Number(this.dataset.index)
                    );

                };

            });


        /*
            Add click events to all Delete buttons.
        */
        document
            .querySelectorAll(".delete-cat")
            .forEach(function (button) {

                button.onclick = function () {

                    deleteCategory(
                        Number(this.dataset.index)
                    );

                };

            });

    }


    /*
        Escape special HTML characters before displaying
        category information inside dynamically generated HTML.

        This helps prevent HTML entered as category data
        from being interpreted as HTML code.
    */
    function escapeHtml(value) {

        return String(value || "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");

    }


    /*
        Open the modal for adding a new category.
    */
    document
        .getElementById("addCategoryBtn")
        .onclick = function () {

            /*
                Clear the existing form values.
            */
            document
                .getElementById("categoryForm")
                .reset();


            /*
                -1 indicates that a new category
                is being created.
            */
            document
                .getElementById("categoryIndex")
                .value = "-1";


            /*
                Set the modal title for the add operation.
            */
            document
                .getElementById("categoryModalTitle")
                .textContent = "Add Category";


            /*
                Display the modal.
            */
            modal.classList.add("show");

        };


    /*
        Open the edit modal and load the selected
        category information into the form.
    */
    function editCategory(index) {

        const cat =
            categories[index];


        /*
            Store the selected category index
            so the form knows which category to update.
        */
        document
            .getElementById("categoryIndex")
            .value = index;


        /*
            Load the existing category name into the form.
        */
        document
            .getElementById("categoryName")
            .value = cat.name;


        /*
            Load the existing category description into the form.
        */
        document
            .getElementById("categoryDescription")
            .value =
                cat.description || "";


        /*
            Change the modal title to indicate
            that an existing category is being edited.
        */
        document
            .getElementById("categoryModalTitle")
            .textContent = "Edit Category";


        /*
            Display the edit modal.
        */
        modal.classList.add("show");

    }


    /*
        Delete the selected category after confirmation.
    */
    function deleteCategory(index) {

        /*
            Ask the administrator to confirm
            the deletion before removing the category.
        */
        if (
            !confirm(
                "Are you sure you want to delete this category?"
            )
        ) {

            return;

        }


        /*
            Remove the selected category from the array.
        */
        categories.splice(index, 1);


        /*
            Save the updated category list.
        */
        save();


        /*
            Refresh the category display.
        */
        render();

    }


    /*
        Handle category form submission.

        The same form is used for both adding
        and editing categories.
    */
    document
        .getElementById("categoryForm")
        .onsubmit = function (event) {

            /*
                Prevent the browser from submitting
                the form and refreshing the page.
            */
            event.preventDefault();


            /*
                Get the index of the selected category.

                A value of -1 means that a new category
                should be added.
            */
            const index =
                Number(
                    document
                        .getElementById("categoryIndex")
                        .value
                );


            /*
                Collect category information entered
                by the administrator.
            */
            const data = {

                name:
                    document
                        .getElementById("categoryName")
                        .value
                        .trim(),

                description:
                    document
                        .getElementById("categoryDescription")
                        .value
                        .trim()

            };


            /*
                Update an existing category when
                a valid category index is available.
            */
            if (index >= 0) {

                categories[index] = data;

            } else {

                /*
                    Add the category as a new record
                    when no existing index is selected.
                */
                categories.push(data);

            }


            /*
                Save the updated category information.
            */
            save();


            /*
                Refresh the category cards.
            */
            render();


            /*
                Close the modal after saving.
            */
            modal.classList.remove("show");

        };


    /*
        Close the category modal.
    */
    function closeModal() {

        modal.classList.remove("show");

    }


    /*
        Close the modal when the close button is clicked.
    */
    document
        .getElementById("closeCategoryModal")
        .onclick = closeModal;


    /*
        Close the modal when the Cancel button is clicked.
    */
    document
        .getElementById("cancelCategory")
        .onclick = closeModal;


    /*
        Close the modal when the modal background is clicked.
    */
    document
        .querySelector(".modal-overlay")
        .onclick = closeModal;


    /*
        Display the category information when
        the page is first loaded.
    */
    render();

});

</script>


<?php

/*
    Include the common footer file.

    This page is located inside the Admin folder,
    so ../ is used to access the includes folder
    in the main project directory.
*/
include '../includes/footer.php';

?>