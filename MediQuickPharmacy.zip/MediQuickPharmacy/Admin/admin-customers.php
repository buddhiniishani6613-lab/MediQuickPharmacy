<?php

// Start the session so the logged-in administrator can be checked.
session_start();

// Load the database connection.
require_once __DIR__ . '/../config/database.php';

// Allow access only to logged-in users.
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

// Check whether the database connection is available.
if (!isset($conn) || !($conn instanceof mysqli)) {
    die("Database connection was not found.");
}

// Store customer records retrieved from MySQL.
$customers = [];

$sql = "
    SELECT
        id,
        full_name,
        email,
        phone,
        role,
        created_at
    FROM users
    WHERE role = ?
    ORDER BY id DESC
";

// Use a prepared statement to safely pass the customer role.
$stmt = $conn->prepare($sql);

if ($stmt) {

    $role = "customer";

    $stmt->bind_param("s", $role);

    $stmt->execute();

    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {

        $customers[] = [
            'id' => (int) $row['id'],
            'full_name' => $row['full_name'] ?? 'Customer',
            'email' => $row['email'] ?? '-',
            'phone' => $row['phone'] ?? '-',
            'role' => $row['role'] ?? 'customer',
            'created_at' => $row['created_at'] ?? ''
        ];
    }

    $stmt->close();
}

// Load the common website header.
include __DIR__ . '/../includes/header.php';

?>

<section class="admin-section">

    <div class="admin-container">

        <div class="page-header">

            <div>

                <span class="small-title">
                    MEDIQUICK PHARMACY
                </span>

                <h1>
                    Customer Management
                </h1>

                <p>
                    View registered pharmacy customers.
                </p>

            </div>

        </div>

        <div class="admin-card">

            <!-- Search field used to find customers quickly. -->
            <input
                type="text"
                id="customerSearch"
                class="search-input"
                placeholder="Search customers..."
            >

            <div class="table-wrapper">

                <table>

                    <thead>

                        <tr>

                            <th>Name</th>

                            <th>Email</th>

                            <th>Phone</th>

                            <th>Role</th>

                            <th>Registered</th>

                            <th>Action</th>

                        </tr>

                    </thead>

                    <tbody id="customersTable"></tbody>

                </table>

            </div>

            <!-- This message is displayed when no matching customers exist. -->
            <div
                id="emptyCustomers"
                class="empty-state"
            >

                <i class="bi bi-people"></i>

                <h3>
                    No customers found
                </h3>

                <p>
                    Registered customers will appear here.
                </p>

            </div>

        </div>

    </div>

</section>

<!-- Modal used to display the selected customer's details. -->
<div
    class="customer-modal"
    id="customerModal"
>

    <div class="customer-modal-box">

        <div class="customer-modal-header">

            <h2>
                Customer Details
            </h2>

            <button
                type="button"
                id="closeCustomerModal"
                class="close-modal"
            >
                &times;
            </button>

        </div>

        <div
            id="customerDetails"
            class="customer-details"
        ></div>

    </div>

</div>

<style>

.admin-section {
    background: #f6fbfd;
    min-height: 80vh;
    padding: 55px 20px;
}

.admin-container {
    max-width: 1200px;
    margin: auto;
}

.page-header {
    margin-bottom: 30px;
}

.small-title {
    color: #087f9b;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 2px;
}

.page-header h1 {
    color: #174f68;
    margin: 8px 0;
    font-size: 36px;
}

.page-header p {
    color: #777;
}

.admin-card {
    background: white;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 5px 25px rgba(0, 80, 110, .08);
}

.search-input {
    width: 100%;
    box-sizing: border-box;
    padding: 13px 15px;
    border: 1px solid #d8e5e9;
    border-radius: 8px;
    margin-bottom: 20px;
    outline: none;
    font-size: 14px;
}

.search-input:focus {
    border-color: #087f9b;
    box-shadow: 0 0 0 3px rgba(8, 127, 155, .08);
}

.table-wrapper {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 800px;
}

th {
    background: #f3fafc;
    color: #174f68;
    padding: 15px;
    text-align: left;
    font-size: 13px;
    font-weight: 700;
}

td {
    padding: 14px 15px;
    border-top: 1px solid #edf2f4;
    color: #555;
    font-size: 14px;
}

tbody tr:hover {
    background: #fbfdfe;
}

.customer-name {
    color: #174f68;
    font-weight: 700;
}

.customer-email {
    color: #555;
}

.role-badge {
    display: inline-block;
    background: #e8f5f8;
    color: #087f9b;
    padding: 6px 10px;
    border-radius: 15px;
    font-size: 11px;
    font-weight: 700;
}

.view-customer {
    border: 0;
    background: #e8f5f8;
    color: #087f9b;
    padding: 8px 12px;
    border-radius: 7px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
}

.view-customer:hover {
    background: #087f9b;
    color: white;
}

.empty-state {
    text-align: center;
    padding: 50px;
    color: #777;
    display: none;
}

.empty-state i {
    font-size: 45px;
    color: #087f9b;
}

.empty-state h3 {
    color: #526c78;
    margin: 15px 0 8px;
}

.customer-modal {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(20, 50, 65, .45);
    z-index: 9999;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.customer-modal.show {
    display: flex;
}

.customer-modal-box {
    background: white;
    width: 100%;
    max-width: 550px;
    border-radius: 16px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, .18);
    overflow: hidden;
}

.customer-modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 24px;
    border-bottom: 1px solid #edf2f4;
}

.customer-modal-header h2 {
    margin: 0;
    color: #174f68;
    font-size: 22px;
}

.close-modal {
    border: 0;
    background: transparent;
    color: #777;
    font-size: 30px;
    cursor: pointer;
    line-height: 1;
}

.close-modal:hover {
    color: #087f9b;
}

.customer-details {
    padding: 25px;
}

.customer-detail-row {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    padding: 12px 0;
    border-bottom: 1px solid #f0f3f4;
}

.customer-detail-label {
    color: #888;
}

.customer-detail-value {
    color: #174f68;
    font-weight: 600;
    text-align: right;
}

@media (max-width: 650px) {

    .admin-section {
        padding: 35px 12px;
    }

    .page-header h1 {
        font-size: 28px;
    }

    .admin-card {
        padding: 15px;
    }

    .customer-modal-box {
        max-width: 100%;
    }

}

</style>

<script>

// PHP sends the customer records from MySQL to JavaScript as JSON.
const customers = <?php
    echo json_encode(
        $customers,
        JSON_HEX_TAG |
        JSON_HEX_APOS |
        JSON_HEX_QUOT |
        JSON_HEX_AMP
    );
?>;

const table = document.getElementById("customersTable");
const empty = document.getElementById("emptyCustomers");
const searchInput = document.getElementById("customerSearch");
const modal = document.getElementById("customerModal");
const customerDetails = document.getElementById("customerDetails");

// Escape HTML characters before displaying database values.
function escapeHtml(value) {

    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}

// Format the registration date for easier reading.
function formatDate(value) {

    if (!value) {
        return "-";
    }

    const date = new Date(value);

    if (isNaN(date.getTime())) {
        return escapeHtml(value);
    }

    return date.toLocaleDateString(
        "en-GB",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );
}

// Filter and display the customer records.
function renderCustomers() {

    const search = searchInput.value
        .toLowerCase()
        .trim();

    table.innerHTML = "";

    // Search by customer name, email or phone number.
    const filtered = customers.filter(function(customer) {

        const text = (
            (customer.full_name || "") +
            " " +
            (customer.email || "") +
            " " +
            (customer.phone || "")
        ).toLowerCase();

        return text.includes(search);
    });

    // Show the empty state when there are no matching customers.
    if (filtered.length === 0) {

        empty.style.display = "block";

        return;
    }

    empty.style.display = "none";

    // Create a table row for each matching customer.
    filtered.forEach(function(customer) {

        const row = document.createElement("tr");

        row.innerHTML = `

            <td>
                <span class="customer-name">
                    ${escapeHtml(customer.full_name)}
                </span>
            </td>

            <td>
                <span class="customer-email">
                    ${escapeHtml(customer.email)}
                </span>
            </td>

            <td>
                ${escapeHtml(customer.phone || "-")}
            </td>

            <td>
                <span class="role-badge">
                    Customer
                </span>
            </td>

            <td>
                ${formatDate(customer.created_at)}
            </td>

            <td>
                <button
                    type="button"
                    class="view-customer"
                    data-id="${customer.id}"
                >
                    <i class="bi bi-eye"></i>
                    View
                </button>
            </td>

        `;

        table.appendChild(row);
    });

    // Add a click event to each customer View button.
    document
        .querySelectorAll(".view-customer")
        .forEach(function(button) {

            button.addEventListener(
                "click",
                function() {

                    const customerId =
                        Number(this.dataset.id);

                    const customer =
                        customers.find(
                            function(item) {
                                return item.id === customerId;
                            }
                        );

                    if (customer) {
                        showCustomer(customer);
                    }
                }
            );

        });
}

// Display the selected customer's information in the modal.
function showCustomer(customer) {

    customerDetails.innerHTML = `

        <div class="customer-detail-row">

            <span class="customer-detail-label">
                Customer ID
            </span>

            <span class="customer-detail-value">
                #${escapeHtml(customer.id)}
            </span>

        </div>

        <div class="customer-detail-row">

            <span class="customer-detail-label">
                Full Name
            </span>

            <span class="customer-detail-value">
                ${escapeHtml(customer.full_name)}
            </span>

        </div>

        <div class="customer-detail-row">

            <span class="customer-detail-label">
                Email
            </span>

            <span class="customer-detail-value">
                ${escapeHtml(customer.email)}
            </span>

        </div>

        <div class="customer-detail-row">

            <span class="customer-detail-label">
                Phone
            </span>

            <span class="customer-detail-value">
                ${escapeHtml(customer.phone || "-")}
            </span>

        </div>

        <div class="customer-detail-row">

            <span class="customer-detail-label">
                Role
            </span>

            <span class="customer-detail-value">
                Customer
            </span>

        </div>

        <div class="customer-detail-row">

            <span class="customer-detail-label">
                Registered
            </span>

            <span class="customer-detail-value">
                ${formatDate(customer.created_at)}
            </span>

        </div>

    `;

    modal.classList.add("show");
}

// Close the customer details modal.
document
    .getElementById("closeCustomerModal")
    .addEventListener(
        "click",
        function() {
            modal.classList.remove("show");
        }
    );

// Close the modal when the user clicks outside the modal box.
modal.addEventListener(
    "click",
    function(event) {

        if (event.target === modal) {
            modal.classList.remove("show");
        }

    }
);

// Re-render the customer list when the search value changes.
searchInput.addEventListener(
    "input",
    renderCustomers
);

// Display the customer list when the page loads.
renderCustomers();

</script>

<?php

// Load the common website footer.
include __DIR__ . '/../includes/footer.php';

?>