
<?php

session_start();

/*
 * Disable browser cache.
 */
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");

/*
 * Display errors during development.
 */
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

/*
 * Database connection.
 */
require_once __DIR__ . '/../config/database.php';

if (!isset($conn) || !$conn) {
    die("Database connection failed.");
}

/*
 * Allow access only to administrators.
 */
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$userId = (int) $_SESSION['user_id'];

/*
 * Escape output.
 */
function e($value)
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
 * Get a single count.
 */
function getCount($conn, $sql)
{
    $result = $conn->query($sql);

    if (!$result) {
        return 0;
    }

    $row = $result->fetch_assoc();

    return (int) ($row['total'] ?? 0);
}

/*
 * Get a numeric value.
 */
function getNumber($conn, $sql)
{
    $result = $conn->query($sql);

    if (!$result) {
        return 0;
    }

    $row = $result->fetch_assoc();

    return (float) ($row['total'] ?? 0);
}

/*
 * Get multiple database records.
 */
function getRows($conn, $sql)
{
    $rows = [];

    $result = $conn->query($sql);

    if (!$result) {
        return $rows;
    }

    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }

    return $rows;
}

/*
 * Get administrator details.
 */
$userStmt = $conn->prepare("
    SELECT id, full_name, email, role
    FROM users
    WHERE id = ?
    LIMIT 1
");

if (!$userStmt) {
    die("User query failed: " . e($conn->error));
}

$userStmt->bind_param("i", $userId);
$userStmt->execute();

$userResult = $userStmt->get_result();

if (!$userResult || $userResult->num_rows === 0) {

    session_unset();
    session_destroy();

    header("Location: ../login.php");
    exit();
}

$user = $userResult->fetch_assoc();

$userName = $user['full_name'] ?? 'Admin';
$userEmail = $user['email'] ?? '';
$userRole = strtolower(trim($user['role'] ?? ''));

$userStmt->close();

/*
 * Check administrator permissions.
 */
if ($userRole !== 'admin') {

    if ($userRole === 'staff') {
        header("Location: ../Staff/staff-dashboard.php");
    } else {
        header("Location: ../index.php");
    }

    exit();
}

/*
 * Automatically update product availability.
 */
$conn->query("
    UPDATE products
    SET status = CASE
        WHEN stock_quantity <= 0 THEN 'Out of Stock'
        ELSE 'Available'
    END
    WHERE status IN ('Available', 'Out of Stock')
");

/*
 * Dashboard statistics.
 */

$totalCustomers = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM users
    WHERE role = 'customer'
    "
);

$totalStaff = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM users
    WHERE role = 'staff'
    "
);

$totalProducts = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM products
    WHERE status <> 'Inactive'
    "
);

$outOfStock = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM products
    WHERE stock_quantity <= 0
    AND status <> 'Inactive'
    "
);

$lowStock = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM products
    WHERE stock_quantity BETWEEN 1 AND 5
    AND status = 'Available'
    "
);

$totalOrders = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM orders
    "
);

$pendingOrders = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM orders
    WHERE order_status = 'Pending'
    "
);

$pendingPrescriptions = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM prescriptions
    WHERE status = 'Pending Review'
    "
);

$totalPrescriptions = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM prescriptions
    "
);

$totalRevenue = getNumber(
    $conn,
    "
    SELECT COALESCE(SUM(total_amount), 0) AS total
    FROM orders
    WHERE order_status <> 'Cancelled'
    "
);

$todayOrders = getCount(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM orders
    WHERE DATE(created_at) = CURDATE()
    "
);

/*
 * Recent orders.
 */
$recentOrders = getRows(
    $conn,
    "
    SELECT
        id,
        order_number,
        full_name,
        total_amount,
        order_status,
        created_at
    FROM orders
    ORDER BY id DESC
    LIMIT 6
    "
);

/*
 * Recent prescriptions.
 */
$recentPrescriptions = getRows(
    $conn,
    "
    SELECT
        id,
        patient_name,
        email,
        status,
        created_at
    FROM prescriptions
    ORDER BY id DESC
    LIMIT 5
    "
);

/*
 * Recent customers.
 */
$recentCustomers = getRows(
    $conn,
    "
    SELECT
        id,
        full_name,
        email,
        created_at
    FROM users
    WHERE role = 'customer'
    ORDER BY id DESC
    LIMIT 5
    "
);

/*
 * Pharmacy hero image.
 */
$pharmacyImage = '../assets/images/Pharmacy.png';

if (!file_exists(__DIR__ . '/../assets/images/Pharmacy.png')) {

    if (file_exists(__DIR__ . '/../assets/images/Pharamacy.png')) {

        $pharmacyImage = '../assets/images/Pharamacy.png';

    } else {

        $pharmacyImage = '../assets/images/Logo.png';
    }
}

/*
 * Order status styles.
 */
function getOrderStatusClass($status)
{
    switch (strtolower(trim($status))) {

        case 'pending':
            return 'status-pending';

        case 'processing':
        case 'confirmed':
            return 'status-processing';

        case 'shipped':
            return 'status-shipped';

        case 'delivered':
            return 'status-available';

        case 'cancelled':
            return 'status-cancelled';

        default:
            return 'status-default';
    }
}

/*
 * Prescription status styles.
 */
function getPrescriptionStatusClass($status)
{
    switch (strtolower(trim($status))) {

        case 'approved':
            return 'status-available';

        case 'rejected':
            return 'status-cancelled';

        case 'pending review':
            return 'status-pending';

        case 'completed':
            return 'status-completed';

        default:
            return 'status-default';
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard | MediQuick Pharmacy</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
        rel="stylesheet"
    >

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: "Segoe UI", Arial, sans-serif;
            background: #f4f7fb;
            color: #263238;
        }

        /* Sidebar */

        .sidebar {
            width: 255px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: linear-gradient(180deg, #087f8c, #075b66);
            color: white;
            padding: 25px 16px;
            z-index: 1000;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
        }

        .brand {
            text-align: center;
            margin-bottom: 30px;
        }

        .brand-icon {
            width: 62px;
            height: 62px;
            margin: auto;
            background: white;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #087f8c;
            font-size: 32px;
        }

        .brand h2 {
            font-size: 21px;
            margin-top: 12px;
            font-weight: 700;
        }

        .brand p {
            font-size: 12px;
            opacity: .8;
        }

        .nav-menu {
            list-style: none;
            padding: 0;
            margin: 0;
            flex: 1;
        }

        .nav-menu li {
            margin-bottom: 7px;
        }

        .nav-menu a {
            display: flex;
            align-items: center;
            gap: 13px;
            padding: 13px 15px;
            color: rgba(255,255,255,.88);
            text-decoration: none;
            border-radius: 12px;
            transition: .2s;
            font-size: 14px;
            position: relative;
        }

        .nav-menu a:hover {
            background: rgba(255,255,255,.14);
            color: white;
        }

        .nav-menu a.active {
            background: white;
            color: #087f8c;
            font-weight: 600;
            box-shadow: 0 5px 15px rgba(0,0,0,.10);
        }

        .nav-menu i {
            font-size: 18px;
            width: 21px;
            text-align: center;
        }

        .nav-title {
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            opacity: .55;
            padding: 18px 15px 7px;
        }

        .sidebar-bottom {
            border-top: 1px solid rgba(255,255,255,.15);
            padding-top: 15px;
            margin-top: 15px;
        }

        .sidebar-bottom a {
            display: flex;
            align-items: center;
            gap: 13px;
            padding: 12px 15px;
            text-decoration: none;
            color: rgba(255,255,255,.88);
            font-size: 14px;
            border-radius: 12px;
            transition: .2s;
        }

        .sidebar-bottom a:hover {
            background: rgba(255,255,255,.14);
            color: white;
        }

        .sidebar-bottom i {
            font-size: 18px;
            width: 21px;
        }

        .sidebar-bottom .logout-link {
            color: #ffd4d4;
        }

        /* Main content */

        .main {
            margin-left: 255px;
            min-height: 100vh;
        }

        /* Topbar */

        .topbar {
            background: white;
            min-height: 75px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 32px;
            border-bottom: 1px solid #e9edf2;
            gap: 15px;
        }

        .page-title h1 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 2px;
            color: #263238;
        }

        .page-title p {
            font-size: 13px;
            color: #78909c;
            margin: 0;
        }

        .admin-profile {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .admin-avatar {
            width: 43px;
            height: 43px;
            border-radius: 50%;
            background: #e0f7fa;
            color: #087f8c;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 17px;
        }

        .admin-info strong {
            display: block;
            font-size: 14px;
        }

        .admin-info span {
            font-size: 11px;
            color: #78909c;
        }

        /* Dashboard content */

        .content {
            padding: 30px;
        }

        /* Hero section */

        .hero {
            background: linear-gradient(135deg, #087f8c, #0b6470);
            min-height: 200px;
            border-radius: 22px;
            position: relative;
            overflow: hidden;
            color: white;
            padding: 30px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
        }

        .hero-content {
            width: 60%;
            position: relative;
            z-index: 2;
        }

        .hero h2 {
            font-size: 30px;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .hero p {
            font-size: 14px;
            line-height: 1.7;
            opacity: .9;
            max-width: 550px;
            margin: 0;
        }

        .hero-image {
            position: absolute;
            right: 20px;
            bottom: 0;
            height: 195px;
            max-width: 40%;
            object-fit: contain;
        }

        .hero-label {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            background: rgba(255,255,255,.15);
            font-size: 11px;
            margin-bottom: 12px;
        }

        /* Main statistics */

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: white;
            border-radius: 17px;
            padding: 21px;
            border: 1px solid #edf0f4;
            box-shadow: 0 5px 20px rgba(30,60,90,.04);
            min-width: 0;
        }

        .stat-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
        }

        .stat-card h3 {
            font-size: 27px;
            margin-top: 17px;
            margin-bottom: 3px;
            color: #174f68;
            font-weight: 700;
        }

        .stat-card p {
            color: #78909c;
            font-size: 12px;
            margin: 0;
        }

        .stat-icon {
            width: 45px;
            height: 45px;
            border-radius: 13px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #e0f7fa;
            color: #087f8c;
            font-size: 21px;
            flex-shrink: 0;
        }

        /* Secondary statistics */

        .secondary-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
            margin-bottom: 25px;
        }

        .secondary-card {
            background: white;
            border-radius: 17px;
            padding: 18px;
            border: 1px solid #edf0f4;
            box-shadow: 0 5px 20px rgba(30,60,90,.04);
        }

        .secondary-card .label {
            color: #78909c;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: .5px;
            font-weight: 600;
        }

        .secondary-card .value {
            margin-top: 8px;
            color: #174f68;
            font-size: 24px;
            font-weight: 700;
            overflow-wrap: anywhere;
        }

        .secondary-card .description {
            margin-top: 5px;
            color: #90a4ae;
            font-size: 11px;
        }

        /* Dashboard columns */

        .dashboard-grid {
            display: grid;
            grid-template-columns: 1.5fr 1fr;
            gap: 22px;
            margin-bottom: 22px;
        }

        .panel {
            background: white;
            border-radius: 18px;
            border: 1px solid #edf0f4;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(30,60,90,.04);
            margin-bottom: 20px;
            min-width: 0;
        }

        .panel-header {
            padding: 20px 22px;
            border-bottom: 1px solid #edf0f4;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
        }

        .panel-header h3 {
            font-size: 17px;
            margin: 0;
            color: #174f68;
            font-weight: 700;
        }

        .view-link {
            text-decoration: none;
            color: #087f8c;
            font-size: 12px;
            font-weight: 600;
            white-space: nowrap;
        }

        .view-link:hover {
            text-decoration: underline;
        }

        /* Tables */

        .table-wrap {
            width: 100%;
            overflow-x: auto;
        }

        .dashboard-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 600px;
        }

        .dashboard-table th {
            font-size: 10px;
            color: #90a4ae;
            text-transform: uppercase;
            padding: 13px 18px;
            text-align: left;
            background: #fafcfd;
            letter-spacing: .5px;
        }

        .dashboard-table td {
            padding: 14px 18px;
            border-top: 1px solid #f0f3f5;
            font-size: 12px;
            color: #536970;
        }

        .order-number {
            font-weight: 700;
            color: #174f68;
        }

        .amount {
            font-weight: 700;
            color: #087f8c;
            white-space: nowrap;
        }

        /* Status labels */

        .status {
            display: inline-block;
            padding: 5px 9px;
            border-radius: 20px;
            font-size: 9px;
            font-weight: 600;
            white-space: nowrap;
        }

        .status-pending {
            background: #fff4d6;
            color: #a66b00;
        }

        .status-processing {
            background: #e3f2fd;
            color: #1565c0;
        }

        .status-shipped {
            background: #ede7f6;
            color: #5e35b1;
        }

        .status-available,
        .status-completed {
            background: #e7f7ef;
            color: #16804a;
        }

        .status-cancelled {
            background: #ffebee;
            color: #c62828;
        }

        .status-default {
            background: #edf3f5;
            color: #60747c;
        }

        /* Customer and prescription lists */

        .dashboard-list {
            padding: 5px 20px 10px;
        }

        .dashboard-list-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 0;
            border-bottom: 1px solid #f0f3f5;
            min-width: 0;
        }

        .dashboard-list-item:last-child {
            border-bottom: none;
        }

        .list-icon {
            width: 42px;
            height: 42px;
            border-radius: 12px;
            background: #e0f7fa;
            color: #087f8c;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 17px;
            flex-shrink: 0;
        }

        .list-content {
            flex: 1;
            min-width: 0;
        }

        .list-content strong {
            display: block;
            color: #174f68;
            font-size: 13px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .list-content span {
            display: block;
            color: #90a4ae;
            font-size: 11px;
            margin-top: 4px;
            overflow-wrap: anywhere;
        }

        /* Quick actions */

        .quick-actions {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
            padding: 18px;
        }

        .quick-action {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 13px;
            border-radius: 12px;
            background: #f6fbfd;
            color: #174f68;
            text-decoration: none;
            font-size: 12px;
            font-weight: 600;
            border: 1px solid #e7f0f2;
            transition: .2s;
        }

        .quick-action:hover {
            background: #e0f7fa;
            color: #087f8c;
            transform: translateY(-2px);
        }

        .quick-action i {
            color: #087f8c;
            font-size: 17px;
        }

        /* Empty states */

        .empty-state {
            padding: 35px 20px;
            text-align: center;
            color: #90a4ae;
        }

        .empty-state i {
            font-size: 32px;
            display: block;
            margin-bottom: 10px;
        }

        .empty-state p {
            font-size: 12px;
            margin: 0;
        }

        /* Mobile menu */

        .mobile-menu-button {
            display: none;
            width: 40px;
            height: 40px;
            border: none;
            border-radius: 10px;
            background: #087f8c;
            color: white;
            font-size: 21px;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }

        .sidebar-overlay {
            display: none;
        }

        /* Responsive layout */

        @media(max-width: 1250px) {

            .stats-grid,
            .secondary-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }

        @media(max-width: 900px) {

            .sidebar {
                width: 255px;
                transform: translateX(-100%);
                transition: transform .3s ease;
            }

            .sidebar.show {
                transform: translateX(0);
            }

            .main {
                margin-left: 0;
            }

            .mobile-menu-button {
                display: flex;
            }

            .sidebar-overlay.show {
                display: block;
                position: fixed;
                inset: 0;
                background: rgba(0,0,0,.4);
                z-index: 999;
            }

            .hero-content {
                width: 65%;
            }
        }

        @media(max-width: 700px) {

            .content {
                padding: 18px;
            }

            .topbar {
                padding: 12px 18px;
            }

            .admin-info {
                display: none;
            }

            .hero {
                padding: 25px;
                min-height: 230px;
            }

            .hero-content {
                width: 100%;
            }

            .hero h2 {
                font-size: 24px;
            }

            .hero-image {
                opacity: .25;
                max-width: 75%;
            }

            .quick-actions {
                grid-template-columns: 1fr;
            }

            .stats-grid,
            .secondary-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 12px;
            }

            .stat-card {
                padding: 15px;
            }
        }

        @media(max-width: 450px) {

            .stats-grid,
            .secondary-grid {
                grid-template-columns: 1fr;
            }

            .content {
                padding: 12px;
            }

            .hero {
                border-radius: 15px;
            }

            .hero h2 {
                font-size: 22px;
            }

            .page-title h1 {
                font-size: 20px;
            }

            .page-title p {
                font-size: 11px;
            }

        }

    </style>

</head>

<body>

<!-- Sidebar overlay -->

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- Admin sidebar -->

<aside class="sidebar" id="adminSidebar">

    <div class="brand">

        <div class="brand-icon">
            <i class="bi bi-heart-pulse-fill"></i>
        </div>

        <h2>MediQuick</h2>

        <p>Pharmacy Management</p>

    </div>

    <ul class="nav-menu">

        <li>
            <a href="admin-dashboard.php" class="active">
                <i class="bi bi-grid-1x2-fill"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <div class="nav-title">Management</div>

        <li>
            <a href="admin-products.php">
                <i class="bi bi-capsule"></i>
                <span>Products</span>
            </a>
        </li>

        <li>
            <a href="admin-categories.php">
                <i class="bi bi-tags"></i>
                <span>Categories</span>
            </a>
        </li>

        <li>
            <a href="admin-orders.php">
                <i class="bi bi-bag-check"></i>
                <span>Orders</span>
            </a>
        </li>

        <li>
            <a href="admin-prescriptions.php">
                <i class="bi bi-file-medical"></i>
                <span>Prescriptions</span>
            </a>
        </li>

        <div class="nav-title">Users</div>

        <li>
            <a href="admin-customers.php">
                <i class="bi bi-people"></i>
                <span>Customers</span>
            </a>
        </li>

        <li>
            <a href="admin-inquiries.php">
                <i class="bi bi-chat-left-text"></i>
                <span>Inquiries</span>
            </a>
        </li>

        <li>
            <a href="admin-staff.php">
                <i class="bi bi-person-badge"></i>
                <span>Staff</span>
            </a>
        </li>

        <div class="nav-title">System</div>

        <li>
            <a href="admin-reports.php">
                <i class="bi bi-bar-chart-line"></i>
                <span>Reports</span>
            </a>
        </li>

        <li>
            <a href="admin-settings.php">
                <i class="bi bi-gear"></i>
                <span>Settings</span>
            </a>
        </li>

    </ul>

    <div class="sidebar-bottom">

        <a href="../index.php">
            <i class="bi bi-globe"></i>
            <span>View Website</span>
        </a>

        <a href="../logout.php" class="logout-link">
            <i class="bi bi-box-arrow-right"></i>
            <span>Logout</span>
        </a>

    </div>

</aside>

<!-- Main dashboard -->

<main class="main">

    <!-- Topbar -->

    <header class="topbar">

        <div style="display:flex; align-items:center; gap:15px;">

            <button
                type="button"
                class="mobile-menu-button"
                id="adminMenuButton"
                aria-label="Open menu"
            >
                <i class="bi bi-list"></i>
            </button>

            <div class="page-title">

                <h1>Dashboard</h1>

                <p>
                    Welcome back, <?php echo e($userName); ?>.
                    Here's what's happening today.
                </p>

            </div>

        </div>

        <div class="admin-profile">

            <div class="admin-avatar">
                <?php echo strtoupper(substr($userName, 0, 1)); ?>
            </div>

            <div class="admin-info">

                <strong><?php echo e($userName); ?></strong>

                <span>Administrator</span>

            </div>

        </div>

    </header>

    <section class="content">

        <!-- Welcome hero -->

        <div class="hero">

            <div class="hero-content">

                <span class="hero-label">
                    <i class="bi bi-shield-check"></i>
                    Administrator Panel
                </span>

                <h2>
                    Welcome, <?php echo e($userName); ?>!
                </h2>

                <p>
                    Manage pharmacy operations, monitor customers,
                    oversee products and inventory, review orders
                    and prescriptions, and stay updated with
                    important pharmacy information.
                </p>

            </div>

            <img
                src="<?php echo e($pharmacyImage); ?>"
                alt="MediQuick Pharmacy"
                class="hero-image"
                onerror="this.style.display='none';"
            >

        </div>

        <!-- Main statistics -->

        <div class="stats-grid">

            <div class="stat-card">

                <div class="stat-top">

                    <div>
                        <h3><?php echo number_format($totalCustomers); ?></h3>
                        <p>Total Customers</p>
                    </div>

                    <div class="stat-icon">
                        <i class="bi bi-people-fill"></i>
                    </div>

                </div>

            </div>

            <div class="stat-card">

                <div class="stat-top">

                    <div>
                        <h3><?php echo number_format($totalStaff); ?></h3>
                        <p>Total Staff</p>
                    </div>

                    <div class="stat-icon">
                        <i class="bi bi-person-badge-fill"></i>
                    </div>

                </div>

            </div>

            <div class="stat-card">

                <div class="stat-top">

                    <div>
                        <h3><?php echo number_format($totalProducts); ?></h3>
                        <p>Active Products</p>
                    </div>

                    <div class="stat-icon">
                        <i class="bi bi-capsule"></i>
                    </div>

                </div>

            </div>

            <div class="stat-card">

                <div class="stat-top">

                    <div>
                        <h3><?php echo number_format($totalOrders); ?></h3>
                        <p>Total Orders</p>
                    </div>

                    <div class="stat-icon">
                        <i class="bi bi-bag-check-fill"></i>
                    </div>

                </div>

            </div>

        </div>

        <!-- Secondary statistics -->

        <div class="secondary-grid">

            <div class="secondary-card">

                <div class="label">Total Revenue</div>

                <div class="value">
                    Rs. <?php echo number_format($totalRevenue, 2); ?>
                </div>

                <div class="description">
                    Excluding cancelled orders
                </div>

            </div>

            <div class="secondary-card">

                <div class="label">Pending Orders</div>

                <div class="value">
                    <?php echo number_format($pendingOrders); ?>
                </div>

                <div class="description">
                    Orders awaiting processing
                </div>

            </div>

            <div class="secondary-card">

                <div class="label">Low Stock</div>

                <div class="value">
                    <?php echo number_format($lowStock); ?>
                </div>

                <div class="description">
                    Products with 1–5 items
                </div>

            </div>

            <div class="secondary-card">

                <div class="label">Out of Stock</div>

                <div class="value">
                    <?php echo number_format($outOfStock); ?>
                </div>

                <div class="description">
                    Products currently unavailable
                </div>

            </div>

        </div>

        <!-- Dashboard content -->

        <div class="dashboard-grid">

            <!-- Left column -->

            <div>

                <!-- Recent orders -->

                <div class="panel">

                    <div class="panel-header">

                        <h3>Recent Orders</h3>

                        <a href="admin-orders.php" class="view-link">
                            View All
                        </a>

                    </div>

                    <?php if (!empty($recentOrders)): ?>

                        <div class="table-wrap">

                            <table class="dashboard-table">

                                <thead>

                                    <tr>
                                        <th>Order</th>
                                        <th>Customer</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                    </tr>

                                </thead>

                                <tbody>

                                    <?php foreach ($recentOrders as $order): ?>

                                        <tr>

                                            <td>
                                                <span class="order-number">
                                                    <?php
                                                    echo e(
                                                        $order['order_number']
                                                        ?? ('#' . ($order['id'] ?? ''))
                                                    );
                                                    ?>
                                                </span>
                                            </td>

                                            <td>
                                                <?php
                                                echo e(
                                                    $order['full_name'] ?? 'Customer'
                                                );
                                                ?>
                                            </td>

                                            <td>
                                                <span class="amount">
                                                    Rs.
                                                    <?php
                                                    echo number_format(
                                                        (float) ($order['total_amount'] ?? 0),
                                                        2
                                                    );
                                                    ?>
                                                </span>
                                            </td>

                                            <td>

                                                <span class="status <?php
                                                    echo getOrderStatusClass(
                                                        $order['order_status'] ?? ''
                                                    );
                                                ?>">
                                                    <?php
                                                    echo e(
                                                        $order['order_status'] ?? 'Unknown'
                                                    );
                                                    ?>
                                                </span>

                                            </td>

                                            <td>

                                                <?php

                                                if (!empty($order['created_at'])) {

                                                    echo e(
                                                        date(
                                                            'M d, Y',
                                                            strtotime($order['created_at'])
                                                        )
                                                    );

                                                } else {

                                                    echo '-';

                                                }

                                                ?>

                                            </td>

                                        </tr>

                                    <?php endforeach; ?>

                                </tbody>

                            </table>

                        </div>

                    <?php else: ?>

                        <div class="empty-state">

                            <i class="bi bi-bag-x"></i>

                            <p>No orders found.</p>

                        </div>

                    <?php endif; ?>

                </div>

                <!-- Recent customers -->

                <div class="panel">

                    <div class="panel-header">

                        <h3>Recent Customers</h3>

                        <a href="admin-customers.php" class="view-link">
                            View All
                        </a>

                    </div>

                    <?php if (!empty($recentCustomers)): ?>

                        <div class="dashboard-list">

                            <?php foreach ($recentCustomers as $customer): ?>

                                <div class="dashboard-list-item">

                                    <div class="list-icon">
                                        <i class="bi bi-person"></i>
                                    </div>

                                    <div class="list-content">

                                        <strong>
                                            <?php
                                            echo e(
                                                $customer['full_name'] ?? 'Customer'
                                            );
                                            ?>
                                        </strong>

                                        <span>
                                            <?php
                                            echo e(
                                                $customer['email'] ?? ''
                                            );
                                            ?>
                                        </span>

                                    </div>

                                    <span class="status status-available">
                                        Customer
                                    </span>

                                </div>

                            <?php endforeach; ?>

                        </div>

                    <?php else: ?>

                        <div class="empty-state">

                            <i class="bi bi-people"></i>

                            <p>No customers found.</p>

                        </div>

                    <?php endif; ?>

                </div>

            </div>

            <!-- Right column -->

            <div>

                <!-- Today's overview -->

                <div class="panel">

                    <div class="panel-header">

                        <h3>Today's Overview</h3>

                    </div>

                    <div class="dashboard-list">

                        <div class="dashboard-list-item">

                            <div class="list-icon">
                                <i class="bi bi-calendar-check"></i>
                            </div>

                            <div class="list-content">

                                <strong>Today's Orders</strong>

                                <span>Orders created today</span>

                            </div>

                            <strong>
                                <?php echo number_format($todayOrders); ?>
                            </strong>

                        </div>

                        <div class="dashboard-list-item">

                            <div class="list-icon">
                                <i class="bi bi-clock-history"></i>
                            </div>

                            <div class="list-content">

                                <strong>Pending Orders</strong>

                                <span>Awaiting processing</span>

                            </div>

                            <strong>
                                <?php echo number_format($pendingOrders); ?>
                            </strong>

                        </div>

                        <div class="dashboard-list-item">

                            <div class="list-icon">
                                <i class="bi bi-file-medical"></i>
                            </div>

                            <div class="list-content">

                                <strong>Pending Prescriptions</strong>

                                <span>Waiting for review</span>

                            </div>

                            <strong>
                                <?php echo number_format($pendingPrescriptions); ?>
                            </strong>

                        </div>

                        <div class="dashboard-list-item">

                            <div class="list-icon">
                                <i class="bi bi-file-earmark-medical"></i>
                            </div>

                            <div class="list-content">

                                <strong>Total Prescriptions</strong>

                                <span>All prescription records</span>

                            </div>

                            <strong>
                                <?php echo number_format($totalPrescriptions); ?>
                            </strong>

                        </div>

                    </div>

                </div>

                <!-- Recent prescriptions -->

                <div class="panel">

                    <div class="panel-header">

                        <h3>Recent Prescriptions</h3>

                        <a href="admin-prescriptions.php" class="view-link">
                            View All
                        </a>

                    </div>

                    <?php if (!empty($recentPrescriptions)): ?>

                        <div class="dashboard-list">

                            <?php foreach ($recentPrescriptions as $prescription): ?>

                                <div class="dashboard-list-item">

                                    <div class="list-icon">
                                        <i class="bi bi-file-medical"></i>
                                    </div>

                                    <div class="list-content">

                                        <strong>
                                            <?php
                                            echo e(
                                                $prescription['patient_name'] ?? 'Patient'
                                            );
                                            ?>
                                        </strong>

                                        <span>
                                            <?php
                                            echo e(
                                                $prescription['email'] ?? ''
                                            );
                                            ?>
                                        </span>

                                    </div>

                                    <span class="status <?php
                                        echo getPrescriptionStatusClass(
                                            $prescription['status'] ?? ''
                                        );
                                    ?>">
                                        <?php
                                        echo e(
                                            $prescription['status'] ?? 'Unknown'
                                        );
                                        ?>
                                    </span>

                                </div>

                            <?php endforeach; ?>

                        </div>

                    <?php else: ?>

                        <div class="empty-state">

                            <i class="bi bi-file-earmark-x"></i>

                            <p>No prescriptions found.</p>

                        </div>

                    <?php endif; ?>

                </div>

                <!-- Quick actions -->

                <div class="panel">

                    <div class="panel-header">

                        <h3>Quick Actions</h3>

                    </div>

                    <div class="quick-actions">

                        <a
                            href="admin-products.php"
                            class="quick-action"
                        >
                            <i class="bi bi-plus-circle"></i>
                            Add Product
                        </a>

                        <a
                            href="admin-orders.php"
                            class="quick-action"
                        >
                            <i class="bi bi-bag-check"></i>
                            Manage Orders
                        </a>

                        <a
                            href="admin-inventory.php"
                            class="quick-action"
                        >
                            <i class="bi bi-box-seam"></i>
                            Inventory
                        </a>

                        <a
                            href="admin-prescriptions.php"
                            class="quick-action"
                        >
                            <i class="bi bi-file-medical"></i>
                            Prescriptions
                        </a>

                        <a
                            href="admin-customers.php"
                            class="quick-action"
                        >
                            <i class="bi bi-people"></i>
                            Customers
                        </a>

                        <a
                            href="admin-reports.php"
                            class="quick-action"
                        >
                            <i class="bi bi-bar-chart-line"></i>
                            Reports
                        </a>

                    </div>

                </div>

            </div>

        </div>

    </section>

</main>

<script>

/* Open and close the mobile sidebar. */

const menuButton = document.getElementById('adminMenuButton');
const sidebar = document.getElementById('adminSidebar');
const overlay = document.getElementById('sidebarOverlay');

menuButton.addEventListener('click', function () {

    sidebar.classList.toggle('show');
    overlay.classList.toggle('show');

});

overlay.addEventListener('click', function () {

    sidebar.classList.remove('show');
    overlay.classList.remove('show');

});

/* Refresh the page when restored from browser cache. */

window.addEventListener('pageshow', function (event) {

    if (event.persisted) {
        window.location.reload();
    }

});

</script>

</body>
</html>
