<?php

/*
    Include the common header file.

    This page is located inside the Admin folder,
    so ../ is used to move back to the main project folder.
*/
include '../includes/header.php';

?>

<section class="admin-section">

    <div class="admin-container">

        <div class="page-header">

            <div>
                <span class="small-title">MEDIQUICK PHARMACY</span>

                <h1>Customer Inquiries</h1>

                <p>Manage customer questions and messages.</p>
            </div>

        </div>

        <div class="admin-card">

            <!-- Customer inquiries are displayed inside this container. -->
            <div id="inquiriesList"></div>

            <!-- This message is displayed when there are no customer inquiries. -->
            <div id="emptyInquiries" class="empty-state">

                <i class="bi bi-chat-dots"></i>

                <h3>No inquiries found</h3>

                <p>Customer inquiries will appear here.</p>

            </div>

        </div>

    </div>

</section>


<style>

/*
    Main section styling for the customer inquiry page.
*/
.admin-section {
    background: #f6fbfd;
    min-height: 80vh;
    padding: 55px 20px;
}

/*
    Controls the maximum width and horizontal alignment
    of the page content.
*/
.admin-container {
    max-width: 1100px;
    margin: auto;
}

/*
    Adds spacing below the page heading.
*/
.page-header {
    margin-bottom: 30px;
}

/*
    Small title displayed above the main page heading.
*/
.small-title {
    color: #087f9b;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 2px;
}

/*
    Main page heading styling.
*/
.page-header h1 {
    color: #174f68;
    margin: 8px 0;
}

/*
    Page description styling.
*/
.page-header p {
    color: #777;
}

/*
    Main white container used to display customer inquiries.
*/
.admin-card {
    background: white;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 5px 25px rgba(0, 80, 110, .08);
}

/*
    Individual customer inquiry card.
*/
.inquiry-card {
    border: 1px solid #e2edf0;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 15px;
}

/*
    Arranges the inquiry heading and reply button
    horizontally.
*/
.inquiry-header {
    display: flex;
    justify-content: space-between;
    gap: 15px;
}

/*
    Customer inquiry subject styling.
*/
.inquiry-card h3 {
    color: #174f68;
    margin: 0 0 5px;
}

/*
    Customer inquiry message styling.
*/
.inquiry-card p {
    color: #666;
    line-height: 1.5;
}

/*
    Displays customer information and inquiry date
    using a smaller font.
*/
.inquiry-meta {
    color: #888;
    font-size: 12px;
}

/*
    Styling for the Reply button.
*/
.reply-btn {
    border: 0;
    background: #087f9b;
    color: white;
    padding: 9px 14px;
    border-radius: 7px;
    cursor: pointer;
}

/*
    Empty state message shown when no inquiries exist.
*/
.empty-state {
    text-align: center;
    padding: 50px;
    color: #777;
    display: none;
}

/*
    Icon displayed in the empty inquiry state.
*/
.empty-state i {
    font-size: 45px;
    color: #087f9b;
}

/*
    Responsive layout for smaller screens.
*/
@media (max-width: 600px) {

    .admin-section {
        padding: 35px 15px;
    }

    .admin-card {
        padding: 18px;
    }

    .inquiry-header {
        flex-direction: column;
    }

    .reply-btn {
        width: 100%;
    }

}

</style>


<script>

/*
    Wait until the HTML document has finished loading
    before executing the inquiry management code.
*/
document.addEventListener("DOMContentLoaded", function () {

    /*
        Store all customer inquiries retrieved from localStorage.
    */
    let inquiries = [];

    /*
        Read the saved customer inquiries from localStorage.

        JSON.parse() converts the stored JSON string
        back into a JavaScript array.
    */
    try {

        inquiries =
            JSON.parse(
                localStorage.getItem("mediquickInquiries")
            ) || [];

    } catch (error) {

        /*
            If the stored data is invalid,
            use an empty array instead.
        */
        inquiries = [];

    }

    /*
        Get the HTML element where inquiry cards
        will be displayed.
    */
    const list =
        document.getElementById("inquiriesList");

    /*
        Display all available customer inquiries.
    */
    function render() {

        /*
            Clear the existing inquiry cards before
            displaying the updated list.
        */
        list.innerHTML = "";

        /*
            If there are no inquiries,
            display the empty state message.
        */
        if (inquiries.length === 0) {

            document
                .getElementById("emptyInquiries")
                .style.display = "block";

            return;
        }

        /*
            Hide the empty state when inquiries are available.
        */
        document
            .getElementById("emptyInquiries")
            .style.display = "none";

        /*
            Create an inquiry card for each customer inquiry.
        */
        inquiries.forEach(function (item, index) {

            const card =
                document.createElement("div");

            /*
                Apply the inquiry card CSS class.
            */
            card.className = "inquiry-card";

            /*
                Add customer inquiry information
                to the card.
            */
            card.innerHTML = `

                <div class="inquiry-header">

                    <div>

                        <h3>
                            ${escapeHtml(
                                item.subject || "Customer Inquiry"
                            )}
                        </h3>

                        <div class="inquiry-meta">

                            ${escapeHtml(
                                item.name || "Customer"
                            )}

                            -

                            ${escapeHtml(
                                item.email || "-"
                            )}

                        </div>

                    </div>

                    <button
                        type="button"
                        class="reply-btn"
                        data-index="${index}">

                        Reply

                    </button>

                </div>

                <p>
                    ${escapeHtml(
                        item.message || ""
                    )}
                </p>

                <div class="inquiry-meta">

                    ${escapeHtml(
                        item.date || ""
                    )}

                </div>

            `;

            /*
                Add the completed inquiry card
                to the inquiry list.
            */
            list.appendChild(card);

        });

        /*
            Find all Reply buttons and assign
            a click event to each button.
        */
        document
            .querySelectorAll(".reply-btn")
            .forEach(function (button) {

                button.onclick = function () {

                    /*
                        Get the array index of the inquiry
                        related to the clicked Reply button.
                    */
                    const index =
                        Number(
                            this.dataset.index
                        );

                    /*
                        Get the selected customer inquiry.
                    */
                    const item =
                        inquiries[index];

                    /*
                        Ask the administrator to enter
                        a reply message.
                    */
                    const reply =
                        prompt(
                            "Enter your reply:"
                        );

                    /*
                        Save the reply only when the administrator
                        enters a non-empty message.
                    */
                    if (
                        reply &&
                        reply.trim()
                    ) {

                        /*
                            Store the administrator's reply
                            in the selected inquiry.
                        */
                        inquiries[index].reply =
                            reply.trim();

                        /*
                            Change the inquiry status
                            to Replied.
                        */
                        inquiries[index].status =
                            "Replied";

                        /*
                            Save the updated inquiry list
                            back to localStorage.
                        */
                        localStorage.setItem(
                            "mediquickInquiries",
                            JSON.stringify(inquiries)
                        );

                        /*
                            Inform the administrator that
                            the reply has been saved.
                        */
                        alert(
                            "Reply saved successfully."
                        );

                        /*
                            Refresh the inquiry list so that
                            the updated information is displayed.
                        */
                        render();

                    }

                };

            });

    }

    /*
        Escape special HTML characters before displaying
        user-provided inquiry data.

        This helps prevent HTML code entered by a customer
        from being interpreted as actual HTML.
    */
    function escapeHtml(value) {

        return String(value || "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");

    }

    /*
        Display the customer inquiries when the page loads.
    */
    render();

});

</script>


<?php

/*
    Include the common footer file.

    This page is inside the Admin folder,
    therefore ../ is required to access the includes folder.
*/
include '../includes/footer.php';

?>