
<?php

// Start the user session.
session_start();

// Connect to the MediQuick Pharmacy database.
require_once __DIR__ . '/../config/database.php';

// Redirect users who are not logged in.
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

// Check the database connection.
if (!isset($conn) || !($conn instanceof mysqli)) {
    die("Database connection was not found.");
}

/*
 * Find a column that actually exists in the database.
 */
function findColumn($columns, $possibleNames)
{
    foreach ($possibleNames as $name) {

        // Check against actual database columns.
        if (in_array($name, $columns, true)) {
            return $name;
        }
    }

    return null;
}

/*
 * Get the actual columns from the orders table.
 */
$ordersColumns = [];

$columnResult = $conn->query("SHOW COLUMNS FROM orders");

if ($columnResult) {
    while ($column = $columnResult->fetch_assoc()) {
        $ordersColumns[] = $column['Field'];
    }
}

// Identify the available orders table columns.
$orderIdColumn = findColumn(
    $ordersColumns,
    ['id', 'order_id']
);

$orderNumberColumn = findColumn(
    $ordersColumns,
    ['order_number', 'order_no', 'order_code']
);

$userIdColumn = findColumn(
    $ordersColumns,
    ['user_id', 'customer_id']
);

$statusColumn = findColumn(
    $ordersColumns,
    ['order_status', 'status']
);

$totalColumn = findColumn(
    $ordersColumns,
    ['total_amount', 'grand_total', 'total', 'amount']
);

$paymentStatusColumn = findColumn(
    $ordersColumns,
    ['payment_status', 'payment']
);

$paymentMethodColumn = findColumn(
    $ordersColumns,
    ['payment_method', 'payment_type']
);

$dateColumn = findColumn(
    $ordersColumns,
    ['created_at', 'order_date', 'date', 'ordered_at']
);

// Check the required order ID column.
if (!$orderIdColumn) {
    die("The orders table does not contain an ID column.");
}

// Check the order status column.
if (!$statusColumn) {
    die("The orders table does not contain an order status column.");
}

/*
 * Update order status when the administrator changes it.
 */
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['action'])
    && $_POST['action'] === 'update_status'
) {

    header('Content-Type: application/json');

    $orderId = isset($_POST['order_id'])
        ? (int) $_POST['order_id']
        : 0;

    $newStatus = isset($_POST['status'])
        ? trim($_POST['status'])
        : '';

    $allowedStatuses = [
        'Pending',
        'Processing',
        'Shipped',
        'Delivered',
        'Cancelled'
    ];

    if (
        $orderId <= 0 ||
        !in_array($newStatus, $allowedStatuses, true)
    ) {

        echo json_encode([
            'success' => false,
            'message' => 'Invalid order or status.'
        ]);

        exit;
    }

    $updateSql = "
        UPDATE orders
        SET `$statusColumn` = ?
        WHERE `$orderIdColumn` = ?
    ";

    $updateStmt = $conn->prepare($updateSql);

    if (!$updateStmt) {

        echo json_encode([
            'success' => false,
            'message' => 'Unable to prepare status update.'
        ]);

        exit;
    }

    $updateStmt->bind_param(
        "si",
        $newStatus,
        $orderId
    );

    if ($updateStmt->execute()) {

        echo json_encode([
            'success' => true,
            'message' => 'Order status updated successfully.'
        ]);

    } else {

        echo json_encode([
            'success' => false,
            'message' => 'Failed to update order status.'
        ]);
    }

    $updateStmt->close();

    exit;
}

/*
 * Prepare the SELECT query using available columns only.
 */
$orderRows = [];

$selectColumns = [];

// Order ID.
$selectColumns[] =
    "`$orderIdColumn` AS order_id";

// Order number.
if ($orderNumberColumn) {

    $selectColumns[] =
        "`$orderNumberColumn` AS order_number";

} else {

    $selectColumns[] =
        "`$orderIdColumn` AS order_number";
}

// Customer ID.
if ($userIdColumn) {

    $selectColumns[] =
        "`$userIdColumn` AS user_id";

} else {

    $selectColumns[] =
        "NULL AS user_id";
}

// Order status.
$selectColumns[] =
    "`$statusColumn` AS order_status";

// Order total.
if ($totalColumn) {

    $selectColumns[] =
        "`$totalColumn` AS order_total";

} else {

    $selectColumns[] =
        "0 AS order_total";
}

// Payment status.
if ($paymentStatusColumn) {

    $selectColumns[] =
        "`$paymentStatusColumn` AS payment_status";

} else {

    $selectColumns[] =
        "'' AS payment_status";
}

// Payment method.
if ($paymentMethodColumn) {

    $selectColumns[] =
        "`$paymentMethodColumn` AS payment_method";

} else {

    $selectColumns[] =
        "'' AS payment_method";
}

// Order date.
if ($dateColumn) {

    $selectColumns[] =
        "`$dateColumn` AS order_date";

} else {

    $selectColumns[] =
        "NULL AS order_date";
}

/*
 * Retrieve orders from the database.
 */
$orderSql = "
    SELECT
        " . implode(", ", $selectColumns) . "
    FROM orders
    ORDER BY `$orderIdColumn` DESC
";

$orderResult = $conn->query($orderSql);

if (!$orderResult) {
    die("Unable to retrieve orders: " . $conn->error);
}

/*
 * Retrieve customer information.
 */
$users = [];

if ($userIdColumn) {

    $userResult = $conn->query("
        SELECT
            id,
            full_name,
            email,
            phone
        FROM users
    ");

    if ($userResult) {

        while ($user = $userResult->fetch_assoc()) {

            $users[(int) $user['id']] = $user;
        }
    }
}

/*
 * Combine orders with their customer information.
 */
while ($order = $orderResult->fetch_assoc()) {

    $userId = isset($order['user_id'])
        ? (int) $order['user_id']
        : 0;

    $customer = $users[$userId] ?? [
        'full_name' => 'Unknown Customer',
        'email' => '-',
        'phone' => '-'
    ];

    $orderRows[] = [

        'id' => (int) $order['order_id'],

        'order_number' =>
            $order['order_number']
            ?: 'MQ' . str_pad(
                (string) $order['order_id'],
                8,
                '0',
                STR_PAD_LEFT
            ),

        'customer' => [

            'full_name' =>
                $customer['full_name'] ?? 'Unknown Customer',

            'email' =>
                $customer['email'] ?? '-',

            'phone' =>
                $customer['phone'] ?? '-'
        ],

        'date' =>
            $order['order_date'] ?? '',

        'total' =>
            (float) ($order['order_total'] ?? 0),

        'payment_status' =>
            $order['payment_status'] ?? '',

        'payment_method' =>
            $order['payment_method'] ?? '',

        'status' =>
            $order['order_status'] ?? 'Pending'
    ];
}

// Load the common header.
include __DIR__ . '/../includes/header.php';

?>

<section class="admin-section">

    <div class="admin-container">

        <div class="page-header">

            <div>

                <span class="small-title">
                    MEDIQUICK PHARMACY
                </span>

                <h1>Order Management</h1>

                <p>
                    View and manage customer orders.
                </p>

            </div>

        </div>

        <div class="admin-card">

            <div class="order-controls">

                <input
                    type="text"
                    id="orderSearch"
                    placeholder="Search order number..."
                >

                <select id="orderStatusFilter">

                    <option value="all">All Status</option>
                    <option value="Pending">Pending</option>
                    <option value="Processing">Processing</option>
                    <option value="Shipped">Shipped</option>
                    <option value="Delivered">Delivered</option>
                    <option value="Cancelled">Cancelled</option>

                </select>

            </div>

            <div class="table-wrapper">

                <table>

                    <thead>

                        <tr>
                            <th>Order</th>
                            <th>Customer</th>
                            <th>Date</th>
                            <th>Total</th>
                            <th>Payment</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>

                    </thead>

                    <tbody id="ordersTable"></tbody>

                </table>

            </div>

            <div id="emptyOrders" class="empty-state">

                <i class="bi bi-bag-x"></i>

                <h3>No orders found</h3>

                <p>
                    Customer orders will appear here.
                </p>

            </div>

        </div>

    </div>

</section>

<!-- Order Details Modal -->
<div class="order-modal" id="orderModal">

    <div class="order-modal-box">

        <div class="order-modal-header">

            <h2>Order Details</h2>

            <button
                type="button"
                id="closeOrderModal"
                class="close-modal"
            >
                &times;
            </button>

        </div>

        <div
            id="orderDetails"
            class="order-details"
        ></div>

    </div>

</div>

<style>

.admin-section {
    background: #f6fbfd;
    min-height: 80vh;
    padding: 55px 20px;
}

.admin-container {
    max-width: 1200px;
    margin: auto;
}

.page-header {
    margin-bottom: 30px;
}

.small-title {
    color: #087f9b;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 2px;
}

.page-header h1 {
    color: #174f68;
    margin: 8px 0;
    font-size: 36px;
}

.page-header p {
    color: #777;
}

.admin-card {
    background: white;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 5px 25px rgba(0,80,110,.08);
}

.order-controls {
    display: flex;
    gap: 15px;
    margin-bottom: 20px;
}

.order-controls input,
.order-controls select {
    padding: 12px 14px;
    border: 1px solid #d8e5e9;
    border-radius: 8px;
    outline: none;
    font-size: 14px;
    background: white;
}

.order-controls input {
    flex: 1;
}

.order-controls select {
    width: 220px;
}

.order-controls input:focus,
.order-controls select:focus {
    border-color: #087f9b;
    box-shadow: 0 0 0 3px rgba(8,127,155,.08);
}

.table-wrapper {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 850px;
}

th {
    background: #f3fafc;
    color: #174f68;
    padding: 15px;
    text-align: left;
    font-size: 13px;
    font-weight: 700;
}

td {
    padding: 14px 15px;
    border-top: 1px solid #edf2f4;
    color: #555;
    font-size: 14px;
}

tbody tr:hover {
    background: #fbfdfe;
}

.order-number {
    color: #087f9b;
    font-weight: 700;
}

.customer-name {
    color: #174f68;
    font-weight: 600;
}

.customer-email {
    display: block;
    color: #999;
    font-size: 12px;
    margin-top: 3px;
}

.status-select {
    padding: 7px 10px;
    border: 1px solid #d8e5e9;
    border-radius: 6px;
    background: white;
    color: #174f68;
    cursor: pointer;
}

.status-select:focus {
    outline: none;
    border-color: #087f9b;
}

.payment-badge {
    display: inline-block;
    padding: 5px 9px;
    border-radius: 20px;
    background: #f0f7f9;
    color: #087f9b;
    font-size: 12px;
}

.view-order {
    border: 0;
    background: #e8f5f8;
    color: #087f9b;
    padding: 8px 11px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
}

.view-order:hover {
    background: #087f9b;
    color: white;
}

.empty-state {
    display: none;
    text-align: center;
    padding: 60px 20px;
    color: #777;
}

.empty-state i {
    font-size: 45px;
    color: #087f9b;
}

.empty-state h3 {
    color: #526c78;
    margin: 15px 0 8px;
}

.empty-state p {
    margin: 0;
}

.order-modal {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(20,50,65,.45);
    z-index: 9999;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.order-modal.show {
    display: flex;
}

.order-modal-box {
    background: white;
    width: 100%;
    max-width: 600px;
    max-height: 85vh;
    overflow-y: auto;
    border-radius: 16px;
    box-shadow: 0 20px 60px rgba(0,0,0,.18);
}

.order-modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 24px;
    border-bottom: 1px solid #edf2f4;
}

.order-modal-header h2 {
    margin: 0;
    color: #174f68;
    font-size: 22px;
}

.close-modal {
    border: 0;
    background: transparent;
    color: #777;
    font-size: 30px;
    cursor: pointer;
    line-height: 1;
}

.close-modal:hover {
    color: #087f9b;
}

.order-details {
    padding: 24px;
}

.detail-section {
    margin-bottom: 22px;
}

.detail-section h4 {
    color: #087f9b;
    margin-bottom: 12px;
    font-size: 14px;
}

.detail-row {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    padding: 8px 0;
    border-bottom: 1px solid #f0f3f4;
}

.detail-label {
    color: #888;
}

.detail-value {
    color: #174f68;
    font-weight: 600;
    text-align: right;
}

.order-total {
    font-size: 20px;
    color: #087f9b;
}

@media(max-width:650px) {

    .admin-section {
        padding: 35px 12px;
    }

    .page-header h1 {
        font-size: 28px;
    }

    .order-controls {
        flex-direction: column;
    }

    .order-controls select {
        width: 100%;
    }

    .admin-card {
        padding: 15px;
    }

}

</style>

<script>

// Load order data from PHP.
const orders = <?php
    echo json_encode(
        $orderRows,
        JSON_HEX_TAG |
        JSON_HEX_APOS |
        JSON_HEX_QUOT |
        JSON_HEX_AMP
    );
?>;

// Get the page elements.
const table = document.getElementById("ordersTable");
const empty = document.getElementById("emptyOrders");
const searchInput = document.getElementById("orderSearch");
const statusFilter = document.getElementById("orderStatusFilter");
const modal = document.getElementById("orderModal");
const orderDetails = document.getElementById("orderDetails");

// Escape special characters before displaying database values.
function escapeHtml(value) {

    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Format the order date.
function formatDate(value) {

    if (!value) {
        return "-";
    }

    const date = new Date(value);

    if (isNaN(date.getTime())) {
        return escapeHtml(value);
    }

    return date.toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    });
}

// Display available payment information.
function getPaymentText(order) {

    if (order.payment_method && order.payment_status) {

        return (
            order.payment_method +
            " - " +
            order.payment_status
        );
    }

    if (order.payment_method) {
        return order.payment_method;
    }

    if (order.payment_status) {
        return order.payment_status;
    }

    return "-";
}

// Generate order status options.
function statusOptions(currentStatus) {

    const statuses = [
        "Pending",
        "Processing",
        "Shipped",
        "Delivered",
        "Cancelled"
    ];

    return statuses.map(function(status) {

        return `
            <option
                value="${escapeHtml(status)}"
                ${currentStatus === status ? "selected" : ""}
            >
                ${escapeHtml(status)}
            </option>
        `;

    }).join("");
}

// Display and filter orders.
function renderOrders() {

    const search = searchInput.value
        .toLowerCase()
        .trim();

    const selectedStatus = statusFilter.value;

    table.innerHTML = "";

    const filtered = orders.filter(function(order) {

        const orderNumber = String(
            order.order_number || ""
        ).toLowerCase();

        const matchesSearch =
            orderNumber.includes(search);

        const matchesStatus =
            selectedStatus === "all" ||
            order.status === selectedStatus;

        return matchesSearch && matchesStatus;
    });

    if (filtered.length === 0) {

        empty.style.display = "block";
        return;
    }

    empty.style.display = "none";

    filtered.forEach(function(order) {

        const row = document.createElement("tr");

        row.innerHTML = `

            <td>
                <span class="order-number">
                    ${escapeHtml(order.order_number)}
                </span>
            </td>

            <td>
                <span class="customer-name">
                    ${escapeHtml(order.customer.full_name)}
                </span>

                <span class="customer-email">
                    ${escapeHtml(order.customer.email)}
                </span>
            </td>

            <td>
                ${formatDate(order.date)}
            </td>

            <td>
                <strong>
                    Rs.
                    ${Number(order.total || 0).toLocaleString(
                        "en-LK",
                        {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        }
                    )}
                </strong>
            </td>

            <td>
                <span class="payment-badge">
                    ${escapeHtml(getPaymentText(order))}
                </span>
            </td>

            <td>
                <select
                    class="status-select"
                    data-id="${order.id}"
                >
                    ${statusOptions(order.status)}
                </select>
            </td>

            <td>
                <button
                    type="button"
                    class="view-order"
                    data-id="${order.id}"
                >
                    <i class="bi bi-eye"></i>
                    View
                </button>
            </td>

        `;

        table.appendChild(row);
    });

    // Handle order status changes.
    document.querySelectorAll(".status-select")
        .forEach(function(select) {

            select.addEventListener("change", function() {

                updateOrderStatus(
                    this.dataset.id,
                    this.value,
                    this
                );

            });
        });

    // Handle View buttons.
    document.querySelectorAll(".view-order")
        .forEach(function(button) {

            button.addEventListener("click", function() {

                const orderId = Number(this.dataset.id);

                const order = orders.find(function(item) {
                    return item.id === orderId;
                });

                if (order) {
                    showOrder(order);
                }

            });
        });
}

// Update order status in the database.
function updateOrderStatus(orderId, newStatus, selectElement) {

    const order = orders.find(function(item) {
        return item.id === Number(orderId);
    });

    const previousStatus = order ? order.status : "Pending";

    const formData = new FormData();

    formData.append("action", "update_status");
    formData.append("order_id", orderId);
    formData.append("status", newStatus);

    // Prevent multiple changes while the request is running.
    selectElement.disabled = true;

    fetch(window.location.href, {
        method: "POST",
        body: formData
    })

    .then(function(response) {

        if (!response.ok) {
            throw new Error("Server response error.");
        }

        return response.json();
    })

    .then(function(data) {

        if (data.success) {

            if (order) {
                order.status = newStatus;
            }

            renderOrders();

            alert("Order status updated successfully.");

        } else {

            selectElement.value = previousStatus;

            alert(
                data.message ||
                "Unable to update order status."
            );
        }

    })

    .catch(function(error) {

        console.error(error);

        selectElement.value = previousStatus;

        alert(
            "A database error occurred while updating the order."
        );

    })

    .finally(function() {

        selectElement.disabled = false;

    });
}

// Show order details inside the modal.
function showOrder(order) {

    orderDetails.innerHTML = `

        <div class="detail-section">

            <h4>Order Information</h4>

            <div class="detail-row">
                <span class="detail-label">Order Number</span>
                <span class="detail-value">
                    ${escapeHtml(order.order_number)}
                </span>
            </div>

            <div class="detail-row">
                <span class="detail-label">Date</span>
                <span class="detail-value">
                    ${formatDate(order.date)}
                </span>
            </div>

            <div class="detail-row">
                <span class="detail-label">Status</span>
                <span class="detail-value">
                    ${escapeHtml(order.status)}
                </span>
            </div>

        </div>

        <div class="detail-section">

            <h4>Customer Information</h4>

            <div class="detail-row">
                <span class="detail-label">Name</span>
                <span class="detail-value">
                    ${escapeHtml(order.customer.full_name)}
                </span>
            </div>

            <div class="detail-row">
                <span class="detail-label">Email</span>
                <span class="detail-value">
                    ${escapeHtml(order.customer.email)}
                </span>
            </div>

            <div class="detail-row">
                <span class="detail-label">Phone</span>
                <span class="detail-value">
                    ${escapeHtml(order.customer.phone)}
                </span>
            </div>

        </div>

        <div class="detail-section">

            <h4>Payment</h4>

            <div class="detail-row">
                <span class="detail-label">Payment</span>
                <span class="detail-value">
                    ${escapeHtml(getPaymentText(order))}
                </span>
            </div>

            <div class="detail-row">
                <span class="detail-label">Order Total</span>
                <span class="detail-value order-total">
                    Rs.
                    ${Number(order.total || 0).toLocaleString(
                        "en-LK",
                        {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        }
                    )}
                </span>
            </div>

        </div>

    `;

    modal.classList.add("show");
}

// Close the order details modal.
document.getElementById("closeOrderModal")
    .addEventListener("click", function() {

        modal.classList.remove("show");

    });

// Close the modal when clicking outside it.
modal.addEventListener("click", function(event) {

    if (event.target === modal) {
        modal.classList.remove("show");
    }

});

// Search orders.
searchInput.addEventListener("input", renderOrders);

// Filter orders by status.
statusFilter.addEventListener("change", renderOrders);

// Display orders when the page loads.
renderOrders();

</script>

<?php

// Load the common website footer.
include __DIR__ . '/../includes/footer.php';

?>
