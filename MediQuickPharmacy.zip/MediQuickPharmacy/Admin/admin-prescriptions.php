<?php
/*
MediQuick Pharmacy - Prescription Management
This page is used by an authorized administrator or staff member.
*/

session_start();

// Prevent a cached management page from appearing after logout.
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

// Confirm that the user is logged in.
if (empty($_SESSION['user_id']) || empty($_SESSION['user_role'])) {
    header('Location: ../login.php');
    exit;
}

// Set the required role for this page.
$requiredRole = 'admin';

if (($_SESSION['user_role'] ?? '') !== $requiredRole) {
    if (($_SESSION['user_role'] ?? '') === 'admin') {
        header('Location: admin-dashboard.php');
    } elseif (($_SESSION['user_role'] ?? '') === 'staff') {
        header('Location: staff-dashboard.php');
    } else {
        header('Location: ../Customer/customer-dashboard.php');
    }
    exit;
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/prescription-helpers.php';

if (!isset($conn) || $conn->connect_error) {
    die('Database connection failed.');
}

$conn->set_charset('utf8mb4');

$message = '';
$messageType = 'success';

// Update the selected prescription status.
if ($_SERVER['REQUEST_METHOD'] === 'POST' &&
    ($_POST['action'] ?? '') === 'update_status') {

    $prescriptionId = (int)($_POST['prescription_id'] ?? 0);
    $newStatus = $_POST['status'] ?? '';
    $allowedStatuses = ['Pending', 'Approved', 'Rejected', 'Completed'];

    if ($prescriptionId <= 0 || !in_array($newStatus, $allowedStatuses, true)) {
        $message = 'Invalid prescription or status selection.';
        $messageType = 'danger';
    } else {
        $update = $conn->prepare(
            'UPDATE prescriptions SET status = ? WHERE id = ?'
        );

        if (!$update) {
            $message = 'Unable to prepare the status update.';
            $messageType = 'danger';
        } else {
            $update->bind_param('si', $newStatus, $prescriptionId);

            if ($update->execute()) {
                $message = 'Prescription status updated successfully.';
            } else {
                $message = 'Unable to update the prescription status.';
                $messageType = 'danger';
            }

            $update->close();
        }
    }
}

// Read and validate the selected status filter.
$statusFilter = $_GET['status'] ?? 'All';
$allowedFilters = ['All', 'Pending', 'Approved', 'Rejected', 'Completed'];

if (!in_array($statusFilter, $allowedFilters, true)) {
    $statusFilter = 'All';
}

// Load prescription records with the matching customer account.
$prescriptions = [];

if ($statusFilter === 'All') {
    $stmt = $conn->prepare(
        'SELECT p.id, p.user_id, p.patient_name, p.phone, p.email,
                p.file_name, p.file_path, p.file_type, p.notes,
                p.status, p.created_at, u.full_name AS customer_name
         FROM prescriptions p
         LEFT JOIN users u ON p.user_id = u.id
         ORDER BY p.created_at DESC'
    );
} else {
    $stmt = $conn->prepare(
        'SELECT p.id, p.user_id, p.patient_name, p.phone, p.email,
                p.file_name, p.file_path, p.file_type, p.notes,
                p.status, p.created_at, u.full_name AS customer_name
         FROM prescriptions p
         LEFT JOIN users u ON p.user_id = u.id
         WHERE p.status = ?
         ORDER BY p.created_at DESC'
    );
}

if (!$stmt) {
    die('Unable to load prescriptions: ' . mqPrescriptionEscape($conn->error));
}

if ($statusFilter !== 'All') {
    $stmt->bind_param('s', $statusFilter);
}

$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $prescriptions[] = $row;
}

$stmt->close();

// Load counts for all four supported statuses.
$counts = ['total' => 0, 'Pending' => 0, 'Approved' => 0, 'Rejected' => 0, 'Completed' => 0];

$countResult = $conn->query(
    "SELECT COUNT(*) AS total,
            SUM(status = 'Pending') AS pending_count,
            SUM(status = 'Approved') AS approved_count,
            SUM(status = 'Rejected') AS rejected_count,
            SUM(status = 'Completed') AS completed_count
     FROM prescriptions"
);

if ($countResult) {
    $countRow = $countResult->fetch_assoc();
    $counts['total'] = (int)($countRow['total'] ?? 0);
    $counts['Pending'] = (int)($countRow['pending_count'] ?? 0);
    $counts['Approved'] = (int)($countRow['approved_count'] ?? 0);
    $counts['Rejected'] = (int)($countRow['rejected_count'] ?? 0);
    $counts['Completed'] = (int)($countRow['completed_count'] ?? 0);
}

$pageTitle = $requiredRole === 'admin' ? 'Admin Prescription Management' : 'Staff Prescription Management';
$displayName = $_SESSION['user_name'] ?? ucfirst($requiredRole);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= mqPrescriptionEscape($pageTitle); ?> | MediQuick Pharmacy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body{background:#f4f7fb;font-family:"Segoe UI",Arial,sans-serif;color:#263238}
        .page-wrap{max-width:1250px;margin:35px auto;padding:0 18px}
        .top-card{background:linear-gradient(135deg,#087f8c,#0999a3);color:#fff;border-radius:18px;padding:25px;margin-bottom:22px}
        .stat-card,.prescription-card{background:#fff;border:1px solid #e9eef3;border-radius:15px;box-shadow:0 5px 18px rgba(25,50,75,.04)}
        .stat-card{padding:18px;height:100%}.stat-card strong{font-size:25px;display:block}
        .prescription-card{padding:22px;margin-bottom:16px}
        .status-pill{padding:6px 12px;border-radius:30px;font-size:12px;font-weight:700}
        .pending{background:#fff3d8;color:#9a6900}.approved{background:#e2f6e9;color:#18733c}
        .rejected{background:#ffe6e9;color:#b42338}.completed{background:#e6efff;color:#315fa8}
        .detail-label{font-size:11px;color:#8492a3;display:block;text-transform:uppercase}
        .detail-value{font-weight:600;overflow-wrap:anywhere}
        .filter-link{display:inline-block;text-decoration:none;padding:8px 13px;border:1px solid #dce5ec;border-radius:9px;color:#536579;margin:3px}
        .filter-link.active,.filter-link:hover{background:#087f8c;color:#fff;border-color:#087f8c}
        @media(max-width:600px){.page-wrap{margin:20px auto}.prescription-card{padding:15px}}
    </style>
</head>
<body>
<div class="page-wrap">
    <div class="top-card d-flex flex-wrap justify-content-between align-items-center gap-3">
        <div>
            <div class="small text-white-50 fw-semibold">MEDIQUICK PHARMACY</div>
            <h1 class="h3 fw-bold mb-1">Customer Prescriptions</h1>
            <p class="mb-0">Review uploaded prescriptions and update their status.</p>
        </div>
        <div class="text-end">
            <strong><?= mqPrescriptionEscape($displayName); ?></strong>
            <div class="small text-white-50"><?= ucfirst($requiredRole); ?></div>
        </div>
    </div>

    <?php if ($message !== ''): ?>
        <div class="alert alert-<?= mqPrescriptionEscape($messageType); ?>"><?= mqPrescriptionEscape($message); ?></div>
    <?php endif; ?>

    <div class="row g-3 mb-4">
        <div class="col-6 col-lg">
            <div class="stat-card"><span class="text-secondary small">Total</span><strong><?= $counts['total']; ?></strong></div>
        </div>
        <div class="col-6 col-lg">
            <div class="stat-card"><span class="text-secondary small">Pending</span><strong><?= $counts['Pending']; ?></strong></div>
        </div>
        <div class="col-6 col-lg">
            <div class="stat-card"><span class="text-secondary small">Approved</span><strong><?= $counts['Approved']; ?></strong></div>
        </div>
        <div class="col-6 col-lg">
            <div class="stat-card"><span class="text-secondary small">Rejected</span><strong><?= $counts['Rejected']; ?></strong></div>
        </div>
        <div class="col-6 col-lg">
            <div class="stat-card"><span class="text-secondary small">Completed</span><strong><?= $counts['Completed']; ?></strong></div>
        </div>
    </div>

    <div class="mb-3">
        <?php foreach ($allowedFilters as $filter): ?>
            <a class="filter-link <?= $statusFilter === $filter ? 'active' : ''; ?>"
               href="?status=<?= urlencode($filter); ?>"><?= mqPrescriptionEscape($filter); ?></a>
        <?php endforeach; ?>
    </div>

    <?php if (!$prescriptions): ?>
        <div class="alert alert-info">No prescriptions found for this filter.</div>
    <?php else: ?>
        <?php foreach ($prescriptions as $prescription): ?>
            <?php
            $fileUrl = mqPrescriptionFileUrl(
                $prescription['file_path'] ?? '',
                $prescription['file_name'] ?? ''
            );
            $status = $prescription['status'] ?? 'Pending';
            ?>
            <article class="prescription-card">
                <div class="d-flex flex-wrap justify-content-between align-items-start gap-2 mb-3">
                    <div>
                        <h2 class="h5 fw-bold mb-1">Prescription #<?= (int)$prescription['id']; ?></h2>
                        <small class="text-secondary"><?= mqPrescriptionEscape($prescription['created_at']); ?></small>
                    </div>
                    <span class="status-pill <?= mqPrescriptionStatusClass($status); ?>"><?= mqPrescriptionEscape($status); ?></span>
                </div>

                <div class="row g-3">
                    <div class="col-md-4">
                        <span class="detail-label">Customer Account</span>
                        <span class="detail-value"><?= mqPrescriptionEscape($prescription['customer_name'] ?? 'Unknown Customer'); ?></span>
                    </div>
                    <div class="col-md-4">
                        <span class="detail-label">Patient Name</span>
                        <span class="detail-value"><?= mqPrescriptionEscape($prescription['patient_name']); ?></span>
                    </div>
                    <div class="col-md-4">
                        <span class="detail-label">Phone</span>
                        <span class="detail-value"><?= mqPrescriptionEscape($prescription['phone']); ?></span>
                    </div>
                    <div class="col-md-6">
                        <span class="detail-label">Email</span>
                        <span class="detail-value"><?= mqPrescriptionEscape($prescription['email']); ?></span>
                    </div>
                    <div class="col-md-6">
                        <span class="detail-label">Original File Name</span>
                        <span class="detail-value"><?= mqPrescriptionEscape($prescription['file_name']); ?></span>
                    </div>
                </div>

                <?php if (!empty($prescription['notes'])): ?>
                    <div class="mt-3">
                        <span class="detail-label">Additional Notes</span>
                        <p class="mb-0"><?= nl2br(mqPrescriptionEscape($prescription['notes'])); ?></p>
                    </div>
                <?php endif; ?>

                <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mt-4 pt-3 border-top">
                    <div>
                        <?php if ($fileUrl !== null): ?>
                            <a class="btn btn-outline-primary btn-sm" href="<?= mqPrescriptionEscape($fileUrl); ?>"
                               target="_blank" rel="noopener">
                                <i class="bi bi-eye me-1"></i> View Prescription
                            </a>
                            <a class="btn btn-outline-secondary btn-sm" href="<?= mqPrescriptionEscape($fileUrl); ?>" download>
                                <i class="bi bi-download me-1"></i> Download
                            </a>
                        <?php else: ?>
                            <span class="text-danger small">
                                <i class="bi bi-exclamation-triangle me-1"></i>
                                File not found in uploads/prescriptions.
                            </span>
                        <?php endif; ?>
                    </div>

                    <form method="POST" class="d-flex flex-wrap gap-2">
                        <input type="hidden" name="action" value="update_status">
                        <input type="hidden" name="prescription_id" value="<?= (int)$prescription['id']; ?>">
                        <select name="status" class="form-select form-select-sm" required>
                            <?php foreach (['Pending', 'Approved', 'Rejected', 'Completed'] as $option): ?>
                                <option value="<?= mqPrescriptionEscape($option); ?>"
                                    <?= $status === $option ? 'selected' : ''; ?>>
                                    <?= mqPrescriptionEscape($option); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn btn-primary btn-sm">Update Status</button>
                    </form>
                </div>
            </article>
        <?php endforeach; ?>
    <?php endif; ?>

    <div class="text-center mt-4">
        <a href="<?= $requiredRole === 'admin' ? 'admin-dashboard.php' : 'staff-dashboard.php'; ?>"
           class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Back to Dashboard
        </a>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
