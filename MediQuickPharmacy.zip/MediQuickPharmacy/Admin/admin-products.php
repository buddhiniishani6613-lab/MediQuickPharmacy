
<?php

session_start();

require_once __DIR__ . '/../config/database.php';

/*
 * Prevent browser caching after logout.
 */
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

/*
 * Check admin login.
 */
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$userId = (int) $_SESSION['user_id'];

/*
 * Retrieve admin details.
 */
$userStmt = $conn->prepare("
    SELECT id, full_name, email, role
    FROM users
    WHERE id = ?
    LIMIT 1
");

if (!$userStmt) {
    die("Database Error: " . $conn->error);
}

$userStmt->bind_param("i", $userId);
$userStmt->execute();

$userResult = $userStmt->get_result();

if ($userResult->num_rows === 0) {
    session_unset();
    session_destroy();

    header("Location: ../login.php");
    exit();
}

$user = $userResult->fetch_assoc();

$userName = $user['full_name'];
$userEmail = $user['email'];
$userRole = $user['role'];

/*
 * Only administrators can access this page.
 */
if ($userRole !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$successMessage = "";
$errorMessage = "";

/*
 * Automatically update product availability.
 * Inactive products are not affected.
 */
$syncSql = "
    UPDATE products
    SET status = CASE
        WHEN stock_quantity <= 0 THEN 'Out of Stock'
        ELSE 'Available'
    END
    WHERE status IN ('Available', 'Out of Stock')
";

if (!$conn->query($syncSql)) {
    $errorMessage = "Unable to synchronize product stock status.";
}

/*
 * Process stock update requests.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';

    if ($action === 'update_stock') {

        $productId = isset($_POST['product_id'])
            ? (int) $_POST['product_id']
            : 0;

        $newStock = isset($_POST['stock_quantity'])
            ? filter_var($_POST['stock_quantity'], FILTER_VALIDATE_INT)
            : false;

        if ($productId <= 0) {

            $errorMessage = "Invalid product.";

        } elseif (
            $newStock === false ||
            $newStock < 0 ||
            $newStock > 999999
        ) {

            $errorMessage = "Please enter a valid stock quantity.";

        } else {

            /*
             * Check whether the product exists.
             */
            $checkStmt = $conn->prepare("
                SELECT id, name, status
                FROM products
                WHERE id = ?
                LIMIT 1
            ");

            if (!$checkStmt) {

                $errorMessage = "Database error while checking product.";

            } else {

                $checkStmt->bind_param("i", $productId);
                $checkStmt->execute();

                $checkResult = $checkStmt->get_result();

                if ($checkResult->num_rows === 0) {

                    $errorMessage = "Product not found.";

                } else {

                    $productData = $checkResult->fetch_assoc();

                    /*
                     * Keep inactive products inactive.
                     */
                    if ($productData['status'] === 'Inactive') {

                        $updateStmt = $conn->prepare("
                            UPDATE products
                            SET stock_quantity = ?
                            WHERE id = ?
                        ");

                        if ($updateStmt) {
                            $updateStmt->bind_param(
                                "ii",
                                $newStock,
                                $productId
                            );
                        }

                    } else {

                        $newStatus = ($newStock <= 0)
                            ? 'Out of Stock'
                            : 'Available';

                        $updateStmt = $conn->prepare("
                            UPDATE products
                            SET stock_quantity = ?, status = ?
                            WHERE id = ?
                        ");

                        if ($updateStmt) {
                            $updateStmt->bind_param(
                                "isi",
                                $newStock,
                                $newStatus,
                                $productId
                            );
                        }
                    }

                    if (isset($updateStmt) && $updateStmt) {

                        if ($updateStmt->execute()) {

                            $successMessage =
                                $productData['name'] .
                                " stock updated successfully.";

                        } else {

                            $errorMessage =
                                "Failed to update product stock.";

                        }

                        $updateStmt->close();

                    } else {

                        $errorMessage =
                            "Unable to prepare stock update.";

                    }
                }

                $checkStmt->close();
            }
        }
    }
}

/*
 * Read search and filter values.
 */
$search = trim($_GET['search'] ?? '');

$categoryFilter = $_GET['category'] ?? 'All';

$statusFilter = $_GET['status'] ?? 'All';

/*
 * Available product categories.
 */
$categories = [
    'Prescription',
    'OTC Products',
    'Wellness Products',
    'Personal Care',
    'Medical Devices',
    'Baby Care'
];

if (
    $categoryFilter !== 'All' &&
    !in_array($categoryFilter, $categories, true)
) {
    $categoryFilter = 'All';
}

$validStatuses = [
    'Available',
    'Out of Stock',
    'Inactive'
];

if (
    $statusFilter !== 'All' &&
    !in_array($statusFilter, $validStatuses, true)
) {
    $statusFilter = 'All';
}

/*
 * Calculate product statistics.
 */
$statsSql = "
    SELECT
        COUNT(*) AS total_products,

        SUM(
            CASE WHEN status = 'Available'
            THEN 1 ELSE 0 END
        ) AS available_products,

        SUM(
            CASE WHEN status = 'Out of Stock'
            THEN 1 ELSE 0 END
        ) AS out_of_stock,

        SUM(
            CASE
                WHEN stock_quantity BETWEEN 1 AND 5
                AND status = 'Available'
                THEN 1 ELSE 0
            END
        ) AS low_stock

    FROM products
";

$statsResult = $conn->query($statsSql);

$stats = [
    'total_products' => 0,
    'available_products' => 0,
    'out_of_stock' => 0,
    'low_stock' => 0
];

if ($statsResult) {

    $statsData = $statsResult->fetch_assoc();

    foreach ($stats as $key => $value) {
        $stats[$key] = (int) ($statsData[$key] ?? 0);
    }
}

/*
 * Retrieve products according to the selected filters.
 */
$searchLike = '%' . $search . '%';

$productSql = "
    SELECT
        id,
        name,
        description,
        category,
        price,
        stock_quantity,
        image,
        requires_prescription,
        status,
        created_at

    FROM products

    WHERE
        (
            ? = ''
            OR name LIKE ?
            OR description LIKE ?
        )

        AND
        (
            ? = 'All'
            OR category = ?
        )

        AND
        (
            ? = 'All'
            OR status = ?
        )

    ORDER BY
        CASE
            WHEN stock_quantity <= 0 THEN 0
            WHEN stock_quantity BETWEEN 1 AND 5 THEN 1
            ELSE 2
        END,
        name ASC
";

$productStmt = $conn->prepare($productSql);

if (!$productStmt) {
    die("Product Query Error: " . $conn->error);
}

$productStmt->bind_param(
    "sssssss",
    $search,
    $searchLike,
    $searchLike,
    $categoryFilter,
    $categoryFilter,
    $statusFilter,
    $statusFilter
);

$productStmt->execute();

$productResult = $productStmt->get_result();

/*
 * Map database category names to image folder names.
 */
function getCategoryFolder($categoryName)
{
    $folders = [
        'Prescription' => 'Prescription Medicines',
        'Prescription Medicines' => 'Prescription Medicines',
        'OTC Products' => 'OTC Products',
        'Wellness Products' => 'Wellness Products',
        'Personal Care' => 'Personal Care',
        'Medical Devices' => 'Medical Devices',
        'Baby Care' => 'Baby Care'
    ];

    return $folders[$categoryName] ?? $categoryName;
}

/*
 * Convert a real project file path into a browser URL.
 */
function productImageUrl($absolutePath)
{
    $root = realpath(__DIR__ . '/..');
    $realFile = realpath($absolutePath);

    if (!$root || !$realFile) {
        return '';
    }

    /*
     * Only allow images inside the project folder.
     */
    $rootPrefix = rtrim($root, DIRECTORY_SEPARATOR)
        . DIRECTORY_SEPARATOR;

    if (strpos($realFile, $rootPrefix) !== 0) {
        return '';
    }

    $relativePath = substr($realFile, strlen($rootPrefix));

    $parts = explode(
        DIRECTORY_SEPARATOR,
        $relativePath
    );

    return '../' . implode(
        '/',
        array_map('rawurlencode', $parts)
    );
}

/*
 * Locate product images using the actual file system.
 * This supports different image extensions and letter cases.
 */
function getProductImage($categoryName, $databaseImage, $productName)
{
    $root = realpath(__DIR__ . '/..');

    if (!$root) {
        return '';
    }

    $folder = getCategoryFolder($categoryName);

    $imageFolders = [
        $root . '/assets/images/products/' . $folder,
        __DIR__ . '/assets/images/products/' . $folder,
        $root . '/images/products/' . $folder,
        $root . '/images/' . $folder
    ];

    /*
     * First check the image path saved in the database.
     */
    if (!empty($databaseImage)) {

        $cleanPath = str_replace('\\', '/', trim($databaseImage));

        $cleanPath = preg_replace(
            '#^(\.\./|/)+#',
            '',
            $cleanPath
        );

        $storedCandidates = [
            $root . '/' . $cleanPath,
            __DIR__ . '/' . $cleanPath
        ];

        foreach ($storedCandidates as $candidate) {

            if (is_file($candidate)) {

                $url = productImageUrl($candidate);

                if ($url !== '') {
                    return $url;
                }
            }
        }

        /*
         * Also search for the stored filename
         * inside the product category folders.
         */
        $storedFileName = basename($cleanPath);

        foreach ($imageFolders as $imageFolder) {

            if (!is_dir($imageFolder)) {
                continue;
            }

            $files = scandir($imageFolder);

            if ($files === false) {
                continue;
            }

            foreach ($files as $file) {

                if (
                    strcasecmp($file, $storedFileName) === 0 &&
                    is_file($imageFolder . '/' . $file)
                ) {
                    return productImageUrl(
                        $imageFolder . '/' . $file
                    );
                }
            }
        }
    }

    /*
     * Try the product name and common image extensions.
     */
    $cleanName = preg_replace(
        '/\s*\d+(?:\.\d+)?\s*(?:mg|mcg|g|ml|l|%)\b/i',
        '',
        $productName
    );

    $possibleNames = array_unique([
        trim($productName),
        trim($cleanName)
    ]);

    $extensions = [
        'jpg',
        'jpeg',
        'png',
        'webp'
    ];

    foreach ($imageFolders as $imageFolder) {

        if (!is_dir($imageFolder)) {
            continue;
        }

        $files = scandir($imageFolder);

        if ($files === false) {
            continue;
        }

        foreach ($possibleNames as $possibleName) {

            foreach ($extensions as $extension) {

                $expectedName =
                    $possibleName . '.' . $extension;

                foreach ($files as $file) {

                    if (
                        strcasecmp($file, $expectedName) === 0 &&
                        is_file($imageFolder . '/' . $file)
                    ) {
                        return productImageUrl(
                            $imageFolder . '/' . $file
                        );
                    }
                }
            }
        }
    }

    /*
     * Use an existing pharmacy logo as a fallback.
     */
    $logoCandidates = [
        $root . '/images/Logo.jpg',
        $root . '/images/Logo.png',
        $root . '/assets/images/Logo.jpg',
        $root . '/assets/images/Logo.png',
        __DIR__ . '/assets/images/Logo.jpg',
        __DIR__ . '/assets/images/Logo.png'
    ];

    foreach ($logoCandidates as $logo) {

        if (is_file($logo)) {

            return productImageUrl($logo);
        }
    }

    return '';
}

/*
 * Escape values before displaying them in HTML.
 */
function e($value)
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>MediQuick Pharmacy - Admin Products</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    >

    <style>

    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        background: #f4f7fb;
        color: #263238;
    }

    .sidebar {
        position: fixed;
        top: 0;
        left: 0;
        width: 255px;
        height: 100vh;
        background: linear-gradient(180deg, #087f8c, #075b66);
        color: white;
        padding: 25px 15px;
        z-index: 1000;
        overflow-y: auto;
    }

    .brand {
        text-align: center;
        margin-bottom: 30px;
    }

    .brand-icon {
        width: 62px;
        height: 62px;
        background: white;
        color: #087f8c;
        border-radius: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 31px;
        margin: 0 auto 10px;
    }

    .brand h3 {
        font-size: 21px;
        font-weight: 700;
        margin: 0;
    }

    .brand p {
        font-size: 12px;
        opacity: .8;
        margin: 4px 0 0;
    }

    .menu-title {
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: 1px;
        opacity: .65;
        margin: 20px 12px 8px;
    }

    .sidebar a {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 11px 14px;
        color: rgba(255,255,255,.82);
        text-decoration: none;
        border-radius: 11px;
        margin-bottom: 5px;
        font-size: 13px;
        transition: .2s;
    }

    .sidebar a i {
        font-size: 17px;
        width: 22px;
    }

    .sidebar a:hover {
        background: rgba(255,255,255,.12);
        color: white;
    }

    .sidebar a.active {
        background: white;
        color: #087f8c;
        font-weight: 600;
    }

    .main {
        margin-left: 255px;
        min-height: 100vh;
    }

    .topbar {
        height: 75px;
        background: white;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 30px;
        border-bottom: 1px solid #e8edf2;
    }

    .topbar-title h5 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
    }

    .topbar-title p {
        margin: 3px 0 0;
        font-size: 12px;
        color: #78909c;
    }

    .profile-area {
        display: flex;
        align-items: center;
        gap: 11px;
    }

    .avatar {
        width: 42px;
        height: 42px;
        border-radius: 50%;
        background: linear-gradient(135deg,#087f8c,#21a6b3);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
    }

    .profile-text strong {
        display: block;
        font-size: 13px;
    }

    .profile-text span {
        display: block;
        font-size: 11px;
        color: #78909c;
    }

    .content {
        padding: 30px;
    }

    .hero {
        background: linear-gradient(135deg,#087f8c,#0b6e79);
        border-radius: 18px;
        padding: 28px 30px;
        color: white;
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 25px;
        box-shadow: 0 10px 25px rgba(8,127,140,.15);
    }

    .hero h2 {
        margin: 0 0 7px;
        font-size: 25px;
        font-weight: 700;
    }

    .hero p {
        margin: 0;
        max-width: 650px;
        font-size: 13px;
        opacity: .9;
    }

    .hero-icon {
        width: 75px;
        height: 75px;
        border-radius: 20px;
        background: rgba(255,255,255,.15);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 37px;
    }

    .custom-alert {
        border: none;
        border-radius: 12px;
        font-size: 13px;
        margin-top: 20px;
    }

    .stat-card {
        background: white;
        border-radius: 16px;
        padding: 20px;
        display: flex;
        align-items: center;
        gap: 15px;
        height: 100%;
        border: 1px solid #edf1f5;
        box-shadow: 0 5px 18px rgba(0,0,0,.04);
    }

    .stat-icon {
        width: 50px;
        height: 50px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 23px;
    }

    .icon-total { background:#e5f6f8; color:#087f8c; }
    .icon-available { background:#e8f7ed; color:#218739; }
    .icon-out { background:#fdeaea; color:#d13c3c; }
    .icon-low { background:#fff4df; color:#d78a00; }

    .stat-info span {
        display: block;
        color: #78909c;
        font-size: 12px;
        margin-bottom: 3px;
    }

    .stat-info strong {
        display: block;
        font-size: 23px;
        font-weight: 700;
    }

    .filter-card {
        background: white;
        border-radius: 16px;
        padding: 22px;
        margin-top: 25px;
        border: 1px solid #edf1f5;
        box-shadow: 0 5px 18px rgba(0,0,0,.04);
    }

    .filter-title {
        display: flex;
        align-items: center;
        gap: 9px;
        font-weight: 700;
        font-size: 15px;
        margin-bottom: 18px;
    }

    .filter-title i {
        color: #087f8c;
        font-size: 18px;
    }

    .form-label {
        font-size: 12px;
        font-weight: 600;
        color: #546e7a;
        margin-bottom: 7px;
    }

    .form-control, .form-select {
        border: 1px solid #dfe7ed;
        border-radius: 9px;
        min-height: 43px;
        font-size: 13px;
    }

    .form-control:focus, .form-select:focus {
        border-color: #087f8c;
        box-shadow: 0 0 0 3px rgba(8,127,140,.10);
    }

    .btn-search {
        background: #087f8c;
        border-color: #087f8c;
        color: white;
        border-radius: 9px;
        min-height: 43px;
        width: 100%;
    }

    .btn-search:hover {
        background: #075f69;
        color: white;
    }

    .btn-reset {
        background: #f1f5f7;
        color: #546e7a;
        border: none;
        border-radius: 9px;
        min-height: 43px;
        width: 100%;
    }

    .products-header {
        margin-top: 28px;
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .products-header h5 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
    }

    .products-header span {
        font-size: 12px;
        color: #78909c;
    }

    .table-card {
        background: white;
        border-radius: 16px;
        overflow: hidden;
        border: 1px solid #edf1f5;
        box-shadow: 0 5px 18px rgba(0,0,0,.04);
    }

    .product-table {
        margin: 0;
        min-width: 1050px;
    }

    .product-table thead {
        background: #f8fafb;
    }

    .product-table thead th {
        border-bottom: 1px solid #e8eef2;
        color: #607d8b;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: .5px;
        padding: 16px 15px;
        white-space: nowrap;
    }

    .product-table tbody td {
        padding: 15px;
        vertical-align: middle;
        border-bottom: 1px solid #f0f3f5;
        font-size: 13px;
    }

    .product-table tbody tr:last-child td {
        border-bottom: none;
    }

    .product-info {
        display: flex;
        align-items: center;
        gap: 12px;
        min-width: 260px;
    }

    .product-image {
        width: 65px;
        height: 65px;
        border-radius: 11px;
        object-fit: contain;
        padding: 5px;
        background: #f5fafc;
        border: 1px solid #e7edf0;
        display: block;
    }

    .product-name {
        font-weight: 700;
        color: #263238;
        margin-bottom: 4px;
    }

    .product-description {
        color: #90a4ae;
        font-size: 11px;
        max-width: 240px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .category-badge {
        display: inline-block;
        background: #e9f6f7;
        color: #087f8c;
        padding: 6px 10px;
        border-radius: 7px;
        font-size: 11px;
        font-weight: 600;
        white-space: nowrap;
    }

    .price {
        font-weight: 700;
        white-space: nowrap;
    }

    .stock-control {
        display: flex;
        align-items: center;
        gap: 5px;
        white-space: nowrap;
    }

    .stock-btn {
        width: 31px;
        height: 31px;
        border: 1px solid #dce5e9;
        background: #f8fafb;
        color: #546e7a;
        border-radius: 7px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
    }

    .stock-btn:hover {
        background: #087f8c;
        border-color: #087f8c;
        color: white;
    }

    .stock-btn:disabled {
        opacity: .5;
        cursor: not-allowed;
    }

    .stock-input {
        width: 58px;
        height: 31px;
        border: 1px solid #dce5e9;
        border-radius: 7px;
        text-align: center;
        font-size: 12px;
        font-weight: 700;
    }

    .update-btn {
        margin-left: 5px;
        height: 31px;
        padding: 0 10px;
        border: none;
        border-radius: 7px;
        background: #087f8c;
        color: white;
        font-size: 11px;
        font-weight: 600;
    }

    .update-btn:hover {
        background: #075f69;
    }

    .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 6px 10px;
        border-radius: 20px;
        font-size: 10px;
        font-weight: 700;
        white-space: nowrap;
    }

    .status-available { background:#e7f7ec; color:#20833a; }
    .status-out { background:#fdeaea; color:#cf3939; }
    .status-inactive { background:#eef1f3; color:#607d8b; }

    .low-stock-label {
        display: inline-block;
        margin-top: 5px;
        padding: 3px 7px;
        border-radius: 5px;
        background: #fff2d9;
        color: #b87800;
        font-size: 9px;
        font-weight: 700;
    }

    .prescription-label {
        font-size: 10px;
        color: #7b1fa2;
        background: #f5eafb;
        padding: 5px 8px;
        border-radius: 6px;
        font-weight: 600;
        white-space: nowrap;
    }

    .normal-label {
        font-size: 10px;
        color: #607d8b;
        background: #f0f4f6;
        padding: 5px 8px;
        border-radius: 6px;
        font-weight: 600;
        white-space: nowrap;
    }

    .empty-state {
        padding: 65px 25px;
        text-align: center;
    }

    .empty-icon {
        width: 70px;
        height: 70px;
        margin: 0 auto 15px;
        border-radius: 20px;
        background: #e9f6f7;
        color: #087f8c;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 31px;
    }

    .empty-state h5 {
        font-size: 17px;
        margin-bottom: 6px;
    }

    .empty-state p {
        font-size: 12px;
        color: #90a4ae;
        margin: 0;
    }

    .page-footer {
        text-align: center;
        color: #90a4ae;
        font-size: 11px;
        padding: 25px 0 10px;
    }

    @media (max-width: 1100px) {
        .sidebar {
            width: 75px;
            padding: 20px 10px;
        }

        .main {
            margin-left: 75px;
        }

        .brand h3, .brand p, .menu-title,
        .sidebar a span {
            display: none;
        }

        .brand-icon {
            width: 50px;
            height: 50px;
        }

        .sidebar a {
            justify-content: center;
            padding: 12px;
        }

        .sidebar a i {
            width: auto;
        }
    }

    @media (max-width: 768px) {
        .topbar {
            padding: 0 18px;
        }

        .topbar-title p, .profile-text {
            display: none;
        }

        .content {
            padding: 18px;
        }

        .hero {
            padding: 23px;
        }

        .hero h2 {
            font-size: 21px;
        }

        .hero-icon {
            width: 55px;
            height: 55px;
            font-size: 27px;
        }

        .products-header {
            display: block;
        }
    }

    @media (max-width: 500px) {
        .sidebar {
            width: 65px;
        }

        .main {
            margin-left: 65px;
        }

        .content {
            padding: 13px;
        }

        .hero-icon {
            display: none;
        }

        .filter-card {
            padding: 16px;
        }
    }

    </style>

</head>

<body>

<!-- Admin Sidebar -->
<div class="sidebar">

    <div class="brand">

        <div class="brand-icon">
            <i class="bi bi-heart-pulse-fill"></i>
        </div>

        <h3>MediQuick</h3>
        <p>Admin Management</p>

    </div>

    <div class="menu-title">Main Menu</div>

    <a href="admin-dashboard.php">
        <i class="bi bi-grid-1x2-fill"></i>
        <span>Dashboard</span>
    </a>

    <a href="admin-products.php" class="active">
        <i class="bi bi-box-seam-fill"></i>
        <span>Products</span>
    </a>

    <a href="admin-categories.php">
        <i class="bi bi-tags-fill"></i>
        <span>Categories</span>
    </a> 
    
    <a href="admin-orders.php">
        <i class="bi bi-bag-check-fill"></i>
        <span>Orders</span>
    </a>

    <a href="admin-prescriptions.php">
        <i class="bi bi-file-earmark-medical-fill"></i>
        <span>Prescriptions</span>
    </a>

    <a href="admin-customers.php">
        <i class="bi bi-people-fill"></i>
        <span>Customers</span>
    </a>

    <a href="admin-inquiries.php">
        <i class="bi bi-chat-left-text-fill"></i>
        <span>Inquiries</span>
    </a>

    <a href="admin-staff.php">
        <i class="bi bi-person-badge-fill"></i>
        <span>Staff</span>
    </a>

    <a href="admin-reports.php">
        <i class="bi bi-bar-chart-fill"></i>
        <span>Reports</span>
    </a>

    <a href="admin-settings.php">
        <i class="bi bi-gear-fill"></i>
        <span>Settings</span>
    </a>

    <div class="menu-title">Account</div>

    <a href="../profile.php">
        <i class="bi bi-person-circle"></i>
        <span>My Profile</span>
    </a>

    <a href="../contact.php">
        <i class="bi bi-headset"></i>
        <span>Contact</span>
    </a>

    <a href="../logout.php">
        <i class="bi bi-box-arrow-right"></i>
        <span>Logout</span>
    </a>

</div>

<!-- Main Content -->
<div class="main">

    <div class="topbar">

        <div class="topbar-title">

            <h5>Product Management</h5>

            <p>
                Manage pharmacy products and stock levels
            </p>

        </div>

        <div class="profile-area">

            <div class="avatar">
                <?php echo e(strtoupper(substr($userName, 0, 1))); ?>
            </div>

            <div class="profile-text">

                <strong><?php echo e($userName); ?></strong>

                <span>Administrator</span>

            </div>

        </div>

    </div>

    <div class="content">

        <!-- Page Introduction -->
        <div class="hero">

            <div>

                <h2>Product Management</h2>

                <p>
                    View all pharmacy products, monitor stock
                    levels and update product quantities.
                    Product availability is automatically updated
                    according to stock.
                </p>

            </div>

            <div class="hero-icon">
                <i class="bi bi-box-seam"></i>
            </div>

        </div>

        <!-- Success Message -->
        <?php if ($successMessage !== ""): ?>

            <div class="alert alert-success custom-alert alert-dismissible fade show">

                <i class="bi bi-check-circle-fill me-2"></i>

                <?php echo e($successMessage); ?>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                ></button>

            </div>

        <?php endif; ?>

        <!-- Error Message -->
        <?php if ($errorMessage !== ""): ?>

            <div class="alert alert-danger custom-alert alert-dismissible fade show">

                <i class="bi bi-exclamation-circle-fill me-2"></i>

                <?php echo e($errorMessage); ?>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                ></button>

            </div>

        <?php endif; ?>

        <!-- Product Statistics -->
        <div class="row g-3 mt-1">

            <div class="col-xl-3 col-md-6">

                <div class="stat-card">

                    <div class="stat-icon icon-total">
                        <i class="bi bi-box-seam-fill"></i>
                    </div>

                    <div class="stat-info">

                        <span>Total Products</span>

                        <strong>
                            <?php echo $stats['total_products']; ?>
                        </strong>

                    </div>

                </div>

            </div>

            <div class="col-xl-3 col-md-6">

                <div class="stat-card">

                    <div class="stat-icon icon-available">
                        <i class="bi bi-check-circle-fill"></i>
                    </div>

                    <div class="stat-info">

                        <span>Available</span>

                        <strong>
                            <?php echo $stats['available_products']; ?>
                        </strong>

                    </div>

                </div>

            </div>

            <div class="col-xl-3 col-md-6">

                <div class="stat-card">

                    <div class="stat-icon icon-out">
                        <i class="bi bi-x-circle-fill"></i>
                    </div>

                    <div class="stat-info">

                        <span>Out of Stock</span>

                        <strong>
                            <?php echo $stats['out_of_stock']; ?>
                        </strong>

                    </div>

                </div>

            </div>

            <div class="col-xl-3 col-md-6">

                <div class="stat-card">

                    <div class="stat-icon icon-low">
                        <i class="bi bi-exclamation-triangle-fill"></i>
                    </div>

                    <div class="stat-info">

                        <span>Low Stock</span>

                        <strong>
                            <?php echo $stats['low_stock']; ?>
                        </strong>

                    </div>

                </div>

            </div>

        </div>

        <!-- Search and Filter -->
        <div class="filter-card">

            <div class="filter-title">

                <i class="bi bi-funnel-fill"></i>

                Search & Filter Products

            </div>

            <form method="GET" action="admin-products.php">

                <div class="row g-3">

                    <div class="col-lg-5 col-md-12">

                        <label class="form-label">
                            Search Product
                        </label>

                        <input
                            type="text"
                            name="search"
                            class="form-control"
                            placeholder="Search by product name or description..."
                            value="<?php echo e($search); ?>"
                        >

                    </div>

                    <div class="col-lg-3 col-md-6">

                        <label class="form-label">
                            Category
                        </label>

                        <select name="category" class="form-select">

                            <option value="All">All Categories</option>

                            <?php foreach ($categories as $category): ?>

                                <option
                                    value="<?php echo e($category); ?>"
                                    <?php echo $categoryFilter === $category ? 'selected' : ''; ?>
                                >
                                    <?php echo e($category); ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>

                    <div class="col-lg-2 col-md-6">

                        <label class="form-label">
                            Status
                        </label>

                        <select name="status" class="form-select">

                            <option value="All">All Status</option>

                            <option
                                value="Available"
                                <?php echo $statusFilter === 'Available' ? 'selected' : ''; ?>
                            >
                                Available
                            </option>

                            <option
                                value="Out of Stock"
                                <?php echo $statusFilter === 'Out of Stock' ? 'selected' : ''; ?>
                            >
                                Out of Stock
                            </option>

                            <option
                                value="Inactive"
                                <?php echo $statusFilter === 'Inactive' ? 'selected' : ''; ?>
                            >
                                Inactive
                            </option>

                        </select>

                    </div>

                    <div class="col-lg-1 col-md-6">

                        <label class="form-label">&nbsp;</label>

                        <button
                            type="submit"
                            class="btn btn-search"
                            title="Search"
                        >
                            <i class="bi bi-search"></i>
                        </button>

                    </div>

                    <div class="col-lg-1 col-md-6">

                        <label class="form-label">&nbsp;</label>

                        <a
                            href="admin-products.php"
                            class="btn btn-reset d-flex align-items-center justify-content-center"
                            title="Reset Filters"
                        >
                            <i class="bi bi-arrow-clockwise"></i>
                        </a>

                    </div>

                </div>

            </form>

        </div>

        <!-- Products Table Heading -->
        <div class="products-header">

            <div>

                <h5>Products</h5>

                <span>
                    Showing
                    <?php echo $productResult->num_rows; ?>
                    product(s)
                </span>

            </div>

            <?php if ($search !== ""): ?>

                <span>
                    Search:
                    <strong>"<?php echo e($search); ?>"</strong>
                </span>

            <?php endif; ?>

        </div>

        <!-- Products Table -->
        <div class="table-card">

            <div class="table-responsive">

                <table class="table product-table">

                    <thead>

                        <tr>

                            <th>Product</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Status</th>
                            <th>Prescription</th>

                        </tr>

                    </thead>

                    <tbody>

                    <?php if ($productResult->num_rows > 0): ?>

                        <?php while ($product = $productResult->fetch_assoc()): ?>

                            <?php

                            $productId = (int) $product['id'];

                            $productName = $product['name'];

                            $categoryName = $product['category'];

                            $stock = (int) $product['stock_quantity'];

                            $productImage = getProductImage(
                                $categoryName,
                                $product['image'],
                                $productName
                            );

                            ?>

                            <tr>

                                <!-- Product Details -->
                                <td>

                                    <div class="product-info">

                                        <?php if ($productImage !== ''): ?>

                                            <img
                                                src="<?php echo e($productImage); ?>"
                                                alt="<?php echo e($productName); ?>"
                                                class="product-image"
                                                onerror="this.style.display='none';"
                                            >

                                        <?php else: ?>

                                            <div class="product-image d-flex align-items-center justify-content-center">
                                                <i class="bi bi-image text-secondary fs-4"></i>
                                            </div>

                                        <?php endif; ?>

                                        <div>

                                            <div class="product-name">
                                                <?php echo e($productName); ?>
                                            </div>

                                            <div class="product-description">
                                                <?php echo e($product['description']); ?>
                                            </div>

                                        </div>

                                    </div>

                                </td>

                                <!-- Category -->
                                <td>

                                    <span class="category-badge">
                                        <?php echo e($categoryName); ?>
                                    </span>

                                </td>

                                <!-- Price -->
                                <td>

                                    <span class="price">
                                        Rs.
                                        <?php echo number_format((float) $product['price'], 2); ?>
                                    </span>

                                </td>

                                <!-- Stock Update -->
                                <td>

                                    <?php if ($product['status'] === 'Inactive'): ?>

                                        <div style="color:#90a4ae;font-size:11px;margin-bottom:6px;">
                                            Inactive Product
                                        </div>

                                    <?php endif; ?>

                                    <form
                                        method="POST"
                                        action="admin-products.php<?php
                                            echo !empty($_SERVER['QUERY_STRING'])
                                                ? '?' . e($_SERVER['QUERY_STRING'])
                                                : '';
                                        ?>"
                                        class="stock-form"
                                    >

                                        <input
                                            type="hidden"
                                            name="action"
                                            value="update_stock"
                                        >

                                        <input
                                            type="hidden"
                                            name="product_id"
                                            value="<?php echo $productId; ?>"
                                        >

                                        <div class="stock-control">

                                            <button
                                                type="button"
                                                class="stock-btn decrease-btn"
                                                onclick="changeStock(this, -1)"
                                                <?php echo $stock <= 0 ? 'disabled' : ''; ?>
                                                title="Decrease Stock"
                                            >
                                                <i class="bi bi-dash"></i>
                                            </button>

                                            <input
                                                type="number"
                                                name="stock_quantity"
                                                class="stock-input stock-number"
                                                value="<?php echo $stock; ?>"
                                                min="0"
                                                max="999999"
                                                required
                                            >

                                            <button
                                                type="button"
                                                class="stock-btn"
                                                onclick="changeStock(this, 1)"
                                                title="Increase Stock"
                                            >
                                                <i class="bi bi-plus"></i>
                                            </button>

                                            <button
                                                type="submit"
                                                class="update-btn"
                                            >
                                                Update
                                            </button>

                                        </div>

                                    </form>

                                    <?php if ($stock > 0 && $stock <= 5): ?>

                                        <span class="low-stock-label">
                                            <i class="bi bi-exclamation-triangle-fill"></i>
                                            Low Stock
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <!-- Product Status -->
                                <td>

                                    <?php if ($product['status'] === 'Available'): ?>

                                        <span class="status-badge status-available">
                                            <i class="bi bi-check-circle-fill"></i>
                                            Available
                                        </span>

                                    <?php elseif ($product['status'] === 'Out of Stock'): ?>

                                        <span class="status-badge status-out">
                                            <i class="bi bi-x-circle-fill"></i>
                                            Out of Stock
                                        </span>

                                    <?php else: ?>

                                        <span class="status-badge status-inactive">
                                            <i class="bi bi-pause-circle-fill"></i>
                                            Inactive
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <!-- Prescription Requirement -->
                                <td>

                                    <?php if ((int) $product['requires_prescription'] === 1): ?>

                                        <span class="prescription-label">
                                            <i class="bi bi-file-earmark-medical-fill"></i>
                                            Required
                                        </span>

                                    <?php else: ?>

                                        <span class="normal-label">
                                            Not Required
                                        </span>

                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <tr>

                            <td colspan="6">

                                <div class="empty-state">

                                    <div class="empty-icon">
                                        <i class="bi bi-box-seam"></i>
                                    </div>

                                    <h5>No Products Found</h5>

                                    <p>
                                        No products match your current search or filter.
                                    </p>

                                </div>

                            </td>

                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

        <!-- Footer -->
        <div class="page-footer">

            MediQuick Pharmacy &copy; <?php echo date('Y'); ?>

            &nbsp; | &nbsp;

            Admin Product Management

        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>

/*
 * Increase or decrease product stock.
 */
function changeStock(button, amount)
{
    const form = button.closest('.stock-form');

    if (!form) return;

    const input = form.querySelector('.stock-number');

    if (!input) return;

    let current = parseInt(input.value) || 0;

    current += amount;

    current = Math.max(0, Math.min(999999, current));

    input.value = current;

    const minusButton = form.querySelector('.decrease-btn');

    if (minusButton) {
        minusButton.disabled = current <= 0;
    }
}

/*
 * Validate stock quantity before submitting.
 */
document.querySelectorAll('.stock-form').forEach(function(form) {

    form.addEventListener('submit', function(event) {

        const input = form.querySelector('.stock-number');

        if (!input) return;

        const value = Number(input.value);

        if (
            !Number.isInteger(value) ||
            value < 0 ||
            value > 999999
        ) {

            event.preventDefault();

            alert('Please enter a valid stock quantity between 0 and 999999.');

            input.focus();
        }

    });

});

/*
 * Update the minus button when stock is entered manually.
 */
document.querySelectorAll('.stock-number').forEach(function(input) {

    input.addEventListener('input', function() {

        const form = input.closest('.stock-form');

        if (!form) return;

        const minusButton = form.querySelector('.decrease-btn');

        if (minusButton) {

            minusButton.disabled =
                input.value === '' ||
                Number(input.value) <= 0;

        }

    });

});

</script>

</body>
</html>

<?php

/*
 * Close database statements.
 */
$productStmt->close();

$userStmt->close();

?>
