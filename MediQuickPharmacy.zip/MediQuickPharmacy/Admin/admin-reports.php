
<?php

session_start();

/*
 * Load the database connection.
 * This page is inside the Admin folder.
 */
require_once __DIR__ . '/../config/database.php';

/*
 * Check the database connection.
 */
if (!isset($conn) || $conn->connect_error) {
    die("Database connection failed.");
}

$errorMessage = '';

/*
 * Initialize report values.
 */
$totalOrders = 0;
$totalSales = 0;
$totalCustomers = 0;
$totalProducts = 0;

$pendingOrders = 0;
$processingOrders = 0;
$deliveredOrders = 0;
$cancelledOrders = 0;

/*
 * Retrieve pharmacy report information from MySQL.
 */
try {

    /*
     * Get total orders, sales and order status counts.
     *
     * Cancelled orders are excluded from total sales.
     */
    $orderQuery = "
        SELECT
            COUNT(*) AS total_orders,

            COALESCE(
                SUM(
                    CASE
                        WHEN order_status != 'Cancelled'
                        THEN total_amount
                        ELSE 0
                    END
                ),
                0
            ) AS total_sales,

            SUM(
                CASE
                    WHEN order_status = 'Pending'
                    THEN 1 ELSE 0
                END
            ) AS pending_orders,

            SUM(
                CASE
                    WHEN order_status = 'Processing'
                    THEN 1 ELSE 0
                END
            ) AS processing_orders,

            SUM(
                CASE
                    WHEN order_status = 'Delivered'
                    THEN 1 ELSE 0
                END
            ) AS delivered_orders,

            SUM(
                CASE
                    WHEN order_status = 'Cancelled'
                    THEN 1 ELSE 0
                END
            ) AS cancelled_orders

        FROM orders
    ";

    $orderResult = $conn->query($orderQuery);

    if (!$orderResult) {
        throw new Exception("Unable to retrieve order reports.");
    }

    $orderData = $orderResult->fetch_assoc();

    $totalOrders = (int)$orderData['total_orders'];

    $totalSales = (float)$orderData['total_sales'];

    $pendingOrders = (int)$orderData['pending_orders'];

    $processingOrders = (int)$orderData['processing_orders'];

    $deliveredOrders = (int)$orderData['delivered_orders'];

    $cancelledOrders = (int)$orderData['cancelled_orders'];


    /*
     * Count registered customer accounts.
     */
    $customerQuery = "
        SELECT COUNT(*) AS total_customers
        FROM users
        WHERE role = 'customer'
    ";

    $customerResult = $conn->query($customerQuery);

    if (!$customerResult) {
        throw new Exception("Unable to retrieve customer reports.");
    }

    $customerData = $customerResult->fetch_assoc();

    $totalCustomers = (int)$customerData['total_customers'];


    /*
     * Count all products in the pharmacy database.
     */
    $productQuery = "
        SELECT COUNT(*) AS total_products
        FROM products
    ";

    $productResult = $conn->query($productQuery);

    if (!$productResult) {
        throw new Exception("Unable to retrieve product reports.");
    }

    $productData = $productResult->fetch_assoc();

    $totalProducts = (int)$productData['total_products'];

} catch (Throwable $e) {

    $errorMessage = "Unable to load report information. Please check the database.";

}

/*
 * Include the common website header.
 */
include __DIR__ . '/../includes/header.php';

?>

<section class="admin-section">

    <div class="admin-container">

        <!-- Reports page heading -->
        <div class="page-header">

            <span class="small-title">
                MEDIQUICK PHARMACY
            </span>

            <h1>
                Reports
            </h1>

            <p>
                View basic pharmacy system reports.
            </p>

        </div>


        <!-- Display database errors if any -->
        <?php if ($errorMessage !== ''): ?>

            <div class="report-error">
                <?= htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8') ?>
            </div>

        <?php endif; ?>


        <!-- Main report statistics -->
        <div class="report-grid">

            <div class="report-card">

                <i class="bi bi-bag-check"></i>

                <span>
                    Total Orders
                </span>

                <strong>
                    <?= $totalOrders ?>
                </strong>

            </div>


            <div class="report-card">

                <i class="bi bi-currency-rupee"></i>

                <span>
                    Total Sales
                </span>

                <strong>
                    Rs. <?= number_format($totalSales, 2) ?>
                </strong>

            </div>


            <div class="report-card">

                <i class="bi bi-people"></i>

                <span>
                    Customers
                </span>

                <strong>
                    <?= $totalCustomers ?>
                </strong>

            </div>


            <div class="report-card">

                <i class="bi bi-box"></i>

                <span>
                    Products
                </span>

                <strong>
                    <?= $totalProducts ?>
                </strong>

            </div>

        </div>


        <!-- Order status summary -->
        <div class="admin-card">

            <h2>
                Order Summary
            </h2>

            <div class="summary-list">

                <div>

                    <span>
                        Pending Orders
                    </span>

                    <strong>
                        <?= $pendingOrders ?>
                    </strong>

                </div>


                <div>

                    <span>
                        Processing Orders
                    </span>

                    <strong>
                        <?= $processingOrders ?>
                    </strong>

                </div>


                <div>

                    <span>
                        Delivered Orders
                    </span>

                    <strong>
                        <?= $deliveredOrders ?>
                    </strong>

                </div>


                <div>

                    <span>
                        Cancelled Orders
                    </span>

                    <strong>
                        <?= $cancelledOrders ?>
                    </strong>

                </div>

            </div>

        </div>

    </div>

</section>


<style>

/* Main reports section */
.admin-section {
    background: #f6fbfd;
    min-height: 80vh;
    padding: 55px 20px;
}


/* Main content container */
.admin-container {
    max-width: 1100px;
    margin: auto;
}


/* Reports page heading */
.page-header {
    margin-bottom: 30px;
}


.small-title {
    color: #087f9b;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 2px;
}


.page-header h1 {
    color: #174f68;
    margin: 8px 0;
}


.page-header p {
    color: #777;
    margin: 0;
}


/* Report error message */
.report-error {
    background: #fdeaea;
    color: #b33a3a;
    padding: 14px 18px;
    border-radius: 8px;
    margin-bottom: 20px;
}


/* Report summary cards */
.report-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
    margin-bottom: 25px;
}


.report-card {
    background: white;
    padding: 25px;
    border-radius: 14px;
    box-shadow: 0 5px 20px rgba(0,80,110,.07);
}


.report-card i {
    font-size: 27px;
    color: #087f9b;
}


.report-card span {
    display: block;
    color: #777;
    font-size: 13px;
    margin: 8px 0 4px;
}


.report-card strong {
    display: block;
    color: #174f68;
    font-size: 23px;
    word-break: break-word;
}


/* Order summary card */
.admin-card {
    background: white;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 5px 25px rgba(0,80,110,.08);
}


.admin-card h2 {
    color: #174f68;
    margin-top: 0;
    margin-bottom: 10px;
}


/* Order status summary list */
.summary-list > div {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 0;
    border-bottom: 1px solid #edf2f4;
}


.summary-list > div:last-child {
    border-bottom: none;
}


.summary-list span {
    color: #666;
}


.summary-list strong {
    color: #087f9b;
}


/* Responsive layout */
@media (max-width: 800px) {

    .report-grid {
        grid-template-columns: repeat(2, 1fr);
    }

}


@media (max-width: 500px) {

    .admin-section {
        padding: 35px 15px;
    }

    .report-grid {
        grid-template-columns: 1fr;
    }

    .admin-card {
        padding: 20px;
    }

}

</style>


<?php

/*
 * Include the common website footer.
 */
include __DIR__ . '/../includes/footer.php';

?>
