<?php

/*
 * This file is inside the Admin folder.
 * The common header is located one level above in the includes folder.
 */
include '../includes/header.php';

?>

<section class="admin-section">
<div class="admin-container">

    <div class="page-header">
        <span class="small-title">MEDIQUICK PHARMACY</span>
        <h1>Settings</h1>
        <p>Manage basic pharmacy system settings.</p>
    </div>


    <div class="settings-card">

        <form id="settingsForm">

            <div class="setting-group">

                <h2>Pharmacy Information</h2>

                <label>Pharmacy Name</label>

                <input
                    type="text"
                    id="pharmacyName"
                    value="MediQuick Pharmacy"
                >

                <label>Email Address</label>

                <input
                    type="email"
                    id="pharmacyEmail"
                    value=""
                    placeholder="pharmacy@example.com"
                >

                <label>Phone Number</label>

                <input
                    type="text"
                    id="pharmacyPhone"
                    value=""
                    placeholder="Enter phone number"
                >

                <label>Address</label>

                <textarea
                    id="pharmacyAddress"
                    rows="4"
                    placeholder="Enter pharmacy address"
                ></textarea>

            </div>


            <div class="setting-group">

                <h2>Order Settings</h2>

                <label>Delivery Fee (Rs.)</label>

                <input
                    type="number"
                    id="deliveryFee"
                    min="0"
                    value="350"
                >

                <label class="checkbox-setting">

                    <input
                        type="checkbox"
                        id="acceptOrders"
                        checked
                    >

                    <span>
                        Accept new orders
                    </span>

                </label>

            </div>


            <button
                type="submit"
                class="save-settings"
            >

                <i class="bi bi-check-circle"></i>

                Save Settings

            </button>

        </form>

    </div>

</div>
</section>


<style>

.admin-section {
    background:#f6fbfd;
    min-height:80vh;
    padding:55px 20px;
}

.admin-container {
    max-width:850px;
    margin:auto;
}

.page-header {
    margin-bottom:30px;
}

.small-title {
    color:#087f9b;
    font-size:13px;
    font-weight:700;
    letter-spacing:2px;
}

.page-header h1 {
    color:#174f68;
    margin:8px 0;
}

.page-header p {
    color:#777;
}

.settings-card {
    background:white;
    padding:30px;
    border-radius:15px;
    box-shadow:0 5px 25px rgba(0,80,110,.08);
}

.setting-group {
    margin-bottom:30px;
}

.setting-group h2 {
    color:#174f68;
    margin-top:0;
    border-bottom:1px solid #edf2f4;
    padding-bottom:12px;
}

.setting-group label {
    display:block;
    color:#174f68;
    font-size:13px;
    font-weight:600;
    margin:16px 0 7px;
}

.setting-group input,
.setting-group textarea {
    width:100%;
    box-sizing:border-box;
    padding:12px;
    border:1px solid #d8e5e9;
    border-radius:8px;
    outline:none;
    font-family:inherit;
}

.setting-group input:focus,
.setting-group textarea:focus {
    border-color:#087f9b;
}

.checkbox-setting {
    display:flex !important;
    align-items:center;
    gap:8px;
    cursor:pointer;
}

.checkbox-setting input {
    width:auto;
    accent-color:#087f9b;
}

.save-settings {
    border:0;
    background:#087f9b;
    color:white;
    padding:13px 20px;
    border-radius:8px;
    cursor:pointer;
    font-weight:700;
}

.save-settings:hover {
    background:#056b83;
}

</style>


<script>

document.addEventListener("DOMContentLoaded", function() {

    /*
     * Load previously saved pharmacy settings from localStorage.
     * If no settings exist, an empty object is used.
     */
    let settings = {};

    try {

        settings =
            JSON.parse(
                localStorage.getItem("mediquickSettings")
            ) || {};

    } catch(e) {

        settings = {};

    }


    /*
     * Display saved pharmacy information in the form.
     */
    if(settings.pharmacyName) {

        document.getElementById("pharmacyName").value =
            settings.pharmacyName;

    }


    if(settings.pharmacyEmail) {

        document.getElementById("pharmacyEmail").value =
            settings.pharmacyEmail;

    }


    if(settings.pharmacyPhone) {

        document.getElementById("pharmacyPhone").value =
            settings.pharmacyPhone;

    }


    if(settings.pharmacyAddress) {

        document.getElementById("pharmacyAddress").value =
            settings.pharmacyAddress;

    }


    /*
     * Restore the saved delivery fee.
     */
    if(settings.deliveryFee !== undefined) {

        document.getElementById("deliveryFee").value =
            settings.deliveryFee;

    }


    /*
     * Restore the order acceptance setting.
     */
    if(settings.acceptOrders !== undefined) {

        document.getElementById("acceptOrders").checked =
            settings.acceptOrders;

    }


    /*
     * Save the updated settings when the administrator submits the form.
     */
    document.getElementById("settingsForm")
        .addEventListener("submit", function(e) {

            e.preventDefault();


            settings = {

                pharmacyName:
                    document.getElementById(
                        "pharmacyName"
                    ).value.trim(),


                pharmacyEmail:
                    document.getElementById(
                        "pharmacyEmail"
                    ).value.trim(),


                pharmacyPhone:
                    document.getElementById(
                        "pharmacyPhone"
                    ).value.trim(),


                pharmacyAddress:
                    document.getElementById(
                        "pharmacyAddress"
                    ).value.trim(),


                deliveryFee:
                    Number(
                        document.getElementById(
                            "deliveryFee"
                        ).value
                    ),


                acceptOrders:
                    document.getElementById(
                        "acceptOrders"
                    ).checked

            };


            /*
             * Store the settings in the browser's localStorage.
             */
            localStorage.setItem(
                "mediquickSettings",
                JSON.stringify(settings)
            );


            alert(
                "Settings saved successfully."
            );

        });

});

</script>


<?php

/*
 * The common footer is located one level above in the includes folder.
 */
include '../includes/footer.php';

?>