<?php

/*
 * Get the current PHP file name.
 * This is used to identify the active sidebar menu item.
 */
$currentPage = basename($_SERVER['PHP_SELF']);

?>

<!--
    Main admin sidebar.
    This sidebar contains navigation links for all
    administrative functions of the MediQuick Pharmacy system.
-->
<aside class="admin-sidebar" id="adminSidebar">

    <!--
        Brand section displays the MediQuick Pharmacy
        logo icon and admin panel name.
    -->
    <div class="admin-brand">

        <div class="admin-logo">
            <i class="bi bi-heart-pulse-fill"></i>
        </div>

        <div class="admin-brand-text">

            <h2>MediQuick</h2>

            <span>Pharmacy Admin</span>

        </div>

    </div>


    <!--
        Main navigation area.
        The navigation is divided into logical sections
        such as Management, Users and System.
    -->
    <nav class="admin-navigation">

        <!-- Main navigation section -->
        <div class="nav-section-title">
            MAIN
        </div>


        <!--
            Dashboard link.
            The active class is added when the current page
            is admin-dashboard.php.
        -->
        <a
            href="admin-dashboard.php"
            class="admin-nav-link <?php echo $currentPage === 'admin-dashboard.php' ? 'active' : ''; ?>"
        >

            <i class="bi bi-grid-1x2-fill"></i>

            <span>Dashboard</span>

        </a>


        <!-- Management section -->
        <div class="nav-section-title">
            MANAGEMENT
        </div>


        <!--
            Products page allows the administrator
            to manage pharmacy products.
        -->
        <a
            href="admin-products.php"
            class="admin-nav-link <?php echo $currentPage === 'admin-products.php' ? 'active' : ''; ?>"
        >

            <i class="bi bi-capsule"></i>

            <span>Products</span>

        </a>


        <!--
            Categories page allows the administrator
            to manage product categories.
        -->
        <a
            href="admin-categories.php"
            class="admin-nav-link <?php echo $currentPage === 'admin-categories.php' ? 'active' : ''; ?>"
        >

            <i class="bi bi-tags"></i>

            <span>Categories</span>

        </a>


        <!--
            Inventory page is used to monitor
            and manage available product stock.
        -->
        <a
            href="admin-inventory.php"
            class="admin-nav-link <?php echo $currentPage === 'admin-inventory.php' ? 'active' : ''; ?>"
        >

            <i class="bi bi-box-seam"></i>

            <span>Inventory</span>

        </a>


        <!--
            Orders page allows the administrator
            to view and manage customer orders.
        -->
        <a
            href="admin-orders.php"
            class="admin-nav-link <?php echo $currentPage === 'admin-orders.php' ? 'active' : ''; ?>"
        >

            <i class="bi bi-bag-check"></i>

            <span>Orders</span>

        </a>


        <!--
            Prescriptions page allows authorized pharmacy
            staff or administrators to review uploaded prescriptions.
        -->
        <a
            href="admin-prescriptions.php"
            class="admin-nav-link <?php echo $currentPage === 'admin-prescriptions.php' ? 'active' : ''; ?>"
        >

            <i class="bi bi-file-medical"></i>

            <span>Prescriptions</span>

        </a>


        <!-- Users section -->
        <div class="nav-section-title">
            USERS
        </div>


        <!--
            Customers page displays and manages
            registered customer accounts.
        -->
        <a
            href="admin-customers.php"
            class="admin-nav-link <?php echo $currentPage === 'admin-customers.php' ? 'active' : ''; ?>"
        >

            <i class="bi bi-people"></i>

            <span>Customers</span>

        </a>


        <!--
            Inquiries page is used to manage
            customer questions and messages.
        -->
        <a
            href="admin-inquiries.php"
            class="admin-nav-link <?php echo $currentPage === 'admin-inquiries.php' ? 'active' : ''; ?>"
        >

            <i class="bi bi-chat-left-text"></i>

            <span>Inquiries</span>

        </a>


        <!--
            Staff page allows the administrator
            to manage staff accounts.
        -->
        <a
            href="admin-staff.php"
            class="admin-nav-link <?php echo $currentPage === 'admin-staff.php' ? 'active' : ''; ?>"
        >

            <i class="bi bi-person-badge"></i>

            <span>Staff</span>

        </a>


        <!-- System section -->
        <div class="nav-section-title">
            SYSTEM
        </div>


        <!--
            Reports page provides system and
            pharmacy-related reports.
        -->
        <a
            href="admin-reports.php"
            class="admin-nav-link <?php echo $currentPage === 'admin-reports.php' ? 'active' : ''; ?>"
        >

            <i class="bi bi-bar-chart-line"></i>

            <span>Reports</span>

        </a>


        <!--
            Settings page is used to manage
            system configuration and preferences.
        -->
        <a
            href="admin-settings.php"
            class="admin-nav-link <?php echo $currentPage === 'admin-settings.php' ? 'active' : ''; ?>"
        >

            <i class="bi bi-gear"></i>

            <span>Settings</span>

        </a>

    </nav>


    <!--
        Bottom navigation contains links that are
        available throughout the admin panel.
    -->
    <div class="admin-sidebar-bottom">

        <!--
            This link takes the administrator back
            to the main MediQuick Pharmacy website.
        -->
        <a
            href="../index.php"
            class="admin-nav-link"
        >

            <i class="bi bi-globe2"></i>

            <span>View Website</span>

        </a>


        <!--
            Logout link ends the current administrator
            session and returns the user to the login page.
        -->
        <a
            href="../logout.php"
            class="admin-nav-link logout-link"
        >

            <i class="bi bi-box-arrow-right"></i>

            <span>Logout</span>

        </a>

    </div>

</aside>


<!--
    Mobile overlay.
    This appears behind the sidebar when the sidebar
    is opened on smaller screen devices.
-->
<div
    class="admin-sidebar-overlay"
    id="adminSidebarOverlay"
></div>


<style>

/*
 * Main sidebar layout.
 * The sidebar remains fixed on the left side
 * of the administrator screen.
 */
.admin-sidebar {

    position: fixed;

    top: 0;

    left: 0;

    width: 255px;

    height: 100vh;

    background: #ffffff;

    border-right: 1px solid #e5eef1;

    display: flex;

    flex-direction: column;

    z-index: 1000;

    box-shadow:
        4px 0 20px
        rgba(0, 80, 110, 0.05);

}


/*
 * Brand area contains the pharmacy logo
 * and the admin panel title.
 */
.admin-brand {

    height: 82px;

    padding: 0 20px;

    display: flex;

    align-items: center;

    gap: 12px;

    border-bottom:
        1px solid #edf2f4;

}


/*
 * Creates the colored square background
 * for the pharmacy icon.
 */
.admin-logo {

    width: 44px;

    height: 44px;

    border-radius: 12px;

    background: #087f9b;

    color: white;

    display: flex;

    align-items: center;

    justify-content: center;

    flex-shrink: 0;

}


.admin-logo i {

    font-size: 22px;

}


/*
 * Styles the MediQuick brand name.
 */
.admin-brand-text h2 {

    margin: 0;

    color: #174f68;

    font-size: 20px;

    line-height: 1.2;

}


/*
 * Styles the Admin subtitle below
 * the pharmacy name.
 */
.admin-brand-text span {

    display: block;

    margin-top: 3px;

    color: #8a9ca3;

    font-size: 11px;

}


/*
 * Navigation uses the remaining vertical
 * space available inside the sidebar.
 */
.admin-navigation {

    flex: 1;

    overflow-y: auto;

    padding: 20px 13px;

}


/*
 * Custom scrollbar for the navigation area.
 */
.admin-navigation::-webkit-scrollbar {

    width: 5px;

}


.admin-navigation::-webkit-scrollbar-thumb {

    background: #d7e7eb;

    border-radius: 10px;

}


/*
 * Small headings used to separate
 * navigation categories.
 */
.nav-section-title {

    padding: 10px 12px 7px;

    color: #9aaab0;

    font-size: 10px;

    font-weight: 800;

    letter-spacing: 1.5px;

}


/*
 * Common styling for all sidebar links.
 */
.admin-nav-link {

    display: flex;

    align-items: center;

    gap: 12px;

    min-height: 44px;

    padding: 0 13px;

    margin: 3px 0;

    border-radius: 9px;

    color: #62757d;

    text-decoration: none;

    font-size: 14px;

    font-weight: 600;

    transition:
        background 0.2s ease,
        color 0.2s ease,
        transform 0.2s ease;

}


/*
 * Sets a fixed width for navigation icons
 * so all menu text is aligned.
 */
.admin-nav-link i {

    width: 20px;

    text-align: center;

    font-size: 17px;

    flex-shrink: 0;

}


/*
 * Hover effect provides visual feedback
 * when the administrator moves over a menu item.
 */
.admin-nav-link:hover {

    background: #eef9fb;

    color: #087f9b;

    transform: translateX(2px);

}


/*
 * Active menu item identifies the page
 * currently being viewed by the administrator.
 */
.admin-nav-link.active {

    background: #087f9b;

    color: white;

    box-shadow:
        0 4px 12px
        rgba(8, 127, 155, 0.18);

}


/*
 * Prevents the active item from changing
 * appearance when it is hovered.
 */
.admin-nav-link.active:hover {

    background: #087f9b;

    color: white;

    transform: none;

}


/*
 * Bottom section is separated from the
 * main navigation using a top border.
 */
.admin-sidebar-bottom {

    padding: 12px 13px 16px;

    border-top:
        1px solid #edf2f4;

}


.admin-sidebar-bottom .admin-nav-link {

    margin: 3px 0;

}


/*
 * Logout is highlighted using a warning color
 * to distinguish it from normal navigation links.
 */
.admin-sidebar-bottom .logout-link {

    color: #d9534f;

}


/*
 * Changes the logout background when hovered.
 */
.admin-sidebar-bottom .logout-link:hover {

    background: #fff1f1;

    color: #c43d39;

}


/*
 * Overlay is hidden by default.
 * It is displayed when the mobile sidebar opens.
 */
.admin-sidebar-overlay {

    display: none;

    position: fixed;

    inset: 0;

    background:
        rgba(0, 0, 0, 0.35);

    z-index: 999;

}


/*
 * Responsive design for screens smaller than 900px.
 * The sidebar is moved outside the screen initially.
 */
@media (max-width: 900px) {

    .admin-sidebar {

        transform:
            translateX(-100%);

        transition:
            transform 0.25s ease;

    }


    /*
     * The open class moves the sidebar
     * back into the visible screen.
     */
    .admin-sidebar.open {

        transform:
            translateX(0);

    }


    /*
     * Displays the background overlay
     * when the mobile sidebar is active.
     */
    .admin-sidebar-overlay.show {

        display: block;

    }

}

</style>


<script>

/*
 * Wait until the complete HTML document
 * has finished loading before accessing elements.
 */
document.addEventListener(
    "DOMContentLoaded",
    function () {

        /*
         * Get the sidebar element.
         */
        const sidebar =
            document.getElementById(
                "adminSidebar"
            );


        /*
         * Get the mobile background overlay.
         */
        const overlay =
            document.getElementById(
                "adminSidebarOverlay"
            );


        /*
         * Get the mobile menu button.
         * This button is normally located in the
         * admin dashboard header.
         */
        const menuButton =
            document.getElementById(
                "adminMenuButton"
            );


        /*
         * Continue only if all required
         * mobile navigation elements exist.
         */
        if (
            menuButton &&
            sidebar &&
            overlay
        ) {

            /*
             * Toggle the sidebar and overlay
             * when the mobile menu button is clicked.
             */
            menuButton.addEventListener(
                "click",
                function () {

                    sidebar.classList.toggle(
                        "open"
                    );

                    overlay.classList.toggle(
                        "show"
                    );

                }
            );


            /*
             * Close the sidebar when the user
             * clicks outside the sidebar.
             */
            overlay.addEventListener(
                "click",
                function () {

                    sidebar.classList.remove(
                        "open"
                    );

                    overlay.classList.remove(
                        "show"
                    );

                }
            );

        }

    }
);

</script>