
<?php

// Start the session.
session_start();

// Connect to the database.
require_once __DIR__ . '/../config/database.php';

// Check whether the user is logged in.
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

// Allow only administrators to manage staff.
$userRole = strtolower(
    $_SESSION['user_role'] ?? $_SESSION['role'] ?? ''
);

if ($userRole !== 'admin') {
    http_response_code(403);
    die("Access denied. Only administrators can manage staff.");
}

// Check the database connection.
if (!isset($conn) || !($conn instanceof mysqli)) {
    die("Database connection was not found.");
}

// Escape values before displaying them in HTML.
function e($value)
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
 * Handle staff management requests.
 * JavaScript sends these requests using fetch().
 */
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['action'])
) {

    header('Content-Type: application/json');

    $action = $_POST['action'];

    try {

        /*
         * Add a new staff member.
         */
        if ($action === 'add') {

            $name = trim($_POST['full_name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $password = $_POST['password'] ?? '';

            if (
                $name === '' ||
                $email === '' ||
                $phone === '' ||
                $password === ''
            ) {
                throw new Exception(
                    "Please complete all required fields."
                );
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception("Please enter a valid email address.");
            }

            if (strlen($password) < 8) {
                throw new Exception(
                    "Password must contain at least 8 characters."
                );
            }

            // Check whether the email is already registered.
            $check = $conn->prepare(
                "SELECT id FROM users WHERE email = ?"
            );

            $check->bind_param("s", $email);
            $check->execute();

            if ($check->get_result()->num_rows > 0) {
                $check->close();

                throw new Exception(
                    "This email address is already registered."
                );
            }

            $check->close();

            // Hash the password before saving it.
            $hashedPassword = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            // Save the new staff account.
            $stmt = $conn->prepare("
                INSERT INTO users
                (
                    full_name,
                    email,
                    phone,
                    password,
                    role
                )
                VALUES (?, ?, ?, ?, 'staff')
            ");

            $stmt->bind_param(
                "ssss",
                $name,
                $email,
                $phone,
                $hashedPassword
            );

            $stmt->execute();
            $stmt->close();

            echo json_encode([
                'success' => true,
                'message' => 'Staff member added successfully.'
            ]);

            exit;
        }

        /*
         * Update an existing staff member.
         */
        if ($action === 'edit') {

            $staffId = (int) ($_POST['staff_id'] ?? 0);

            $name = trim($_POST['full_name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $phone = trim($_POST['phone'] ?? '');
            $password = $_POST['password'] ?? '';

            if (
                $staffId <= 0 ||
                $name === '' ||
                $email === '' ||
                $phone === ''
            ) {
                throw new Exception(
                    "Please complete all required fields."
                );
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception("Please enter a valid email address.");
            }

            // Check whether this staff account exists.
            $check = $conn->prepare("
                SELECT id
                FROM users
                WHERE id = ? AND role = 'staff'
            ");

            $check->bind_param("i", $staffId);
            $check->execute();

            if ($check->get_result()->num_rows === 0) {
                $check->close();

                throw new Exception("Staff member was not found.");
            }

            $check->close();

            // Check whether another account uses this email.
            $check = $conn->prepare("
                SELECT id
                FROM users
                WHERE email = ? AND id != ?
            ");

            $check->bind_param("si", $email, $staffId);
            $check->execute();

            if ($check->get_result()->num_rows > 0) {
                $check->close();

                throw new Exception(
                    "This email address is already registered."
                );
            }

            $check->close();

            if ($password !== '') {

                if (strlen($password) < 8) {
                    throw new Exception(
                        "Password must contain at least 8 characters."
                    );
                }

                $hashedPassword = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                $stmt = $conn->prepare("
                    UPDATE users
                    SET
                        full_name = ?,
                        email = ?,
                        phone = ?,
                        password = ?
                    WHERE id = ? AND role = 'staff'
                ");

                $stmt->bind_param(
                    "ssssi",
                    $name,
                    $email,
                    $phone,
                    $hashedPassword,
                    $staffId
                );

            } else {

                // Keep the existing password when no new password is entered.
                $stmt = $conn->prepare("
                    UPDATE users
                    SET
                        full_name = ?,
                        email = ?,
                        phone = ?
                    WHERE id = ? AND role = 'staff'
                ");

                $stmt->bind_param(
                    "sssi",
                    $name,
                    $email,
                    $phone,
                    $staffId
                );
            }

            $stmt->execute();
            $stmt->close();

            echo json_encode([
                'success' => true,
                'message' => 'Staff details updated successfully.'
            ]);

            exit;
        }

        /*
         * Delete an existing staff member.
         */
        if ($action === 'delete') {

            $staffId = (int) ($_POST['staff_id'] ?? 0);

            if ($staffId <= 0) {
                throw new Exception("Invalid staff member.");
            }

            $stmt = $conn->prepare("
                DELETE FROM users
                WHERE id = ? AND role = 'staff'
            ");

            $stmt->bind_param("i", $staffId);
            $stmt->execute();

            if ($stmt->affected_rows === 0) {
                $stmt->close();

                throw new Exception(
                    "Staff member was not found."
                );
            }

            $stmt->close();

            echo json_encode([
                'success' => true,
                'message' => 'Staff member deleted successfully.'
            ]);

            exit;
        }

        throw new Exception("Invalid request.");

    } catch (mysqli_sql_exception $error) {

        // Handle database errors.
        $message = $error->getCode() === 1062
            ? "This email address is already registered."
            : "A database error occurred. Please check your details.";

        echo json_encode([
            'success' => false,
            'message' => $message
        ]);

        exit;

    } catch (Exception $error) {

        echo json_encode([
            'success' => false,
            'message' => $error->getMessage()
        ]);

        exit;
    }
}

/*
 * Retrieve all staff members from the users table.
 */
$staffMembers = [];

$staffResult = $conn->query("
    SELECT
        id,
        full_name,
        email,
        phone
    FROM users
    WHERE role = 'staff'
    ORDER BY id DESC
");

if (!$staffResult) {
    die("Unable to retrieve staff members.");
}

while ($staff = $staffResult->fetch_assoc()) {
    $staffMembers[] = $staff;
}

// Load the common website header.
include __DIR__ . '/../includes/header.php';

?>

<section class="admin-section">

    <div class="admin-container">

        <div class="page-header">

            <div>

                <span class="small-title">
                    MEDIQUICK PHARMACY
                </span>

                <h1>Staff Management</h1>

                <p>Manage pharmacy staff members.</p>

            </div>

            <button
                type="button"
                class="primary-btn"
                id="addStaff"
            >

                <i class="bi bi-person-plus"></i>
                Add Staff

            </button>

        </div>

        <!-- Staff search -->
        <div class="staff-search">

            <i class="bi bi-search"></i>

            <input
                type="text"
                id="staffSearch"
                placeholder="Search staff by name or email..."
            >

        </div>

        <div class="admin-card">

            <div id="staffGrid" class="staff-grid">

                <?php foreach ($staffMembers as $member): ?>

                    <div
                        class="staff-card"
                        data-id="<?= (int) $member['id'] ?>"
                        data-name="<?= e($member['full_name']) ?>"
                        data-email="<?= e($member['email']) ?>"
                        data-phone="<?= e($member['phone']) ?>"
                    >

                        <div class="staff-avatar">

                            <i class="bi bi-person"></i>

                        </div>

                        <h3>
                            <?= e($member['full_name']) ?>
                        </h3>

                        <p>
                            <i class="bi bi-envelope"></i>
                            <?= e($member['email']) ?>
                        </p>

                        <p>
                            <i class="bi bi-telephone"></i>
                            <?= e($member['phone']) ?>
                        </p>

                        <span class="staff-role">
                            <i class="bi bi-shield-check"></i>
                            Pharmacy Staff
                        </span>

                        <div class="staff-actions">

                            <button
                                type="button"
                                class="edit-staff"
                                data-id="<?= (int) $member['id'] ?>"
                            >

                                <i class="bi bi-pencil-square"></i>
                                Edit

                            </button>

                            <button
                                type="button"
                                class="delete-staff"
                                data-id="<?= (int) $member['id'] ?>"
                            >

                                <i class="bi bi-trash"></i>
                                Delete

                            </button>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

            <div
                id="emptyStaff"
                class="empty-state"
                style="<?= count($staffMembers) === 0 ? 'display:block;' : '' ?>"
            >

                <i class="bi bi-person-badge"></i>

                <h3>No staff members found</h3>

                <p>
                    Add a staff member to see them here.
                </p>

            </div>

        </div>

    </div>

</section>


<!-- Add / Edit Staff Modal -->
<div class="staff-modal" id="staffModal">

    <div class="modal-overlay"></div>

    <div class="modal-box">

        <button
            type="button"
            class="close-btn"
            id="closeStaff"
        >

            <i class="bi bi-x-lg"></i>

        </button>

        <h2 id="staffModalTitle">
            Add Staff
        </h2>

        <p class="modal-description">
            Enter the staff member's account details.
        </p>

        <form id="staffForm">

            <input
                type="hidden"
                id="staffId"
            >

            <label for="staffName">
                Full Name
            </label>

            <input
                type="text"
                id="staffName"
                placeholder="Enter full name"
                required
            >

            <label for="staffEmail">
                Email Address
            </label>

            <input
                type="email"
                id="staffEmail"
                placeholder="Enter email address"
                required
            >

            <label for="staffPhone">
                Phone Number
            </label>

            <input
                type="tel"
                id="staffPhone"
                placeholder="Enter phone number"
                required
            >

            <label for="staffPassword">
                Password
            </label>

            <input
                type="password"
                id="staffPassword"
                placeholder="Enter password"
                minlength="8"
            >

            <small id="passwordHelp">
                Minimum 8 characters.
            </small>

            <div class="modal-actions">

                <button
                    type="button"
                    class="secondary-btn"
                    id="cancelStaff"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="primary-btn"
                    id="saveStaff"
                >
                    Save Staff
                </button>

            </div>

        </form>

    </div>

</div>


<style>

/* Main page */
.admin-section {
    background: #f6fbfd;
    min-height: 80vh;
    padding: 55px 20px;
}

.admin-container {
    max-width: 1100px;
    margin: auto;
}

.page-header {
    display: flex;
    justify-content: space-between;
    align-items: end;
    margin-bottom: 30px;
}

.small-title {
    color: #087f9b;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 2px;
}

.page-header h1 {
    color: #174f68;
    margin: 8px 0;
}

.page-header p {
    color: #777;
}

/* Buttons */
.primary-btn,
.secondary-btn {
    border: 0;
    padding: 12px 18px;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 700;
    transition: .2s;
}

.primary-btn {
    background: #087f9b;
    color: white;
}

.primary-btn:hover {
    background: #066b82;
}

.primary-btn:disabled {
    opacity: .6;
    cursor: not-allowed;
}

.secondary-btn {
    background: #edf3f5;
    color: #174f68;
}

/* Search */
.staff-search {
    position: relative;
    margin-bottom: 20px;
}

.staff-search i {
    position: absolute;
    left: 16px;
    top: 14px;
    color: #087f9b;
}

.staff-search input {
    width: 100%;
    box-sizing: border-box;
    padding: 13px 15px 13px 45px;
    border: 1px solid #d8e5e9;
    border-radius: 9px;
    outline: none;
    background: white;
}

.staff-search input:focus {
    border-color: #087f9b;
}

/* Staff card area */
.admin-card {
    background: white;
    padding: 25px;
    border-radius: 15px;
    box-shadow: 0 5px 25px rgba(0,80,110,.08);
}

.staff-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
}

.staff-card {
    border: 1px solid #e2edf0;
    border-radius: 12px;
    padding: 20px;
    transition: .2s;
}

.staff-card:hover {
    box-shadow: 0 5px 20px rgba(0,80,110,.08);
    transform: translateY(-3px);
}

.staff-avatar {
    width: 55px;
    height: 55px;
    border-radius: 50%;
    background: #e8f7fa;
    color: #087f9b;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
}

.staff-card h3 {
    color: #174f68;
    margin: 15px 0 10px;
}

.staff-card p {
    color: #777;
    font-size: 13px;
    overflow-wrap: anywhere;
    margin-bottom: 10px;
}

.staff-card p i {
    color: #087f9b;
    margin-right: 5px;
}

.staff-role {
    display: inline-block;
    padding: 6px 10px;
    border-radius: 20px;
    background: #e8f5f8;
    color: #087f9b;
    font-size: 12px;
    margin: 5px 0 15px;
}

.staff-actions {
    display: flex;
    gap: 8px;
    border-top: 1px solid #edf2f4;
    padding-top: 15px;
}

.staff-actions button {
    flex: 1;
    border: 0;
    padding: 9px 10px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
}

.edit-staff {
    background: #e8f5f8;
    color: #087f9b;
}

.delete-staff {
    background: #fdeaea;
    color: #b33a3a;
}

.staff-actions button:hover {
    opacity: .8;
}

/* Empty state */
.empty-state {
    display: none;
    text-align: center;
    padding: 50px 20px;
    color: #777;
}

.empty-state i {
    font-size: 45px;
    color: #087f9b;
}

.empty-state h3 {
    color: #526c78;
    margin: 15px 0 8px;
}

/* Staff modal */
.staff-modal {
    position: fixed;
    inset: 0;
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    padding: 15px;
}

.staff-modal.show {
    display: flex;
}

.modal-overlay {
    position: absolute;
    inset: 0;
    background: rgba(0,0,0,.5);
}

.modal-box {
    position: relative;
    z-index: 1;
    width: 100%;
    max-width: 500px;
    max-height: 90vh;
    overflow-y: auto;
    background: white;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 15px 40px rgba(0,0,0,.15);
}

.close-btn {
    position: absolute;
    right: 18px;
    top: 18px;
    border: 0;
    width: 35px;
    height: 35px;
    border-radius: 7px;
    background: #f1f5f6;
    cursor: pointer;
}

.modal-box h2 {
    color: #174f68;
    margin: 0;
}

.modal-description {
    color: #888;
    font-size: 13px;
    margin-bottom: 20px;
}

.modal-box label {
    display: block;
    color: #174f68;
    font-weight: 600;
    margin: 14px 0 6px;
    font-size: 14px;
}

.modal-box input {
    width: 100%;
    box-sizing: border-box;
    padding: 12px;
    border: 1px solid #d8e5e9;
    border-radius: 8px;
    outline: none;
}

.modal-box input:focus {
    border-color: #087f9b;
    box-shadow: 0 0 0 3px rgba(8,127,155,.08);
}

#passwordHelp {
    display: block;
    color: #888;
    margin-top: 6px;
    font-size: 12px;
}

.modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    margin-top: 22px;
}

/* Responsive layout */
@media(max-width:800px) {

    .staff-grid {
        grid-template-columns: repeat(2, 1fr);
    }

}

@media(max-width:550px) {

    .page-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 15px;
    }

    .staff-grid {
        grid-template-columns: 1fr;
    }

    .admin-card {
        padding: 15px;
    }

    .modal-box {
        padding: 25px 20px;
    }

}

</style>


<script>

// Get the HTML elements.
const staffGrid = document.getElementById("staffGrid");
const staffModal = document.getElementById("staffModal");
const staffForm = document.getElementById("staffForm");
const staffSearch = document.getElementById("staffSearch");
const emptyStaff = document.getElementById("emptyStaff");

const staffIdInput = document.getElementById("staffId");
const staffNameInput = document.getElementById("staffName");
const staffEmailInput = document.getElementById("staffEmail");
const staffPhoneInput = document.getElementById("staffPhone");
const staffPasswordInput = document.getElementById("staffPassword");

const saveButton = document.getElementById("saveStaff");

// Open the staff modal.
function openModal() {
    staffModal.classList.add("show");
}

// Close the staff modal.
function closeModal() {
    staffModal.classList.remove("show");
    staffForm.reset();
    staffIdInput.value = "";
}

// Open the form for adding a staff member.
document.getElementById("addStaff").addEventListener(
    "click",
    function() {

        staffForm.reset();

        staffIdInput.value = "";

        document.getElementById("staffModalTitle").textContent =
            "Add Staff";

        document.getElementById("passwordHelp").textContent =
            "Minimum 8 characters.";

        staffPasswordInput.required = true;

        openModal();

    }
);

// Close buttons.
document.getElementById("closeStaff").addEventListener(
    "click",
    closeModal
);

document.getElementById("cancelStaff").addEventListener(
    "click",
    closeModal
);

document.querySelector(".modal-overlay").addEventListener(
    "click",
    closeModal
);

// Send a request to PHP and receive a JSON response.
async function sendRequest(formData) {

    const response = await fetch(
        window.location.href,
        {
            method: "POST",
            body: formData
        }
    );

    if (!response.ok) {
        throw new Error("Server error: " + response.status);
    }

    return await response.json();
}

// Refresh the staff cards from the database.
function reloadStaff() {
    window.location.reload();
}

// Search staff members.
staffSearch.addEventListener("input", function() {

    const search = this.value.toLowerCase().trim();

    const cards = document.querySelectorAll(".staff-card");

    let visibleCount = 0;

    cards.forEach(function(card) {

        const name = card.dataset.name.toLowerCase();
        const email = card.dataset.email.toLowerCase();
        const phone = card.dataset.phone.toLowerCase();

        const matches =
            name.includes(search) ||
            email.includes(search) ||
            phone.includes(search);

        card.style.display = matches ? "" : "none";

        if (matches) {
            visibleCount++;
        }

    });

    emptyStaff.style.display =
        visibleCount === 0 ? "block" : "none";

    const heading = emptyStaff.querySelector("h3");
    const description = emptyStaff.querySelector("p");

    if (search !== "" && visibleCount === 0) {

        heading.textContent = "No matching staff members";

        description.textContent =
            "Try searching with another name or email.";

    } else {

        heading.textContent = "No staff members found";

        description.textContent =
            "Add a staff member to see them here.";

    }

});

// Handle staff form submission.
staffForm.addEventListener("submit", async function(event) {

    event.preventDefault();

    const staffId = staffIdInput.value;

    const formData = new FormData();

    formData.append(
        "action",
        staffId ? "edit" : "add"
    );

    if (staffId) {
        formData.append("staff_id", staffId);
    }

    formData.append("full_name", staffNameInput.value.trim());
    formData.append("email", staffEmailInput.value.trim());
    formData.append("phone", staffPhoneInput.value.trim());
    formData.append("password", staffPasswordInput.value);

    saveButton.disabled = true;
    saveButton.textContent = "Saving...";

    try {

        const result = await sendRequest(formData);

        if (result.success) {

            alert(result.message);

            closeModal();

            reloadStaff();

        } else {

            alert(result.message);

        }

    } catch(error) {

        console.error(error);

        alert(
            "Unable to save staff details. Please try again."
        );

    } finally {

        saveButton.disabled = false;
        saveButton.textContent = "Save Staff";

    }

});

// Handle Edit and Delete buttons.
staffGrid.addEventListener("click", async function(event) {

    const editButton = event.target.closest(".edit-staff");
    const deleteButton = event.target.closest(".delete-staff");

    // Edit selected staff member.
    if (editButton) {

        const card = editButton.closest(".staff-card");

        staffIdInput.value = card.dataset.id;

        staffNameInput.value = card.dataset.name;
        staffEmailInput.value = card.dataset.email;
        staffPhoneInput.value = card.dataset.phone;

        // Leave the password blank to keep the existing password.
        staffPasswordInput.value = "";
        staffPasswordInput.required = false;

        document.getElementById("staffModalTitle").textContent =
            "Edit Staff";

        document.getElementById("passwordHelp").textContent =
            "Leave blank to keep the current password. Enter a new password to change it.";

        openModal();

        return;
    }

    // Delete selected staff member.
    if (deleteButton) {

        const staffId = deleteButton.dataset.id;

        const confirmed = confirm(
            "Are you sure you want to delete this staff member?"
        );

        if (!confirmed) {
            return;
        }

        const formData = new FormData();

        formData.append("action", "delete");
        formData.append("staff_id", staffId);

        deleteButton.disabled = true;

        try {

            const result = await sendRequest(formData);

            if (result.success) {

                alert(result.message);

                reloadStaff();

            } else {

                alert(result.message);

                deleteButton.disabled = false;

            }

        } catch(error) {

            console.error(error);

            alert(
                "Unable to delete the staff member."
            );

            deleteButton.disabled = false;

        }
    }

});

</script>


<?php

// Load the common website footer.
include __DIR__ . '/../includes/footer.php';

?>
