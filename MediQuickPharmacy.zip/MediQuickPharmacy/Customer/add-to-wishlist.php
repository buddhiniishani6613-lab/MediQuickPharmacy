<?php

session_start();

require_once __DIR__ . '/../config/database.php';

/* Check whether the customer is logged in. */
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

/* Get the product ID from the URL. */
$productId = isset($_GET['id']) ? (int) $_GET['id'] : 0;

/* Check whether a valid product ID was provided. */
if ($productId <= 0) {
    header('Location: ../products.php');
    exit;
}

/* Check whether the selected product exists. */
$productStmt = $conn->prepare(
    'SELECT id FROM products WHERE id = ? LIMIT 1'
);

if (!$productStmt) {
    header('Location: ../products.php');
    exit;
}

$productStmt->bind_param(
    'i',
    $productId
);

$productStmt->execute();

$productResult = $productStmt->get_result();

$productExists =
    $productResult &&
    $productResult->num_rows > 0;

$productStmt->close();

if (!$productExists) {
    header('Location: ../products.php');
    exit;
}

/* Check whether the product is already in the wishlist. */
$checkStmt = $conn->prepare(
    'SELECT id
     FROM wishlist
     WHERE user_id = ?
     AND product_id = ?
     LIMIT 1'
);

if ($checkStmt) {

    $checkStmt->bind_param(
        'ii',
        $userId,
        $productId
    );

    $checkStmt->execute();

    $checkResult = $checkStmt->get_result();

    $alreadyExists =
        $checkResult &&
        $checkResult->num_rows > 0;

    $checkStmt->close();

    if ($alreadyExists) {
        header('Location: wishlist.php?exists=1');
        exit;
    }
}

/* Add the product to the wishlist. */
$insertStmt = $conn->prepare(
    'INSERT INTO wishlist
     (user_id, product_id, created_at)
     VALUES (?, ?, NOW())'
);

if ($insertStmt) {

    $insertStmt->bind_param(
        'ii',
        $userId,
        $productId
    );

    $insertStmt->execute();

    $insertStmt->close();
}

/* Redirect to the wishlist page. */
header('Location: wishlist.php?added=1');
exit;
?>