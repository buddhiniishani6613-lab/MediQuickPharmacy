
<?php

session_start();

/*
|--------------------------------------------------------------------------
| Database Connection
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/../config/database.php';


/*
|--------------------------------------------------------------------------
| Check Customer Login
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {

    header("Location: ../login.php");
    exit();

}

$userId = (int) $_SESSION['user_id'];

$message = "";
$messageType = "";


/*
|--------------------------------------------------------------------------
| Escape Output
|--------------------------------------------------------------------------
*/

function e($value)
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}


/*
|--------------------------------------------------------------------------
| Update Delivery Address
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $address = trim($_POST['address'] ?? '');
    $city = trim($_POST['city'] ?? '');

    if ($address === '') {

        $message = "Please enter your delivery address.";
        $messageType = "danger";

    } elseif ($city === '') {

        $message = "Please enter your city.";
        $messageType = "danger";

    } else {

        $stmt = $conn->prepare("
            UPDATE users
            SET
                address = ?,
                city = ?
            WHERE id = ?
        ");

        if ($stmt) {

            $stmt->bind_param(
                "ssi",
                $address,
                $city,
                $userId
            );

            if ($stmt->execute()) {

                $message = "Delivery address updated successfully.";
                $messageType = "success";

            } else {

                $message = "Failed to update delivery address.";
                $messageType = "danger";

            }

            $stmt->close();

        } else {

            $message = "Database error occurred.";
            $messageType = "danger";

        }

    }

}


/*
|--------------------------------------------------------------------------
| Get Customer Information
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        full_name,
        email,
        phone,
        address,
        city
    FROM users
    WHERE id = ?
    LIMIT 1
");

if (!$stmt) {
    die("Database error occurred.");
}

$stmt->bind_param("i", $userId);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {

    $stmt->close();

    session_unset();
    session_destroy();

    header("Location: ../login.php");
    exit();

}

$user = $result->fetch_assoc();

$stmt->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>My Address | MediQuick Pharmacy</title>

    <!-- Bootstrap CSS -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Bootstrap Icons -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
        rel="stylesheet"
    >

    <style>

        body {
            background: #f6f9fc;
            font-family: Arial, Helvetica, sans-serif;
        }

        /* Page Banner */

        .address-header {

            background: linear-gradient(
                135deg,
                #006391,
                #0dcaf0
            );

            color: white;

            padding: 45px 20px;

            border-radius: 0 0 25px 25px;

            margin-bottom: 35px;

        }

        .address-header h1 {

            font-weight: 700;

            margin-bottom: 8px;

        }

        .address-header p {

            margin: 0;

            opacity: 0.9;

            font-size: 14px;

        }

        .address-header-icon {

            width: 65px;

            height: 65px;

            min-width: 65px;

            background: rgba(255,255,255,0.18);

            border-radius: 16px;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 32px;

        }

        /* Main Page */

        .address-page {

            min-height: 70vh;

            padding-bottom: 65px;

        }

        /* Main Address Card */

        .address-card {

            background: white;

            border-radius: 20px;

            border: 1px solid #e6edf1;

            padding: 30px;

            box-shadow:
                0 5px 25px rgba(0,0,0,0.06);

        }

        .section-title {

            color: #24373e;

            font-size: 21px;

            font-weight: 700;

            margin-bottom: 8px;

        }

        .section-description {

            color: #7d8b91;

            font-size: 14px;

            margin-bottom: 25px;

        }

        /* Customer Information */

        .customer-info {

            background: #f6fafb;

            border: 1px solid #e5edef;

            border-radius: 14px;

            padding: 20px;

            margin-bottom: 28px;

        }

        .customer-item {

            display: flex;

            align-items: center;

            gap: 13px;

        }

        .customer-item + .customer-item {

            margin-top: 17px;

        }

        .customer-item-icon {

            width: 42px;

            height: 42px;

            min-width: 42px;

            background: #e5f7f6;

            color: #078b91;

            border-radius: 11px;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 18px;

        }

        .customer-label {

            font-size: 12px;

            color: #87959b;

            margin-bottom: 3px;

        }

        .customer-value {

            color: #33474e;

            font-size: 14px;

            font-weight: 600;

            overflow-wrap: anywhere;

        }

        /* Form */

        .form-label {

            color: #40535a;

            font-weight: 600;

            font-size: 14px;

            margin-bottom: 8px;

        }

        .form-control {

            border: 1px solid #dce6e9;

            border-radius: 10px;

            padding: 12px 14px;

            font-size: 14px;

        }

        .form-control:focus {

            border-color: #078b91;

            box-shadow:
                0 0 0 0.2rem rgba(7,139,145,0.12);

        }

        textarea.form-control {

            min-height: 125px;

            resize: vertical;

        }

        .input-group-text {

            background: #f4f8f9;

            border: 1px solid #dce6e9;

            color: #078b91;

            border-radius: 10px 0 0 10px;

        }

        .input-group .form-control {

            border-radius: 0 10px 10px 0;

        }

        /* Buttons */

        .btn-save {

            background: #078b91;

            color: white;

            border: none;

            border-radius: 10px;

            padding: 12px 24px;

            font-weight: 600;

            transition: 0.2s;

        }

        .btn-save:hover {

            background: #056d72;

            color: white;

            transform: translateY(-1px);

        }

        .btn-clear {

            background: white;

            color: #687980;

            border: 1px solid #d7e1e4;

            border-radius: 10px;

            padding: 12px 22px;

            font-weight: 600;

            transition: 0.2s;

        }

        .btn-clear:hover {

            background: #f3f6f7;

            color: #34474d;

        }

        /* Information Box */

        .info-box {

            background: #eef9f8;

            border: 1px solid #d4efed;

            border-radius: 14px;

            padding: 18px;

            margin-top: 28px;

            color: #416267;

            font-size: 13px;

            line-height: 1.7;

        }

        .info-box i {

            color: #078b91;

            font-size: 20px;

        }

        /* Responsive Design */

        @media (max-width: 767px) {

            .address-header {

                padding: 30px 20px;

            }

            .address-header h1 {

                font-size: 25px;

            }

            .address-header-icon {

                width: 55px;

                height: 55px;

                min-width: 55px;

                font-size: 25px;

            }

            .address-card {

                padding: 20px;

            }

            .btn-save,
            .btn-clear {

                width: 100%;

            }

            .address-page {

                padding-bottom: 45px;

            }

        }

    </style>

</head>

<body>

<?php

/*
|--------------------------------------------------------------------------
| Common Website Header
|--------------------------------------------------------------------------
*/

include __DIR__ . '/../includes/header.php';

?>


<!-- Page Banner -->

<section class="address-header">

    <div class="container">

        <div class="d-flex align-items-center gap-3">

            <div class="address-header-icon">

                <i class="bi bi-geo-alt-fill"></i>

            </div>

            <div>

                <h1>My Address</h1>

                <p>
                    Manage your delivery address and keep your
                    information up to date.
                </p>

            </div>

        </div>

    </div>

</section>


<!-- Main Address Section -->

<div class="container address-page">


    <!-- Success and Error Messages -->

    <?php if ($message !== ''): ?>

        <div
            class="alert alert-<?= e($messageType); ?> alert-dismissible fade show"
            role="alert"
        >

            <?php if ($messageType === 'success'): ?>

                <i class="bi bi-check-circle-fill me-2"></i>

            <?php else: ?>

                <i class="bi bi-exclamation-circle-fill me-2"></i>

            <?php endif; ?>

            <?= e($message); ?>

            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="alert"
                aria-label="Close"
            ></button>

        </div>

    <?php endif; ?>


    <div class="row justify-content-center">

        <div class="col-lg-9 col-xl-8">

            <div class="address-card">


                <!-- Section Heading -->

                <h2 class="section-title">

                    <i class="bi bi-house-door me-2 text-primary"></i>

                    Delivery Address

                </h2>

                <p class="section-description">

                    Manage the address where you would like your
                    MediQuick Pharmacy orders to be delivered.

                </p>


                <!-- Customer Information -->

                <div class="customer-info">

                    <h6 class="fw-bold mb-3 text-dark">

                        <i class="bi bi-person-circle me-2 text-primary"></i>

                        Customer Information

                    </h6>


                    <!-- Customer Name -->

                    <div class="customer-item">

                        <div class="customer-item-icon">

                            <i class="bi bi-person"></i>

                        </div>

                        <div>

                            <div class="customer-label">
                                Customer Name
                            </div>

                            <div class="customer-value">

                                <?= e($user['full_name']); ?>

                            </div>

                        </div>

                    </div>


                    <!-- Customer Email -->

                    <div class="customer-item">

                        <div class="customer-item-icon">

                            <i class="bi bi-envelope"></i>

                        </div>

                        <div>

                            <div class="customer-label">
                                Email Address
                            </div>

                            <div class="customer-value">

                                <?= e($user['email']); ?>

                            </div>

                        </div>

                    </div>


                    <!-- Customer Phone -->

                    <div class="customer-item">

                        <div class="customer-item-icon">

                            <i class="bi bi-telephone"></i>

                        </div>

                        <div>

                            <div class="customer-label">
                                Phone Number
                            </div>

                            <div class="customer-value">

                                <?= !empty($user['phone'])
                                    ? e($user['phone'])
                                    : 'Not provided'; ?>

                            </div>

                        </div>

                    </div>

                </div>


                <!-- Address Form -->

                <form method="POST" action="">


                    <!-- Delivery Address -->

                    <div class="mb-4">

                        <label
                            for="address"
                            class="form-label"
                        >

                            Delivery Address

                        </label>

                        <textarea
                            class="form-control"
                            id="address"
                            name="address"
                            placeholder="Enter your complete delivery address"
                            required
                        ><?= e($user['address'] ?? ''); ?></textarea>

                        <div class="form-text">

                            Example: No. 25, Main Street, Kurunegala.

                        </div>

                    </div>


                    <!-- City -->

                    <div class="mb-4">

                        <label
                            for="city"
                            class="form-label"
                        >

                            City

                        </label>

                        <div class="input-group">

                            <span class="input-group-text">

                                <i class="bi bi-buildings"></i>

                            </span>

                            <input
                                type="text"
                                class="form-control"
                                id="city"
                                name="city"
                                value="<?= e($user['city'] ?? ''); ?>"
                                placeholder="Enter your city"
                                required
                            >

                        </div>

                    </div>


                    <!-- Form Buttons -->

                    <div class="d-flex gap-2 flex-wrap">

                        <button
                            type="submit"
                            class="btn-save"
                        >

                            <i class="bi bi-check2-circle me-2"></i>

                            Save Address

                        </button>

                        <button
                            type="reset"
                            class="btn-clear"
                        >

                            <i class="bi bi-arrow-counterclockwise me-2"></i>

                            Reset Changes

                        </button>

                    </div>

                </form>


                <!-- Delivery Information -->

                <div class="info-box">

                    <div class="d-flex gap-3">

                        <i class="bi bi-info-circle-fill"></i>

                        <div>

                            <strong>Delivery Information</strong>

                            <p class="mb-0">

                                Please make sure your delivery address
                                is accurate and complete. Your saved
                                address can be used when placing your
                                MediQuick Pharmacy orders.

                            </p>

                        </div>

                    </div>

                </div>


            </div>

        </div>

    </div>

</div>


<!-- Bootstrap JavaScript -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


<?php

/*
|--------------------------------------------------------------------------
| Common Website Footer
|--------------------------------------------------------------------------
*/

include __DIR__ . '/../includes/footer.php';

?>

</body>
</html>
