<?php

session_start();

/*
 * This file is inside the Customer folder.
 * Therefore ../ is required to access the root config folder.
 */
require_once '../config/database.php';


/*
 * Only POST requests are allowed for order processing.
 */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header("Location: checkout.php");

    exit;
}


/*
 * Get the logged-in user's ID from the session.
 */
$userId = isset($_SESSION['user_id'])
    ? (int)$_SESSION['user_id']
    : 0;


if ($userId <= 0) {

    die("
        <div style='font-family:Arial; text-align:center; margin-top:80px;'>
            <h2>Please login before placing an order.</h2>
            <a href='../login.php'>Go to Login</a>
        </div>
    ");

}


/*
 * Get checkout form data.
 */
$fullName = trim($_POST['full_name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$deliveryAddress = trim($_POST['delivery_address'] ?? '');
$city = trim($_POST['city'] ?? '');
$paymentMethod = trim($_POST['payment_method'] ?? '');
$cartData = $_POST['cart_data'] ?? '';


/*
 * Validate required checkout information.
 */
if (
    empty($fullName) ||
    empty($email) ||
    empty($phone) ||
    empty($deliveryAddress) ||
    empty($city) ||
    empty($paymentMethod) ||
    empty($cartData)
) {

    die("
        <div style='font-family:Arial; text-align:center; margin-top:80px;'>
            <h2>Missing required information.</h2>
            <a href='checkout.php'>Back to Checkout</a>
        </div>
    ");

}


/*
 * Define the payment methods accepted by the system.
 */
$allowedPaymentMethods = [
    'Cash on Delivery',
    'Card Payment'
];


if (!in_array($paymentMethod, $allowedPaymentMethods, true)) {

    die("
        <div style='font-family:Arial; text-align:center; margin-top:80px;'>
            <h2>Invalid payment method.</h2>
            <a href='checkout.php'>Back to Checkout</a>
        </div>
    ");

}


/*
 * Convert the cart JSON data into a PHP array.
 */
$cart = json_decode($cartData, true);


if (!is_array($cart) || empty($cart)) {

    die("
        <div style='font-family:Arial; text-align:center; margin-top:80px;'>
            <h2>Your cart is empty.</h2>
            <a href='../products.php'>Continue Shopping</a>
        </div>
    ");

}


/*
 * Get the logged-in user's current information
 * from the database.
 */
$userStmt = $conn->prepare("
    SELECT id, full_name, email, phone
    FROM users
    WHERE id = ?
    LIMIT 1
");


if (!$userStmt) {

    die("Database error: " . $conn->error);

}


$userStmt->bind_param("i", $userId);

$userStmt->execute();

$userResult = $userStmt->get_result();


if ($userResult->num_rows === 0) {

    $userStmt->close();

    die("
        <div style='font-family:Arial; text-align:center; margin-top:80px;'>
            <h2>User account not found.</h2>
            <a href='../login.php'>Login Again</a>
        </div>
    ");

}


$user = $userResult->fetch_assoc();

$userStmt->close();


/*
 * Use the user information stored in the database.
 */
$fullName = $user['full_name'];

$email = $user['email'];


if (!empty($user['phone'])) {

    $phone = $user['phone'];

}


/*
 * Start a database transaction so that
 * all order operations are completed together.
 */
$conn->begin_transaction();


try {

    $validatedItems = [];

    $subtotal = 0.00;


    /*
     * Validate every product in the cart
     * against the current database information.
     */
    foreach ($cart as $item) {

        $productId = isset($item['id'])
            ? (int)$item['id']
            : 0;

        $quantity = isset($item['quantity'])
            ? (int)$item['quantity']
            : 0;


        if ($productId <= 0 || $quantity <= 0) {

            throw new Exception(
                "Invalid product or quantity in cart."
            );

        }


        /*
         * Get the latest product information
         * and lock the row during the transaction.
         */
        $productStmt = $conn->prepare("
            SELECT
                id,
                name,
                price,
                stock_quantity,
                status
            FROM products
            WHERE id = ?
            LIMIT 1
            FOR UPDATE
        ");


        if (!$productStmt) {

            throw new Exception(
                "Product query failed: " . $conn->error
            );

        }


        $productStmt->bind_param(
            "i",
            $productId
        );

        $productStmt->execute();

        $productResult =
            $productStmt->get_result();


        if ($productResult->num_rows === 0) {

            $productStmt->close();

            throw new Exception(
                "Product ID {$productId} was not found."
            );

        }


        $product =
            $productResult->fetch_assoc();

        $productStmt->close();


        /*
         * Check whether the product is available.
         */
        if ($product['status'] !== 'Available') {

            throw new Exception(
                $product['name'] .
                " is currently not available."
            );

        }


        /*
         * Check whether enough stock is available.
         */
        if (
            (int)$product['stock_quantity']
            < $quantity
        ) {

            throw new Exception(
                "Not enough stock for " .
                $product['name'] .
                ". Available stock: " .
                $product['stock_quantity']
            );

        }


        /*
         * Use the price stored in the database
         * instead of trusting the browser price.
         */
        $unitPrice =
            (float)$product['price'];

        $itemTotal =
            $unitPrice * $quantity;

        $subtotal += $itemTotal;


        /*
         * Save the validated product information
         * for the order insertion.
         */
        $validatedItems[] = [

            'product_id' =>
                $product['id'],

            'product_name' =>
                $product['name'],

            'quantity' =>
                $quantity,

            'unit_price' =>
                $unitPrice,

            'total_price' =>
                $itemTotal

        ];

    }


    /*
     * Calculate delivery fee.
     *
     * Orders of Rs. 5,000 or more receive
     * free delivery.
     */
    if ($subtotal >= 5000) {

        $deliveryFee = 0.00;

    } else {

        $deliveryFee = 350.00;

    }


    /*
     * Calculate the final order amount.
     */
    $totalAmount =
        $subtotal + $deliveryFee;


    /*
     * Generate a unique order number.
     */
    do {

        $orderNumber =
            'MQ' .
            date('YmdHis') .
            random_int(100, 999);


        $checkOrderStmt =
            $conn->prepare("
                SELECT id
                FROM orders
                WHERE order_number = ?
                LIMIT 1
            ");


        if (!$checkOrderStmt) {

            throw new Exception(
                "Order number check failed: " .
                $conn->error
            );

        }


        $checkOrderStmt->bind_param(
            "s",
            $orderNumber
        );


        $checkOrderStmt->execute();


        $checkResult =
            $checkOrderStmt->get_result();


        $exists =
            $checkResult->num_rows > 0;


        $checkOrderStmt->close();


    } while ($exists);


    /*
     * Insert the main order record.
     */
    $orderStatus = 'Pending';


    $orderStmt = $conn->prepare("
        INSERT INTO orders
        (
            user_id,
            order_number,
            full_name,
            email,
            phone,
            delivery_address,
            city,
            payment_method,
            subtotal,
            delivery_fee,
            total_amount,
            order_status
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");


    if (!$orderStmt) {

        throw new Exception(
            "Order insert preparation failed: " .
            $conn->error
        );

    }


    $orderStmt->bind_param(
        "isssssssddds",
        $userId,
        $orderNumber,
        $fullName,
        $email,
        $phone,
        $deliveryAddress,
        $city,
        $paymentMethod,
        $subtotal,
        $deliveryFee,
        $totalAmount,
        $orderStatus
    );


    if (!$orderStmt->execute()) {

        throw new Exception(
            "Order could not be saved: " .
            $orderStmt->error
        );

    }


    $orderId =
        $conn->insert_id;


    $orderStmt->close();


    /*
     * Insert each product into order_items
     * and reduce its stock.
     */
    foreach ($validatedItems as $item) {

        $itemStmt = $conn->prepare("
            INSERT INTO order_items
            (
                order_id,
                product_id,
                product_name,
                quantity,
                unit_price,
                total_price
            )
            VALUES (?, ?, ?, ?, ?, ?)
        ");


        if (!$itemStmt) {

            throw new Exception(
                "Order item preparation failed: " .
                $conn->error
            );

        }


        $itemStmt->bind_param(
            "iisidd",
            $orderId,
            $item['product_id'],
            $item['product_name'],
            $item['quantity'],
            $item['unit_price'],
            $item['total_price']
        );


        if (!$itemStmt->execute()) {

            throw new Exception(
                "Order item could not be saved: " .
                $itemStmt->error
            );

        }


        $itemStmt->close();


        /*
         * Reduce product stock and automatically
         * update the product status.
         */
        $newStock =
            $item['quantity'];


        $stockStmt = $conn->prepare("
            UPDATE products
            SET
                stock_quantity =
                    stock_quantity - ?,

                status =
                    CASE
                        WHEN stock_quantity - ? <= 0
                            THEN 'Out of Stock'
                        ELSE 'Available'
                    END
            WHERE id = ?
        ");


        if (!$stockStmt) {

            throw new Exception(
                "Stock update preparation failed: " .
                $conn->error
            );

        }


        $stockStmt->bind_param(
            "iii",
            $newStock,
            $newStock,
            $item['product_id']
        );


        if (!$stockStmt->execute()) {

            throw new Exception(
                "Stock could not be updated: " .
                $stockStmt->error
            );

        }


        $stockStmt->close();

    }


    /*
     * Insert payment information.
     */
    $paymentStatus = 'Pending';

    $transactionReference = null;


    $paymentStmt = $conn->prepare("
        INSERT INTO payments
        (
            order_id,
            payment_method,
            amount,
            payment_status,
            transaction_reference
        )
        VALUES (?, ?, ?, ?, ?)
    ");


    if (!$paymentStmt) {

        throw new Exception(
            "Payment preparation failed: " .
            $conn->error
        );

    }


    $paymentStmt->bind_param(
        "isdss",
        $orderId,
        $paymentMethod,
        $totalAmount,
        $paymentStatus,
        $transactionReference
    );


    if (!$paymentStmt->execute()) {

        throw new Exception(
            "Payment could not be saved: " .
            $paymentStmt->error
        );

    }


    $paymentStmt->close();


    /*
     * Commit the transaction after all
     * order operations are successful.
     */
    $conn->commit();

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Order Successful - MediQuick Pharmacy
    </title>


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >


    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    >


    <style>

        body {

            background: #f4f9ff;

            font-family: Arial, sans-serif;

        }


        .success-container {

            max-width: 650px;

            margin: 80px auto;

            padding: 20px;

        }


        .success-card {

            background: white;

            border-radius: 20px;

            padding: 45px 35px;

            text-align: center;

            box-shadow:
                0 10px 35px
                rgba(0,0,0,0.08);

        }


        .success-icon {

            width: 90px;

            height: 90px;

            margin: 0 auto 25px;

            border-radius: 50%;

            background: #e8f8ef;

            display: flex;

            align-items: center;

            justify-content: center;

            color: #198754;

            font-size: 48px;

        }


        .success-card h1 {

            color: #198754;

            font-weight: 700;

            margin-bottom: 15px;

        }


        .order-number {

            background: #f0f7ff;

            padding: 15px;

            border-radius: 12px;

            margin: 25px 0;

        }


        .order-number strong {

            color: #0d6efd;

            font-size: 20px;

        }


        .summary {

            background: #f8f9fa;

            border-radius: 12px;

            padding: 20px;

            text-align: left;

            margin-bottom: 25px;

        }


        .summary-row {

            display: flex;

            justify-content: space-between;

            padding: 8px 0;

        }


        .summary-row.total {

            border-top: 1px solid #ddd;

            margin-top: 10px;

            padding-top: 15px;

            font-size: 20px;

            font-weight: bold;

        }


        .free-delivery {

            color: #198754;

            font-weight: bold;

        }


        .btn-custom {

            border-radius: 10px;

            padding: 12px 22px;

            margin: 5px;

        }

    </style>

</head>


<body>


<div class="success-container">

    <div class="success-card">

        <div class="success-icon">

            <i class="bi bi-check-lg"></i>

        </div>


        <h1>
            Order Placed Successfully!
        </h1>


        <p class="text-muted">
            Thank you for shopping with MediQuick Pharmacy.
        </p>


        <div class="order-number">

            <div class="text-muted mb-1">
                Your Order Number
            </div>

            <strong>
                <?php
                echo htmlspecialchars($orderNumber);
                ?>
            </strong>

        </div>


        <div class="summary">

            <div class="summary-row">

                <span>
                    Subtotal
                </span>

                <strong>

                    Rs.

                    <?php
                    echo number_format(
                        $subtotal,
                        2
                    );
                    ?>

                </strong>

            </div>


            <div class="summary-row">

                <span>
                    Delivery Fee
                </span>


                <?php if ($deliveryFee == 0): ?>

                    <span class="free-delivery">
                        FREE
                    </span>

                <?php else: ?>

                    <strong>

                        Rs.

                        <?php
                        echo number_format(
                            $deliveryFee,
                            2
                        );
                        ?>

                    </strong>

                <?php endif; ?>

            </div>


            <?php if ($deliveryFee == 0): ?>

                <div class="text-center mt-2">

                    <small class="text-success">

                        <i class="bi bi-truck"></i>

                        Free delivery applied for orders
                        of Rs. 5,000 or more.

                    </small>

                </div>

            <?php endif; ?>


            <div class="summary-row total">

                <span>
                    Total
                </span>

                <span class="text-primary">

                    Rs.

                    <?php
                    echo number_format(
                        $totalAmount,
                        2
                    );
                    ?>

                </span>

            </div>

        </div>


        <div>

            <a
                href="../products.php"
                class="btn btn-primary btn-custom"
            >

                <i class="bi bi-cart"></i>

                Continue Shopping

            </a>


            <a
                href="customer-dashboard.php"
                class="btn btn-outline-primary btn-custom"
            >

                <i class="bi bi-speedometer2"></i>

                My Dashboard

            </a>

        </div>

    </div>

</div>


<script>

/*
 * Clear the active cart after
 * the order has been successfully placed.
 */

localStorage.removeItem('mediquickCart');


/*
 * Clear the old cart key if it exists.
 */

localStorage.removeItem('cart');

</script>


</body>

</html>


<?php

} catch (Exception $e) {

    /*
     * Roll back all database changes if
     * any part of the order process fails.
     */

    $conn->rollback();

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Order Error - MediQuick Pharmacy
    </title>


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >


    <style>

        body {

            background: #f8f9fa;

            font-family: Arial, sans-serif;

        }


        .error-container {

            max-width: 600px;

            margin: 100px auto;

            padding: 20px;

        }


        .error-card {

            background: white;

            border-radius: 18px;

            padding: 40px;

            text-align: center;

            box-shadow:
                0 10px 30px
                rgba(0,0,0,0.08);

        }


        .error-icon {

            font-size: 60px;

            color: #dc3545;

            margin-bottom: 20px;

        }

    </style>

</head>


<body>


<div class="error-container">

    <div class="error-card">

        <div class="error-icon">

            !

        </div>


        <h2 class="text-danger">

            Order Could Not Be Placed

        </h2>


        <p class="text-muted mt-3">

            <?php

            echo htmlspecialchars(
                $e->getMessage()
            );

            ?>

        </p>


        <a
            href="checkout.php"
            class="btn btn-primary mt-3"
        >
            Back to Checkout
        </a>

    </div>

</div>


</body>

</html>

<?php

}

?>