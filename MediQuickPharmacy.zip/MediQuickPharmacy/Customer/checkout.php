
<?php

session_start();

/*
Database Connection
*/

require_once __DIR__ . '/../config/database.php';


/*
Check Customer Login
*/

$userId = isset($_SESSION['user_id'])
    ? (int) $_SESSION['user_id']
    : 0;

if ($userId <= 0) {
    header("Location: ../login.php");
    exit;
}


/*
Load Customer Information
*/

$userStmt = $conn->prepare("
    SELECT id, full_name, email, phone
    FROM users
    WHERE id = ?
    LIMIT 1
");

if (!$userStmt) {
    die("Database connection error.");
}

$userStmt->bind_param("i", $userId);
$userStmt->execute();

$userResult = $userStmt->get_result();

if ($userResult->num_rows !== 1) {
    $userStmt->close();

    session_destroy();

    header("Location: ../login.php");
    exit;
}

$user = $userResult->fetch_assoc();

$userStmt->close();


/*
Image Name Normalization
*/

function normalizeImageName($name)
{
    $name = strtolower(trim($name));

    $name = preg_replace(
        '/\.(jpg|jpeg|png|webp)$/i',
        '',
        $name
    );

    $name = preg_replace(
        '/[^a-z0-9]+/',
        ' ',
        $name
    );

    $name = preg_replace(
        '/\s+/',
        ' ',
        $name
    );

    return trim($name);
}


/*
Find Product Image From Image Folders
*/

function getProductImageFromFolder($productName)
{
    $rootFolder = dirname(__DIR__);

    $possibleFolders = [
        $rootFolder . '/assets/images/products',
        $rootFolder . '/images/products'
    ];

    $normalizedProduct = normalizeImageName($productName);

    $exactMatch = '';
    $partialMatch = '';

    foreach ($possibleFolders as $folder) {

        if (!is_dir($folder)) {
            continue;
        }

        try {

            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator(
                    $folder,
                    FilesystemIterator::SKIP_DOTS
                )
            );

        } catch (Exception $e) {

            continue;
        }

        foreach ($iterator as $file) {

            if (!$file->isFile()) {
                continue;
            }

            $extension = strtolower($file->getExtension());

            if (!in_array($extension, [
                'jpg',
                'jpeg',
                'png',
                'webp'
            ], true)) {
                continue;
            }

            $fileName = pathinfo(
                $file->getFilename(),
                PATHINFO_FILENAME
            );

            $normalizedFile = normalizeImageName($fileName);

            if ($normalizedFile === $normalizedProduct) {

                $exactMatch = $file->getPathname();

                break 2;
            }

            if (
                $normalizedFile !== '' &&
                (
                    strpos($normalizedProduct, $normalizedFile) === 0 ||
                    strpos($normalizedFile, $normalizedProduct) === 0
                ) &&
                $partialMatch === ''
            ) {

                $partialMatch = $file->getPathname();
            }
        }
    }

    $foundFile = $exactMatch ?: $partialMatch;

    if ($foundFile === '') {
        return '';
    }

    $relativePath = str_replace(
        '\\',
        '/',
        substr($foundFile, strlen($rootFolder))
    );

    $parts = explode('/', ltrim($relativePath, '/'));

    $encodedParts = array_map('rawurlencode', $parts);

    return '../' . implode('/', $encodedParts);
}


/*
Resolve Database Product Image Path
*/

function getDatabaseProductImage($image)
{
    $image = trim(str_replace('\\', '/', $image));

    if ($image === '') {
        return '';
    }

    $rootFolder = dirname(__DIR__);

    $relativePath = ltrim($image, '/');

    if (strpos($relativePath, 'assets/') === 0) {

        $candidates = [
            $rootFolder . '/' . $relativePath
        ];

    } elseif (strpos($relativePath, 'images/products/') === 0) {

        $candidates = [
            $rootFolder . '/assets/' . $relativePath,
            $rootFolder . '/' . $relativePath
        ];

    } else {

        $candidates = [
            $rootFolder . '/' . $relativePath
        ];
    }

    foreach ($candidates as $candidate) {

        $realFile = realpath($candidate);

        if (
            $realFile !== false &&
            is_file($realFile) &&
            (
                strpos(
                    $realFile,
                    realpath($rootFolder) . DIRECTORY_SEPARATOR
                ) === 0
            )
        ) {

            $relativeFile = str_replace(
                '\\',
                '/',
                substr(
                    $realFile,
                    strlen(realpath($rootFolder)) + 1
                )
            );

            $parts = explode('/', $relativeFile);

            $encodedParts = array_map(
                'rawurlencode',
                $parts
            );

            return '../' . implode('/', $encodedParts);
        }
    }

    return '';
}


/*
AJAX Product Information Resolver
*/

if (
    isset($_GET['resolve_images']) &&
    $_GET['resolve_images'] === '1'
) {

    header('Content-Type: application/json; charset=utf-8');

    $idsString = $_GET['ids'] ?? '';

    $idsArray = [];

    foreach (explode(',', $idsString) as $id) {

        $id = (int) $id;

        if ($id > 0) {
            $idsArray[] = $id;
        }
    }

    $idsArray = array_values(array_unique($idsArray));

    if (empty($idsArray)) {

        echo json_encode([
            'success' => false,
            'images' => []
        ]);

        exit;
    }

    $placeholders = implode(
        ',',
        array_fill(0, count($idsArray), '?')
    );

    $sql = "
        SELECT
            id,
            name,
            category,
            price,
            stock_quantity,
            image,
            status
        FROM products
        WHERE id IN ($placeholders)
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {

        http_response_code(500);

        echo json_encode([
            'success' => false,
            'images' => []
        ]);

        exit;
    }

    $types = str_repeat('i', count($idsArray));

    $stmt->bind_param($types, ...$idsArray);

    $stmt->execute();

    $result = $stmt->get_result();

    $products = [];

    while ($row = $result->fetch_assoc()) {

        $productId = (int) $row['id'];

        /*
         * First use the database image path.
         */
        $imagePath = getDatabaseProductImage(
            $row['image'] ?? ''
        );

        /*
         * Search the product folders if the database
         * image path is unavailable.
         */
        if ($imagePath === '') {

            $imagePath = getProductImageFromFolder(
                $row['name']
            );
        }

        $products[$productId] = [

            'id' => $productId,

            'name' => $row['name'],

            'category' => $row['category'],

            'price' => (float) $row['price'],

            'stock' => (int) $row['stock_quantity'],

            'status' => $row['status'],

            'image' => $imagePath
        ];
    }

    $stmt->close();

    echo json_encode(
        [
            'success' => true,
            'images' => $products
        ],
        JSON_UNESCAPED_SLASHES |
        JSON_UNESCAPED_UNICODE
    );

    exit;
}


/*
Load Website Header
*/

include '../includes/header.php';

?>

<section class="checkout-section">

    <div class="checkout-container">

        <!-- Page Heading -->
        <div class="checkout-heading">

            <span class="small-title">
                MEDIQUICK PHARMACY
            </span>

            <h1>Checkout</h1>

            <p>
                Complete your delivery and payment details.
            </p>

        </div>


        <div class="checkout-layout">

            <!-- Delivery Information -->
            <div class="checkout-form-box">

                <h2>
                    <i class="bi bi-person"></i>
                    Delivery Information
                </h2>


                <form
                    id="checkoutForm"
                    method="POST"
                    action="checkout-process.php"
                >

                    <!-- Customer details come from the PHP session. -->
                    <input
                        type="hidden"
                        name="user_id"
                        value="<?php echo (int) $userId; ?>"
                    >

                    <!-- Cart data will be added before submission. -->
                    <input
                        type="hidden"
                        name="cart_data"
                        id="cartData"
                    >


                    <!-- Full Name -->
                    <div class="form-group">

                        <label for="fullName">
                            Full Name
                        </label>

                        <div class="input-wrapper">

                            <i class="bi bi-person"></i>

                            <input
                                type="text"
                                name="full_name"
                                id="fullName"
                                value="<?php echo htmlspecialchars($user['full_name'], ENT_QUOTES, 'UTF-8'); ?>"
                                placeholder="Enter your full name"
                                required
                            >

                        </div>

                    </div>


                    <!-- Email -->
                    <div class="form-group">

                        <label for="email">
                            Email Address
                        </label>

                        <div class="input-wrapper">

                            <i class="bi bi-envelope"></i>

                            <input
                                type="email"
                                name="email"
                                id="email"
                                value="<?php echo htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?>"
                                placeholder="Enter your email address"
                                required
                            >

                        </div>

                    </div>


                    <!-- Phone -->
                    <div class="form-group">

                        <label for="phone">
                            Phone Number
                        </label>

                        <div class="input-wrapper">

                            <i class="bi bi-telephone"></i>

                            <input
                                type="tel"
                                name="phone"
                                id="phone"
                                value="<?php echo htmlspecialchars($user['phone'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                placeholder="Enter your phone number"
                                required
                            >

                        </div>

                    </div>


                    <!-- Delivery Address -->
                    <div class="form-group">

                        <label for="address">
                            Delivery Address
                        </label>

                        <div class="input-wrapper textarea-wrapper">

                            <i class="bi bi-geo-alt"></i>

                            <textarea
                                name="delivery_address"
                                id="address"
                                placeholder="Enter your delivery address"
                                rows="4"
                                required
                            ></textarea>

                        </div>

                    </div>


                    <!-- City -->
                    <div class="form-group">

                        <label for="city">
                            City
                        </label>

                        <div class="input-wrapper">

                            <i class="bi bi-building"></i>

                            <input
                                type="text"
                                name="city"
                                id="city"
                                placeholder="Enter your city"
                                required
                            >

                        </div>

                    </div>


                    <!-- Payment Method -->
                    <div class="form-group">

                        <label>
                            Payment Method
                        </label>

                        <div class="payment-options">

                            <label class="payment-option">

                                <input
                                    type="radio"
                                    name="payment_method"
                                    value="Cash on Delivery"
                                    checked
                                >

                                <div>

                                    <i class="bi bi-cash-stack"></i>

                                    <strong>
                                        Cash on Delivery
                                    </strong>

                                    <small>
                                        Pay when your order arrives.
                                    </small>

                                </div>

                            </label>


                            <label class="payment-option">

                                <input
                                    type="radio"
                                    name="payment_method"
                                    value="Card Payment"
                                >

                                <div>

                                    <i class="bi bi-credit-card"></i>

                                    <strong>
                                        Card Payment
                                    </strong>

                                    <small>
                                        Card payment option.
                                    </small>

                                </div>

                            </label>

                        </div>

                    </div>


                    <!-- Place Order -->
                    <button
                        type="submit"
                        class="place-order-button"
                        id="placeOrderButton"
                    >

                        <i class="bi bi-check-circle"></i>

                        Place Order

                    </button>


                    <a
                        href="../cart.php"
                        class="back-cart"
                    >

                        <i class="bi bi-arrow-left"></i>

                        Back to Cart

                    </a>

                </form>

            </div>


            <!-- Order Summary -->
            <div class="checkout-summary">

                <h2>

                    <i class="bi bi-receipt"></i>

                    Order Summary

                </h2>


                <div
                    id="checkoutItems"
                    class="checkout-items"
                >

                    <p class="text-muted text-center">
                        Loading cart items...
                    </p>

                </div>


                <hr>


                <div class="summary-line">

                    <span>Items</span>

                    <span id="itemCount">0</span>

                </div>


                <div class="summary-line">

                    <span>Subtotal</span>

                    <span>
                        Rs. <span id="subtotal">0.00</span>
                    </span>

                </div>


                <div class="summary-line">

                    <span>Delivery Fee</span>

                    <span id="deliveryWrapper">
                        Rs. <span id="delivery">350.00</span>
                    </span>

                </div>


                <div
                    id="freeDeliveryMessage"
                    class="free-delivery-message"
                    style="display:none;"
                >

                    <i class="bi bi-truck"></i>

                    Free Delivery Applied!

                </div>


                <hr>


                <div class="total-line">

                    <span>Total</span>

                    <strong>
                        Rs. <span id="total">0.00</span>
                    </strong>

                </div>


                <div class="delivery-info">

                    <i class="bi bi-info-circle"></i>

                    <span>
                        Orders of Rs. 5,000 or more qualify
                        for FREE delivery.
                    </span>

                </div>

            </div>

        </div>

    </div>

</section>


<style>

/* Main checkout section */
.checkout-section {
    background: #f6fbfd;
    min-height: 75vh;
    padding: 60px 20px;
}

/* Main container */
.checkout-container {
    max-width: 1150px;
    margin: auto;
}

/* Heading */
.checkout-heading {
    text-align: center;
    margin-bottom: 40px;
}

.small-title {
    color: #087f9b;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 2px;
}

.checkout-heading h1 {
    color: #174f68;
    margin: 8px 0;
    font-size: 32px;
}

.checkout-heading p {
    color: #777;
}

/* Checkout layout */
.checkout-layout {
    display: grid;
    grid-template-columns: 1fr 380px;
    gap: 30px;
    align-items: start;
}

/* Form container */
.checkout-form-box {
    background: white;
    border-radius: 16px;
    padding: 30px;
    box-shadow: 0 5px 20px rgba(0, 80, 110, 0.08);
}

.checkout-form-box h2,
.checkout-summary h2 {
    color: #174f68;
    font-size: 21px;
    margin: 0 0 25px;
}

.checkout-form-box h2 i,
.checkout-summary h2 i {
    color: #087f9b;
    margin-right: 7px;
}

/* Form fields */
.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    color: #174f68;
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 8px;
}

/* Input wrappers */
.input-wrapper {
    position: relative;
}

.input-wrapper > i {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: #087f9b;
    pointer-events: none;
}

.textarea-wrapper > i {
    top: 22px;
    transform: none;
}

/* Inputs */
.input-wrapper input,
.input-wrapper textarea {
    width: 100%;
    box-sizing: border-box;
    border: 1px solid #d8e5e9;
    border-radius: 8px;
    padding: 13px 15px 13px 42px;
    outline: none;
    font-family: inherit;
    font-size: 14px;
    transition: 0.2s;
}

.input-wrapper textarea {
    resize: vertical;
    min-height: 100px;
}

/* Input focus */
.input-wrapper input:focus,
.input-wrapper textarea:focus {
    border-color: #087f9b;
    box-shadow: 0 0 0 3px rgba(8, 127, 155, 0.08);
}

/* Payment options */
.payment-options {
    display: grid;
    gap: 12px;
}

.payment-option {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    border: 1px solid #d8e5e9;
    border-radius: 10px;
    padding: 14px;
    cursor: pointer;
    transition: 0.2s;
}

.payment-option:hover {
    border-color: #087f9b;
    background: #f8fcfd;
}

.payment-option input {
    margin-top: 4px;
    accent-color: #087f9b;
}

.payment-option i {
    color: #087f9b;
    font-size: 20px;
    margin-right: 6px;
}

.payment-option strong {
    color: #174f68;
    font-size: 14px;
}

.payment-option small {
    display: block;
    color: #777;
    font-size: 12px;
    margin-top: 4px;
}

/* Place order button */
.place-order-button {
    width: 100%;
    border: none;
    background: #087f9b;
    color: white;
    padding: 14px;
    border-radius: 9px;
    font-size: 16px;
    font-weight: 700;
    cursor: pointer;
    transition: 0.2s;
}

.place-order-button:hover {
    background: #056b83;
}

.place-order-button:disabled {
    background: #9aabb0;
    cursor: not-allowed;
}

/* Back to cart */
.back-cart {
    display: block;
    text-align: center;
    margin-top: 18px;
    color: #087f9b;
    text-decoration: none;
    font-weight: 600;
    font-size: 14px;
}

/* Order summary */
.checkout-summary {
    background: white;
    border-radius: 16px;
    padding: 25px;
    box-shadow: 0 5px 20px rgba(0, 80, 110, 0.08);
    position: sticky;
    top: 20px;
}

/* Checkout products */
.checkout-items {
    max-height: 350px;
    overflow-y: auto;
}

.checkout-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 0;
    border-bottom: 1px solid #edf1f3;
}

.checkout-item-image {
    width: 55px;
    height: 55px;
    background: #f5fafc;
    border-radius: 8px;
    overflow: hidden;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
}

.checkout-item-image img {
    width: 100%;
    height: 100%;
    object-fit: contain;
    padding: 4px;
    display: block;
}

.checkout-image-fallback {
    color: #9aaeb5;
    font-size: 10px;
    text-align: center;
    padding: 5px;
}

.checkout-item-details {
    flex: 1;
    min-width: 0;
}

.checkout-item-details h4 {
    color: #174f68;
    font-size: 14px;
    margin: 0 0 4px;
}

.checkout-item-details p {
    color: #777;
    font-size: 12px;
    margin: 0;
}

.checkout-item-total {
    color: #087f9b;
    font-size: 13px;
    font-weight: 700;
    white-space: nowrap;
}

/* Summary rows */
.summary-line {
    display: flex;
    justify-content: space-between;
    margin-bottom: 15px;
    color: #555;
    font-size: 14px;
}

.checkout-summary hr {
    border: none;
    border-top: 1px solid #e7eef1;
    margin: 20px 0;
}

/* Free delivery */
.free-delivery-message {
    margin-top: -5px;
    margin-bottom: 15px;
    padding: 10px 12px;
    background: #eaf9f0;
    color: #198754;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 700;
}

.free-delivery-message i {
    margin-right: 5px;
}

/* Total */
.total-line {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 20px 0;
}

.total-line span {
    color: #174f68;
    font-size: 18px;
    font-weight: 700;
}

.total-line strong {
    color: #087f9b;
    font-size: 22px;
}

/* Delivery information */
.delivery-info {
    display: flex;
    gap: 8px;
    align-items: flex-start;
    background: #eef8fc;
    color: #53717e;
    padding: 11px;
    border-radius: 9px;
    font-size: 11px;
    line-height: 1.5;
}

.delivery-info i {
    color: #087f9b;
    font-size: 14px;
    margin-top: 1px;
}

/* Tablet */
@media (max-width: 850px) {

    .checkout-layout {
        grid-template-columns: 1fr;
    }

    .checkout-summary {
        position: static;
    }
}

/* Mobile */
@media (max-width: 500px) {

    .checkout-section {
        padding: 40px 15px;
    }

    .checkout-form-box,
    .checkout-summary {
        padding: 20px;
    }

    .checkout-heading h1 {
        font-size: 27px;
    }
}

</style>


<script>

/*
Escape HTML Characters
*/

function escapeHTML(value)
{
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


/*
Get Product ID
*/

function getProductId(item)
{
    return Number(
        item.product_id ||
        item.productId ||
        item.id ||
        item.productID ||
        0
    );
}


/*
Get Product Quantity
*/

function getQuantity(item)
{
    return Number(
        item.quantity ||
        item.qty ||
        item.count ||
        0
    );
}


/*
Load Checkout Information
*/

document.addEventListener(
    "DOMContentLoaded",
    async function()
    {

        const checkoutItems = document.getElementById(
            "checkoutItems"
        );

        const checkoutForm = document.getElementById(
            "checkoutForm"
        );

        const placeOrderButton = document.getElementById(
            "placeOrderButton"
        );

        const cartDataInput = document.getElementById(
            "cartData"
        );


        /*
         * Read the shopping cart.
         */
        let cart = [];

        try {

            cart = JSON.parse(
                localStorage.getItem("mediquickCart")
            ) || [];

        } catch (error) {

            cart = [];
        }


        /*
         * Redirect if the cart is empty.
         */
        if (!Array.isArray(cart) || cart.length === 0) {

            alert("Your cart is empty.");

            window.location.href = "../products.php";

            return;
        }


        /*
         * Validate cart items.
         */
        const invalidCart = cart.some(function(item) {

            return (
                !Number.isSafeInteger(getProductId(item)) ||
                getProductId(item) <= 0 ||
                !Number.isSafeInteger(getQuantity(item)) ||
                getQuantity(item) <= 0
            );

        });


        if (invalidCart) {

            alert(
                "Invalid cart items found. Please update your cart."
            );

            window.location.href = "../cart.php";

            return;
        }


        /*
         * Get unique product IDs.
         */
        const productIds = [
            ...new Set(
                cart.map(function(item) {
                    return getProductId(item);
                })
            )
        ];


        /*
         * Get the latest product information from the database.
         */
        let databaseProducts = {};

        try {

            const response = await fetch(
                "checkout.php?resolve_images=1&ids=" +
                encodeURIComponent(productIds.join(",")),
                {
                    method: "GET",
                    cache: "no-store",
                    credentials: "same-origin"
                }
            );


            if (!response.ok) {

                throw new Error("Product loading failed.");
            }


            const data = await response.json();


            if (!data.success || !data.images) {

                throw new Error("Invalid product response.");
            }


            databaseProducts = data.images;


        } catch (error) {

            console.error(error);

            checkoutItems.innerHTML = `
                <p class="text-danger">
                    Unable to load product information.
                    Please refresh the page.
                </p>
            `;

            placeOrderButton.disabled = true;

            return;
        }


        /*
         * Prepare order summary.
         */
        let itemCount = 0;

        let subtotal = 0;

        checkoutItems.innerHTML = "";


        /*
         * Display cart products.
         */
        for (const item of cart) {

            const productId = getProductId(item);

            const quantity = getQuantity(item);

            const product = databaseProducts[productId];


            /*
             * Ensure that every product exists.
             */
            if (!product) {

                checkoutItems.innerHTML = `
                    <p class="text-danger">
                        A product in your cart could not be found.
                        Please update your cart.
                    </p>
                `;

                placeOrderButton.disabled = true;

                return;
            }


            /*
             * Check product availability.
             */
            if (
                product.status !== "Available" ||
                Number(product.stock) < quantity
            ) {

                checkoutItems.innerHTML = `
                    <p class="text-danger">
                        ${escapeHTML(product.name)}
                        is unavailable or has insufficient stock.
                        Please update your cart.
                    </p>
                `;

                placeOrderButton.disabled = true;

                return;
            }


            const productName = product.name;

            const price = Number(product.price);

            const itemTotal = price * quantity;


            if (
                !Number.isFinite(price) ||
                price < 0
            ) {

                placeOrderButton.disabled = true;

                return;
            }


            itemCount += quantity;

            subtotal += itemTotal;


            /*
             * Get the product image.
             */
            const imagePath = product.image || "";


            /*
             * Create the product element.
             */
            const itemDiv = document.createElement("div");

            itemDiv.className = "checkout-item";


            let imageHTML = `
                <div class="checkout-image-fallback">
                    Image not available
                </div>
            `;


            if (imagePath !== "") {

                imageHTML = `
                    <img
                        src="${escapeHTML(imagePath)}"
                        alt="${escapeHTML(productName)}"
                        class="checkout-product-image"
                    >
                `;
            }


            itemDiv.innerHTML = `

                <div class="checkout-item-image">

                    ${imageHTML}

                </div>

                <div class="checkout-item-details">

                    <h4>
                        ${escapeHTML(productName)}
                    </h4>

                    <p>
                        Rs. ${price.toFixed(2)}
                        × ${quantity}
                    </p>

                </div>

                <div class="checkout-item-total">

                    Rs. ${itemTotal.toFixed(2)}

                </div>

            `;


            /*
             * Show fallback when the product image fails.
             */
            const imageElement = itemDiv.querySelector(
                ".checkout-product-image"
            );


            if (imageElement) {

                imageElement.addEventListener(
                    "error",
                    function()
                    {

                        const fallback = document.createElement("div");

                        fallback.className =
                            "checkout-image-fallback";

                        fallback.textContent =
                            "Image not available";

                        this.replaceWith(fallback);

                    }
                );
            }


            checkoutItems.appendChild(itemDiv);

        }


        /*
         * Calculate delivery fee.
         */
        const deliveryFee = subtotal >= 5000 ? 0 : 350;


        /*
         * Calculate total amount.
         */
        const total = subtotal + deliveryFee;


        /*
         * Update order summary.
         */
        document.getElementById("itemCount").textContent =
            itemCount;

        document.getElementById("subtotal").textContent =
            subtotal.toFixed(2);

        document.getElementById("total").textContent =
            total.toFixed(2);


        /*
         * Display delivery fee and free delivery message.
         */
        const deliveryWrapper = document.getElementById(
            "deliveryWrapper"
        );

        const freeDeliveryMessage = document.getElementById(
            "freeDeliveryMessage"
        );


        if (deliveryFee === 0) {

            deliveryWrapper.innerHTML = `
                <span style="color:#198754;font-weight:700;">
                    FREE
                </span>
            `;

            freeDeliveryMessage.style.display = "block";

        } else {

            deliveryWrapper.innerHTML = `
                Rs. ${deliveryFee.toFixed(2)}
            `;

            freeDeliveryMessage.style.display = "none";
        }


        /*
         * Check for duplicate submissions.
         */
        let isSubmitting = false;


        /*
         * Prepare cart data before submitting the form.
         */
        checkoutForm.addEventListener(
            "submit",
            function(event)
            {

                if (isSubmitting) {

                    event.preventDefault();

                    return;
                }


                /*
                 * Read the latest cart.
                 */
                let latestCart = [];

                try {

                    latestCart = JSON.parse(
                        localStorage.getItem("mediquickCart")
                    ) || [];

                } catch (error) {

                    latestCart = [];
                }


                if (
                    !Array.isArray(latestCart) ||
                    latestCart.length === 0
                ) {

                    event.preventDefault();

                    alert("Your cart is empty.");

                    return;
                }


                /*
                 * Validate the latest cart.
                 */
                const invalidProduct = latestCart.some(
                    function(item)
                    {

                        return (
                            getProductId(item) <= 0 ||
                            getQuantity(item) <= 0
                        );

                    }
                );


                if (invalidProduct) {

                    event.preventDefault();

                    alert(
                        "Invalid cart items. Please update your cart."
                    );

                    return;
                }


                /*
                 * Prepare the format expected by checkout-process.php.
                 */
                const normalizedCart = latestCart.map(
                    function(item)
                    {

                        return {

                            id: getProductId(item),

                            quantity: getQuantity(item)

                        };

                    }
                );


                /*
                 * Add normalized cart data to the hidden field.
                 */
                cartDataInput.value = JSON.stringify(
                    normalizedCart
                );


                /*
                 * Disable the button to prevent duplicate orders.
                 */
                isSubmitting = true;

                placeOrderButton.disabled = true;

                placeOrderButton.innerHTML = `
                    <i class="bi bi-hourglass-split"></i>
                    Processing Order...
                `;

            }
        );

    }
);

</script>


<?php

/*
Load Website Footer
*/
include '../includes/footer.php';

?>
