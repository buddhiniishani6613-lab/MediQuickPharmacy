<?php

session_start();

require_once dirname(__DIR__) . '/config/database.php';

/*
    Check whether the user is logged in.
*/
$userId = isset($_SESSION['user_id'])
    ? (int) $_SESSION['user_id']
    : 0;

$userRole = $_SESSION['user_role'] ?? '';

if ($userId <= 0 || empty($userRole)) {
    header("Location: ../login.php");
    exit;
}

/*
    Redirect staff and admin users to their own dashboards.
*/
if ($userRole !== 'customer') {

    if ($userRole === 'staff') {
        header("Location: ../Staff/staff-dashboard.php");
        exit;
    }

    if ($userRole === 'admin') {
        header("Location: ../Admin/admin-dashboard.php");
        exit;
    }

    session_unset();
    session_destroy();

    header("Location: ../login.php");
    exit;
}

/*
    Default customer information.
*/
$userName  = "Customer";
$userEmail = "";
$userPhone = "";

/*
    Get logged-in customer information.
*/
$stmt = $conn->prepare("
    SELECT id, full_name, email, phone
    FROM users
    WHERE id = ?
      AND role = 'customer'
    LIMIT 1
");

if ($stmt) {

    $stmt->bind_param("i", $userId);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {

        $user = $result->fetch_assoc();

        $userName  = $user['full_name'] ?? 'Customer';
        $userEmail = $user['email'] ?? '';
        $userPhone = $user['phone'] ?? '';

    } else {

        session_unset();
        session_destroy();

        header("Location: ../login.php");
        exit;
    }

    $stmt->close();
}

/*
    Dashboard statistics.
*/
$totalOrders         = 0;
$totalPrescriptions  = 0;
$totalWishlist       = 0;
$totalAddresses      = 0;
$unreadNotifications = 0;

/*
    Get total orders.
*/
$stmt = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM orders
    WHERE user_id = ?
");

if ($stmt) {

    $stmt->bind_param("i", $userId);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $totalOrders = (int) $row['total'];
    }

    $stmt->close();
}

/*
    Get total prescriptions.
*/
$stmt = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM prescriptions
    WHERE user_id = ?
");

if ($stmt) {

    $stmt->bind_param("i", $userId);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $totalPrescriptions = (int) $row['total'];
    }

    $stmt->close();
}

/*
    Get total wishlist items.
*/
$stmt = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM wishlist
    WHERE user_id = ?
");

if ($stmt) {

    $stmt->bind_param("i", $userId);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $totalWishlist = (int) $row['total'];
    }

    $stmt->close();
}

/*
    Check whether the addresses table exists.
*/
$addressesTableExists = false;

$tableCheck = $conn->query("
    SHOW TABLES LIKE 'addresses'
");

if ($tableCheck && $tableCheck->num_rows > 0) {
    $addressesTableExists = true;
}

/*
    Get saved address count.
*/
if ($addressesTableExists) {

    $stmt = $conn->prepare("
        SELECT COUNT(*) AS total
        FROM addresses
        WHERE user_id = ?
    ");

    if ($stmt) {

        $stmt->bind_param("i", $userId);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $totalAddresses = (int) $row['total'];
        }

        $stmt->close();
    }

} else {

    /*
        Check whether users table contains an address column.
    */
    $columnCheck = $conn->query("
        SHOW COLUMNS FROM users LIKE 'address'
    ");

    if ($columnCheck && $columnCheck->num_rows > 0) {

        $stmt = $conn->prepare("
            SELECT
                CASE
                    WHEN address IS NOT NULL
                    AND TRIM(address) <> ''
                    THEN 1
                    ELSE 0
                END AS total
            FROM users
            WHERE id = ?
            LIMIT 1
        ");

        if ($stmt) {

            $stmt->bind_param("i", $userId);
            $stmt->execute();

            $result = $stmt->get_result();

            if ($row = $result->fetch_assoc()) {
                $totalAddresses = (int) $row['total'];
            }

            $stmt->close();
        }
    }
}

/*
    Check whether notifications table exists.
*/
$notificationsTableExists = false;

$tableCheck = $conn->query("
    SHOW TABLES LIKE 'notifications'
");

if ($tableCheck && $tableCheck->num_rows > 0) {
    $notificationsTableExists = true;
}

/*
    Get unread notification count.
*/
if ($notificationsTableExists) {

    $stmt = $conn->prepare("
        SELECT COUNT(*) AS total
        FROM notifications
        WHERE user_id = ?
          AND is_read = 0
    ");

    if ($stmt) {

        $stmt->bind_param("i", $userId);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $unreadNotifications = (int) $row['total'];
        }

        $stmt->close();
    }
}

/*
    Get three most recent orders.
*/
$recentOrders = [];

$stmt = $conn->prepare("
    SELECT
        id,
        order_number,
        total_amount,
        order_status,
        created_at
    FROM orders
    WHERE user_id = ?
    ORDER BY created_at DESC, id DESC
    LIMIT 3
");

if ($stmt) {

    $stmt->bind_param("i", $userId);
    $stmt->execute();

    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $recentOrders[] = $row;
    }

    $stmt->close();
}

/*
    Escape HTML output.
*/
function e($value)
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
    Return CSS class for order status.
*/
function orderStatusClass($status)
{
    switch ($status) {

        case 'Delivered':
            return 'status-delivered';

        case 'Shipped':
            return 'status-shipped';

        case 'Processing':
            return 'status-processing';

        case 'Cancelled':
            return 'status-cancelled';

        default:
            return 'status-pending';
    }
}

/*
    Include common header.
*/
include dirname(__DIR__) . '/includes/header.php';

?>

<section class="customer-dashboard">

    <div class="dashboard-wrapper">

        <!-- Customer dashboard sidebar -->

        <aside class="dashboard-sidebar">

            <div class="sidebar-user">

                <div class="sidebar-user-icon">
                    <i class="bi bi-person"></i>
                </div>

                <div class="sidebar-user-info">

                    <span>Hello,</span>

                    <strong>
                        <?php echo e($userName); ?>
                    </strong>

                    <small>
                        Welcome back!
                    </small>

                </div>

            </div>

            <nav class="dashboard-menu">

                <a
                    href="customer-dashboard.php"
                    class="dashboard-menu-item active"
                >
                    <span class="menu-icon">
                        <i class="bi bi-house-fill"></i>
                    </span>

                    <span>
                        Dashboard
                    </span>
                </a>

                <a
                    href="orders.php"
                    class="dashboard-menu-item"
                >
                    <span class="menu-icon">
                        <i class="bi bi-bag"></i>
                    </span>

                    <span>
                        My Orders
                    </span>
                </a>

                <a
                    href="my-prescriptions.php"
                    class="dashboard-menu-item"
                >
                    <span class="menu-icon">
                        <i class="bi bi-file-earmark-medical"></i>
                    </span>

                    <span>
                        My Prescriptions
                    </span>
                </a>

                <a
                    href="../profile.php"
                    class="dashboard-menu-item"
                >
                    <span class="menu-icon">
                        <i class="bi bi-person"></i>
                    </span>

                    <span>
                        My Profile
                    </span>
                </a>

                <a
                    href="addresses.php"
                    class="dashboard-menu-item"
                >
                    <span class="menu-icon">
                        <i class="bi bi-geo-alt"></i>
                    </span>

                    <span>
                        Addresses
                    </span>
                </a>

                <a
                    href="wishlist.php"
                    class="dashboard-menu-item"
                >
                    <span class="menu-icon">
                        <i class="bi bi-heart"></i>
                    </span>

                    <span>
                        Wishlist
                    </span>
                </a>

                <a
                    href="notifications.php"
                    class="dashboard-menu-item notification-menu"
                >
                    <span class="menu-icon">
                        <i class="bi bi-bell"></i>
                    </span>

                    <span>
                        Notifications
                    </span>

                    <?php if ($unreadNotifications > 0): ?>

                        <span class="notification-badge">
                            <?php
                            echo $unreadNotifications > 99
                                ? '99+'
                                : $unreadNotifications;
                            ?>
                        </span>

                    <?php endif; ?>

                </a>

                <a
                    href="help.php"
                    class="dashboard-menu-item"
                >
                    <span class="menu-icon">
                        <i class="bi bi-question-circle"></i>
                    </span>

                    <span>
                        Help & Support
                    </span>
                </a>

            </nav>

            <div class="sidebar-divider"></div>

            <a
                href="../logout.php"
                class="dashboard-menu-item logout-item"
            >
                <span class="menu-icon">
                    <i class="bi bi-box-arrow-right"></i>
                </span>

                <span>
                    Logout
                </span>
            </a>

        </aside>

        <!-- Free delivery card -->

        <div class="delivery-card">

            <div class="delivery-content">

                <span class="delivery-title">
                    Free Delivery
                </span>

                <span class="delivery-text">
                    On orders above
                </span>

                <strong>
                    Rs. 5,000
                </strong>

                <a
                    href="../products.php"
                    class="delivery-button"
                >
                    Shop Now
                </a>

            </div>

            <div class="delivery-image">

                <img
                    src="../assets/images/Delivery Boy.png"
                    alt="Delivery"
                >

            </div>

        </div>

        <!-- Main dashboard -->

        <main class="dashboard-main">

            <!-- Welcome banner -->

            <section class="welcome-banner">

                <div class="welcome-image">

                    <img
                        src="../assets/images/Welcome Banner.png"
                        alt="MediQuick Pharmacy"
                    >

                </div>

                <div class="welcome-content">

                    <span class="welcome-small">
                        Welcome back,
                    </span>

                    <h1>
                        <?php echo e($userName); ?>
                    </h1>

                    <p>
                        We're glad to have you with us.
                    </p>

                    <p>
                        Take care and stay healthy!
                    </p>

                </div>

            </section>

            <!-- Dashboard statistics -->

            <section class="dashboard-stats">

                <div class="stat-card">

                    <div class="stat-icon stat-blue">
                        <i class="bi bi-bag-fill"></i>
                    </div>

                    <div class="stat-info">

                        <strong>
                            <?php echo $totalOrders; ?>
                        </strong>

                        <span>
                            Total Orders
                        </span>

                        <a href="orders.php">
                            View all orders
                            <i class="bi bi-arrow-right"></i>
                        </a>

                    </div>

                </div>

                <div class="stat-card">

                    <div class="stat-icon stat-green">
                        <i class="bi bi-file-earmark-text-fill"></i>
                    </div>

                    <div class="stat-info">

                        <strong>
                            <?php echo $totalPrescriptions; ?>
                        </strong>

                        <span>
                            Prescriptions
                        </span>

                        <a href="my-prescriptions.php">
                            View prescriptions
                            <i class="bi bi-arrow-right"></i>
                        </a>

                    </div>

                </div>

                <div class="stat-card">

                    <div class="stat-icon stat-yellow">
                        <i class="bi bi-heart-fill"></i>
                    </div>

                    <div class="stat-info">

                        <strong>
                            <?php echo $totalWishlist; ?>
                        </strong>

                        <span>
                            Wishlist Items
                        </span>

                        <a href="wishlist.php">
                            View wishlist
                            <i class="bi bi-arrow-right"></i>
                        </a>

                    </div>

                </div>

                <div class="stat-card">

                    <div class="stat-icon stat-purple">
                        <i class="bi bi-geo-alt-fill"></i>
                    </div>

                    <div class="stat-info">

                        <strong>
                            <?php echo $totalAddresses; ?>
                        </strong>

                        <span>
                            Saved Addresses
                        </span>

                        <a href="addresses.php">
                            Manage addresses
                            <i class="bi bi-arrow-right"></i>
                        </a>

                    </div>

                </div>

            </section>

            <!-- Recent orders and quick actions -->

            <section class="dashboard-middle">

                <div class="recent-orders dashboard-box">

                    <div class="box-heading">

                        <div>

                            <h2>
                                Recent Orders
                            </h2>

                            <p>
                                Keep track of your recent purchases.
                            </p>

                        </div>

                        <a href="orders.php">
                            View All
                            <i class="bi bi-arrow-right"></i>
                        </a>

                    </div>

                    <?php if (count($recentOrders) > 0): ?>

                        <div class="recent-order-list">

                            <?php foreach ($recentOrders as $order): ?>

                                <div class="recent-order-item">

                                    <div class="recent-order-icon">
                                        <i class="bi bi-bag-check"></i>
                                    </div>

                                    <div class="recent-order-info">

                                        <strong>
                                            Order #
                                            <?php
                                            echo e(
                                                $order['order_number']
                                            );
                                            ?>
                                        </strong>

                                        <small>
                                            <?php

                                            $orderDate = strtotime(
                                                $order['created_at']
                                            );

                                            echo $orderDate
                                                ? date(
                                                    'd M Y',
                                                    $orderDate
                                                )
                                                : '';

                                            ?>
                                        </small>

                                    </div>

                                    <div class="recent-order-right">

                                        <strong>
                                            Rs.
                                            <?php
                                            echo number_format(
                                                (float) $order['total_amount'],
                                                2
                                            );
                                            ?>
                                        </strong>

                                        <span
                                            class="order-status <?php echo e(orderStatusClass($order['order_status'])); ?>"
                                        >
                                            <?php
                                            echo e(
                                                $order['order_status']
                                            );
                                            ?>
                                        </span>

                                    </div>

                                </div>

                            <?php endforeach; ?>

                        </div>

                    <?php else: ?>

                        <div class="empty-orders">

                            <div class="empty-order-icon">
                                <i class="bi bi-bag"></i>
                            </div>

                            <h3>
                                No orders yet
                            </h3>

                            <p>
                                Your recent orders will appear here.
                            </p>

                            <a
                                href="../products.php"
                                class="start-shopping"
                            >
                                <i class="bi bi-cart3"></i>
                                Start Shopping
                            </a>

                        </div>

                    <?php endif; ?>

                </div>

                <!-- Quick actions -->

                <div class="quick-actions dashboard-box">

                    <div class="box-heading">

                        <div>

                            <h2>
                                Quick Actions
                            </h2>

                            <p>
                                What would you like to do?
                            </p>

                        </div>

                    </div>

                    <!-- Upload Prescription -->
                    <!-- prescription.php is in the root folder -->

                    <a
                        href="../prescription.php"
                        class="quick-action"
                    >

                        <div class="quick-icon">
                            <i class="bi bi-file-earmark-arrow-up"></i>
                        </div>

                        <div>

                            <strong>
                                Upload Prescription
                            </strong>

                            <small>
                                Upload and get medicines
                            </small>

                        </div>

                    </a>

                    <!-- Shop Medicines -->

                    <a
                        href="../products.php"
                        class="quick-action"
                    >

                        <div class="quick-icon">
                            <i class="bi bi-bag-plus"></i>
                        </div>

                        <div>

                            <strong>
                                Shop Medicines
                            </strong>

                            <small>
                                Browse all medicines
                            </small>

                        </div>

                    </a>

                    <!-- Offers -->

                    <a
                        href="../products.php"
                        class="quick-action"
                    >

                        <div class="quick-icon">
                            <i class="bi bi-percent"></i>
                        </div>

                        <div>

                            <strong>
                                Offers & Discounts
                            </strong>

                            <small>
                                View latest offers
                            </small>

                        </div>

                    </a>

                    <!-- Track Order -->

                    <a
                        href="orders.php"
                        class="quick-action"
                    >

                        <div class="quick-icon">
                            <i class="bi bi-truck"></i>
                        </div>

                        <div>

                            <strong>
                                Track Order
                            </strong>

                            <small>
                                Track your order status
                            </small>

                        </div>

                    </a>

                </div>

            </section>

            <!-- Special offer -->

            <section class="special-offer">

                <div class="offer-content">

                    <span class="offer-small">
                        SPECIAL OFFER
                    </span>

                    <h2>
                        Flat 20% OFF
                    </h2>

                    <p>
                        On selected healthcare products
                    </p>

                </div>

                <div class="offer-code">

                    <span>
                        Use Code:
                    </span>

                    <strong>
                        MEDI20
                    </strong>

                </div>

                <a
                    href="../products.php"
                    class="offer-button"
                >
                    Shop Now
                    <i class="bi bi-arrow-right"></i>
                </a>

                <div class="special-offer-image">

                    <img
                        src="../assets/images/Special Offer.png"
                        alt="Special Offer"
                    >

                </div>

            </section>

            <!-- Bottom information cards -->

            <section class="bottom-info">

                <div class="bottom-card">

                    <div class="bottom-icon">
                        <i class="bi bi-headset"></i>
                    </div>

                    <div class="bottom-text">

                        <strong>
                            Need help?
                        </strong>

                        <p>
                            We're here for you.
                            Contact our support team anytime.
                        </p>

                    </div>

                    <a
                        href="help.php"
                        class="contact-button"
                    >
                        Contact Support
                    </a>

                </div>

                <div class="bottom-card">

                    <div class="bottom-icon shield">
                        <i class="bi bi-shield-check"></i>
                    </div>

                    <div class="bottom-text">

                        <strong>
                            Our Promise
                        </strong>

                        <p>
                            Genuine products, secure payments,
                            and fast delivery.
                        </p>

                    </div>

                </div>

            </section>

        </main>

    </div>

</section>

<style>

.customer-dashboard,
.customer-dashboard * {
    box-sizing: border-box;
}

.customer-dashboard {

    width: 100%;

    min-height: calc(100vh - 130px);

    padding: 28px 30px 50px;

    background:
        linear-gradient(
            180deg,
            #fafdfe 0%,
            #f5fafc 100%
        );

    font-family:
        Arial,
        Helvetica,
        sans-serif;

    color: #183b55;
}

.dashboard-wrapper {

    max-width: 1280px;

    margin: auto;

    position: relative;

    padding-left: 290px;
}

.dashboard-sidebar {

    position: absolute;

    left: 0;
    top: 0;

    width: 264px;

    background: rgba(255,255,255,.96);

    border: 1px solid #e1edf1;

    border-radius: 16px;

    padding: 20px 12px 15px;

    box-shadow:
        0 4px 18px
        rgba(24,75,100,.05);
}

.sidebar-user {

    display: flex;

    align-items: center;

    gap: 12px;

    padding: 4px 8px 16px;
}

.sidebar-user-icon {

    width: 58px;
    height: 58px;

    border-radius: 50%;

    background:
        linear-gradient(
            145deg,
            #e8f8fc,
            #dff4f8
        );

    display: flex;

    align-items: center;

    justify-content: center;

    color: #087f9b;

    font-size: 28px;

    flex-shrink: 0;
}

.sidebar-user-info {

    display: flex;

    flex-direction: column;
}

.sidebar-user-info span {

    color: #557083;

    font-size: 12px;

    margin-bottom: 3px;
}

.sidebar-user-info strong {

    color: #173e5a;

    font-size: 14px;

    margin-bottom: 4px;
}

.sidebar-user-info small {

    color: #6c7e89;

    font-size: 11px;
}

.dashboard-menu {

    display: flex;

    flex-direction: column;

    gap: 3px;
}

.dashboard-menu-item {

    position: relative;

    display: flex;

    align-items: center;

    gap: 13px;

    min-height: 44px;

    padding: 9px 13px;

    border-radius: 9px;

    color: #355069;

    text-decoration: none;

    font-size: 14px;

    font-weight: 500;

    transition: .2s;
}

.dashboard-menu-item:hover {

    background: #f0f9fb;

    color: #087f9b;
}

.dashboard-menu-item.active {

    background:
        linear-gradient(
            135deg,
            #1195a9,
            #087f9b
        );

    color: white;

    box-shadow:
        0 4px 12px
        rgba(8,127,155,.18);
}

.menu-icon {

    width: 28px;

    text-align: center;

    font-size: 18px;

    flex-shrink: 0;
}

.sidebar-divider {

    height: 1px;

    background: #edf1f3;

    margin: 10px 8px;
}

.logout-item {

    color: #e45454;
}

.notification-badge {

    margin-left: auto;

    min-width: 22px;

    height: 22px;

    padding: 0 6px;

    border-radius: 12px;

    background: #ff5b62;

    color: white;

    font-size: 11px;

    font-weight: 700;

    display: flex;

    align-items: center;

    justify-content: center;
}

.delivery-card {

    position: absolute;

    top: 595px;
    left: 0;

    width: 264px;
    height: 174px;

    border-radius: 16px;

    overflow: hidden;

    background:
        linear-gradient(
            135deg,
            #e8faff,
            #d7f4fa
        );

    border: 1px solid #c8eaf1;

    display: flex;

    align-items: center;

    padding: 20px;
}

.delivery-content {

    position: relative;

    z-index: 2;

    width: 58%;

    display: flex;

    flex-direction: column;
}

.delivery-title {

    color: #087f9b;

    font-size: 14px;

    font-weight: 700;
}

.delivery-text {

    color: #31566c;

    font-size: 12px;
}

.delivery-content strong {

    color: #173e5a;

    font-size: 16px;

    margin-top: 5px;
}

.delivery-button {

    display: inline-flex;

    align-items: center;

    justify-content: center;

    width: 82px;
    height: 35px;

    margin-top: 12px;

    border-radius: 8px;

    background: #07849c;

    color: white;

    text-decoration: none;

    font-size: 12px;

    font-weight: 700;
}

.delivery-image {

    position: absolute;

    right: -2px;
    bottom: -1px;

    width: 70%;
    height: 100%;

    display: flex;

    align-items: flex-end;

    justify-content: flex-end;
}

.delivery-image img {

    width: 100%;
    height: 100%;

    object-fit: contain;

    object-position: right center;

    background: transparent;

    mix-blend-mode: multiply;
}

.dashboard-main {

    width: 100%;
}

.welcome-banner {

    position: relative;

    width: 100%;

    height: 250px;

    overflow: hidden;

    border-radius: 16px;

    border: 1px solid #c8e7ef;

    background: #e8f7fc;

    box-shadow:
        0 6px 20px
        rgba(24,75,100,.06);
}

.welcome-image {

    position: absolute;

    inset: 0;

    width: 100%;

    height: 100%;

    z-index: 1;
}

.welcome-image img {

    width: 100%;
    height: 100%;

    object-fit: fill;
}

.welcome-content {

    position: absolute;

    left: 0;
    top: 0;

    width: 55%;
    height: 100%;

    z-index: 5;

    display: flex;

    flex-direction: column;

    justify-content: center;

    padding-left: 42px;
}

.welcome-small {

    color: #31566c;

    font-size: 16px;
}

.welcome-content h1 {

    margin: 5px 0 9px;

    color: #078ba5;

    font-size: 36px;

    font-weight: 700;
}

.welcome-content p {

    margin: 2px 0;

    color: #416274;

    font-size: 14px;
}

.dashboard-stats {

    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 20px;

    margin-top: 20px;
}

.stat-card {

    min-height: 128px;

    background: white;

    border: 1px solid #e2edf1;

    border-radius: 15px;

    padding: 18px;

    display: flex;

    align-items: center;

    gap: 14px;

    box-shadow:
        0 4px 16px
        rgba(31,84,106,.035);
}

.stat-icon {

    width: 57px;
    height: 57px;

    border-radius: 50%;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 23px;

    flex-shrink: 0;
}

.stat-blue {
    color: #1476d4;
    background: #eaf4ff;
}

.stat-green {
    color: #18a969;
    background: #eafaf2;
}

.stat-yellow {
    color: #efa719;
    background: #fff7e5;
}

.stat-purple {
    color: #8650d7;
    background: #f3ebff;
}

.stat-info {
    min-width: 0;
}

.stat-info strong {

    display: block;

    color: #173e5a;

    font-size: 23px;

    margin-bottom: 7px;
}

.stat-info > span {

    display: block;

    color: #526477;

    font-size: 12px;

    margin-bottom: 12px;
}

.stat-info a {

    color: #087f9b;

    text-decoration: none;

    font-size: 11px;

    font-weight: 700;

    white-space: nowrap;
}

.dashboard-middle {

    display: grid;

    grid-template-columns:
        1.35fr 1fr;

    gap: 20px;

    margin-top: 20px;
}

.dashboard-box {

    background: white;

    border: 1px solid #e1edf1;

    border-radius: 15px;

    padding: 20px;

    box-shadow:
        0 4px 16px
        rgba(31,84,106,.035);
}

.box-heading {

    display: flex;

    justify-content: space-between;

    align-items: flex-start;
}

.box-heading h2 {

    color: #173e5a;

    font-size: 20px;

    margin: 0 0 6px;
}

.box-heading p {

    color: #778793;

    font-size: 11px;

    margin: 0;
}

.box-heading a {

    color: #087f9b;

    text-decoration: none;

    font-size: 11px;

    font-weight: 700;
}

.recent-order-list {
    margin-top: 17px;
}

.recent-order-item {

    display: flex;

    align-items: center;

    gap: 12px;

    padding: 13px 5px;

    border-bottom: 1px solid #edf2f4;
}

.recent-order-item:last-child {
    border-bottom: none;
}

.recent-order-icon {

    width: 42px;
    height: 42px;

    border-radius: 10px;

    background: #ebf8fb;

    color: #087f9b;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 18px;

    flex-shrink: 0;
}

.recent-order-info {

    flex: 1;

    min-width: 0;
}

.recent-order-info strong {

    display: block;

    color: #173e5a;

    font-size: 13px;
}

.recent-order-info small {

    display: block;

    color: #84929b;

    font-size: 10px;

    margin-top: 4px;
}

.recent-order-right {
    text-align: right;
}

.recent-order-right > strong {

    display: block;

    color: #173e5a;

    font-size: 12px;

    margin-bottom: 5px;
}

.order-status {

    display: inline-block;

    padding: 4px 8px;

    border-radius: 20px;

    font-size: 9px;

    font-weight: 700;
}

.status-delivered {
    background: #e8f8ef;
    color: #198754;
}

.status-shipped {
    background: #e7f2ff;
    color: #0d6efd;
}

.status-processing {
    background: #fff4dc;
    color: #c58b00;
}

.status-pending {
    background: #fff4dc;
    color: #b77900;
}

.status-cancelled {
    background: #ffe8eb;
    color: #dc3545;
}

.empty-orders {

    min-height: 240px;

    margin-top: 16px;

    border: 2px dashed #e2eaee;

    border-radius: 13px;

    display: flex;

    align-items: center;

    justify-content: center;

    flex-direction: column;

    text-align: center;
}

.empty-order-icon {

    width: 57px;
    height: 57px;

    border-radius: 50%;

    background: #ebf9fc;

    color: #087f9b;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 24px;

    margin-bottom: 10px;
}

.empty-orders h3 {

    color: #173e5a;

    font-size: 15px;

    margin: 0 0 6px;
}

.empty-orders p {

    color: #788793;

    font-size: 11px;

    margin: 0 0 15px;
}

.start-shopping {

    display: inline-flex;

    align-items: center;

    gap: 7px;

    background: #07879f;

    color: white;

    text-decoration: none;

    padding: 12px 22px;

    border-radius: 8px;

    font-size: 13px;

    font-weight: 700;
}

.quick-action {

    display: flex;

    align-items: center;

    gap: 12px;

    min-height: 56px;

    border: 1px solid #e0eaee;

    border-radius: 9px;

    padding: 9px 11px;

    margin-top: 10px;

    text-decoration: none;
}

.quick-action:hover {

    border-color: #a9dbe4;

    background: #f8fdfe;
}

.quick-icon {

    width: 40px;
    height: 40px;

    border-radius: 8px;

    background: #eefafd;

    color: #07839b;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 19px;
}

.quick-action strong {

    display: block;

    color: #173e5a;

    font-size: 13px;
}

.quick-action small {

    display: block;

    color: #788793;

    font-size: 10px;

    margin-top: 4px;
}

.special-offer {

    position: relative;

    height: 96px;

    margin-top: 20px;

    overflow: hidden;

    border-radius: 15px;

    border: 1px solid #bfe7e7;

    background:
        linear-gradient(
            100deg,
            #d8f7f4,
            #d4f5f2,
            #d9f8f5
        );

    display: flex;

    align-items: center;
}

.offer-content {

    position: relative;

    z-index: 4;

    width: 43%;

    padding-left: 38px;
}

.offer-small {

    display: block;

    color: #087f9b;

    font-size: 9px;

    font-weight: 700;

    letter-spacing: 1px;
}

.offer-content h2 {

    color: #075878;

    font-size: 29px;

    margin: 3px 0;
}

.offer-content p {

    color: #315e70;

    font-size: 10px;

    margin: 0;
}

.offer-code {

    position: relative;

    z-index: 5;

    width: 105px;
    height: 70px;

    border: 1px dashed #0b8ca1;

    border-radius: 9px;

    display: flex;

    flex-direction: column;

    justify-content: center;

    align-items: center;
}

.offer-code span {

    color: #397082;

    font-size: 9px;
}

.offer-code strong {

    color: #087f9b;

    font-size: 19px;
}

.offer-button {

    position: relative;

    z-index: 6;

    display: inline-flex;

    align-items: center;

    justify-content: center;

    gap: 7px;

    width: 116px;
    height: 42px;

    background: white;

    border-radius: 8px;

    color: #087f9b;

    text-decoration: none;

    font-size: 12px;

    font-weight: 700;

    margin-left: 18px;
}

.special-offer-image {

    position: absolute;

    right: 0;
    top: 0;

    width: 35%;
    height: 100%;
}

.special-offer-image img {

    width: 100%;
    height: 100%;

    object-fit: cover;

    mix-blend-mode: multiply;
}

.bottom-info {

    display: grid;

    grid-template-columns:
        1fr 1fr;

    gap: 20px;

    margin-top: 20px;
}

.bottom-card {

    min-height: 76px;

    border: 1px solid #dcecef;

    border-radius: 14px;

    background: #f4fcfe;

    display: flex;

    align-items: center;

    padding: 12px;

    gap: 12px;
}

.bottom-icon {

    width: 44px;
    height: 44px;

    border-radius: 50%;

    background: white;

    color: #087f9b;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 20px;

    flex-shrink: 0;
}

.bottom-text {
    flex: 1;
}

.bottom-text strong {

    display: block;

    color: #173e5a;

    font-size: 12px;
}

.bottom-text p {

    color: #6d7e89;

    font-size: 10px;

    margin: 4px 0 0;
}

.contact-button {

    background: white;

    border: 1px solid #d6e8ec;

    color: #087f9b;

    text-decoration: none;

    padding: 9px 14px;

    border-radius: 8px;

    font-size: 10px;

    font-weight: 700;

    white-space: nowrap;
}

@media (max-width: 1100px) {

    .dashboard-wrapper {
        padding-left: 0;
    }

    .dashboard-sidebar {

        position: relative;

        width: 100%;

        margin-bottom: 20px;
    }

    .dashboard-menu {

        display: grid;

        grid-template-columns:
            repeat(4, 1fr);
    }

    .delivery-card {

        position: relative;

        top: auto;
        left: auto;

        width: 100%;

        margin-bottom: 20px;
    }
}

@media (max-width: 850px) {

    .dashboard-stats {

        grid-template-columns:
            repeat(2, 1fr);
    }

    .dashboard-middle {

        grid-template-columns: 1fr;
    }

    .bottom-info {

        grid-template-columns: 1fr;
    }
}

@media (max-width: 600px) {

    .customer-dashboard {

        padding: 18px 12px 30px;
    }

    .dashboard-menu {

        grid-template-columns:
            repeat(2, 1fr);
    }

    .dashboard-stats {

        grid-template-columns: 1fr;
    }

    .welcome-banner {
        height: 220px;
    }

    .welcome-content {

        width: 65%;

        padding-left: 20px;
    }

    .welcome-content h1 {
        font-size: 24px;
    }

    .welcome-content p {
        font-size: 10px;
    }

    .offer-code {
        display: none;
    }

    .offer-content {

        width: 60%;

        padding-left: 20px;
    }

    .offer-button {

        position: absolute;

        left: 20px;
        bottom: 15px;

        margin-left: 0;
    }

    .special-offer {
        height: 145px;
    }

    .special-offer-image {
        width: 48%;
    }
}

</style>

<?php

/*
    Include common website footer.
*/
include dirname(__DIR__) . '/includes/footer.php';

?>