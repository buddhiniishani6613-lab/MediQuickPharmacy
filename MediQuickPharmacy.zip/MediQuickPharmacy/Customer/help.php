
<?php

session_start();

/*
 * Load the database connection.
 */
require_once __DIR__ . '/../config/database.php';

/*
 * Check whether the customer is logged in.
 */
if (!isset($_SESSION['user_id'])) {

    header("Location: ../login.php");
    exit;

}

$userId = (int) $_SESSION['user_id'];

/*
 * Escape output before displaying it in HTML.
 */
function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Help & Support | MediQuick Pharmacy</title>

    <!-- Bootstrap CSS -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Bootstrap Icons -->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    >

    <style>

        /* General body styles */
        body {

            background: #f6f9fc;

            font-family: Arial, sans-serif;

        }


        /* Help and Support Banner */
        .help-hero {

            background:
                linear-gradient(
                    135deg,
                    #006391,
                    #0dcaf0
                );

            color: white;

            padding: 45px 20px;

            border-radius: 0 0 25px 25px;

            margin-bottom: 35px;

        }


        .help-hero h1 {

            font-size: 36px;

            font-weight: 700;

            margin-bottom: 8px;

        }


        .help-hero p {

            margin: 0;

            opacity: 0.92;

            font-size: 15px;

            line-height: 1.6;

        }


        .hero-icon {

            width: 75px;

            height: 75px;

            min-width: 75px;

            border-radius: 50%;

            background: rgba(255,255,255,0.18);

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 36px;

        }


        /* Section headings */
        .section-title {

            font-size: 26px;

            font-weight: 700;

            color: #212529;

            margin-bottom: 8px;

        }


        .section-subtitle {

            color: #6c757d;

            font-size: 14px;

            margin-bottom: 28px;

        }


        /* Support cards */
        .support-card {

            background: white;

            border: 1px solid #edf0f2;

            border-radius: 18px;

            padding: 28px 22px;

            height: 100%;

            text-align: center;

            box-shadow:
                0 5px 20px rgba(0,0,0,0.06);

            transition: all 0.3s ease;

        }


        .support-card:hover {

            transform: translateY(-5px);

            box-shadow:
                0 12px 30px rgba(0,0,0,0.10);

        }


        .support-icon {

            width: 65px;

            height: 65px;

            border-radius: 16px;

            display: flex;

            align-items: center;

            justify-content: center;

            margin: 0 auto 18px;

            font-size: 27px;

        }


        .icon-blue {

            background: #e8f1ff;

            color: #087f9b;

        }


        .icon-green {

            background: #e3f7ed;

            color: #198754;

        }


        .icon-yellow {

            background: #fff3cd;

            color: #b8860b;

        }


        .icon-red {

            background: #ffe8ec;

            color: #dc3545;

        }


        .support-card h5 {

            font-weight: 700;

            font-size: 17px;

            color: #212529;

            margin-bottom: 10px;

        }


        .support-card p {

            color: #6c757d;

            font-size: 13px;

            line-height: 1.6;

            min-height: 62px;

        }


        .support-btn {

            border-radius: 9px;

            padding: 9px 17px;

            font-size: 13px;

            font-weight: 600;

        }


        /* FAQ section */
        .faq-container {

            background: white;

            border: 1px solid #edf0f2;

            border-radius: 20px;

            padding: 25px;

            box-shadow:
                0 5px 20px rgba(0,0,0,0.06);

        }


        .accordion-item {

            border: 1px solid #edf0f2 !important;

            border-radius: 12px !important;

            margin-bottom: 12px;

            overflow: hidden;

        }


        .accordion-button {

            font-weight: 600;

            color: #212529;

            background: white;

            box-shadow: none !important;

            padding: 18px 20px;

            font-size: 14px;

        }


        .accordion-button:not(.collapsed) {

            color: #087f9b;

            background: #f0f9fc;

        }


        .accordion-body {

            color: #6c757d;

            line-height: 1.7;

            font-size: 13px;

        }


        /* Quick help section */
        .quick-help {

            background:
                linear-gradient(
                    135deg,
                    #ffffff,
                    #eef9fc
                );

            border: 1px solid #e0edf2;

            border-radius: 20px;

            padding: 30px;

        }


        .quick-help h4 {

            font-weight: 700;

            color: #174f68;

            margin-bottom: 10px;

        }


        .quick-help p {

            color: #6c757d;

            font-size: 14px;

        }


        /* Contact section */
        .contact-section {

            background: white;

            border: 1px solid #edf0f2;

            border-radius: 20px;

            padding: 30px;

            box-shadow:
                0 5px 20px rgba(0,0,0,0.06);

        }


        .contact-item {

            display: flex;

            align-items: center;

            gap: 15px;

            padding: 16px;

            background: #f6fafc;

            border: 1px solid #edf2f4;

            border-radius: 13px;

            margin-bottom: 12px;

            transition: 0.2s;

        }


        .contact-item:hover {

            background: #eef8fb;

            border-color: #cce9f0;

        }


        .contact-icon {

            width: 45px;

            height: 45px;

            min-width: 45px;

            border-radius: 12px;

            background: #e5f4f8;

            color: #087f9b;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 19px;

        }


        .contact-item h6 {

            margin: 0 0 5px;

            font-weight: 700;

            font-size: 14px;

            color: #174f68;

        }


        .contact-item p {

            margin: 0;

            color: #6c757d;

            font-size: 13px;

        }


        .contact-item a {

            color: #087f9b;

            text-decoration: none;

        }


        .contact-item a:hover {

            text-decoration: underline;

        }


        /* Main content spacing */
        .help-content {

            padding-bottom: 55px;

        }


        /* Mobile responsive styles */
        @media (max-width: 576px) {

            .help-hero {

                padding: 38px 18px;

            }

            .help-hero h1 {

                font-size: 28px;

            }

            .help-hero p {

                font-size: 13px;

            }

            .hero-icon {

                width: 60px;

                height: 60px;

                min-width: 60px;

                font-size: 29px;

            }

            .section-title {

                font-size: 22px;

            }

            .faq-container {

                padding: 15px;

            }

            .contact-section {

                padding: 20px;

            }

            .quick-help {

                padding: 22px;

            }

            .support-card {

                padding: 24px 18px;

            }

        }

    </style>

</head>

<body>

<?php

/*
 * Include the common website header.
 */
include __DIR__ . '/../includes/header.php';

?>


<!-- Help and Support Banner -->

<section class="help-hero">

    <div class="container">

        <div class="d-flex align-items-center gap-3">

            <div class="hero-icon">

                <i class="bi bi-headset"></i>

            </div>

            <div>

                <h1>Help & Support</h1>

                <p>
                    We're here to help you with your
                    orders, prescriptions, payments
                    and more.
                </p>

            </div>

        </div>

    </div>

</section>


<!-- Main content -->

<div class="container help-content">


    <!-- Support options -->

    <div class="text-center mb-4">

        <h2 class="section-title">

            How Can We Help You?

        </h2>

        <p class="section-subtitle">

            Choose a topic below to find the help you need.

        </p>

    </div>


    <div class="row g-4 mb-5">


        <!-- Order help -->

        <div class="col-lg-3 col-md-6">

            <div class="support-card">

                <div class="support-icon icon-blue">

                    <i class="bi bi-box-seam"></i>

                </div>

                <h5>Order Help</h5>

                <p>
                    Need help with your order,
                    delivery or order status?
                </p>

                <a
                    href="my-orders.php"
                    class="btn btn-outline-primary support-btn"
                >

                    <i class="bi bi-box-arrow-up-right me-1"></i>

                    View Orders

                </a>

            </div>

        </div>


        <!-- Prescription help -->

        <div class="col-lg-3 col-md-6">

            <div class="support-card">

                <div class="support-icon icon-yellow">

                    <i class="bi bi-file-earmark-medical"></i>

                </div>

                <h5>Prescription Help</h5>

                <p>
                    Learn how to upload and
                    manage your prescriptions.
                </p>

                <a
                    href="my-prescriptions.php"
                    class="btn btn-outline-warning support-btn"
                >

                    <i class="bi bi-file-earmark-text me-1"></i>

                    My Prescriptions

                </a>

            </div>

        </div>


        <!-- Payment help -->

        <div class="col-lg-3 col-md-6">

            <div class="support-card">

                <div class="support-icon icon-green">

                    <i class="bi bi-credit-card"></i>

                </div>

                <h5>Payment Help</h5>

                <p>
                    Get information about available
                    payment methods and payments.
                </p>

                <a
                    href="#faq"
                    class="btn btn-outline-success support-btn"
                >

                    <i class="bi bi-question-circle me-1"></i>

                    Learn More

                </a>

            </div>

        </div>


        <!-- Account help -->

        <div class="col-lg-3 col-md-6">

            <div class="support-card">

                <div class="support-icon icon-red">

                    <i class="bi bi-person-circle"></i>

                </div>

                <h5>Account Help</h5>

                <p>
                    Manage your profile,
                    contact information and
                    account settings.
                </p>

                <a
                    href="../profile.php"
                    class="btn btn-outline-danger support-btn"
                >

                    <i class="bi bi-person me-1"></i>

                    My Profile

                </a>

            </div>

        </div>


    </div>


    <!-- Frequently Asked Questions -->

    <div id="faq" class="mb-5">


        <div class="text-center mb-4">

            <h2 class="section-title">

                Frequently Asked Questions

            </h2>

            <p class="section-subtitle">

                Find quick answers to common questions.

            </p>

        </div>


        <div class="faq-container">

            <div class="accordion" id="faqAccordion">


                <!-- FAQ 1 -->

                <div class="accordion-item">

                    <h2 class="accordion-header">

                        <button
                            class="accordion-button"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#faq1"
                        >

                            <i class="bi bi-bag-check text-primary me-3"></i>

                            How can I place an order?

                        </button>

                    </h2>

                    <div
                        id="faq1"
                        class="accordion-collapse collapse show"
                        data-bs-parent="#faqAccordion"
                    >

                        <div class="accordion-body">

                            Browse our products, select the items
                            you need and click
                            <strong>Add to Cart</strong>.

                            Open your cart, review your items
                            and proceed to checkout.

                            Enter your delivery details and
                            select your preferred payment
                            method to complete your order.

                        </div>

                    </div>

                </div>


                <!-- FAQ 2 -->

                <div class="accordion-item">

                    <h2 class="accordion-header">

                        <button
                            class="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#faq2"
                        >

                            <i class="bi bi-truck text-primary me-3"></i>

                            How can I track my order?

                        </button>

                    </h2>

                    <div
                        id="faq2"
                        class="accordion-collapse collapse"
                        data-bs-parent="#faqAccordion"
                    >

                        <div class="accordion-body">

                            Go to the
                            <strong>My Orders</strong>
                            section from your customer account.

                            You can view the current status
                            of your orders there.

                            Order statuses may include
                            Pending, Processing, Shipped,
                            Delivered or Cancelled.

                        </div>

                    </div>

                </div>


                <!-- FAQ 3 -->

                <div class="accordion-item">

                    <h2 class="accordion-header">

                        <button
                            class="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#faq3"
                        >

                            <i class="bi bi-file-earmark-medical text-warning me-3"></i>

                            How do I upload a prescription?

                        </button>

                    </h2>

                    <div
                        id="faq3"
                        class="accordion-collapse collapse"
                        data-bs-parent="#faqAccordion"
                    >

                        <div class="accordion-body">

                            Open the Prescription section
                            and upload a clear image or PDF
                            of your valid prescription.

                            Make sure all prescription
                            details are clearly visible
                            before submitting it.

                        </div>

                    </div>

                </div>


                <!-- FAQ 4 -->

                <div class="accordion-item">

                    <h2 class="accordion-header">

                        <button
                            class="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#faq4"
                        >

                            <i class="bi bi-credit-card text-success me-3"></i>

                            What payment methods are available?

                        </button>

                    </h2>

                    <div
                        id="faq4"
                        class="accordion-collapse collapse"
                        data-bs-parent="#faqAccordion"
                    >

                        <div class="accordion-body">

                            The payment methods available
                            for your order will be displayed
                            during checkout.

                            Select your preferred payment
                            method and follow the instructions
                            shown on the checkout page.

                        </div>

                    </div>

                </div>


                <!-- FAQ 5 -->

                <div class="accordion-item">

                    <h2 class="accordion-header">

                        <button
                            class="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#faq5"
                        >

                            <i class="bi bi-cart-x text-danger me-3"></i>

                            What happens if a product is out of stock?

                        </button>

                    </h2>

                    <div
                        id="faq5"
                        class="accordion-collapse collapse"
                        data-bs-parent="#faqAccordion"
                    >

                        <div class="accordion-body">

                            Products that are unavailable
                            are marked as
                            <strong>Out of Stock</strong>.

                            Unavailable products cannot
                            be added to your shopping cart.

                        </div>

                    </div>

                </div>


                <!-- FAQ 6 -->

                <div class="accordion-item">

                    <h2 class="accordion-header">

                        <button
                            class="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#faq6"
                        >

                            <i class="bi bi-heart text-danger me-3"></i>

                            What is the Wishlist?

                        </button>

                    </h2>

                    <div
                        id="faq6"
                        class="accordion-collapse collapse"
                        data-bs-parent="#faqAccordion"
                    >

                        <div class="accordion-body">

                            The Wishlist allows you to save
                            your favourite products for later.

                            Click the heart icon on a product
                            to add it to your Wishlist.

                        </div>

                    </div>

                </div>


                <!-- FAQ 7 -->

                <div class="accordion-item">

                    <h2 class="accordion-header">

                        <button
                            class="accordion-button collapsed"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#faq7"
                        >

                            <i class="bi bi-person-lock text-primary me-3"></i>

                            How can I update my profile?

                        </button>

                    </h2>

                    <div
                        id="faq7"
                        class="accordion-collapse collapse"
                        data-bs-parent="#faqAccordion"
                    >

                        <div class="accordion-body">

                            Open the
                            <strong>Profile</strong>
                            section from your customer account.

                            You can update your personal
                            information such as your name,
                            email and phone number.

                        </div>

                    </div>

                </div>


            </div>

        </div>

    </div>


    <!-- Quick help section -->

    <div class="quick-help mb-5">

        <div class="row align-items-center">

            <div class="col-md-8">

                <h4>Still Need Help?</h4>

                <p class="mb-md-0">

                    If you couldn't find the answer
                    you were looking for, our support
                    team is ready to assist you.

                </p>

            </div>

            <div class="col-md-4 text-md-end mt-3 mt-md-0">

                <a
                    href="#contact"
                    class="btn btn-primary btn-lg"
                >

                    <i class="bi bi-headset me-2"></i>

                    Contact Support

                </a>

            </div>

        </div>

    </div>


    <!-- Contact support section -->

    <div id="contact" class="contact-section">


        <div class="text-center mb-4">

            <h2 class="section-title">

                Contact Support

            </h2>

            <p class="section-subtitle mb-0">

                We're happy to help you.
                Contact MediQuick Pharmacy
                using one of the options below.

            </p>

        </div>


        <div class="row mt-4">


            <!-- Phone support -->

            <div class="col-md-6">

                <div class="contact-item">

                    <div class="contact-icon">

                        <i class="bi bi-telephone-fill"></i>

                    </div>

                    <div>

                        <h6>Phone Support</h6>

                        <p>+94 37 222 4567</p>

                    </div>

                </div>

            </div>


            <!-- Email support -->

            <div class="col-md-6">

                <div class="contact-item">

                    <div class="contact-icon">

                        <i class="bi bi-envelope-fill"></i>

                    </div>

                    <div>

                        <h6>Email Support</h6>

                        <p>

                            <a href="mailto:support@mediquick.lk">

                                support@mediquick.lk

                            </a>

                        </p>

                    </div>

                </div>

            </div>


            <!-- Pharmacy location -->

            <div class="col-md-6">

                <div class="contact-item">

                    <div class="contact-icon">

                        <i class="bi bi-geo-alt-fill"></i>

                    </div>

                    <div>

                        <h6>Pharmacy Location</h6>

                        <p>Kurunegala, Sri Lanka</p>

                    </div>

                </div>

            </div>


            <!-- Support hours -->

            <div class="col-md-6">

                <div class="contact-item">

                    <div class="contact-icon">

                        <i class="bi bi-clock-fill"></i>

                    </div>

                    <div>

                        <h6>Support Hours</h6>

                        <p>
                            Monday - Saturday |
                            8:00 AM - 8:00 PM
                        </p>

                    </div>

                </div>

            </div>


        </div>


        <!-- Email support button -->

        <div class="text-center mt-3">

            <a
                href="mailto:support@mediquick.lk"
                class="btn btn-primary px-4"
            >

                <i class="bi bi-envelope me-2"></i>

                Email Our Support Team

            </a>

        </div>


    </div>


</div>


<?php

/*
 * Include the common website footer.
 */
include __DIR__ . '/../includes/footer.php';

?>


<!-- Bootstrap JavaScript -->

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>


</body>

</html>
