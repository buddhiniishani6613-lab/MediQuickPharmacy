
<?php
/*
|--------------------------------------------------------------------------
| MediQuick Pharmacy - Customer My Prescriptions
|--------------------------------------------------------------------------
*/

session_start();

/*
 * Check customer login and user role.
 */
if (empty($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

if (($_SESSION['user_role'] ?? '') !== 'customer') {

    if (($_SESSION['user_role'] ?? '') === 'admin') {
        header('Location: ../Admin/admin-dashboard.php');

    } elseif (($_SESSION['user_role'] ?? '') === 'staff') {
        header('Location: ../Staff/staff-dashboard.php');

    } else {
        header('Location: ../login.php');
    }

    exit;
}

/*
 * Load database connection and prescription helpers.
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/prescription-helpers.php';

if (!isset($conn) || $conn->connect_error) {
    die('Database connection failed.');
}

$conn->set_charset('utf8mb4');

$userId = (int) $_SESSION['user_id'];

/*
 * Load prescriptions belonging to the logged-in customer.
 */
$prescriptions = [];

$stmt = $conn->prepare(
    "SELECT
        id,
        patient_name,
        phone,
        email,
        file_name,
        file_path,
        file_type,
        notes,
        status,
        created_at
    FROM prescriptions
    WHERE user_id = ?
    ORDER BY created_at DESC"
);

if (!$stmt) {
    die(
        'Unable to load prescriptions: ' .
        mqPrescriptionEscape($conn->error)
    );
}

$stmt->bind_param('i', $userId);
$stmt->execute();

$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $prescriptions[] = $row;
}

$stmt->close();

/*
 * Calculate prescription status counts.
 */
$totalPrescriptions = count($prescriptions);

$statusCounts = [
    'Pending Review' => 0,
    'Approved' => 0,
    'Rejected' => 0,
    'Completed' => 0
];

foreach ($prescriptions as $prescription) {

    $status = trim($prescription['status'] ?? '');

    if (isset($statusCounts[$status])) {
        $statusCounts[$status]++;
    }
}

/*
 * Get the correct Bootstrap status colour.
 */
function getPrescriptionStatusClass($status)
{
    switch (strtolower(trim($status))) {

        case 'approved':
            return 'status-approved';

        case 'rejected':
            return 'status-rejected';

        case 'completed':
            return 'status-completed';

        case 'pending':
        case 'pending review':
            return 'status-pending';

        default:
            return 'status-default';
    }
}

/*
 * Include the common website header.
 */
include __DIR__ . '/../includes/header.php';

?>

<!-- ==============================
     Page Banner
============================== -->

<section class="prescription-banner">

    <div class="container">

        <div class="banner-content">

            <div class="banner-icon">
                <i class="bi bi-file-earmark-medical-fill"></i>
            </div>

            <div>

                <h1>My Prescriptions</h1>

                <p>
                    Manage your uploaded prescriptions
                    and check their latest review status.
                </p>

            </div>

        </div>

    </div>

</section>


<!-- ==============================
     Main Prescription Section
============================== -->

<section class="prescription-section">

    <div class="container">

        <!-- Page Heading -->

        <div class="page-heading">

            <div>

                <span class="section-label">
                    CUSTOMER ACCOUNT
                </span>

                <h2>Prescription History</h2>

                <p>
                    View your prescription details,
                    download uploaded files and track
                    their progress.
                </p>

            </div>

            <a
                href="../prescription.php"
                class="btn upload-btn"
            >

                <i class="bi bi-cloud-upload me-2"></i>

                Upload Prescription

            </a>

        </div>


        <!-- ==============================
             Prescription Summary
        ============================== -->

        <div class="row g-3 summary-row">

            <div class="col-6 col-lg-3">

                <div class="summary-card">

                    <div class="summary-icon total-icon">
                        <i class="bi bi-files"></i>
                    </div>

                    <div>

                        <h3>
                            <?= $totalPrescriptions; ?>
                        </h3>

                        <p>Total Prescriptions</p>

                    </div>

                </div>

            </div>


            <div class="col-6 col-lg-3">

                <div class="summary-card">

                    <div class="summary-icon pending-icon">
                        <i class="bi bi-clock-history"></i>
                    </div>

                    <div>

                        <h3>
                            <?= $statusCounts['Pending Review']; ?>
                        </h3>

                        <p>Pending Review</p>

                    </div>

                </div>

            </div>


            <div class="col-6 col-lg-3">

                <div class="summary-card">

                    <div class="summary-icon approved-icon">
                        <i class="bi bi-check-circle"></i>
                    </div>

                    <div>

                        <h3>
                            <?= $statusCounts['Approved']; ?>
                        </h3>

                        <p>Approved</p>

                    </div>

                </div>

            </div>


            <div class="col-6 col-lg-3">

                <div class="summary-card">

                    <div class="summary-icon completed-icon">
                        <i class="bi bi-check2-all"></i>
                    </div>

                    <div>

                        <h3>
                            <?= $statusCounts['Completed']; ?>
                        </h3>

                        <p>Completed</p>

                    </div>

                </div>

            </div>

        </div>


        <!-- ==============================
             Prescription List
        ============================== -->

        <div class="prescription-container">

            <div class="prescription-container-header">

                <div>

                    <h3>
                        <i class="bi bi-folder2-open me-2"></i>
                        Uploaded Prescriptions
                    </h3>

                    <p>
                        Your prescription records and review details.
                    </p>

                </div>

                <span class="record-count">
                    <?= $totalPrescriptions; ?>
                    Records
                </span>

            </div>


            <?php if (empty($prescriptions)): ?>

                <!-- Empty State -->

                <div class="empty-prescriptions">

                    <div class="empty-icon">

                        <i class="bi bi-file-earmark-medical"></i>

                    </div>

                    <h3>No Prescriptions Yet</h3>

                    <p>
                        You haven't uploaded any prescriptions yet.
                        Upload your prescription to let our pharmacy
                        team review it.
                    </p>

                    <a
                        href="../prescription.php"
                        class="btn upload-btn"
                    >

                        <i class="bi bi-cloud-upload me-2"></i>

                        Upload Your First Prescription

                    </a>

                </div>


            <?php else: ?>


                <?php foreach ($prescriptions as $prescription): ?>

                    <?php

                    $fileUrl = mqPrescriptionFileUrl(
                        $prescription['file_path'] ?? '',
                        $prescription['file_name'] ?? ''
                    );

                    $status = $prescription['status'] ?? 'Pending Review';

                    $statusClass = getPrescriptionStatusClass($status);

                    $prescriptionDate = !empty($prescription['created_at'])
                        ? date(
                            'd M Y, h:i A',
                            strtotime($prescription['created_at'])
                        )
                        : 'Date unavailable';

                    ?>

                    <div class="prescription-card">

                        <!-- Prescription Header -->

                        <div class="prescription-card-header">

                            <div class="prescription-heading-left">

                                <div class="prescription-file-icon">

                                    <i class="bi bi-file-earmark-medical-fill"></i>

                                </div>

                                <div>

                                    <h4>
                                        Prescription #<?= (int)$prescription['id']; ?>
                                    </h4>

                                    <span class="prescription-date">

                                        <i class="bi bi-calendar3 me-1"></i>

                                        <?= mqPrescriptionEscape($prescriptionDate); ?>

                                    </span>

                                </div>

                            </div>


                            <span class="prescription-status <?= $statusClass; ?>">

                                <i class="bi bi-circle-fill me-1"></i>

                                <?= mqPrescriptionEscape($status); ?>

                            </span>

                        </div>


                        <!-- Patient Information -->

                        <div class="patient-information">

                            <h5>
                                <i class="bi bi-person-vcard me-2"></i>
                                Patient Information
                            </h5>

                            <div class="row g-3">

                                <div class="col-md-4">

                                    <div class="detail-box">

                                        <span>Patient Name</span>

                                        <strong>
                                            <?= mqPrescriptionEscape($prescription['patient_name']); ?>
                                        </strong>

                                    </div>

                                </div>


                                <div class="col-md-4">

                                    <div class="detail-box">

                                        <span>Phone Number</span>

                                        <strong>
                                            <?= mqPrescriptionEscape($prescription['phone']); ?>
                                        </strong>

                                    </div>

                                </div>


                                <div class="col-md-4">

                                    <div class="detail-box">

                                        <span>Email Address</span>

                                        <strong>
                                            <?= mqPrescriptionEscape($prescription['email']); ?>
                                        </strong>

                                    </div>

                                </div>

                            </div>

                        </div>


                        <!-- Prescription Notes -->

                        <?php if (!empty($prescription['notes'])): ?>

                            <div class="prescription-notes">

                                <h5>

                                    <i class="bi bi-chat-left-text me-2"></i>

                                    Additional Notes

                                </h5>

                                <p>
                                    <?= nl2br(mqPrescriptionEscape($prescription['notes'])); ?>
                                </p>

                            </div>

                        <?php endif; ?>


                        <!-- Uploaded File -->

                        <div class="uploaded-file-section">

                            <div class="uploaded-file-info">

                                <div class="uploaded-file-icon">

                                    <i class="bi bi-file-earmark-image"></i>

                                </div>

                                <div>

                                    <strong>Uploaded Prescription</strong>

                                    <span>
                                        <?= mqPrescriptionEscape($prescription['file_name']); ?>
                                    </span>

                                </div>

                            </div>


                            <div class="file-actions">

                                <?php if ($fileUrl !== null): ?>

                                    <a
                                        class="btn btn-outline-primary btn-sm"
                                        href="<?= mqPrescriptionEscape($fileUrl); ?>"
                                        target="_blank"
                                        rel="noopener"
                                    >

                                        <i class="bi bi-eye me-1"></i>

                                        View

                                    </a>


                                    <a
                                        class="btn btn-outline-secondary btn-sm"
                                        href="<?= mqPrescriptionEscape($fileUrl); ?>"
                                        download
                                    >

                                        <i class="bi bi-download me-1"></i>

                                        Download

                                    </a>

                                <?php else: ?>

                                    <span class="file-unavailable">

                                        <i class="bi bi-exclamation-triangle me-1"></i>

                                        File unavailable

                                    </span>

                                <?php endif; ?>

                            </div>

                        </div>


                    </div>

                <?php endforeach; ?>


            <?php endif; ?>

        </div>


        <!-- Information Note -->

        <div class="prescription-information">

            <div class="information-icon">

                <i class="bi bi-info-circle-fill"></i>

            </div>

            <div>

                <strong>Prescription Review Information</strong>

                <p>
                    Your uploaded prescriptions are reviewed by
                    the MediQuick Pharmacy team. You can check
                    the latest status on this page.
                </p>

            </div>

        </div>


    </div>

</section>


<!-- ==============================
     Page Styles
============================== -->

<style>

/* General Page */

.prescription-section {
    background: #f6f9fc;
    padding: 40px 0 70px;
    min-height: 75vh;
}


/* Banner */

.prescription-banner {
    background: linear-gradient(
        135deg,
        #006391,
        #0dcaf0
    );

    color: white;

    padding: 45px 20px;

    border-radius: 0 0 25px 25px;
}

.banner-content {
    display: flex;
    align-items: center;
    gap: 22px;
}

.banner-icon {
    width: 75px;
    height: 75px;
    min-width: 75px;

    background: rgba(255,255,255,0.18);

    border: 1px solid rgba(255,255,255,0.3);

    border-radius: 18px;

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 38px;
}

.prescription-banner h1 {
    font-size: 34px;
    font-weight: 750;
    margin: 0 0 8px;
}

.prescription-banner p {
    margin: 0;
    opacity: 0.92;
    font-size: 15px;
}


/* Page Heading */

.page-heading {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 20px;
    margin-bottom: 28px;
}

.section-label {
    color: #087f9b;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1.7px;
}

.page-heading h2 {
    color: #174f68;
    font-size: 27px;
    font-weight: 750;
    margin: 7px 0;
}

.page-heading p {
    color: #71818a;
    font-size: 14px;
    margin: 0;
}

.upload-btn {
    background: #087f9b;
    color: white;
    border: none;
    border-radius: 9px;
    padding: 11px 19px;
    font-size: 13px;
    font-weight: 700;
    transition: 0.2s;
}

.upload-btn:hover {
    background: #056b83;
    color: white;
    transform: translateY(-2px);
}


/* Summary Cards */

.summary-row {
    margin-bottom: 28px;
}

.summary-card {
    background: white;
    border: 1px solid #e8eef2;
    border-radius: 14px;
    padding: 17px;
    display: flex;
    align-items: center;
    gap: 13px;
    height: 100%;
    box-shadow: 0 4px 18px rgba(0,70,100,0.04);
}

.summary-icon {
    width: 47px;
    height: 47px;
    min-width: 47px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
}

.total-icon {
    background: #e5f4fb;
    color: #087f9b;
}

.pending-icon {
    background: #fff3d9;
    color: #c58a19;
}

.approved-icon {
    background: #e1f6eb;
    color: #198754;
}

.completed-icon {
    background: #e8edff;
    color: #5269c7;
}

.summary-card h3 {
    color: #174f68;
    font-size: 23px;
    font-weight: 750;
    margin: 0 0 3px;
}

.summary-card p {
    color: #7b8991;
    font-size: 11px;
    margin: 0;
}


/* Main Container */

.prescription-container {
    background: white;
    border-radius: 17px;
    border: 1px solid #e6edf1;
    box-shadow: 0 5px 25px rgba(0,0,0,0.05);
    overflow: hidden;
}

.prescription-container-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
    padding: 23px 25px;
    border-bottom: 1px solid #edf0f2;
}

.prescription-container-header h3 {
    color: #174f68;
    font-size: 18px;
    font-weight: 750;
    margin: 0 0 5px;
}

.prescription-container-header h3 i {
    color: #087f9b;
}

.prescription-container-header p {
    color: #89959b;
    font-size: 12px;
    margin: 0;
}

.record-count {
    background: #e8f6fa;
    color: #087f9b;
    border-radius: 20px;
    padding: 6px 13px;
    font-size: 11px;
    font-weight: 700;
}


/* Prescription Card */

.prescription-card {
    margin: 22px 25px;
    border: 1px solid #e5edf1;
    border-radius: 14px;
    padding: 22px;
    transition: 0.2s;
}

.prescription-card:hover {
    border-color: #b9dfe8;
    box-shadow: 0 5px 20px rgba(0,90,120,0.06);
}

.prescription-card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
    padding-bottom: 18px;
    border-bottom: 1px solid #edf1f3;
}

.prescription-heading-left {
    display: flex;
    align-items: center;
    gap: 13px;
}

.prescription-file-icon {
    width: 48px;
    height: 48px;
    background: #e7f5fa;
    color: #087f9b;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 23px;
}

.prescription-heading-left h4 {
    color: #174f68;
    font-size: 16px;
    font-weight: 750;
    margin: 0 0 5px;
}

.prescription-date {
    color: #89969c;
    font-size: 11px;
}


/* Status Badges */

.prescription-status {
    padding: 7px 13px;
    border-radius: 25px;
    font-size: 11px;
    font-weight: 750;
    white-space: nowrap;
}

.prescription-status i {
    font-size: 7px;
}

.status-pending {
    background: #fff3d9;
    color: #a87512;
}

.status-approved {
    background: #e1f6eb;
    color: #198754;
}

.status-rejected {
    background: #ffe7e7;
    color: #d04444;
}

.status-completed {
    background: #e8edff;
    color: #5269c7;
}

.status-default {
    background: #e8f6fa;
    color: #087f9b;
}


/* Patient Information */

.patient-information {
    padding: 20px 0;
}

.patient-information h5,
.prescription-notes h5 {
    color: #174f68;
    font-size: 13px;
    font-weight: 750;
    margin-bottom: 14px;
}

.patient-information h5 i,
.prescription-notes h5 i {
    color: #087f9b;
}

.detail-box {
    background: #f7fafc;
    border: 1px solid #edf1f3;
    border-radius: 9px;
    padding: 12px;
    height: 100%;
    min-width: 0;
}

.detail-box span {
    display: block;
    color: #89969c;
    font-size: 10px;
    margin-bottom: 6px;
}

.detail-box strong {
    display: block;
    color: #365767;
    font-size: 12px;
    overflow-wrap: anywhere;
}


/* Notes */

.prescription-notes {
    padding: 15px;
    background: #f4f9fc;
    border-radius: 10px;
    margin-bottom: 18px;
}

.prescription-notes h5 {
    margin-bottom: 8px;
}

.prescription-notes p {
    color: #647780;
    font-size: 13px;
    line-height: 1.6;
    margin: 0;
}


/* Uploaded File */

.uploaded-file-section {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
    padding: 15px;
    background: #f8fbfc;
    border: 1px solid #edf1f3;
    border-radius: 10px;
}

.uploaded-file-info {
    display: flex;
    align-items: center;
    gap: 12px;
    min-width: 0;
}

.uploaded-file-icon {
    width: 42px;
    height: 42px;
    min-width: 42px;
    background: #e5f4fb;
    color: #087f9b;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
}

.uploaded-file-info strong {
    display: block;
    color: #365767;
    font-size: 12px;
    margin-bottom: 4px;
}

.uploaded-file-info span {
    display: block;
    color: #89969c;
    font-size: 10px;
    overflow-wrap: anywhere;
}

.file-actions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.file-actions .btn {
    font-size: 11px;
    font-weight: 650;
    border-radius: 7px;
    padding: 7px 12px;
}

.file-unavailable {
    color: #dc3545;
    font-size: 11px;
    font-weight: 600;
}


/* Empty State */

.empty-prescriptions {
    text-align: center;
    padding: 65px 20px;
}

.empty-icon {
    width: 95px;
    height: 95px;
    background: #eaf5fa;
    color: #087f9b;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 42px;
    margin: 0 auto 20px;
}

.empty-prescriptions h3 {
    color: #174f68;
    font-size: 21px;
    font-weight: 750;
    margin-bottom: 10px;
}

.empty-prescriptions p {
    max-width: 480px;
    margin: 0 auto 23px;
    color: #7b8991;
    font-size: 13px;
    line-height: 1.7;
}


/* Information Note */

.prescription-information {
    display: flex;
    align-items: flex-start;
    gap: 13px;
    background: #eaf6fb;
    border: 1px solid #d8edf5;
    border-radius: 12px;
    padding: 17px 20px;
    margin-top: 25px;
}

.information-icon {
    color: #087f9b;
    font-size: 21px;
}

.prescription-information strong {
    display: block;
    color: #174f68;
    font-size: 12px;
    margin-bottom: 5px;
}

.prescription-information p {
    color: #6d828d;
    font-size: 11px;
    line-height: 1.6;
    margin: 0;
}


/* Responsive Design */

@media (max-width: 768px) {

    .prescription-banner {
        padding: 35px 15px;
    }

    .prescription-banner h1 {
        font-size: 27px;
    }

    .banner-icon {
        width: 60px;
        height: 60px;
        min-width: 60px;
        font-size: 29px;
    }

    .page-heading {
        align-items: flex-start;
    }

    .prescription-card {
        margin: 16px;
        padding: 17px;
    }

    .prescription-container-header {
        padding: 18px;
    }

}

@media (max-width: 576px) {

    .prescription-section {
        padding: 30px 0 45px;
    }

    .prescription-banner h1 {
        font-size: 23px;
    }

    .prescription-banner p {
        font-size: 12px;
    }

    .banner-content {
        gap: 14px;
    }

    .banner-icon {
        width: 52px;
        height: 52px;
        min-width: 52px;
        font-size: 25px;
        border-radius: 13px;
    }

    .page-heading h2 {
        font-size: 23px;
    }

    .summary-card {
        padding: 12px;
        gap: 9px;
    }

    .summary-icon {
        width: 38px;
        height: 38px;
        min-width: 38px;
        font-size: 18px;
    }

    .summary-card h3 {
        font-size: 19px;
    }

    .summary-card p {
        font-size: 9px;
    }

    .prescription-card-header {
        align-items: flex-start;
        flex-direction: column;
    }

    .uploaded-file-section {
        align-items: flex-start;
        flex-direction: column;
    }

    .file-actions {
        width: 100%;
    }

    .file-actions .btn {
        flex: 1;
    }

}

</style>


<!-- Bootstrap JS -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


<?php

/*
 * Include the common website footer.
 */
include __DIR__ . '/../includes/footer.php';

?>
