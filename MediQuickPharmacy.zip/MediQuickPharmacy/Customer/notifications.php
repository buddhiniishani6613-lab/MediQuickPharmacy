<?php
session_start();

/*
 * Load the database connection.
 * This file is inside the Customer folder, so ../ is used
 * to move to the main project folder.
 */
require_once __DIR__ . '/../config/database.php';

/*
 * Check whether the customer is logged in.
 * If the user is not logged in, redirect to the main login page.
 */
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$userId = (int) $_SESSION['user_id'];

/*
 * Escape values before displaying them in HTML.
 */
function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
 * Mark a single notification as read.
 * The notification can only be updated when it belongs
 * to the currently logged-in customer.
 */
if (isset($_GET['read'])) {

    $notificationId = (int) $_GET['read'];

    if ($notificationId > 0) {

        $stmt = $conn->prepare("
            UPDATE notifications
            SET is_read = 1
            WHERE id = ?
            AND user_id = ?
        ");

        if ($stmt) {

            $stmt->bind_param(
                "ii",
                $notificationId,
                $userId
            );

            $stmt->execute();
            $stmt->close();
        }
    }

    header(
        "Location: notifications.php"
    );

    exit;
}

/*
 * Mark all unread notifications belonging to
 * the current customer as read.
 */
if (
    isset($_GET['mark_all']) &&
    $_GET['mark_all'] === '1'
) {

    $stmt = $conn->prepare("
        UPDATE notifications
        SET is_read = 1
        WHERE user_id = ?
        AND is_read = 0
    ");

    if ($stmt) {

        $stmt->bind_param(
            "i",
            $userId
        );

        $stmt->execute();
        $stmt->close();
    }

    header(
        "Location: notifications.php?marked=1"
    );

    exit;
}

/*
 * Delete a single notification belonging to
 * the currently logged-in customer.
 */
if (isset($_GET['delete'])) {

    $notificationId = (int) $_GET['delete'];

    if ($notificationId > 0) {

        $stmt = $conn->prepare("
            DELETE FROM notifications
            WHERE id = ?
            AND user_id = ?
        ");

        if ($stmt) {

            $stmt->bind_param(
                "ii",
                $notificationId,
                $userId
            );

            $stmt->execute();
            $stmt->close();
        }
    }

    header(
        "Location: notifications.php?deleted=1"
    );

    exit;
}

/*
 * Delete all notifications belonging to
 * the currently logged-in customer.
 */
if (
    isset($_GET['clear']) &&
    $_GET['clear'] === '1'
) {

    $stmt = $conn->prepare("
        DELETE FROM notifications
        WHERE user_id = ?
    ");

    if ($stmt) {

        $stmt->bind_param(
            "i",
            $userId
        );

        $stmt->execute();
        $stmt->close();
    }

    header(
        "Location: notifications.php?cleared=1"
    );

    exit;
}

/*
 * Get all notifications belonging to
 * the currently logged-in customer.
 */
$notifications = [];

$stmt = $conn->prepare("
    SELECT
        id,
        title,
        message,
        type,
        related_id,
        is_read,
        created_at
    FROM notifications
    WHERE user_id = ?
    ORDER BY created_at DESC
");

if ($stmt) {

    $stmt->bind_param(
        "i",
        $userId
    );

    $stmt->execute();

    $result = $stmt->get_result();

    while (
        $row = $result->fetch_assoc()
    ) {

        $notifications[] = $row;
    }

    $stmt->close();
}

/*
 * Get the number of unread notifications.
 */
$unreadCount = 0;

$stmt = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM notifications
    WHERE user_id = ?
    AND is_read = 0
");

if ($stmt) {

    $stmt->bind_param(
        "i",
        $userId
    );

    $stmt->execute();

    $result = $stmt->get_result();

    $row = $result->fetch_assoc();

    $unreadCount = (int) $row['total'];

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Notifications | MediQuick Pharmacy
    </title>

    <!-- Bootstrap CSS -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Bootstrap Icons -->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    >

    <style>

        body {
            background: #f6f9fc;
            font-family:
                Arial,
                sans-serif;
        }

        .notification-header {
            background:
                linear-gradient(
                    135deg,
                    #006391,
                    #0dcaf0
                );

            color: white;

            padding:
                45px 20px;

            border-radius:
                0 0 25px 25px;

            margin-bottom: 35px;
        }

        .notification-header h1 {
            font-weight: 700;
            margin-bottom: 8px;
        }

        .notification-header p {
            margin: 0;
            opacity: 0.9;
        }

        .notification-container {
            background: white;

            border-radius: 20px;

            box-shadow:
                0 5px 25px
                rgba(0,0,0,0.07);

            overflow: hidden;
        }

        .notification-top {
            padding:
                22px 25px;

            border-bottom:
                1px solid #edf0f2;

            display: flex;

            justify-content:
                space-between;

            align-items: center;

            gap: 15px;

            flex-wrap: wrap;
        }

        .notification-title {
            font-size: 20px;

            font-weight: 700;

            color: #212529;
        }

        .unread-badge {
            background: #dc3545;

            color: white;

            font-size: 12px;

            padding:
                5px 9px;

            border-radius: 20px;

            margin-left: 7px;
        }

        .notification-item {
            padding:
                20px 25px;

            border-bottom:
                1px solid #edf0f2;

            display: flex;

            align-items: flex-start;

            gap: 17px;

            position: relative;

            transition:
                background 0.2s ease;
        }

        .notification-item:hover {
            background: #f9fbfd;
        }

        .notification-item.unread {
            background: #f0f7ff;
        }

        .notification-icon {
            min-width: 48px;

            width: 48px;

            height: 48px;

            border-radius: 50%;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 21px;
        }

        .icon-order {
            background: #e8f1ff;
            color: #006f9b;
        }

        .icon-prescription {
            background: #fff3cd;
            color: #856404;
        }

        .icon-payment {
            background: #d1e7dd;
            color: #198754;
        }

        .icon-product {
            background: #fce8f0;
            color: #d63384;
        }

        .icon-system {
            background: #e9ecef;
            color: #495057;
        }

        .notification-content {
            flex: 1;

            padding-right: 30px;
        }

        .notification-content h5 {
            margin:
                0 0 7px;

            font-size: 16px;

            font-weight: 700;

            color: #212529;
        }

        .notification-content p {
            margin:
                0 0 8px;

            font-size: 14px;

            color: #6c757d;

            line-height: 1.55;
        }

        .notification-time {
            font-size: 12px;

            color: #929aa2;
        }

        .unread-dot {
            width: 9px;

            height: 9px;

            background: #0081cc;

            border-radius: 50%;

            position: absolute;

            top: 25px;

            right: 18px;
        }

        .delete-notification {
            color: #adb5bd;

            text-decoration: none;

            font-size: 18px;

            transition: 0.2s;
        }

        .delete-notification:hover {
            color: #dc3545;
        }

        .type-badge {
            display: inline-block;

            font-size: 10px;

            padding:
                4px 8px;

            border-radius: 12px;

            margin-bottom: 7px;

            font-weight: 600;
        }

        .badge-order {
            background: #e8f1ff;
            color: #008ecf;
        }

        .badge-prescription {
            background: #fff3cd;
            color: #856404;
        }

        .badge-payment {
            background: #d1e7dd;
            color: #198754;
        }

        .badge-product {
            background: #fce8f0;
            color: #d63384;
        }

        .badge-system {
            background: #e9ecef;
            color: #495057;
        }

        .empty-notifications {
            padding:
                75px 25px;

            text-align: center;
        }

        .empty-icon {
            width: 100px;

            height: 100px;

            border-radius: 50%;

            background: #eaf3ff;

            color: #007ec7;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 45px;

            margin:
                0 auto 22px;
        }

        .empty-notifications h3 {
            font-weight: 700;

            margin-bottom: 10px;
        }

        .empty-notifications p {
            color: #6c757d;

            max-width: 500px;

            margin:
                0 auto 25px;
        }

        @media (max-width: 576px) {

            .notification-item {
                padding:
                    18px 15px;
            }

            .notification-top {
                padding:
                    18px 15px;
            }

            .notification-icon {
                min-width: 42px;

                width: 42px;

                height: 42px;

                font-size: 18px;
            }

            .notification-content {
                padding-right: 20px;
            }
        }

    </style>

</head>

<body>

<?php
/*
 * Load the common website header.
 * This file is inside the Customer folder, so ../ is required.
 */
include __DIR__ . '/../includes/header.php';
?>

<section class="notification-header">

    <div class="container">

        <div
            class="d-flex align-items-center gap-3"
        >

            <div>

                <i
                    class="bi bi-bell-fill fs-1"
                ></i>

            </div>

            <div>

                <h1>
                    Notifications
                </h1>

                <p>
                    Stay updated with your
                    orders, prescriptions and
                    pharmacy updates.
                </p>

            </div>

        </div>

    </div>

</section>

<div class="container pb-5">

    <div
        class="notification-container"
    >

        <div
            class="notification-top"
        >

            <div
                class="notification-title"
            >

                <i
                    class="bi bi-bell me-2 text-primary"
                ></i>

                Notifications

                <?php if ($unreadCount > 0): ?>

                    <span
                        class="unread-badge"
                    >

                        <?php
                        echo $unreadCount;
                        ?>

                        New

                    </span>

                <?php endif; ?>

            </div>

            <div
                class="d-flex gap-2 flex-wrap"
            >

                <?php if ($unreadCount > 0): ?>

                    <a
                        href="notifications.php?mark_all=1"
                        class="btn btn-sm btn-outline-primary"
                    >

                        <i
                            class="bi bi-check2-all me-1"
                        ></i>

                        Mark All as Read

                    </a>

                <?php endif; ?>

                <?php if (count($notifications) > 0): ?>

                    <a
                        href="notifications.php?clear=1"
                        class="btn btn-sm btn-outline-danger"
                        onclick="
                            return confirm(
                                'Are you sure you want to delete all notifications?'
                            );
                        "
                    >

                        <i
                            class="bi bi-trash me-1"
                        ></i>

                        Clear All

                    </a>

                <?php endif; ?>

            </div>

        </div>

        <?php if (count($notifications) > 0): ?>

            <?php foreach (
                $notifications
                as $notification
            ): ?>

                <?php

                $type =
                    $notification['type'];

                $iconClass =
                    'icon-system';

                $icon =
                    'bi-info-circle';

                $badgeClass =
                    'badge-system';

                switch ($type) {

                    case 'Order':

                        $iconClass =
                            'icon-order';

                        $icon =
                            'bi-bag-check';

                        $badgeClass =
                            'badge-order';

                        break;

                    case 'Prescription':

                        $iconClass =
                            'icon-prescription';

                        $icon =
                            'bi-file-earmark-medical';

                        $badgeClass =
                            'badge-prescription';

                        break;

                    case 'Payment':

                        $iconClass =
                            'icon-payment';

                        $icon =
                            'bi-credit-card';

                        $badgeClass =
                            'badge-payment';

                        break;

                    case 'Product':

                        $iconClass =
                            'icon-product';

                        $icon =
                            'bi-box-seam';

                        $badgeClass =
                            'badge-product';

                        break;

                    case 'System':

                        $iconClass =
                            'icon-system';

                        $icon =
                            'bi-info-circle';

                        $badgeClass =
                            'badge-system';

                        break;
                }

                $isUnread =
                    (
                        (int)
                        $notification['is_read'] === 0
                    );

                ?>

                <div
                    class="
                        notification-item
                        <?php
                        echo $isUnread
                            ? 'unread'
                            : '';
                        ?>
                    "
                >

                    <div
                        class="
                            notification-icon
                            <?php
                            echo e(
                                $iconClass
                            );
                            ?>
                        "
                    >

                        <i
                            class="
                                bi
                                <?php
                                echo e(
                                    $icon
                                );
                                ?>
                            "
                        ></i>

                    </div>

                    <div
                        class="notification-content"
                    >

                        <span
                            class="
                                type-badge
                                <?php
                                echo e(
                                    $badgeClass
                                );
                                ?>
                            "
                        >

                            <?php
                            echo e(
                                $type
                            );
                            ?>

                        </span>

                        <h5>

                            <?php
                            echo e(
                                $notification['title']
                            );
                            ?>

                        </h5>

                        <p>

                            <?php
                            echo e(
                                $notification['message']
                            );
                            ?>

                        </p>

                        <div
                            class="notification-time"
                        >

                            <i
                                class="bi bi-clock me-1"
                            ></i>

                            <?php
                            echo date(
                                "M d, Y • h:i A",
                                strtotime(
                                    $notification['created_at']
                                )
                            );
                            ?>

                            <?php if ($isUnread): ?>

                                <span
                                    class="ms-2 text-primary fw-semibold"
                                >

                                    • Unread

                                </span>

                            <?php endif; ?>

                        </div>

                        <?php if ($isUnread): ?>

                            <div class="mt-2">

                                <a
                                    href="notifications.php?read=<?php
                                        echo (int)
                                        $notification['id'];
                                    ?>"
                                    class="
                                        btn
                                        btn-sm
                                        btn-outline-primary
                                    "
                                >

                                    <i
                                        class="bi bi-check2 me-1"
                                    ></i>

                                    Mark as Read

                                </a>

                            </div>

                        <?php endif; ?>

                    </div>

                    <?php if ($isUnread): ?>

                        <span
                            class="unread-dot"
                        ></span>

                    <?php endif; ?>

                    <a
                        href="notifications.php?delete=<?php
                            echo (int)
                            $notification['id'];
                        ?>"
                        class="delete-notification"
                        title="Delete Notification"
                        onclick="
                            return confirm(
                                'Delete this notification?'
                            );
                        "
                    >

                        <i
                            class="bi bi-x-lg"
                        ></i>

                    </a>

                </div>

            <?php endforeach; ?>

        <?php else: ?>

            <div
                class="empty-notifications"
            >

                <div
                    class="empty-icon"
                >

                    <i
                        class="bi bi-bell-slash"
                    ></i>

                </div>

                <h3>
                    No Notifications
                </h3>

                <p>
                    You don't have any
                    notifications right now.
                    We'll notify you when
                    there are updates about
                    your orders, prescriptions
                    or pharmacy services.
                </p>

                <a
                    href="../products.php"
                    class="btn btn-primary"
                >

                    <i
                        class="bi bi-shop me-2"
                    ></i>

                    Browse Products

                </a>

            </div>

        <?php endif; ?>

    </div>

</div>

<?php
/*
 * Load the common website footer.
 * This file is inside the Customer folder, so ../ is required.
 */
include __DIR__ . '/../includes/footer.php';
?>

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>

</body>
</html>