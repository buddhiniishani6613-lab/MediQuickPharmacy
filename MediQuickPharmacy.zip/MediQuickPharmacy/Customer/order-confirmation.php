<?php

/*
 * Load the common header from the main includes folder.
 * This file is inside the Customer folder, so ../ is used.
 */
include '../includes/header.php';

?>

<section class="confirmation-section">

    <div class="confirmation-container">

        <!-- SUCCESS MESSAGE -->

        <div class="success-icon">
            <i class="bi bi-check-circle-fill"></i>
        </div>

        <h1>Order Placed Successfully!</h1>

        <p class="success-message">
            Thank you for choosing MediQuick Pharmacy.
            Your order has been received successfully.
        </p>


        <!-- ORDER DETAILS -->

        <div class="confirmation-layout">

            <!-- CUSTOMER INFORMATION -->

            <div class="confirmation-card">

                <h2>
                    <i class="bi bi-person"></i>
                    Customer Details
                </h2>

                <div class="detail-row">

                    <span>Order Number</span>

                    <strong id="orderNumber">
                        -
                    </strong>

                </div>


                <div class="detail-row">

                    <span>Customer Name</span>

                    <strong id="customerName">
                        -
                    </strong>

                </div>


                <div class="detail-row">

                    <span>Email</span>

                    <strong id="customerEmail">
                        -
                    </strong>

                </div>


                <div class="detail-row">

                    <span>Phone</span>

                    <strong id="customerPhone">
                        -
                    </strong>

                </div>


                <div class="detail-row">

                    <span>Payment Method</span>

                    <strong id="paymentMethod">
                        -
                    </strong>

                </div>


                <div class="address-box">

                    <strong>
                        <i class="bi bi-geo-alt"></i>
                        Delivery Address
                    </strong>

                    <p id="deliveryAddress">
                        -
                    </p>

                </div>

            </div>


            <!-- ORDER SUMMARY -->

            <div class="confirmation-card">

                <h2>
                    <i class="bi bi-bag-check"></i>
                    Order Summary
                </h2>


                <div id="orderedItems">

                    <!-- Products loaded here -->

                </div>


                <div class="summary-line"></div>


                <div class="total-row">

                    <span>
                        Subtotal
                    </span>

                    <strong>
                        Rs.
                        <span id="orderSubtotal">
                            0.00
                        </span>
                    </strong>

                </div>


                <div class="total-row">

                    <span>
                        Delivery
                    </span>

                    <strong>
                        Rs.
                        <span id="orderDelivery">
                            0.00
                        </span>
                    </strong>

                </div>


                <div class="summary-line"></div>


                <div class="grand-total">

                    <span>
                        Total
                    </span>

                    <strong>
                        Rs.
                        <span id="orderTotal">
                            0.00
                        </span>
                    </strong>

                </div>

            </div>

        </div>


        <!-- BUTTONS -->

        <div class="confirmation-buttons">

            <a
                href="../products.php"
                class="continue-shopping"
            >

                <i class="bi bi-cart"></i>

                Continue Shopping

            </a>


            <a
                href="../index.php"
                class="home-button"
            >

                <i class="bi bi-house"></i>

                Back to Home

            </a>

        </div>

    </div>

</section>


<style>

/* Order confirmation section */

.confirmation-section {

    min-height: 80vh;

    background: #f6fbfd;

    padding: 60px 20px;

}


.confirmation-container {

    max-width: 1050px;

    margin: auto;

    text-align: center;

}


/* Success icon */

.success-icon {

    width: 80px;

    height: 80px;

    margin: 0 auto 20px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 50%;

    background: #e6f8f5;

}


.success-icon i {

    font-size: 48px;

    color: #0b9b83;

}


.confirmation-container > h1 {

    color: #174f68;

    font-size: 34px;

    margin: 0 0 10px;

}


.success-message {

    color: #777;

    max-width: 650px;

    margin: 0 auto 40px;

    line-height: 1.7;

}


/* Confirmation layout */

.confirmation-layout {

    display: grid;

    grid-template-columns:
        1fr 1fr;

    gap: 25px;

    text-align: left;

}


/* Confirmation cards */

.confirmation-card {

    background: white;

    padding: 28px;

    border-radius: 16px;

    box-shadow:
        0 5px 25px
        rgba(0, 80, 110, 0.08);

}


.confirmation-card h2 {

    color: #174f68;

    font-size: 20px;

    margin: 0 0 22px;

    display: flex;

    align-items: center;

    gap: 9px;

}


.confirmation-card h2 i {

    color: #087f9b;

}


/* Customer details */

.detail-row {

    display: flex;

    justify-content: space-between;

    gap: 20px;

    padding: 13px 0;

    border-bottom:
        1px solid #edf2f4;

}


.detail-row span {

    color: #777;

    font-size: 14px;

}


.detail-row strong {

    color: #174f68;

    font-size: 14px;

    text-align: right;

    word-break: break-word;

}


/* Delivery address */

.address-box {

    margin-top: 20px;

    padding: 16px;

    background: #f5fafc;

    border-radius: 10px;

}


.address-box strong {

    color: #174f68;

}


.address-box strong i {

    color: #087f9b;

}


.address-box p {

    color: #666;

    margin: 10px 0 0;

    line-height: 1.6;

}


/* Ordered products */

.confirmation-item {

    display: flex;

    align-items: center;

    gap: 12px;

    padding: 12px 0;

    border-bottom:
        1px solid #edf2f4;

}


.confirmation-item-image {

    width: 60px;

    height: 60px;

    padding: 5px;

    object-fit: contain;

    border-radius: 8px;

    background: #f5fafc;

}


.confirmation-item-info {

    flex: 1;

}


.confirmation-item-info h4 {

    color: #174f68;

    font-size: 14px;

    margin: 0 0 5px;

}


.confirmation-item-info p {

    color: #777;

    font-size: 13px;

    margin: 0;

}


.confirmation-item-price {

    color: #087f9b;

    font-weight: 700;

    font-size: 14px;

}


/* Order totals */

.summary-line {

    height: 1px;

    background: #e8eff1;

    margin: 18px 0;

}


.total-row {

    display: flex;

    justify-content: space-between;

    padding: 7px 0;

    color: #666;

}


.total-row strong {

    color: #174f68;

}


.grand-total {

    display: flex;

    justify-content: space-between;

    align-items: center;

    font-size: 20px;

    color: #174f68;

}


.grand-total strong {

    color: #087f9b;

}


/* Confirmation buttons */

.confirmation-buttons {

    display: flex;

    justify-content: center;

    gap: 15px;

    margin-top: 35px;

}


.continue-shopping,
.home-button {

    text-decoration: none;

    padding: 13px 24px;

    border-radius: 8px;

    font-weight: 600;

    transition: 0.2s;

}


.continue-shopping {

    background: #087f9b;

    color: white;

}


.continue-shopping:hover {

    background: #056b83;

}


.home-button {

    background: white;

    color: #087f9b;

    border:
        1px solid #087f9b;

}


.home-button:hover {

    background: #eef9fb;

}


/* Responsive layout */

@media (max-width: 800px) {

    .confirmation-layout {

        grid-template-columns: 1fr;

    }

}


@media (max-width: 550px) {

    .confirmation-section {

        padding: 40px 15px;

    }


    .confirmation-container > h1 {

        font-size: 27px;

    }


    .confirmation-card {

        padding: 20px;

    }


    .confirmation-buttons {

        flex-direction: column;

    }


    .continue-shopping,
    .home-button {

        text-align: center;

    }

}

</style>


<script>

/*
 * Load the most recently saved order
 * from localStorage.
 */

function loadOrderConfirmation() {

    let order = null;


    try {

        order =
            JSON.parse(
                localStorage.getItem(
                    "mediquickLastOrder"
                )
            );

    } catch (error) {

        order = null;

    }


    /*
     * Display an empty state when
     * no recent order is available.
     */

    if (!order) {

        document.getElementById(
            "orderedItems"
        ).innerHTML = `

            <div style="
                text-align:center;
                padding:25px 0;
                color:#777;
            ">

                <i
                    class="bi bi-receipt"
                    style="
                        font-size:40px;
                        color:#087f9b;
                    "
                ></i>

                <p>
                    No recent order found.
                </p>

                <a
                    href="../products.php"
                    style="
                        color:#087f9b;
                        font-weight:600;
                        text-decoration:none;
                    "
                >
                    Start Shopping
                </a>

            </div>

        `;

        return;

    }


    /* Customer information */

    document.getElementById(
        "orderNumber"
    ).textContent =
        order.orderNumber || "-";


    document.getElementById(
        "customerName"
    ).textContent =
        order.customer?.fullName || "-";


    document.getElementById(
        "customerEmail"
    ).textContent =
        order.customer?.email || "-";


    document.getElementById(
        "customerPhone"
    ).textContent =
        order.customer?.phone || "-";


    document.getElementById(
        "paymentMethod"
    ).textContent =
        order.paymentMethod || "-";


    document.getElementById(
        "deliveryAddress"
    ).textContent =

        (order.customer?.address || "") +
        ", " +
        (order.customer?.city || "");


    /* Ordered products */

    const itemsContainer =
        document.getElementById(
            "orderedItems"
        );


    itemsContainer.innerHTML = "";


    let subtotal = 0;

    let itemCount = 0;


    if (
        order.items &&
        order.items.length > 0
    ) {

        order.items.forEach(
            function (item) {

                const quantity =
                    Number(item.quantity) || 1;

                const price =
                    Number(item.price) || 0;

                const itemTotal =
                    price * quantity;


                subtotal +=
                    itemTotal;

                itemCount +=
                    quantity;


                /*
                 * Product images are stored relative
                 * to the main project assets folder.
                 */

                let imagePath =
                    item.image ||
                    "../assets/images/Logo.png";


                /*
                 * Remove ./ from old image paths.
                 */

                if (
                    imagePath.startsWith("./")
                ) {

                    imagePath =
                        imagePath.substring(2);

                }


                /*
                 * Convert image paths that start with
                 * assets/ into paths suitable for a
                 * page inside the Customer folder.
                 */

                if (
                    imagePath.startsWith("assets/")
                ) {

                    imagePath =
                        "../" +
                        imagePath;

                }


                /*
                 * Convert old images/ paths into the
                 * current assets/images/ structure.
                 */

                else if (
                    imagePath.startsWith("images/")
                ) {

                    imagePath =
                        "../assets/" +
                        imagePath;

                }


                /*
                 * Convert the old logo path to
                 * the current MediQuick logo.
                 */

                if (
                    imagePath ===
                    "../assets/Logo.jpg"
                ) {

                    imagePath =
                        "../assets/images/Logo.png";

                }


                /*
                 * Encode spaces in image filenames
                 * without changing the folder structure.
                 */

                imagePath =
                    encodeURI(imagePath);


                const itemElement =
                    document.createElement(
                        "div"
                    );


                itemElement.className =
                    "confirmation-item";


                itemElement.innerHTML = `

                    <img
                        src="${imagePath}"
                        alt="${item.name}"
                        class="confirmation-item-image"
                        onerror="
                            this.onerror=null;
                            this.src='../assets/images/Logo.png';
                        "
                    >


                    <div
                        class="confirmation-item-info"
                    >

                        <h4>
                            ${item.name}
                        </h4>

                        <p>
                            Qty:
                            ${quantity}
                        </p>

                    </div>


                    <div
                        class="confirmation-item-price"
                    >

                        Rs.
                        ${itemTotal.toFixed(2)}

                    </div>

                `;


                itemsContainer.appendChild(
                    itemElement
                );

            }
        );

    }


    /* Calculate order totals */

    const delivery =
        subtotal > 0 ? 350 : 0;


    const total =
        subtotal + delivery;


    document.getElementById(
        "orderSubtotal"
    ).textContent =
        subtotal.toFixed(2);


    document.getElementById(
        "orderDelivery"
    ).textContent =
        delivery.toFixed(2);


    document.getElementById(
        "orderTotal"
    ).textContent =
        total.toFixed(2);

}


/*
 * Load order information after
 * the page has finished loading.
 */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        loadOrderConfirmation();

    }
);

</script>


<?php

/*
 * Load the common footer from the main includes folder.
 */
include '../includes/footer.php';

?>