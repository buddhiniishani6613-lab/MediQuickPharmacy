
<?php

session_start();

/*
 * Load the database connection.
 */
require_once __DIR__ . '/../config/database.php';

/*
 * Check whether the customer is logged in.
 */
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$userId = (int) $_SESSION['user_id'];

/*
 * Escape values before displaying them in HTML.
 */
function e($value)
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
 * Get all orders belonging to the logged-in customer.
 */
$orders = [];

$orderSql = "
    SELECT
        o.id,
        o.order_number,
        o.full_name,
        o.email,
        o.phone,
        o.delivery_address,
        o.city,
        o.payment_method,
        o.subtotal,
        o.delivery_fee,
        o.total_amount,
        o.order_status,
        o.created_at
    FROM orders o
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC
";

$orderStmt = $conn->prepare($orderSql);

if ($orderStmt) {

    $orderStmt->bind_param("i", $userId);

    $orderStmt->execute();

    $result = $orderStmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }

    $orderStmt->close();
}

/*
 * Get all items belonging to the customer's orders.
 */
$orderItems = [];

if (!empty($orders)) {

    $orderIds = [];

    foreach ($orders as $order) {
        $orderIds[] = (int) $order['id'];
    }

    $placeholders = implode(
        ',',
        array_fill(0, count($orderIds), '?')
    );

    $types = str_repeat('i', count($orderIds));

    $itemsSql = "
        SELECT
            oi.id,
            oi.order_id,
            oi.product_id,
            oi.product_name,
            oi.quantity,
            oi.unit_price,
            oi.total_price,
            p.image,
            p.category
        FROM order_items oi
        LEFT JOIN products p
            ON oi.product_id = p.id
        WHERE oi.order_id IN ($placeholders)
        ORDER BY oi.id ASC
    ";

    $itemsStmt = $conn->prepare($itemsSql);

    if ($itemsStmt) {

        $bindValues = [];
        $bindValues[] = $types;

        foreach ($orderIds as $key => $id) {
            $bindValues[] = &$orderIds[$key];
        }

        call_user_func_array(
            [$itemsStmt, 'bind_param'],
            $bindValues
        );

        $itemsStmt->execute();

        $itemsResult = $itemsStmt->get_result();

        while ($item = $itemsResult->fetch_assoc()) {

            $orderItems[(int) $item['order_id']][] = $item;
        }

        $itemsStmt->close();
    }
}

/*
 * Encode image paths safely.
 */
function makeWebPath($path)
{
    $path = str_replace('\\', '/', $path);

    $parts = explode('/', $path);

    $encoded = [];

    foreach ($parts as $part) {
        $encoded[] = rawurlencode($part);
    }

    return implode('/', $encoded);
}

/*
 * Find the correct product image.
 */
function findProductImage($image, $category = '')
{
    $root = dirname(__DIR__);

    $productsFolder =
        $root .
        DIRECTORY_SEPARATOR .
        'assets' .
        DIRECTORY_SEPARATOR .
        'images' .
        DIRECTORY_SEPARATOR .
        'products';

    if (empty($image)) {
        return '../assets/images/Logo.png';
    }

    $image = str_replace('\\', '/', trim($image));

    $image = ltrim($image, './');

    if (strpos($image, 'assets/images/') === 0) {

        $relativeImage = $image;

    } elseif (strpos($image, 'assets/') === 0) {

        $relativeImage = 'assets/images/' . basename($image);

    } elseif (strpos($image, 'images/products/') === 0) {

        $relativeImage = 'assets/' . $image;

    } elseif (strpos($image, 'images/') === 0) {

        $relativeImage = 'assets/images/' . basename($image);

    } else {

        $relativeImage =
            'assets/images/products/' .
            ($category ? $category . '/' : '') .
            basename($image);
    }

    $fullPath =
        $root .
        DIRECTORY_SEPARATOR .
        str_replace('/', DIRECTORY_SEPARATOR, $relativeImage);

    if (is_file($fullPath)) {
        return '../' . makeWebPath($relativeImage);
    }

    $fileName = basename($image);

    if (!empty($category)) {

        $categoryPath =
            $productsFolder .
            DIRECTORY_SEPARATOR .
            $category .
            DIRECTORY_SEPARATOR .
            $fileName;

        if (is_file($categoryPath)) {

            $relative =
                'assets/images/products/' .
                $category .
                '/' .
                $fileName;

            return '../' . makeWebPath($relative);
        }
    }

    if (is_dir($productsFolder)) {

        try {

            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator(
                    $productsFolder,
                    FilesystemIterator::SKIP_DOTS
                )
            );

            foreach ($iterator as $file) {

                if (!$file->isFile()) {
                    continue;
                }

                if (
                    strcasecmp(
                        $file->getFilename(),
                        $fileName
                    ) === 0
                ) {

                    $absolute = $file->getPathname();

                    $relative = str_replace(
                        $root . DIRECTORY_SEPARATOR,
                        '',
                        $absolute
                    );

                    $relative = str_replace(
                        '\\',
                        '/',
                        $relative
                    );

                    return '../' . makeWebPath($relative);
                }
            }

        } catch (Exception $e) {
            // Ignore folder scanning errors.
        }
    }

    return '../assets/images/Logo.png';
}

/*
 * Return the Bootstrap badge class for each order status.
 */
function getStatusClass($status)
{
    switch (strtolower(trim($status))) {

        case 'pending':
            return 'bg-warning-subtle text-warning-emphasis';

        case 'processing':
            return 'bg-info-subtle text-info-emphasis';

        case 'shipped':
            return 'bg-primary-subtle text-primary';

        case 'delivered':
            return 'bg-success-subtle text-success';

        case 'cancelled':
            return 'bg-danger-subtle text-danger';

        default:
            return 'bg-secondary-subtle text-secondary';
    }
}

/*
 * Include the common website header.
 */
require_once __DIR__ . '/../includes/header.php';

?>

<!-- My Orders Banner -->
<section class="orders-banner">

    <div class="container">

        <div class="d-flex align-items-center gap-3">

            <div class="banner-icon">

                <i class="bi bi-bag-check-fill"></i>

            </div>

            <div>

                <h1>My Orders</h1>

                <p>
                    View and track your MediQuick Pharmacy orders.
                    Stay updated on your purchases and deliveries.
                </p>

            </div>

        </div>

    </div>

</section>

<!-- Orders Main Section -->
<section class="orders-section">

    <div class="container">

        <!-- Orders Container -->
        <div class="orders-container">

            <!-- Orders Heading -->
            <div class="orders-top">

                <div>

                    <h4>
                        <i class="bi bi-bag-check me-2"></i>
                        Order History
                    </h4>

                    <p>
                        All your recent and previous orders in one place.
                    </p>

                </div>

                <div class="order-count">

                    <i class="bi bi-box-seam me-1"></i>

                    <?php echo count($orders); ?>

                    <?php echo count($orders) === 1 ? 'Order' : 'Orders'; ?>

                </div>

            </div>

            <?php if (!empty($orders)): ?>

                <?php foreach ($orders as $order): ?>

                    <?php

                    $orderId = (int) $order['id'];

                    $status = !empty($order['order_status'])
                        ? $order['order_status']
                        : 'Pending';

                    $items = $orderItems[$orderId] ?? [];

                    ?>

                    <!-- Individual Order Card -->
                    <div class="order-card">

                        <!-- Order Header -->
                        <div class="order-card-header">

                            <div class="order-details">

                                <div class="order-number">

                                    <i class="bi bi-receipt me-2"></i>

                                    Order #

                                    <?php echo e($order['order_number']); ?>

                                </div>

                                <div class="order-date">

                                    <i class="bi bi-calendar3 me-1"></i>

                                    <?php

                                    echo !empty($order['created_at'])
                                        ? date(
                                            'd M Y, h:i A',
                                            strtotime($order['created_at'])
                                        )
                                        : '';

                                    ?>

                                </div>

                            </div>

                            <span class="badge rounded-pill order-status <?php echo getStatusClass($status); ?>">

                                <?php echo e($status); ?>

                            </span>

                        </div>

                        <!-- Ordered Products -->
                        <div class="order-products">

                            <?php if (!empty($items)): ?>

                                <?php foreach ($items as $item): ?>

                                    <?php

                                    $quantity = (int) $item['quantity'];

                                    $unitPrice = (float) $item['unit_price'];

                                    $totalPrice = (float) $item['total_price'];

                                    $imagePath = findProductImage(
                                        $item['image'] ?? '',
                                        $item['category'] ?? ''
                                    );

                                    ?>

                                    <div class="order-product">

                                        <!-- Product Image -->
                                        <div class="product-image-box">

                                            <img
                                                src="<?php echo e($imagePath); ?>"
                                                alt="<?php echo e($item['product_name']); ?>"
                                                class="product-image"
                                                onerror="this.onerror=null;this.src='../assets/images/Logo.png';"
                                            >

                                        </div>

                                        <!-- Product Information -->
                                        <div class="product-information">

                                            <h6>

                                                <?php echo e($item['product_name']); ?>

                                            </h6>

                                            <p>

                                                Rs. <?php echo number_format($unitPrice, 2); ?>

                                                <span class="mx-1">×</span>

                                                Qty: <?php echo $quantity; ?>

                                            </p>

                                        </div>

                                        <!-- Product Total -->
                                        <div class="product-total">

                                            Rs. <?php echo number_format($totalPrice, 2); ?>

                                        </div>

                                    </div>

                                <?php endforeach; ?>

                            <?php else: ?>

                                <div class="no-items">

                                    <i class="bi bi-box-seam me-2"></i>

                                    No item details available.

                                </div>

                            <?php endif; ?>

                        </div>

                        <!-- Order Summary -->
                        <div class="order-summary">

                            <div class="payment-method">

                                <span class="summary-label">
                                    Payment Method
                                </span>

                                <strong>

                                    <i class="bi bi-credit-card me-1"></i>

                                    <?php echo e($order['payment_method'] ?? 'Not specified'); ?>

                                </strong>

                            </div>

                            <div class="order-total">

                                <span>Total Amount</span>

                                <strong>

                                    Rs.

                                    <?php

                                    echo number_format(
                                        (float) $order['total_amount'],
                                        2
                                    );

                                    ?>

                                </strong>

                            </div>

                        </div>

                        <!-- Delivery Information -->
                        <div class="delivery-information">

                            <div class="delivery-title">

                                <i class="bi bi-truck me-2"></i>

                                Delivery Address

                            </div>

                            <p>

                                <?php echo e($order['delivery_address'] ?? ''); ?>

                                <?php if (!empty($order['city'])): ?>

                                    , <?php echo e($order['city']); ?>

                                <?php endif; ?>

                            </p>

                        </div>

                    </div>

                <?php endforeach; ?>

            <?php else: ?>

                <!-- Empty Orders Message -->
                <div class="empty-orders">

                    <div class="empty-icon">

                        <i class="bi bi-bag-x"></i>

                    </div>

                    <h3>No Orders Yet</h3>

                    <p>
                        You haven't placed any orders yet.
                        Start shopping and your orders will appear here.
                    </p>

                    <a
                        href="../products.php"
                        class="btn btn-primary shop-button"
                    >

                        <i class="bi bi-cart me-2"></i>

                        Start Shopping

                    </a>

                </div>

            <?php endif; ?>

        </div>

    </div>

</section>

<style>

/* General Page Styling */
body {
    background: #f6f9fc;
    font-family: Arial, sans-serif;
}

/* My Orders Banner */
.orders-banner {
    background: linear-gradient(
        135deg,
        #006391,
        #0dcaf0
    );

    color: white;

    padding: 45px 20px;

    border-radius: 0 0 25px 25px;

    margin-bottom: 35px;
}

.orders-banner h1 {
    font-size: 32px;
    font-weight: 700;
    margin-bottom: 8px;
}

.orders-banner p {
    font-size: 14px;
    margin: 0;
    opacity: 0.9;
    line-height: 1.6;
}

.banner-icon {
    width: 65px;
    height: 65px;

    background: rgba(255,255,255,0.18);

    border: 1px solid rgba(255,255,255,0.25);

    border-radius: 16px;

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 32px;

    flex-shrink: 0;
}

/* Main Orders Section */
.orders-section {
    min-height: 75vh;
    padding-bottom: 60px;
}

.orders-container {
    background: white;

    border-radius: 20px;

    box-shadow: 0 5px 25px rgba(0,0,0,0.07);

    overflow: hidden;
}

/* Orders Heading */
.orders-top {
    padding: 22px 25px;

    border-bottom: 1px solid #edf0f2;

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;

    flex-wrap: wrap;
}

.orders-top h4 {
    color: #212529;
    font-size: 20px;
    font-weight: 700;
    margin-bottom: 6px;
}

.orders-top h4 i {
    color: #087f9b;
}

.orders-top p {
    color: #6c757d;
    font-size: 13px;
    margin: 0;
}

.order-count {
    background: #e8f4ff;

    color: #006f9b;

    padding: 8px 14px;

    border-radius: 25px;

    font-size: 13px;

    font-weight: 700;
}

/* Individual Order Card */
.order-card {
    margin: 22px 25px;

    padding: 22px;

    border: 1px solid #e5edf1;

    border-radius: 15px;

    background: #ffffff;

    transition: 0.25s ease;
}

.order-card:hover {
    border-color: #b8dce9;

    box-shadow: 0 5px 18px rgba(0,80,110,0.07);
}

/* Order Header */
.order-card-header {
    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;

    padding-bottom: 17px;

    border-bottom: 1px solid #edf0f2;
}

.order-number {
    color: #174f68;

    font-size: 16px;

    font-weight: 700;
}

.order-number i {
    color: #087f9b;
}

.order-date {
    color: #89949b;

    font-size: 12px;

    margin-top: 7px;
}

.order-date i {
    color: #087f9b;
}

.order-status {
    font-size: 12px;

    padding: 8px 14px;

    font-weight: 700;
}

/* Product List */
.order-products {
    padding: 5px 0;
}

.order-product {
    display: flex;

    align-items: center;

    gap: 15px;

    padding: 15px 0;

    border-bottom: 1px solid #edf0f2;
}

.order-product:last-child {
    border-bottom: none;
}

/* Product Image */
.product-image-box {
    width: 65px;
    height: 65px;

    flex-shrink: 0;

    background: #f5f9fb;

    border: 1px solid #e7eef2;

    border-radius: 10px;

    display: flex;

    align-items: center;

    justify-content: center;

    overflow: hidden;
}

.product-image {
    width: 100%;
    height: 100%;

    object-fit: contain;

    padding: 5px;
}

/* Product Information */
.product-information {
    flex: 1;
    min-width: 0;
}

.product-information h6 {
    color: #174f68;

    font-size: 14px;

    font-weight: 700;

    margin-bottom: 6px;

    overflow-wrap: anywhere;
}

.product-information p {
    color: #7c8990;

    font-size: 12px;

    margin: 0;
}

.product-total {
    color: #087f9b;

    font-size: 14px;

    font-weight: 700;

    white-space: nowrap;
}

/* Order Summary */
.order-summary {
    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;

    padding-top: 18px;

    border-top: 1px solid #edf0f2;
}

.payment-method {
    display: flex;

    flex-direction: column;

    gap: 6px;
}

.summary-label {
    color: #89949b;

    font-size: 11px;
}

.payment-method strong {
    color: #174f68;

    font-size: 13px;
}

.payment-method strong i {
    color: #087f9b;
}

.order-total {
    display: flex;

    align-items: center;

    gap: 12px;
}

.order-total span {
    color: #7b8990;

    font-size: 13px;
}

.order-total strong {
    color: #087f9b;

    font-size: 19px;

    font-weight: 700;
}

/* Delivery Information */
.delivery-information {
    margin-top: 17px;

    padding: 13px 15px;

    background: #f0f7fa;

    border-radius: 10px;
}

.delivery-title {
    color: #087f9b;

    font-size: 13px;

    font-weight: 700;

    margin-bottom: 6px;
}

.delivery-information p {
    color: #697a83;

    font-size: 12px;

    margin: 0;

    line-height: 1.6;

    overflow-wrap: anywhere;
}

/* No Items */
.no-items {
    display: flex;

    align-items: center;

    padding: 18px 0;

    color: #89949b;

    font-size: 13px;
}

.no-items i {
    color: #087f9b;
}

/* Empty Orders */
.empty-orders {
    padding: 75px 25px;

    text-align: center;
}

.empty-icon {
    width: 95px;
    height: 95px;

    border-radius: 50%;

    background: #eaf3ff;

    color: #007ec7;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 43px;

    margin: 0 auto 22px;
}

.empty-orders h3 {
    color: #212529;

    font-size: 23px;

    font-weight: 700;

    margin-bottom: 10px;
}

.empty-orders p {
    color: #6c757d;

    font-size: 14px;

    max-width: 480px;

    line-height: 1.6;

    margin: 0 auto 25px;
}

.shop-button {
    background: #087f9b;

    border-color: #087f9b;

    padding: 11px 22px;

    border-radius: 8px;

    font-size: 14px;

    font-weight: 600;
}

.shop-button:hover {
    background: #056b83;

    border-color: #056b83;
}

/* Responsive Design */
@media (max-width: 768px) {

    .orders-banner {
        padding: 35px 18px;
    }

    .orders-banner h1 {
        font-size: 27px;
    }

    .orders-top {
        padding: 20px 17px;
    }

    .order-card {
        margin: 17px 15px;
        padding: 17px;
    }

    .order-card-header {
        align-items: flex-start;
        flex-direction: column;
    }

    .order-summary {
        align-items: flex-start;
        flex-direction: column;
    }

    .order-total {
        width: 100%;
        justify-content: space-between;
    }

}

@media (max-width: 576px) {

    .orders-banner {
        padding: 30px 15px;
        border-radius: 0 0 20px 20px;
    }

    .banner-icon {
        width: 52px;
        height: 52px;
        font-size: 25px;
    }

    .orders-banner h1 {
        font-size: 24px;
    }

    .orders-banner p {
        font-size: 12px;
    }

    .orders-top h4 {
        font-size: 18px;
    }

    .order-card {
        margin: 14px 10px;
        padding: 15px;
    }

    .order-product {
        gap: 10px;
    }

    .product-image-box {
        width: 52px;
        height: 52px;
    }

    .product-information h6 {
        font-size: 12px;
    }

    .product-information p {
        font-size: 11px;
    }

    .product-total {
        font-size: 12px;
    }

    .order-total strong {
        font-size: 17px;
    }

    .empty-orders {
        padding: 55px 18px;
    }

}

</style>

<?php

/*
 * Include the common website footer.
 */
require_once __DIR__ . '/../includes/footer.php';

?>

<!-- Bootstrap JavaScript -->
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>
