<?php

session_start();

require_once __DIR__ . '/../config/database.php';

/*
|--------------------------------------------------------------------------
| Check Customer Login
|--------------------------------------------------------------------------
*/
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$userId = (int) $_SESSION['user_id'];


/*
|--------------------------------------------------------------------------
| Escape HTML Output
|--------------------------------------------------------------------------
*/
function e($value)
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}


/*
|--------------------------------------------------------------------------
| Get Product Category Folder
|--------------------------------------------------------------------------
*/
function getCategoryFolder($categoryName)
{
    $folders = [
        "Prescription" => "Prescription Medicines",
        "Prescription Medicines" => "Prescription Medicines",
        "OTC Products" => "OTC Products",
        "Wellness Products" => "Wellness Products",
        "Personal Care" => "Personal Care",
        "Medical Devices" => "Medical Devices",
        "Baby Care" => "Baby Care"
    ];

    return $folders[$categoryName] ?? $categoryName;
}


/*
|--------------------------------------------------------------------------
| Find Correct Product Image
|--------------------------------------------------------------------------
*/
function getProductImage(
    $categoryName,
    $databaseImage,
    $productName
) {

    $root = dirname(__DIR__);

    $folder = getCategoryFolder($categoryName);

    $serverFolder =
        $root .
        "/assets/images/products/" .
        $folder .
        "/";

    $webFolder =
        "../assets/images/products/" .
        rawurlencode($folder) .
        "/";

    // Check image path stored in the database.
    if (!empty($databaseImage)) {

        $databaseImage = str_replace(
            "\\",
            "/",
            trim($databaseImage)
        );

        $databaseFile = basename($databaseImage);

        $databaseServerPath =
            $root .
            "/" .
            ltrim($databaseImage, "/");

        if (is_file($databaseServerPath)) {

            $relativePath = ltrim(
                $databaseImage,
                "/"
            );

            if (strpos($relativePath, "assets/") === 0) {

                return "../" . $relativePath;

            }

            if (strpos($relativePath, "images/") === 0) {

                return "../assets/" . $relativePath;

            }
        }

        // Check the image inside its category folder.
        if (is_file($serverFolder . $databaseFile)) {

            return $webFolder .
                rawurlencode($databaseFile);
        }
    }

    // Remove dosage information from product name.
    $cleanName = preg_replace(
        '/\s*\d+(?:\.\d+)?\s*(?:mg|mcg|g|ml|l|%)\b/i',
        '',
        $productName
    );

    $cleanName = trim($cleanName);

    // Supported image extensions.
    $extensions = [
        "jpg",
        "jpeg",
        "png"
    ];

    // Check exact and cleaned product names.
    foreach ([$productName, $cleanName] as $name) {

        foreach ($extensions as $extension) {

            $fileName =
                $name . "." . $extension;

            if (is_file($serverFolder . $fileName)) {

                return $webFolder .
                    rawurlencode($fileName);
            }
        }
    }

    // Search category folder without considering letter case.
    if (is_dir($serverFolder)) {

        $files = scandir($serverFolder);

        $possibleNames = [];

        foreach ([$productName, $cleanName] as $name) {

            foreach ($extensions as $extension) {

                $possibleNames[] =
                    strtolower($name . "." . $extension);
            }
        }

        foreach ($files as $file) {

            if (
                in_array(
                    strtolower($file),
                    $possibleNames,
                    true
                )
            ) {

                return $webFolder .
                    rawurlencode($file);
            }
        }
    }

    // Default pharmacy logo.
    return "../assets/images/Logo.png";
}


/*
|--------------------------------------------------------------------------
| Remove Single Wishlist Product
|--------------------------------------------------------------------------
*/
if (isset($_GET['remove'])) {

    $productId = (int) $_GET['remove'];

    if ($productId > 0) {

        $stmt = $conn->prepare("
            DELETE FROM wishlist
            WHERE user_id = ?
            AND product_id = ?
        ");

        if ($stmt) {

            $stmt->bind_param(
                "ii",
                $userId,
                $productId
            );

            $stmt->execute();
            $stmt->close();
        }
    }

    header("Location: wishlist.php?removed=1");
    exit;
}


/*
|--------------------------------------------------------------------------
| Clear Entire Wishlist
|--------------------------------------------------------------------------
*/
if (
    isset($_GET['clear']) &&
    $_GET['clear'] === '1'
) {

    $stmt = $conn->prepare("
        DELETE FROM wishlist
        WHERE user_id = ?
    ");

    if ($stmt) {

        $stmt->bind_param(
            "i",
            $userId
        );

        $stmt->execute();
        $stmt->close();
    }

    header("Location: wishlist.php?cleared=1");
    exit;
}


/*
|--------------------------------------------------------------------------
| Wishlist Action Messages
|--------------------------------------------------------------------------
*/
$message = "";
$messageType = "";

if (isset($_GET['added'])) {

    $message =
        "Product added to your wishlist successfully.";

    $messageType = "success";
}

if (isset($_GET['exists'])) {

    $message =
        "This product is already in your wishlist.";

    $messageType = "warning";
}

if (isset($_GET['removed'])) {

    $message =
        "Product removed from your wishlist.";

    $messageType = "success";
}

if (isset($_GET['cleared'])) {

    $message =
        "Your wishlist has been cleared.";

    $messageType = "success";
}


/*
|--------------------------------------------------------------------------
| Retrieve Customer Wishlist
|--------------------------------------------------------------------------
*/
$wishlistItems = [];

$sql = "
    SELECT
        w.id AS wishlist_id,
        w.product_id,
        w.created_at,

        p.name,
        p.description,
        p.category,
        p.price,
        p.stock_quantity,
        p.image,
        p.requires_prescription,
        p.status

    FROM wishlist w

    INNER JOIN products p
        ON w.product_id = p.id

    WHERE w.user_id = ?

    ORDER BY w.created_at DESC
";

$stmt = $conn->prepare($sql);

if ($stmt) {

    $stmt->bind_param(
        "i",
        $userId
    );

    $stmt->execute();

    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {

        $wishlistItems[] = $row;
    }

    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        My Wishlist | MediQuick Pharmacy
    </title>

    <!-- Bootstrap CSS -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Bootstrap Icons -->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    >

    <style>

/*--------------------------------------------------
  General Page Styling
--------------------------------------------------*/

body {
    background: #f6f9fc;
    font-family: Arial, sans-serif;
}


/*--------------------------------------------------
  Wishlist Banner
--------------------------------------------------*/

.wishlist-header {

    background: linear-gradient(
        135deg,
        #006391,
        #0dcaf0
    );

    color: white;

    padding: 45px 20px;

    border-radius: 0 0 25px 25px;

    margin-bottom: 35px;
}

.wishlist-header h1 {

    font-weight: 700;

    margin-bottom: 8px;

    font-size: 32px;
}

.wishlist-header p {

    margin: 0;

    opacity: 0.9;

    font-size: 15px;
}


/*--------------------------------------------------
  Wishlist Top Actions
--------------------------------------------------*/

.top-actions {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;

    flex-wrap: wrap;

    margin-bottom: 25px;
}

.wishlist-count {

    font-size: 17px;

    font-weight: 600;

    color: #495057;
}


/*--------------------------------------------------
  Product Cards
--------------------------------------------------*/

.wishlist-card {

    background: white;

    border: 1px solid #edf0f2;

    border-radius: 18px;

    overflow: hidden;

    height: 100%;

    box-shadow:
        0 5px 20px rgba(0, 0, 0, 0.07);

    transition: all 0.3s ease;
}

.wishlist-card:hover {

    transform: translateY(-5px);

    box-shadow:
        0 12px 30px rgba(0, 0, 0, 0.12);
}


/*--------------------------------------------------
  Product Image
--------------------------------------------------*/

.product-image-wrapper {

    height: 230px;

    background: #f8fafc;

    display: flex;

    align-items: center;

    justify-content: center;

    position: relative;

    padding: 20px;
}

.product-image {

    width: 100%;

    height: 100%;

    max-height: 190px;

    object-fit: contain;
}


/*--------------------------------------------------
  Remove Wishlist Button
--------------------------------------------------*/

.remove-btn {

    position: absolute;

    top: 12px;

    right: 12px;

    width: 42px;

    height: 42px;

    border-radius: 50%;

    background: white;

    color: #dc3545;

    display: flex;

    align-items: center;

    justify-content: center;

    text-decoration: none;

    box-shadow:
        0 3px 12px rgba(0, 0, 0, 0.12);

    transition: 0.2s;

    z-index: 5;
}

.remove-btn:hover {

    background: #dc3545;

    color: white;

    transform: scale(1.08);
}


/*--------------------------------------------------
  Product Information
--------------------------------------------------*/

.product-info {

    padding: 20px;
}

.category-badge {

    display: inline-block;

    background: #e8f3ff;

    color: #0d6efd;

    padding: 5px 11px;

    border-radius: 20px;

    font-size: 12px;

    font-weight: 600;

    margin-bottom: 10px;
}

.product-name {

    font-size: 19px;

    font-weight: 700;

    color: #212529;

    min-height: 45px;
}

.product-description {

    color: #6c757d;

    font-size: 14px;

    min-height: 42px;

    line-height: 1.5;
}


/*--------------------------------------------------
  Product Price
--------------------------------------------------*/

.product-price {

    font-size: 21px;

    font-weight: 700;

    color: #087f9b;
}


/*--------------------------------------------------
  Stock Status
--------------------------------------------------*/

.stock-available {

    color: #198754;

    font-size: 13px;

    font-weight: 600;
}

.stock-unavailable {

    color: #dc3545;

    font-size: 13px;

    font-weight: 600;
}


/*--------------------------------------------------
  Prescription Badge
--------------------------------------------------*/

.prescription-badge {

    display: inline-block;

    background: #fff3cd;

    color: #856404;

    padding: 6px 9px;

    border-radius: 10px;

    font-size: 11px;

    font-weight: 600;
}


/*--------------------------------------------------
  Empty Wishlist
--------------------------------------------------*/

.empty-wishlist {

    background: white;

    border: 1px solid #edf0f2;

    border-radius: 22px;

    padding: 70px 25px;

    text-align: center;

    box-shadow:
        0 5px 20px rgba(0, 0, 0, 0.06);
}

.empty-icon {

    width: 100px;

    height: 100px;

    border-radius: 50%;

    background: #fff0f1;

    color: #dc3545;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 45px;

    margin: 0 auto 22px;
}


/*--------------------------------------------------
  Responsive Design
--------------------------------------------------*/

@media (max-width: 576px) {

    .wishlist-header {

        padding: 35px 18px;
    }

    .wishlist-header h1 {

        font-size: 28px;
    }

    .product-image-wrapper {

        height: 210px;
    }

    .top-actions {

        align-items: flex-start;

        flex-direction: column;
    }

    .empty-wishlist {

        padding: 50px 20px;
    }
}

    </style>

</head>

<body>


<!-- Common Website Header -->

<?php

include __DIR__ . '/../includes/header.php';

?>


<!--=================================================
    WISHLIST BANNER
==================================================-->

<section class="wishlist-header">

    <div class="container">

        <div class="d-flex align-items-center gap-3">

            <div>

                <i class="bi bi-heart-fill fs-1"></i>

            </div>

            <div>

                <h1>My Wishlist</h1>

                <p>
                    Save your favourite products for later.
                </p>

            </div>

        </div>

    </div>

</section>


<!--=================================================
    WISHLIST CONTENT
==================================================-->

<div class="container pb-5">


    <!-- Wishlist Action Messages -->

    <?php if ($message !== ""): ?>

        <div
            class="alert alert-<?php echo e($messageType); ?> alert-dismissible fade show"
            role="alert"
        >

            <?php if ($messageType === "success"): ?>

                <i class="bi bi-check-circle-fill me-2"></i>

            <?php else: ?>

                <i class="bi bi-exclamation-circle-fill me-2"></i>

            <?php endif; ?>

            <?php echo e($message); ?>

            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="alert"
            ></button>

        </div>

    <?php endif; ?>


    <?php if (!empty($wishlistItems)): ?>


        <!-- Wishlist Top Actions -->

        <div class="top-actions">

            <div class="wishlist-count">

                <i class="bi bi-heart-fill text-danger me-2"></i>

                <?php echo count($wishlistItems); ?>

                <?php
                echo count($wishlistItems) === 1
                    ? "Product"
                    : "Products";
                ?>

                in your wishlist

            </div>


            <div class="d-flex gap-2 flex-wrap">

                <a
                    href="../products.php"
                    class="btn btn-outline-primary"
                >

                    <i class="bi bi-bag me-1"></i>

                    Continue Shopping

                </a>


                <a
                    href="wishlist.php?clear=1"
                    class="btn btn-outline-danger"
                    onclick="
                        return confirm(
                            'Are you sure you want to clear your wishlist?'
                        );
                    "
                >

                    <i class="bi bi-trash me-1"></i>

                    Clear All

                </a>

            </div>

        </div>


        <!-- Wishlist Product Cards -->

        <div class="row g-4">

            <?php foreach ($wishlistItems as $item): ?>

                <?php

                // Get the correct product image.
                $imagePath = getProductImage(
                    $item["category"],
                    $item["image"],
                    $item["name"]
                );

                // Check product availability.
                $inStock = (
                    (int) $item["stock_quantity"] > 0
                    &&
                    $item["status"] === "Available"
                );

                ?>


                <div class="col-lg-4 col-md-6">

                    <div class="wishlist-card">


                        <!-- Product Image -->

                        <div class="product-image-wrapper">

                            <img
                                src="<?php echo e($imagePath); ?>"
                                alt="<?php echo e($item["name"]); ?>"
                                class="product-image"
                                onerror="
                                    this.onerror=null;
                                    this.src='../assets/images/Logo.png';
                                "
                            >


                            <!-- Remove Product -->

                            <a
                                href="wishlist.php?remove=<?php echo (int) $item["product_id"]; ?>"
                                class="remove-btn"
                                title="Remove from Wishlist"
                                aria-label="Remove from Wishlist"
                                onclick="
                                    return confirm(
                                        'Remove this product from your wishlist?'
                                    );
                                "
                            >

                                <i class="bi bi-heart-fill"></i>

                            </a>

                        </div>


                        <!-- Product Details -->

                        <div class="product-info">


                            <!-- Category -->

                            <span class="category-badge">

                                <?php
                                echo e($item["category"]);
                                ?>

                            </span>


                            <!-- Product Name -->

                            <h5 class="product-name">

                                <?php
                                echo e($item["name"]);
                                ?>

                            </h5>


                            <!-- Product Description -->

                            <p class="product-description">

                                <?php

                                $description = trim(
                                    (string) $item["description"]
                                );

                                if ($description === "") {

                                    echo e(
                                        "Quality healthcare product from MediQuick Pharmacy."
                                    );

                                } else {

                                    if (strlen($description) > 90) {

                                        $description =
                                            substr(
                                                $description,
                                                0,
                                                90
                                            ) . "...";
                                    }

                                    echo e($description);
                                }

                                ?>

                            </p>


                            <!-- Prescription Information -->

                            <?php if (
                                (int) $item["requires_prescription"] === 1
                            ): ?>

                                <div class="mb-3">

                                    <span class="prescription-badge">

                                        <i class="bi bi-file-earmark-medical me-1"></i>

                                        Prescription Required

                                    </span>

                                </div>

                            <?php endif; ?>


                            <!-- Price and Stock -->

                            <div
                                class="
                                    d-flex
                                    justify-content-between
                                    align-items-center
                                    mb-3
                                "
                            >

                                <span class="product-price">

                                    Rs.

                                    <?php
                                    echo number_format(
                                        (float) $item["price"],
                                        2
                                    );
                                    ?>

                                </span>


                                <?php if ($inStock): ?>

                                    <span class="stock-available">

                                        <i class="bi bi-check-circle-fill me-1"></i>

                                        In Stock

                                    </span>

                                <?php else: ?>

                                    <span class="stock-unavailable">

                                        <i class="bi bi-x-circle-fill me-1"></i>

                                        Out of Stock

                                    </span>

                                <?php endif; ?>

                            </div>


                            <!-- Add to Cart Button -->

                            <?php if ($inStock): ?>

                                <button
                                    type="button"
                                    class="
                                        btn
                                        btn-primary
                                        w-100
                                        add-cart-btn
                                    "
                                    data-id="<?php echo (int) $item["product_id"]; ?>"
                                    data-name="<?php echo e($item["name"]); ?>"
                                    data-price="<?php echo e($item["price"]); ?>"
                                    data-image="<?php echo e($imagePath); ?>"
                                    data-stock="<?php echo (int) $item["stock_quantity"]; ?>"
                                >

                                    <i class="bi bi-cart-plus me-1"></i>

                                    Add to Cart

                                </button>

                            <?php else: ?>

                                <button
                                    type="button"
                                    class="btn btn-secondary w-100"
                                    disabled
                                >

                                    <i class="bi bi-x-circle me-1"></i>

                                    Currently Unavailable

                                </button>

                            <?php endif; ?>


                        </div>

                    </div>

                </div>


            <?php endforeach; ?>

        </div>


    <?php else: ?>


        <!-- Empty Wishlist -->

        <div class="empty-wishlist">


            <div class="empty-icon">

                <i class="bi bi-heart"></i>

            </div>


            <h2 class="fw-bold mb-3">

                Your Wishlist is Empty

            </h2>


            <p class="text-muted mb-4">

                You haven't added any products to your wishlist yet.

                Browse our products and save your favourite products here.

            </p>


            <a
                href="../products.php"
                class="btn btn-primary btn-lg px-4"
            >

                <i class="bi bi-bag-heart me-2"></i>

                Browse Products

            </a>


        </div>


    <?php endif; ?>


</div>


<!-- Common Website Footer -->

<?php

include __DIR__ . '/../includes/footer.php';

?>


<!-- Bootstrap JavaScript -->

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>


<script>

/*
|--------------------------------------------------------------------------
| Add Product to Cart
|--------------------------------------------------------------------------
*/

document
    .querySelectorAll(".add-cart-btn")
    .forEach(function(button) {

        button.addEventListener("click", function() {


            // Get product information.

            const productId =
                Number(this.dataset.id);

            const productName =
                this.dataset.name;

            const productPrice =
                Number(this.dataset.price);

            const productImage =
                this.dataset.image;

            const stock =
                Number(this.dataset.stock);


            let cart = [];


            // Load existing cart data.

            try {

                cart = JSON.parse(
                    localStorage.getItem("mediquickCart")
                ) || [];

            } catch (error) {

                cart = [];

            }


            // Find the existing product.

            let existingItem = cart.find(
                function(item) {

                    return Number(
                        item.product_id ||
                        item.productId ||
                        item.id
                    ) === productId;

                }
            );


            if (existingItem) {


                // Get current product quantity.

                let quantity = Number(
                    existingItem.quantity ||
                    existingItem.qty ||
                    0
                );


                // Check available stock.

                if (quantity >= stock) {

                    alert(
                        "You cannot add more than the available stock."
                    );

                    return;

                }


                quantity++;


                // Update existing cart item.

                existingItem.quantity = quantity;

                existingItem.qty = quantity;

                existingItem.product_id = productId;

                existingItem.productId = productId;

                existingItem.id = productId;

                existingItem.name = productName;

                existingItem.product_name = productName;

                existingItem.price = productPrice;

                existingItem.image = productImage;


            } else {


                // Create a new cart item.

                cart.push({

                    id: productId,

                    product_id: productId,

                    productId: productId,

                    name: productName,

                    product_name: productName,

                    price: productPrice,

                    image: productImage,

                    quantity: 1,

                    qty: 1,

                    stock: stock

                });

            }


            // Save updated cart.

            localStorage.setItem(
                "mediquickCart",
                JSON.stringify(cart)
            );


            // Display success feedback.

            const oldText = this.innerHTML;

            this.innerHTML =
                '<i class="bi bi-check-circle me-1"></i> Added to Cart';

            this.classList.remove("btn-primary");

            this.classList.add("btn-success");


            const currentButton = this;


            setTimeout(function() {

                currentButton.innerHTML = oldText;

                currentButton.classList.remove("btn-success");

                currentButton.classList.add("btn-primary");

            }, 1500);


            // Update header cart count.

            updateCartCount();


        });

    });


/*
|--------------------------------------------------------------------------
| Update Header Cart Count
|--------------------------------------------------------------------------
*/

function updateCartCount()
{

    let cart = [];

    try {

        cart = JSON.parse(
            localStorage.getItem("mediquickCart")
        ) || [];

    } catch (error) {

        cart = [];

    }


    let totalQuantity = 0;


    cart.forEach(function(item) {

        totalQuantity += Number(
            item.quantity ||
            item.qty ||
            0
        );

    });


    // Update available cart counters.

    const counters = document.querySelectorAll(
        ".cart-count, #cart-count, [data-cart-count]"
    );


    counters.forEach(function(counter) {

        counter.textContent = totalQuantity;

    });

}


// Update cart count when the page loads.

updateCartCount();

</script>


</body>

</html>