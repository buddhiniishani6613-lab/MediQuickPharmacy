<?php

session_start();

/*
 * Prevent cached pages from being displayed after logout.
 */
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");

/*
 * Allow access only to logged-in staff members.
 */
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {

    header("Location: ../login.php");
    exit;
}

if ($_SESSION['user_role'] !== 'staff') {

    if ($_SESSION['user_role'] === 'customer') {
        header("Location: ../Customer/customer-dashboard.php");
        exit;
    }

    if ($_SESSION['user_role'] === 'admin') {
        header("Location: ../Admin/admin-dashboard.php");
        exit;
    }

    header("Location: ../login.php");
    exit;
}

/*
 * Load the database connection.
 * This file is inside the Staff folder, so the database
 * configuration is one level above.
 */
require_once '../config/database.php';

$userId = (int) $_SESSION['user_id'];

/*
 * Get logged-in staff details.
 */
$staffName = $_SESSION['user_name'] ?? 'Staff Member';
$staffEmail = $_SESSION['user_email'] ?? '';

$stmt = $conn->prepare("
    SELECT full_name, email, phone
    FROM users
    WHERE id = ?
    AND role = 'staff'
    LIMIT 1
");

if ($stmt) {

    $stmt->bind_param("i", $userId);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {

        $staffName = $row['full_name'];
        $staffEmail = $row['email'];
    }

    $stmt->close();
}

/*
 * Escape values before displaying them in HTML.
 */
function e($value)
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
 * Dashboard statistics.
 */
$totalOrders = 0;
$pendingOrders = 0;
$processingOrders = 0;
$totalCustomers = 0;
$totalProducts = 0;
$lowStockProducts = 0;
$outOfStockProducts = 0;
$pendingPrescriptions = 0;
$unreadNotifications = 0;

/*
 * Get total customer orders.
 */
$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM orders
");

if ($result && $row = $result->fetch_assoc()) {
    $totalOrders = (int) $row['total'];
}

/*
 * Get pending orders.
 */
$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM orders
    WHERE order_status = 'Pending'
");

if ($result && $row = $result->fetch_assoc()) {
    $pendingOrders = (int) $row['total'];
}

/*
 * Get processing orders.
 */
$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM orders
    WHERE order_status = 'Processing'
");

if ($result && $row = $result->fetch_assoc()) {
    $processingOrders = (int) $row['total'];
}

/*
 * Get total registered customers.
 */
$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM users
    WHERE role = 'customer'
");

if ($result && $row = $result->fetch_assoc()) {
    $totalCustomers = (int) $row['total'];
}

/*
 * Get total active products.
 */
$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM products
    WHERE status != 'Inactive'
");

if ($result && $row = $result->fetch_assoc()) {
    $totalProducts = (int) $row['total'];
}

/*
 * Get low-stock products.
 * Products with 1 to 10 units are considered low stock.
 */
$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM products
    WHERE stock_quantity > 0
    AND stock_quantity <= 10
    AND status != 'Inactive'
");

if ($result && $row = $result->fetch_assoc()) {
    $lowStockProducts = (int) $row['total'];
}

/*
 * Get out-of-stock products.
 */
$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM products
    WHERE stock_quantity <= 0
    AND status != 'Inactive'
");

if ($result && $row = $result->fetch_assoc()) {
    $outOfStockProducts = (int) $row['total'];
}

/*
 * Get pending prescription count.
 */
$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM prescriptions
    WHERE status = 'Pending Review'
");

if ($result && $row = $result->fetch_assoc()) {
    $pendingPrescriptions = (int) $row['total'];
}

/*
 * Get unread staff notifications.
 */
$result = $conn->query("
    SELECT COUNT(*) AS total
    FROM notifications
    WHERE user_id = $userId
    AND is_read = 0
");

if ($result && $row = $result->fetch_assoc()) {
    $unreadNotifications = (int) $row['total'];
}

/*
 * Get the five most recent customer orders.
 */
$recentOrders = [];

$stmt = $conn->prepare("
    SELECT
        o.id,
        o.order_number,
        o.full_name,
        o.email,
        o.total_amount,
        o.order_status,
        o.created_at
    FROM orders o
    ORDER BY o.created_at DESC
    LIMIT 5
");

if ($stmt) {

    $stmt->execute();

    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $recentOrders[] = $row;
    }

    $stmt->close();
}

/*
 * Get the five most recent prescriptions.
 */
$recentPrescriptions = [];

$stmt = $conn->prepare("
    SELECT
        p.id,
        p.patient_name,
        p.phone,
        p.email,
        p.file_name,
        p.status,
        p.created_at
    FROM prescriptions p
    ORDER BY p.created_at DESC
    LIMIT 5
");

if ($stmt) {

    $stmt->execute();

    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $recentPrescriptions[] = $row;
    }

    $stmt->close();
}

/*
 * Get products that currently have low stock.
 */
$lowStockList = [];

$stmt = $conn->prepare("
    SELECT
        id,
        name,
        category,
        stock_quantity,
        price,
        image,
        status
    FROM products
    WHERE stock_quantity > 0
    AND stock_quantity <= 10
    AND status != 'Inactive'
    ORDER BY stock_quantity ASC, name ASC
    LIMIT 5
");

if ($stmt) {

    $stmt->execute();

    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $lowStockList[] = $row;
    }

    $stmt->close();
}

/*
 * Return the CSS class for an order status.
 */
function orderStatusClass($status)
{
    switch ($status) {

        case 'Pending':
            return 'status-pending';

        case 'Processing':
            return 'status-processing';

        case 'Shipped':
            return 'status-shipped';

        case 'Delivered':
            return 'status-delivered';

        case 'Cancelled':
            return 'status-cancelled';

        default:
            return 'status-pending';
    }
}

/*
 * Return the CSS class for a prescription status.
 */
function prescriptionStatusClass($status)
{
    switch ($status) {

        case 'Approved':
            return 'prescription-approved';

        case 'Rejected':
            return 'prescription-rejected';

        case 'Completed':
            return 'prescription-completed';

        default:
            return 'prescription-pending';
    }
}

/*
 * Find the correct product image from the current
 * assets/images/products directory structure.
 */
function getProductImage($image, $category)
{
    $placeholder = '../assets/images/Logo.png';

    if (empty($image)) {
        return $placeholder;
    }

    $image = trim($image);

    $image = str_replace('\\', '/', $image);

    /*
     * Allow external image URLs.
     */
    if (preg_match('/^https?:\/\//i', $image)) {
        return $image;
    }

    /*
     * Remove old path prefixes so the current
     * assets/images structure can be used.
     */
    $image = ltrim($image, './');

    if (str_starts_with($image, 'assets/images/')) {
        $image = substr($image, strlen('assets/images/'));
    }

    if (str_starts_with($image, 'images/')) {
        $image = substr($image, strlen('images/'));
    }

    if (str_starts_with($image, 'products/')) {
        $image = substr($image, strlen('products/'));
    }

    /*
     * Check the category folder.
     */
    $categoryPath =
        '../assets/images/products/' .
        $category .
        '/' .
        basename($image);

    if (file_exists(__DIR__ . '/../assets/images/products/' . $category . '/' . basename($image))) {
        return $categoryPath;
    }

    /*
     * Check the main products directory.
     */
    $directPath =
        '../assets/images/products/' .
        basename($image);

    if (file_exists(__DIR__ . '/../assets/images/products/' . basename($image))) {
        return $directPath;
    }

    /*
     * Search through the product category folders.
     */
    $productsDirectory = __DIR__ . '/../assets/images/products';

    if (is_dir($productsDirectory)) {

        $folders = scandir($productsDirectory);

        if ($folders !== false) {

            foreach ($folders as $folder) {

                if ($folder === '.' || $folder === '..') {
                    continue;
                }

                $possibleFile =
                    $productsDirectory .
                    '/' .
                    $folder .
                    '/' .
                    basename($image);

                if (file_exists($possibleFile)) {

                    return
                        '../assets/images/products/' .
                        $folder .
                        '/' .
                        basename($image);
                }
            }
        }
    }

    return $placeholder;
}

/*
 * Use the current Pharmacy.png image from assets/images.
 * If it is not available, use the current Logo.png image.
 */
$pharmacyImage = '../assets/images/Pharmacy.png';

if (!file_exists(__DIR__ . '/../assets/images/Pharmacy.png')) {

    if (file_exists(__DIR__ . '/../assets/images/Pharamacy.png')) {

        $pharmacyImage = '../assets/images/Pharamacy.png';

    } else {

        $pharmacyImage = '../assets/images/Logo.png';
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Staff Dashboard - MediQuick Pharmacy
    </title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
        rel="stylesheet"
    >

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family:
                "Segoe UI",
                Arial,
                sans-serif;
            background: #f4f7fb;
            color: #263238;
        }

        /* Sidebar */

        .sidebar {
            width: 255px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background:
                linear-gradient(
                    180deg,
                    #087f8c,
                    #075b66
                );
            color: white;
            padding: 25px 16px;
            z-index: 1000;
            overflow-y: auto;
        }

        .brand {
            text-align: center;
            margin-bottom: 30px;
        }

        .brand-icon {
            width: 62px;
            height: 62px;
            margin: auto;
            background: white;
            border-radius: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #087f8c;
            font-size: 32px;
        }

        .brand h2 {
            font-size: 21px;
            margin-top: 12px;
            font-weight: 700;
        }

        .brand p {
            font-size: 12px;
            opacity: .8;
        }

        .nav-menu {
            list-style: none;
            padding: 0;
        }

        .nav-menu li {
            margin-bottom: 7px;
        }

        .nav-menu a {
            display: flex;
            align-items: center;
            gap: 13px;
            padding: 13px 15px;
            color:
                rgba(
                    255,
                    255,
                    255,
                    .88
                );
            text-decoration: none;
            border-radius: 12px;
            transition: .2s;
            font-size: 14px;
            position: relative;
        }

        .nav-menu a:hover {
            background:
                rgba(
                    255,
                    255,
                    255,
                    .14
                );
            color: white;
        }

        .nav-menu a.active {
            background: white;
            color: #087f8c;
            font-weight: 600;
            box-shadow:
                0 5px 15px
                rgba(
                    0,
                    0,
                    0,
                    .10
                );
        }

        .nav-menu i {
            font-size: 18px;
            width: 21px;
            text-align: center;
        }

        .nav-title {
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            opacity: .55;
            padding:
                18px 15px 7px;
        }

        .notification-badge {
            margin-left: auto;
            background: #ff5252;
            color: white;
            min-width: 22px;
            height: 22px;
            padding: 0 6px;
            border-radius: 50px;
            font-size: 11px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Main content */

        .main {
            margin-left: 255px;
            min-height: 100vh;
        }

        /* Top bar */

        .topbar {
            background: white;
            height: 75px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 32px;
            border-bottom:
                1px solid #e9edf2;
        }

        .page-title h1 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 2px;
        }

        .page-title p {
            font-size: 13px;
            color: #78909c;
        }

        .staff-profile {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .staff-avatar {
            width: 43px;
            height: 43px;
            border-radius: 50%;
            background: #e0f7fa;
            color: #087f8c;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 17px;
        }

        .staff-info strong {
            display: block;
            font-size: 14px;
        }

        .staff-info span {
            font-size: 11px;
            color: #78909c;
        }

        /* Content */

        .content {
            padding: 30px;
        }

        /* Hero section */

        .hero {
            background:
                linear-gradient(
                    135deg,
                    #087f8c,
                    #0b6470
                );
            min-height: 220px;
            border-radius: 22px;
            position: relative;
            overflow: hidden;
            color: white;
            padding: 35px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
        }

        .hero-content {
            width: 58%;
            position: relative;
            z-index: 2;
        }

        .hero h2 {
            font-size: 30px;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .hero p {
            font-size: 14px;
            line-height: 1.7;
            opacity: .9;
            max-width: 550px;
        }

        .hero-image {
            position: absolute;
            right: 20px;
            bottom: 0;
            height: 210px;
            max-width: 42%;
            object-fit: contain;
        }

        .staff-label {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            background:
                rgba(
                    255,
                    255,
                    255,
                    .15
                );
            font-size: 11px;
            margin-bottom: 12px;
        }

        /* Statistics */

        .stats-grid {
            display: grid;
            grid-template-columns:
                repeat(4, 1fr);
            gap: 18px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: white;
            border-radius: 17px;
            padding: 21px;
            border:
                1px solid #edf0f4;
            box-shadow:
                0 5px 20px
                rgba(
                    30,
                    60,
                    90,
                    .04
                );
        }

        .stat-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .stat-icon {
            width: 45px;
            height: 45px;
            border-radius: 13px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #e0f7fa;
            color: #087f8c;
            font-size: 21px;
        }

        .stat-icon.warning {
            background: #fff4d6;
            color: #a66b00;
        }

        .stat-card h3 {
            font-size: 27px;
            margin-top: 17px;
            margin-bottom: 3px;
        }

        .stat-card p {
            color: #78909c;
            font-size: 12px;
        }

        /* Quick actions */

        .section-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .section-title h3 {
            font-size: 19px;
            font-weight: 700;
        }

        .section-title span {
            font-size: 12px;
            color: #78909c;
        }

        .quick-actions {
            display: grid;
            grid-template-columns:
                repeat(4, 1fr);
            gap: 18px;
            margin-bottom: 28px;
        }

        .quick-card {
            background: white;
            border:
                1px solid #edf0f4;
            border-radius: 17px;
            padding: 22px;
            text-decoration: none;
            color: #263238;
            transition: .2s;
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .quick-card:hover {
            transform:
                translateY(-3px);
            box-shadow:
                0 10px 25px
                rgba(
                    30,
                    60,
                    90,
                    .09
                );
            color: #087f8c;
        }

        .quick-icon {
            width: 52px;
            height: 52px;
            border-radius: 15px;
            background: #e0f7fa;
            color: #087f8c;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 23px;
            flex-shrink: 0;
        }

        .quick-card h4 {
            font-size: 15px;
            margin-bottom: 5px;
        }

        .quick-card p {
            font-size: 11px;
            color: #78909c;
            margin: 0;
        }

        .quick-arrow {
            margin-left: auto;
            color: #90a4ae;
        }

        /* Dashboard columns */

        .dashboard-grid {
            display: grid;
            grid-template-columns:
                1.5fr 1fr;
            gap: 22px;
            margin-bottom: 22px;
        }

        .panel {
            background: white;
            border-radius: 18px;
            border:
                1px solid #edf0f4;
            overflow: hidden;
        }

        .panel-header {
            padding: 20px 22px;
            border-bottom:
                1px solid #edf0f4;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .panel-header h3 {
            font-size: 17px;
            margin: 0;
        }

        .view-link {
            text-decoration: none;
            color: #087f8c;
            font-size: 12px;
            font-weight: 600;
        }

        .table-wrap {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            font-size: 10px;
            color: #90a4ae;
            text-transform: uppercase;
            padding:
                13px 18px;
            text-align: left;
            background: #fafcfd;
        }

        td {
            padding:
                14px 18px;
            border-top:
                1px solid #f0f3f5;
            font-size: 12px;
        }

        .customer-name {
            font-weight: 600;
        }

        .customer-email {
            font-size: 10px;
            color: #90a4ae;
            margin-top: 2px;
        }

        /* Status labels */

        .status {
            display: inline-block;
            padding:
                5px 9px;
            border-radius: 20px;
            font-size: 9px;
            font-weight: 600;
            white-space: nowrap;
        }

        .status-pending,
        .prescription-pending {
            background: #fff4d6;
            color: #a66b00;
        }

        .status-processing {
            background: #e3f2fd;
            color: #1565c0;
        }

        .status-shipped {
            background: #ede7f6;
            color: #5e35b1;
        }

        .status-delivered,
        .prescription-approved,
        .prescription-completed {
            background: #e7f7ef;
            color: #16804a;
        }

        .status-cancelled,
        .prescription-rejected {
            background: #ffebee;
            color: #c62828;
        }

        /* Product stock panel */

        .stock-product {
            display: flex;
            align-items: center;
            gap: 12px;
            padding:
                15px 20px;
            border-bottom:
                1px solid #f0f3f5;
        }

        .stock-product:last-child {
            border-bottom: none;
        }

        .stock-product-image {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            object-fit: cover;
            background: #f1f5f7;
            border:
                1px solid #e8eef1;
            flex-shrink: 0;
        }

        .stock-product-info {
            min-width: 0;
            flex: 1;
        }

        .stock-product-name {
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .stock-product-category {
            font-size: 9px;
            color: #90a4ae;
            margin-top: 3px;
        }

        .stock-count {
            text-align: right;
            flex-shrink: 0;
        }

        .stock-count strong {
            display: block;
            font-size: 14px;
            color: #a66b00;
        }

        .stock-count span {
            font-size: 9px;
            color: #90a4ae;
        }

        .stock-empty {
            padding: 35px 20px;
            text-align: center;
            color: #90a4ae;
        }

        .stock-empty i {
            font-size: 30px;
            display: block;
            margin-bottom: 8px;
        }

        .stock-empty p {
            font-size: 11px;
            margin: 0;
        }

        /* Empty states */

        .empty-state {
            padding:
                35px 20px;
            text-align: center;
            color: #90a4ae;
        }

        .empty-state i {
            font-size: 35px;
            margin-bottom: 10px;
            display: block;
        }

        .empty-state p {
            font-size: 12px;
        }

        /* Responsive layout */

        @media(max-width: 1250px) {

            .stats-grid {
                grid-template-columns:
                    repeat(2, 1fr);
            }

            .quick-actions {
                grid-template-columns:
                    repeat(2, 1fr);
            }

            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }

        @media(max-width: 900px) {

            .sidebar {
                width: 75px;
                padding:
                    20px 9px;
            }

            .brand h2,
            .brand p,
            .nav-menu span,
            .nav-title {
                display: none;
            }

            .brand-icon {
                width: 50px;
                height: 50px;
                font-size: 25px;
            }

            .nav-menu a {
                justify-content: center;
                padding:
                    13px 8px;
            }

            .notification-badge {
                position: absolute;
                margin-left: 25px;
                margin-top: -25px;
            }

            .main {
                margin-left: 75px;
            }

            .hero-content {
                width: 65%;
            }
        }

        @media(max-width: 700px) {

            .content {
                padding: 18px;
            }

            .topbar {
                padding: 0 18px;
            }

            .staff-info {
                display: none;
            }

            .hero {
                padding: 25px;
                min-height: 250px;
            }

            .hero-content {
                width: 100%;
            }

            .hero h2 {
                font-size: 24px;
            }

            .hero-image {
                opacity: .25;
                max-width: 75%;
            }

            .quick-actions {
                grid-template-columns: 1fr;
            }

            .stats-grid {
                grid-template-columns:
                    1fr 1fr;
                gap: 12px;
            }

            .stat-card {
                padding: 15px;
            }
        }

        @media(max-width: 450px) {

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .sidebar {
                width: 60px;
            }

            .main {
                margin-left: 60px;
            }

            .content {
                padding: 12px;
            }

            .hero {
                border-radius: 15px;
            }
        }

    </style>

</head>

<body>

<!-- Staff sidebar -->

<aside class="sidebar">

    <div class="brand">

        <div class="brand-icon">
            <i class="bi bi-heart-pulse-fill"></i>
        </div>

        <h2>MediQuick</h2>

        <p>
            Pharmacy Management
        </p>

    </div>

    <ul class="nav-menu">

        <!-- Dashboard -->

        <li>

            <a
                href="staff-dashboard.php"
                class="active"
            >

                <i class="bi bi-grid-1x2-fill"></i>

                <span>
                    Dashboard
                </span>

            </a>

        </li>

        <div class="nav-title">
            Management
        </div>

        <!-- Customer Orders -->

        <li>

            <a href="staff-orders.php">

                <i class="bi bi-bag-check-fill"></i>

                <span>
                    Customer Orders
                </span>

            </a>

        </li>

        <!-- Prescriptions -->

        <li>

            <a href="staff-prescriptions.php">

                <i class="bi bi-file-medical-fill"></i>

                <span>
                    Prescriptions
                </span>

            </a>

        </li>

        <!-- Products -->

        <li>

            <a href="staff-products.php">

                <i class="bi bi-box-seam-fill"></i>

                <span>
                    Products
                </span>

                <?php if ($lowStockProducts > 0): ?>

                    <span
                        class="notification-badge"
                        title="Low stock products"
                    >

                        <?php
                        echo $lowStockProducts;
                        ?>

                    </span>

                <?php endif; ?>

            </a>

        </li>

        <!-- Notifications -->

        <li>

            <a href="staff-notifications.php">

                <i class="bi bi-bell-fill"></i>

                <span>
                    Notifications
                </span>

                <?php if ($unreadNotifications > 0): ?>

                    <span
                        class="notification-badge"
                    >

                        <?php
                        echo $unreadNotifications;
                        ?>

                    </span>

                <?php endif; ?>

            </a>

        </li>

        <div class="nav-title">
            Account
        </div>

        <!-- Staff profile -->

        <li>

            <a href="../profile.php">

                <i class="bi bi-person-circle"></i>

                <span>
                    My Profile
                </span>

            </a>

        </li>

        <!-- Contact -->

        <li>

            <a href="../contact.php">

                <i class="bi bi-headset"></i>

                <span>
                    Contact
                </span>

            </a>

        </li>

        <!-- Logout -->

        <li>

            <a href="../logout.php">

                <i class="bi bi-box-arrow-right"></i>

                <span>
                    Logout
                </span>

            </a>

        </li>

    </ul>

</aside>

<!-- Main dashboard -->

<main class="main">

    <!-- Top bar -->

    <header class="topbar">

        <div class="page-title">

            <h1>
                Staff Dashboard
            </h1>

            <p>
                Manage customer orders, prescriptions,
                products and pharmacy operations.
            </p>

        </div>

        <div class="staff-profile">

            <div class="staff-avatar">

                <?php
                echo strtoupper(
                    substr(
                        $staffName,
                        0,
                        1
                    )
                );
                ?>

            </div>

            <div class="staff-info">

                <strong>
                    <?php
                    echo e($staffName);
                    ?>
                </strong>

                <span>
                    Pharmacy Staff
                </span>

            </div>

        </div>

    </header>

    <!-- Dashboard content -->

    <section class="content">

        <!-- Hero -->

        <div class="hero">

            <div class="hero-content">

                <span class="staff-label">

                    <i class="bi bi-shield-check"></i>

                    Staff Panel

                </span>

                <h2>

                    Welcome,

                    <?php
                    echo e($staffName);
                    ?>!

                </h2>

                <p>

                    Manage customer orders, review uploaded
                    prescriptions, monitor pharmacy products,
                    update stock levels and stay updated with
                    important staff notifications.

                </p>

            </div>

            <img
                src="<?php echo e($pharmacyImage); ?>"
                alt="MediQuick Pharmacy"
                class="hero-image"
                onerror="this.style.display='none';"
            >

        </div>

        <!-- Statistics -->

        <div class="stats-grid">

            <!-- Total orders -->

            <div class="stat-card">

                <div class="stat-top">

                    <div>

                        <h3>
                            <?php
                            echo $totalOrders;
                            ?>
                        </h3>

                        <p>
                            Total Customer Orders
                        </p>

                    </div>

                    <div class="stat-icon">

                        <i class="bi bi-bag-check-fill"></i>

                    </div>

                </div>

            </div>

            <!-- Pending orders -->

            <div class="stat-card">

                <div class="stat-top">

                    <div>

                        <h3>
                            <?php
                            echo $pendingOrders;
                            ?>
                        </h3>

                        <p>
                            Pending Orders
                        </p>

                    </div>

                    <div class="stat-icon">

                        <i class="bi bi-hourglass-split"></i>

                    </div>

                </div>

            </div>

            <!-- Pending prescriptions -->

            <div class="stat-card">

                <div class="stat-top">

                    <div>

                        <h3>
                            <?php
                            echo $pendingPrescriptions;
                            ?>
                        </h3>

                        <p>
                            Pending Prescriptions
                        </p>

                    </div>

                    <div class="stat-icon">

                        <i class="bi bi-file-medical-fill"></i>

                    </div>

                </div>

            </div>

            <!-- Customers -->

            <div class="stat-card">

                <div class="stat-top">

                    <div>

                        <h3>
                            <?php
                            echo $totalCustomers;
                            ?>
                        </h3>

                        <p>
                            Registered Customers
                        </p>

                    </div>

                    <div class="stat-icon">

                        <i class="bi bi-people-fill"></i>

                    </div>

                </div>

            </div>

        </div>

        <!-- Quick actions -->

        <div class="section-title">

            <div>

                <h3>
                    Quick Actions
                </h3>

            </div>

            <span>
                Staff management
            </span>

        </div>

        <div class="quick-actions">

            <!-- Orders -->

            <a
                href="staff-orders.php"
                class="quick-card"
            >

                <div class="quick-icon">

                    <i class="bi bi-bag-check-fill"></i>

                </div>

                <div>

                    <h4>
                        View Orders
                    </h4>

                    <p>
                        View and manage customer orders
                    </p>

                </div>

                <i
                    class="bi bi-chevron-right quick-arrow"
                ></i>

            </a>

            <!-- Prescriptions -->

            <a
                href="staff-prescriptions.php"
                class="quick-card"
            >

                <div class="quick-icon">

                    <i class="bi bi-file-medical-fill"></i>

                </div>

                <div>

                    <h4>
                        Prescriptions
                    </h4>

                    <p>
                        Review uploaded prescriptions
                    </p>

                </div>

                <i
                    class="bi bi-chevron-right quick-arrow"
                ></i>

            </a>

            <!-- Products -->

            <a
                href="staff-products.php"
                class="quick-card"
            >

                <div class="quick-icon">

                    <i class="bi bi-box-seam-fill"></i>

                </div>

                <div>

                    <h4>
                        Products
                    </h4>

                    <p>
                        Manage products and stock
                    </p>

                </div>

                <i
                    class="bi bi-chevron-right quick-arrow"
                ></i>

            </a>

            <!-- Notifications -->

            <a
                href="staff-notifications.php"
                class="quick-card"
            >

                <div class="quick-icon">

                    <i class="bi bi-bell-fill"></i>

                </div>

                <div>

                    <h4>
                        Notifications
                    </h4>

                    <p>
                        View staff notifications
                    </p>

                </div>

                <?php if ($unreadNotifications > 0): ?>

                    <span
                        class="notification-badge"
                    >

                        <?php
                        echo $unreadNotifications;
                        ?>

                    </span>

                <?php endif; ?>

                <i
                    class="bi bi-chevron-right quick-arrow"
                ></i>

            </a>

        </div>

        <!-- Recent orders and prescriptions -->

        <div class="dashboard-grid">

            <!-- Recent customer orders -->

            <div class="panel">

                <div class="panel-header">

                    <h3>

                        <i
                            class="bi bi-bag-check me-2"
                        ></i>

                        Recent Customer Orders

                    </h3>

                    <a
                        href="staff-orders.php"
                        class="view-link"
                    >
                        View All
                    </a>

                </div>

                <?php if (!empty($recentOrders)): ?>

                    <div class="table-wrap">

                        <table>

                            <thead>

                                <tr>

                                    <th>
                                        Order
                                    </th>

                                    <th>
                                        Customer
                                    </th>

                                    <th>
                                        Total
                                    </th>

                                    <th>
                                        Status
                                    </th>

                                </tr>

                            </thead>

                            <tbody>

                                <?php foreach (
                                    $recentOrders
                                    as $order
                                ): ?>

                                    <tr>

                                        <td>

                                            <strong>

                                                #

                                                <?php
                                                echo e(
                                                    $order['order_number']
                                                );
                                                ?>

                                            </strong>

                                            <div
                                                class="customer-email"
                                            >

                                                <?php
                                                echo date(
                                                    'd M Y',
                                                    strtotime(
                                                        $order['created_at']
                                                    )
                                                );
                                                ?>

                                            </div>

                                        </td>

                                        <td>

                                            <div
                                                class="customer-name"
                                            >

                                                <?php
                                                echo e(
                                                    $order['full_name']
                                                );
                                                ?>

                                            </div>

                                            <div
                                                class="customer-email"
                                            >

                                                <?php
                                                echo e(
                                                    $order['email']
                                                );
                                                ?>

                                            </div>

                                        </td>

                                        <td>

                                            <strong>

                                                Rs.

                                                <?php
                                                echo number_format(
                                                    (float)
                                                    $order['total_amount'],
                                                    2
                                                );
                                                ?>

                                            </strong>

                                        </td>

                                        <td>

                                            <span
                                                class="status <?php echo orderStatusClass($order['order_status']); ?>"
                                            >

                                                <?php
                                                echo e(
                                                    $order['order_status']
                                                );
                                                ?>

                                            </span>

                                        </td>

                                    </tr>

                                <?php endforeach; ?>

                            </tbody>

                        </table>

                    </div>

                <?php else: ?>

                    <div class="empty-state">

                        <i
                            class="bi bi-bag-x"
                        ></i>

                        <p>
                            No customer orders found.
                        </p>

                    </div>

                <?php endif; ?>

            </div>

            <!-- Recent prescriptions -->

            <div class="panel">

                <div class="panel-header">

                    <h3>

                        <i
                            class="bi bi-file-medical me-2"
                        ></i>

                        Recent Prescriptions

                    </h3>

                    <a
                        href="staff-prescriptions.php"
                        class="view-link"
                    >
                        View All
                    </a>

                </div>

                <?php if (!empty($recentPrescriptions)): ?>

                    <?php foreach (
                        $recentPrescriptions
                        as $prescription
                    ): ?>

                        <div
                            style="
                                padding:17px 20px;
                                border-bottom:1px solid #f0f3f5;
                            "
                        >

                            <div
                                style="
                                    display:flex;
                                    justify-content:space-between;
                                    align-items:flex-start;
                                    gap:10px;
                                "
                            >

                                <div>

                                    <strong
                                        style="
                                            font-size:13px;
                                            display:block;
                                        "
                                    >

                                        <?php
                                        echo e(
                                            $prescription['patient_name']
                                        );
                                        ?>

                                    </strong>

                                    <span
                                        style="
                                            font-size:10px;
                                            color:#90a4ae;
                                            display:block;
                                            margin-top:3px;
                                        "
                                    >

                                        <?php
                                        echo e(
                                            $prescription['email']
                                        );
                                        ?>

                                    </span>

                                    <span
                                        style="
                                            font-size:10px;
                                            color:#90a4ae;
                                            display:block;
                                            margin-top:3px;
                                        "
                                    >

                                        <i
                                            class="bi bi-file-earmark"
                                        ></i>

                                        <?php
                                        echo e(
                                            $prescription['file_name']
                                        );
                                        ?>

                                    </span>

                                </div>

                                <span
                                    class="status <?php echo prescriptionStatusClass($prescription['status']); ?>"
                                >

                                    <?php
                                    echo e(
                                        $prescription['status']
                                    );
                                    ?>

                                </span>

                            </div>

                        </div>

                    <?php endforeach; ?>

                <?php else: ?>

                    <div class="empty-state">

                        <i
                            class="bi bi-file-earmark-x"
                        ></i>

                        <p>
                            No prescriptions uploaded yet.
                        </p>

                    </div>

                <?php endif; ?>

            </div>

        </div>

        <!-- Product stock overview -->

        <div class="panel">

            <div class="panel-header">

                <h3>

                    <i
                        class="bi bi-box-seam me-2"
                    ></i>

                    Product Stock Overview

                </h3>

                <a
                    href="staff-products.php"
                    class="view-link"
                >
                    Manage Products
                </a>

            </div>

            <div
                style="
                    display:grid;
                    grid-template-columns:repeat(3,1fr);
                    gap:15px;
                    padding:18px 20px;
                    border-bottom:1px solid #edf0f4;
                "
            >

                <!-- Total products -->

                <div
                    style="
                        background:#f8fbfc;
                        border-radius:12px;
                        padding:15px;
                    "
                >

                    <div
                        style="
                            color:#087f8c;
                            font-size:20px;
                            margin-bottom:6px;
                        "
                    >

                        <i
                            class="bi bi-box-seam-fill"
                        ></i>

                    </div>

                    <strong
                        style="
                            display:block;
                            font-size:20px;
                        "
                    >

                        <?php
                        echo $totalProducts;
                        ?>

                    </strong>

                    <span
                        style="
                            font-size:10px;
                            color:#78909c;
                        "
                    >
                        Active Products
                    </span>

                </div>

                <!-- Low stock -->

                <div
                    style="
                        background:#fffaf0;
                        border-radius:12px;
                        padding:15px;
                    "
                >

                    <div
                        style="
                            color:#d78a00;
                            font-size:20px;
                            margin-bottom:6px;
                        "
                    >

                        <i
                            class="bi bi-exclamation-triangle-fill"
                        ></i>

                    </div>

                    <strong
                        style="
                            display:block;
                            font-size:20px;
                            color:#a66b00;
                        "
                    >

                        <?php
                        echo $lowStockProducts;
                        ?>

                    </strong>

                    <span
                        style="
                            font-size:10px;
                            color:#78909c;
                        "
                    >
                        Low Stock Products
                    </span>

                </div>

                <!-- Out of stock -->

                <div
                    style="
                        background:#fff5f5;
                        border-radius:12px;
                        padding:15px;
                    "
                >

                    <div
                        style="
                            color:#d13c3c;
                            font-size:20px;
                            margin-bottom:6px;
                        "
                    >

                        <i
                            class="bi bi-x-circle-fill"
                        ></i>

                    </div>

                    <strong
                        style="
                            display:block;
                            font-size:20px;
                            color:#c62828;
                        "
                    >

                        <?php
                        echo $outOfStockProducts;
                        ?>

                    </strong>

                    <span
                        style="
                            font-size:10px;
                            color:#78909c;
                        "
                    >
                        Out of Stock
                    </span>

                </div>

            </div>

            <!-- Low-stock products -->

            <?php if (!empty($lowStockList)): ?>

                <?php foreach (
                    $lowStockList
                    as $product
                ): ?>

                    <div class="stock-product">

                        <img
                            src="<?php
                            echo e(
                                getProductImage(
                                    $product['image'],
                                    $product['category']
                                )
                            );
                            ?>"
                            alt="<?php
                            echo e(
                                $product['name']
                            );
                            ?>"
                            class="stock-product-image"
                            onerror="
                                this.onerror=null;
                                this.src='../assets/images/Logo.png';
                            "
                        >

                        <div class="stock-product-info">

                            <div
                                class="stock-product-name"
                            >

                                <?php
                                echo e(
                                    $product['name']
                                );
                                ?>

                            </div>

                            <div
                                class="stock-product-category"
                            >

                                <?php
                                echo e(
                                    $product['category']
                                );
                                ?>

                            </div>

                        </div>

                        <div class="stock-count">

                            <strong>

                                <?php
                                echo (int)
                                    $product['stock_quantity'];
                                ?>

                            </strong>

                            <span>
                                units left
                            </span>

                        </div>

                    </div>

                <?php endforeach; ?>

            <?php else: ?>

                <div class="stock-empty">

                    <i
                        class="bi bi-check-circle"
                    ></i>

                    <p>
                        All products have healthy stock levels.
                    </p>

                </div>

            <?php endif; ?>

        </div>

    </section>

</main>

<!-- Reload the page when it is restored from browser cache. -->

<script>

window.addEventListener(
    "pageshow",
    function(event) {

        if (event.persisted) {
            window.location.reload();
        }

    }
);

</script>

</body>

</html>