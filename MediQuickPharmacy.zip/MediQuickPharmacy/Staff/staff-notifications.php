<?php

session_start();

/*
 * Prevent cached pages from being displayed after logout.
 */
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");


/*
 * Allow access only to logged-in staff members.
 */
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {

    header("Location: ../login.php");
    exit;
}

if ($_SESSION['user_role'] !== 'staff') {

    if ($_SESSION['user_role'] === 'customer') {
        header("Location: ../Customer/customer-dashboard.php");
        exit;
    }

    if ($_SESSION['user_role'] === 'admin') {
        header("Location: ../Admin/admin-dashboard.php");
        exit;
    }

    header("Location: ../login.php");
    exit;
}


/*
 * Load the database connection.
 * This file is inside Staff/, so the config folder
 * is one level above the current directory.
 */
require_once '../config/database.php';

$staffId = (int)($_SESSION['user_id'] ?? 0);
$staffName = $_SESSION['user_name'] ?? 'Staff Member';


/*
 * Escape values before displaying them in HTML.
 */
function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}


/*
 * Check whether the notifications table exists.
 */
$tableExists = false;

$check = $conn->query(
    "SHOW TABLES LIKE 'notifications'"
);

if ($check && $check->num_rows > 0) {
    $tableExists = true;
}


/*
 * Mark one notification as read.
 */
if (
    $tableExists &&
    isset($_GET['read'])
) {

    $notificationId = (int)$_GET['read'];

    if ($notificationId > 0) {

        $stmt = $conn->prepare("
            UPDATE notifications
            SET is_read = 1
            WHERE id = ?
            AND user_id = ?
        ");

        if ($stmt) {

            $stmt->bind_param(
                "ii",
                $notificationId,
                $staffId
            );

            $stmt->execute();
            $stmt->close();
        }
    }

    header("Location: staff-notifications.php");
    exit;
}


/*
 * Mark all staff notifications as read.
 */
if (
    $tableExists &&
    isset($_GET['mark_all'])
) {

    $stmt = $conn->prepare("
        UPDATE notifications
        SET is_read = 1
        WHERE user_id = ?
    ");

    if ($stmt) {

        $stmt->bind_param(
            "i",
            $staffId
        );

        $stmt->execute();
        $stmt->close();
    }

    header("Location: staff-notifications.php");
    exit;
}


/*
 * Delete one notification.
 */
if (
    $tableExists &&
    isset($_GET['delete'])
) {

    $notificationId = (int)$_GET['delete'];

    if ($notificationId > 0) {

        $stmt = $conn->prepare("
            DELETE FROM notifications
            WHERE id = ?
            AND user_id = ?
        ");

        if ($stmt) {

            $stmt->bind_param(
                "ii",
                $notificationId,
                $staffId
            );

            $stmt->execute();
            $stmt->close();
        }
    }

    header("Location: staff-notifications.php");
    exit;
}


/*
 * Delete all notifications belonging to the
 * currently logged-in staff member.
 */
if (
    $tableExists &&
    isset($_GET['clear_all'])
) {

    $stmt = $conn->prepare("
        DELETE FROM notifications
        WHERE user_id = ?
    ");

    if ($stmt) {

        $stmt->bind_param(
            "i",
            $staffId
        );

        $stmt->execute();
        $stmt->close();
    }

    header("Location: staff-notifications.php");
    exit;
}


/*
 * Load notifications.
 */
$notifications = [];
$unreadCount = 0;

if ($tableExists) {

    /*
     * Get unread notification count.
     */
    $stmt = $conn->prepare("
        SELECT COUNT(*) AS total
        FROM notifications
        WHERE user_id = ?
        AND is_read = 0
    ");

    if ($stmt) {

        $stmt->bind_param(
            "i",
            $staffId
        );

        $stmt->execute();

        $result = $stmt->get_result();

        if ($result) {

            $row = $result->fetch_assoc();

            $unreadCount =
                (int)($row['total'] ?? 0);
        }

        $stmt->close();
    }


    /*
     * Get the latest 100 notifications.
     */
    $stmt = $conn->prepare("
        SELECT
            id,
            title,
            message,
            type,
            related_id,
            is_read,
            created_at
        FROM notifications
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 100
    ");

    if ($stmt) {

        $stmt->bind_param(
            "i",
            $staffId
        );

        $stmt->execute();

        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $notifications[] = $row;
        }

        $stmt->close();
    }
}


/*
 * Return the CSS class according to notification type.
 */
function notificationClass($type)
{
    switch ($type) {

        case 'Order':
            return 'order';

        case 'Prescription':
            return 'prescription';

        case 'Payment':
            return 'payment';

        case 'Product':
            return 'product';

        default:
            return 'system';
    }
}


/*
 * Return the Bootstrap icon according to
 * notification type.
 */
function notificationIcon($type)
{
    switch ($type) {

        case 'Order':
            return 'bi-bag-check-fill';

        case 'Prescription':
            return 'bi-file-earmark-medical-fill';

        case 'Payment':
            return 'bi-credit-card-fill';

        case 'Product':
            return 'bi-capsule';

        default:
            return 'bi-info-circle-fill';
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Staff Notifications | MediQuick Pharmacy
    </title>


    <!-- Bootstrap CSS -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >


    <!-- Bootstrap Icons -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
        rel="stylesheet"
    >


    <style>

        /* Reset default browser spacing. */

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }


        /* Main page styling. */

        body {
            font-family: "Segoe UI", Arial, sans-serif;
            background: #f4f7fb;
            color: #263238;
        }


        /* Fixed staff sidebar. */

        .sidebar {
            width: 255px;
            height: 100vh;

            position: fixed;

            left: 0;
            top: 0;

            background:
                linear-gradient(
                    180deg,
                    #087f8c,
                    #075b66
                );

            color: white;

            padding: 25px 16px;

            z-index: 1000;

            overflow-y: auto;
        }


        /* MediQuick brand section. */

        .brand {
            text-align: center;

            margin-bottom: 30px;
        }


        .brand-icon {
            width: 62px;
            height: 62px;

            margin: auto;

            background: white;

            border-radius: 18px;

            display: flex;

            align-items: center;

            justify-content: center;

            color: #087f8c;

            font-size: 32px;
        }


        .brand h2 {
            font-size: 21px;

            margin-top: 12px;

            margin-bottom: 2px;

            font-weight: 700;
        }


        .brand p {
            font-size: 12px;

            opacity: .8;

            margin: 0;
        }


        /* Sidebar navigation list. */

        .nav-menu {
            list-style: none;

            padding: 0;

            margin: 0;
        }


        .nav-menu li {
            margin-bottom: 7px;
        }


        .nav-menu a {
            display: flex;

            align-items: center;

            gap: 13px;

            padding: 13px 15px;

            color: rgba(255,255,255,.88);

            text-decoration: none;

            border-radius: 12px;

            transition: .2s;

            font-size: 14px;
        }


        .nav-menu a:hover,
        .nav-menu a.active {
            background:
                rgba(255,255,255,.16);

            color: white;
        }


        .nav-menu i {
            font-size: 18px;

            width: 20px;

            text-align: center;
        }


        .nav-title {
            font-size: 10px;

            text-transform: uppercase;

            letter-spacing: 1px;

            opacity: .55;

            padding: 18px 15px 7px;
        }


        /* Main page area. */

        .main {
            margin-left: 255px;

            min-height: 100vh;

            padding-bottom: 40px;
        }


        /* Top navigation bar. */

        .topbar {
            background: white;

            min-height: 75px;

            display: flex;

            align-items: center;

            justify-content: space-between;

            padding: 15px 32px;

            border-bottom:
                1px solid #e9edf2;
        }


        .page-title h1 {
            font-size: 24px;

            font-weight: 700;

            margin-bottom: 2px;
        }


        .page-title p {
            font-size: 13px;

            color: #78909c;

            margin: 0;
        }


        /* Logged-in staff profile. */

        .staff-profile {
            display: flex;

            align-items: center;

            gap: 12px;
        }


        .staff-avatar {
            width: 43px;
            height: 43px;

            border-radius: 50%;

            background: #e0f7fa;

            color: #087f8c;

            display: flex;

            align-items: center;

            justify-content: center;

            font-weight: 700;

            font-size: 17px;
        }


        .staff-info strong {
            display: block;

            font-size: 14px;
        }


        .staff-info span {
            font-size: 11px;

            color: #78909c;
        }


        /* Main content container. */

        .content {
            padding: 30px;
        }


        /* Notification page introduction. */

        .page-intro {
            background:
                linear-gradient(
                    135deg,
                    #087f8c,
                    #0b6470
                );

            color: white;

            border-radius: 20px;

            padding: 25px 28px;

            margin-bottom: 25px;

            display: flex;

            align-items: center;

            justify-content: space-between;

            overflow: hidden;

            position: relative;
        }


        .page-intro::after {
            content: "";

            position: absolute;

            width: 190px;
            height: 190px;

            border-radius: 50%;

            background:
                rgba(255,255,255,.07);

            right: -55px;

            top: -75px;
        }


        .intro-content {
            position: relative;

            z-index: 2;
        }


        .intro-label {
            display: inline-flex;

            align-items: center;

            gap: 6px;

            padding: 6px 12px;

            background:
                rgba(255,255,255,.14);

            border-radius: 20px;

            font-size: 10px;

            margin-bottom: 9px;
        }


        .page-intro h2 {
            font-size: 23px;

            margin-bottom: 6px;

            font-weight: 700;
        }


        .page-intro p {
            margin: 0;

            font-size: 12px;

            opacity: .88;
        }


        .intro-icon {
            width: 70px;
            height: 70px;

            border-radius: 20px;

            background:
                rgba(255,255,255,.12);

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 34px;

            position: relative;

            z-index: 2;
        }


        /* Notification summary box. */

        .notification-top {
            background: white;

            border-radius: 17px;

            padding: 19px 21px;

            margin-bottom: 20px;

            display: flex;

            justify-content: space-between;

            align-items: center;

            border: 1px solid #edf0f4;

            box-shadow:
                0 5px 20px rgba(30,60,90,.035);
        }


        .notification-summary {
            display: flex;

            align-items: center;

            gap: 13px;
        }


        .summary-icon {
            width: 45px;
            height: 45px;

            background: #e0f7fa;

            color: #087f8c;

            border-radius: 13px;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 21px;
        }


        .summary-text strong {
            display: block;

            font-size: 16px;

            color: #304761;
        }


        .summary-text span {
            display: block;

            color: #8b99a9;

            font-size: 11px;

            margin-top: 3px;
        }


        /* Notification action buttons. */

        .top-buttons {
            display: flex;

            gap: 8px;
        }


        .top-buttons a {
            padding: 9px 13px;

            border-radius: 9px;

            font-size: 10px;

            text-decoration: none;

            font-weight: 600;

            transition: .2s;
        }


        .mark-btn {
            background: #eef8fa;

            color: #087a8c;
        }


        .mark-btn:hover {
            background: #087f8c;

            color: white;
        }


        .clear-btn {
            background: #fff0f2;

            color: #c34559;
        }


        .clear-btn:hover {
            background: #c34559;

            color: white;
        }


        /* Individual notification card. */

        .notification {
            background: white;

            border: 1px solid #edf0f4;

            border-radius: 17px;

            padding: 18px 20px;

            margin-bottom: 12px;

            display: flex;

            gap: 15px;

            align-items: flex-start;

            transition: .2s;

            box-shadow:
                0 5px 20px rgba(30,60,90,.025);
        }


        .notification:hover {
            box-shadow:
                0 9px 28px rgba(30,60,90,.07);

            transform: translateY(-2px);
        }


        .notification.unread {
            border-left:
                4px solid #087f8c;

            background: #fbfeff;
        }


        /* Notification type icon. */

        .icon {
            width: 47px;
            height: 47px;

            border-radius: 13px;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 20px;

            flex-shrink: 0;
        }


        .icon.order {
            background: #eaf2ff;

            color: #4169b9;
        }


        .icon.prescription {
            background: #f1edff;

            color: #7256ba;
        }


        .icon.payment {
            background: #e7f8ee;

            color: #21814c;
        }


        .icon.product {
            background: #fff4dd;

            color: #c48410;
        }


        .icon.system {
            background: #eef8fa;

            color: #087a8c;
        }


        /* Notification text. */

        .notification-content {
            flex: 1;

            min-width: 0;
        }


        .notification-content h4 {
            margin: 0 0 5px;

            font-size: 14px;

            font-weight: 800;

            color: #304761;
        }


        .notification-content p {
            margin: 0;

            color: #6f7f91;

            font-size: 12px;

            line-height: 1.65;
        }


        .notification-content small {
            display: block;

            margin-top: 8px;

            color: #9aa6b4;

            font-size: 10px;
        }


        /* Unread indicator. */

        .unread-dot {
            width: 7px;
            height: 7px;

            background: #087a8c;

            border-radius: 50%;

            margin-top: 7px;

            flex-shrink: 0;
        }


        /* Notification action buttons. */

        .notification-actions {
            display: flex;

            gap: 5px;
        }


        .notification-actions a {
            width: 32px;
            height: 32px;

            border-radius: 9px;

            display: flex;

            justify-content: center;

            align-items: center;

            background: #f5f7fa;

            color: #718197;

            text-decoration: none;

            transition: .2s;
        }


        .notification-actions a:hover {
            background: #eef8fa;

            color: #087a8c;
        }


        .notification-actions a.delete:hover {
            background: #fff0f2;

            color: #c34559;
        }


        /* Empty notification state. */

        .empty {
            background: white;

            border-radius: 18px;

            padding: 75px 20px;

            text-align: center;

            color: #95a2b1;

            border: 1px solid #edf0f4;

            box-shadow:
                0 5px 20px rgba(30,60,90,.035);
        }


        .empty i {
            font-size: 48px;

            display: block;

            margin-bottom: 13px;

            color: #cbd6dd;
        }


        .empty h5 {
            color: #40546b;

            font-size: 17px;

            font-weight: 700;

            margin-bottom: 5px;
        }


        .empty p {
            margin: 0;

            font-size: 12px;
        }


        /* Error message. */

        .alert {
            border: none;

            border-radius: 13px;

            font-size: 12px;

            margin-bottom: 20px;
        }


        /* Tablet layout. */

        @media(max-width: 900px) {

            .sidebar {
                width: 75px;

                padding:
                    20px 9px;
            }


            .brand h2,
            .brand p,
            .nav-title,
            .nav-menu span {
                display: none;
            }


            .brand-icon {
                width: 50px;
                height: 50px;

                font-size: 25px;
            }


            .nav-menu a {
                justify-content: center;

                padding:
                    13px 8px;
            }


            .main {
                margin-left: 75px;
            }


            .content {
                padding: 22px;
            }


            .page-intro {
                padding: 22px;
            }
        }


        /* Mobile layout. */

        @media(max-width: 700px) {

            .content {
                padding: 18px;
            }


            .topbar {
                padding:
                    14px 18px;
            }


            .page-title h1 {
                font-size: 21px;
            }


            .staff-info {
                display: none;
            }


            .page-intro {
                min-height: 165px;

                padding: 22px;
            }


            .page-intro h2 {
                font-size: 21px;
            }


            .intro-icon {
                display: none;
            }


            .notification-top {
                align-items: flex-start;

                flex-direction: column;

                gap: 15px;
            }


            .top-buttons {
                width: 100%;
            }


            .top-buttons a {
                flex: 1;

                text-align: center;
            }


            .notification {
                padding: 15px;

                gap: 11px;
            }


            .notification-actions {
                flex-direction: column;
            }
        }


        /* Small mobile layout. */

        @media(max-width: 450px) {

            .sidebar {
                width: 60px;
            }


            .main {
                margin-left: 60px;
            }


            .content {
                padding: 12px;
            }


            .topbar {
                min-height: 65px;
            }


            .page-title p {
                display: none;
            }


            .notification {
                flex-wrap: wrap;
            }


            .notification-content {
                width:
                    calc(100% - 58px);
            }


            .notification-actions {
                margin-left: 58px;

                flex-direction: row;
            }
        }

    </style>

</head>


<body>


<!-- Staff navigation sidebar -->

<aside class="sidebar">


    <div class="brand">

        <div class="brand-icon">

            <i class="bi bi-heart-pulse-fill"></i>

        </div>


        <h2>
            MediQuick
        </h2>


        <p>
            Pharmacy Management
        </p>

    </div>


    <ul class="nav-menu">


        <!-- Staff Dashboard -->

        <li>

            <a href="staff-dashboard.php">

                <i class="bi bi-grid-1x2-fill"></i>

                <span>
                    Dashboard
                </span>

            </a>

        </li>


        <div class="nav-title">
            Management
        </div>


        <!-- Customer Orders -->

        <li>

            <a href="staff-orders.php">

                <i class="bi bi-bag-check-fill"></i>

                <span>
                    Customer Orders
                </span>

            </a>

        </li>


        <!-- Prescriptions -->

        <li>

            <a href="staff-prescriptions.php">

                <i class="bi bi-file-medical-fill"></i>

                <span>
                    Prescriptions
                </span>

            </a>

        </li>


        <!-- Products -->

        <li>

            <a href="staff-products.php">

                <i class="bi bi-capsule"></i>

                <span>
                    Products
                </span>

            </a>

        </li>


        <!-- Notifications -->

        <li>

            <a
                href="staff-notifications.php"
                class="active"
            >

                <i class="bi bi-bell-fill"></i>

                <span>
                    Notifications
                </span>


                <?php if ($unreadCount > 0): ?>

                    <span
                        style="
                            margin-left:auto;
                            background:#ff5252;
                            color:white;
                            min-width:22px;
                            height:22px;
                            padding:0 6px;
                            border-radius:50px;
                            font-size:10px;
                            display:flex;
                            align-items:center;
                            justify-content:center;
                        "
                    >

                        <?php
                        echo $unreadCount;
                        ?>

                    </span>

                <?php endif; ?>

            </a>

        </li>


    </ul>


    <div class="nav-title">
        Account
    </div>


    <ul class="nav-menu">


        <!-- Staff profile is located inside Customer folder. -->

        <li>

            <a href="../profile.php">

                <i class="bi bi-person-circle"></i>

                <span>
                    My Profile
                </span>

            </a>

        </li>


        <!-- Contact page is located in the project root. -->

        <li>

            <a href="../contact.php">

                <i class="bi bi-headset"></i>

                <span>
                    Contact
                </span>

            </a>

        </li>


        <!-- Logout page is located in the project root. -->

        <li>

            <a href="../logout.php">

                <i class="bi bi-box-arrow-right"></i>

                <span>
                    Logout
                </span>

            </a>

        </li>


    </ul>

</aside>


<!-- Main notification area -->

<main class="main">


    <!-- Top bar -->

    <header class="topbar">


        <div class="page-title">

            <h1>
                Staff Notifications
            </h1>

            <p>
                Notifications and alerts for staff members
            </p>

        </div>


        <div class="staff-profile">


            <div class="staff-avatar">

                <?php

                echo e(
                    strtoupper(
                        substr(
                            trim($staffName),
                            0,
                            1
                        )
                    )
                );

                ?>

            </div>


            <div class="staff-info">

                <strong>
                    <?php
                    echo e($staffName);
                    ?>
                </strong>

                <span>
                    Pharmacy Staff
                </span>

            </div>


        </div>


    </header>


    <!-- Main page content -->

    <section class="content">


        <!-- Page introduction -->

        <div class="page-intro">


            <div class="intro-content">


                <span class="intro-label">

                    <i class="bi bi-bell-fill"></i>

                    Staff Notification Center

                </span>


                <h2>
                    Stay Updated
                </h2>


                <p>
                    View important order, prescription,
                    payment and product notifications.
                </p>


            </div>


            <div class="intro-icon">

                <i class="bi bi-bell-fill"></i>

            </div>


        </div>


        <!-- Display message when notifications table does not exist. -->

        <?php if (!$tableExists): ?>


            <div class="alert alert-danger">

                <i
                    class="bi bi-exclamation-triangle-fill me-2"
                ></i>

                <strong>
                    Notifications table not found.
                </strong>

                Please create the
                <strong>notifications</strong>
                table in phpMyAdmin.

            </div>


        <?php else: ?>


            <!-- Notification summary -->

            <div class="notification-top">


                <div class="notification-summary">


                    <div class="summary-icon">

                        <i class="bi bi-bell-fill"></i>

                    </div>


                    <div class="summary-text">

                        <strong>
                            Your Notifications
                        </strong>


                        <span>

                            <?php
                            echo $unreadCount;
                            ?>

                            unread notification<?php

                            echo
                                $unreadCount == 1
                                ? ''
                                : 's';

                            ?>

                        </span>

                    </div>


                </div>


                <!-- Notification management buttons -->

                <div class="top-buttons">


                    <?php if ($unreadCount > 0): ?>


                        <a
                            href="staff-notifications.php?mark_all=1"
                            class="mark-btn"
                        >

                            <i
                                class="bi bi-check2-all me-1"
                            ></i>

                            Mark All Read

                        </a>


                    <?php endif; ?>


                    <?php if (count($notifications) > 0): ?>


                        <a
                            href="staff-notifications.php?clear_all=1"
                            class="clear-btn"
                            onclick="
                                return confirm(
                                    'Clear all staff notifications?'
                                );
                            "
                        >

                            <i
                                class="bi bi-trash me-1"
                            ></i>

                            Clear All

                        </a>


                    <?php endif; ?>


                </div>


            </div>


            <!-- Display notification list -->

            <?php if (count($notifications) > 0): ?>


                <?php foreach ($notifications as $notification): ?>


                    <?php

                    $typeClass =
                        notificationClass(
                            $notification['type']
                        );

                    $icon =
                        notificationIcon(
                            $notification['type']
                        );

                    ?>


                    <div
                        class="
                            notification
                            <?php

                            echo !$notification['is_read']
                                ? 'unread'
                                : '';

                            ?>
                        "
                    >


                        <!-- Notification icon -->

                        <div
                            class="
                                icon
                                <?php
                                echo e($typeClass);
                                ?>
                            "
                        >

                            <i
                                class="
                                    bi
                                    <?php
                                    echo e($icon);
                                    ?>
                                "
                            ></i>

                        </div>


                        <!-- Notification details -->

                        <div class="notification-content">


                            <h4>

                                <?php

                                echo e(
                                    $notification['title']
                                );

                                ?>


                                <?php if (!$notification['is_read']): ?>


                                    <span
                                        style="
                                            display:inline-block;
                                            width:7px;
                                            height:7px;
                                            background:#087f8c;
                                            border-radius:50%;
                                            margin-left:6px;
                                            vertical-align:middle;
                                        "
                                    ></span>


                                <?php endif; ?>


                            </h4>


                            <p>

                                <?php

                                echo e(
                                    $notification['message']
                                );

                                ?>

                            </p>


                            <small>

                                <i
                                    class="bi bi-clock me-1"
                                ></i>


                                <?php

                                if (
                                    !empty(
                                        $notification['created_at']
                                    )
                                ) {

                                    echo date(
                                        'd M Y, h:i A',
                                        strtotime(
                                            $notification['created_at']
                                        )
                                    );

                                }

                                ?>


                                <span class="mx-1">
                                    •
                                </span>


                                <i
                                    class="
                                        bi
                                        <?php
                                        echo e($icon);
                                        ?>
                                        me-1
                                    "
                                ></i>


                                <?php

                                echo e(
                                    $notification['type']
                                );

                                ?>

                            </small>


                        </div>


                        <!-- Notification actions -->

                        <div class="notification-actions">


                            <?php if (!$notification['is_read']): ?>


                                <a
                                    href="
                                        staff-notifications.php?read=<?php
                                        echo (int)$notification['id'];
                                        ?>
                                    "
                                    title="Mark as read"
                                >

                                    <i
                                        class="bi bi-check2"
                                    ></i>

                                </a>


                            <?php endif; ?>


                            <a
                                href="
                                    staff-notifications.php?delete=<?php
                                    echo (int)$notification['id'];
                                    ?>
                                "
                                class="delete"
                                title="Delete"
                                onclick="
                                    return confirm(
                                        'Delete this notification?'
                                    );
                                "
                            >

                                <i
                                    class="bi bi-trash"
                                ></i>

                            </a>


                        </div>


                    </div>


                <?php endforeach; ?>


            <?php else: ?>


                <!-- Empty notification state -->

                <div class="empty">


                    <i
                        class="bi bi-bell-slash"
                    ></i>


                    <h5>
                        No Notifications
                    </h5>


                    <p>
                        You don't have any staff notifications yet.
                    </p>


                </div>


            <?php endif; ?>


        <?php endif; ?>


    </section>


</main>


<!-- Reload the page when restored from browser back/forward cache. -->

<script>

window.addEventListener(
    "pageshow",
    function(event) {

        if (event.persisted) {
            window.location.reload();
        }

    }
);

</script>


</body>

</html>