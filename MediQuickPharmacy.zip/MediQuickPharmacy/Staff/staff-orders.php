<?php
session_start();

/* Prevent cached pages from being displayed after logout. */
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");

/* Allow access only to logged-in staff members. */
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
    header("Location: ../login.php");
    exit;
}

if ($_SESSION['user_role'] !== 'staff') {

    if ($_SESSION['user_role'] === 'customer') {
        header("Location: ../Customer/customer-dashboard.php");
        exit;
    }

    if ($_SESSION['user_role'] === 'admin') {
        header("Location: ../Admin/admin-dashboard.php");
        exit;
    }

    header("Location: ../login.php");
    exit;
}

/* Load the database connection from the project root. */
require_once '../config/database.php';

$staffName = $_SESSION['user_name'] ?? 'Staff Member';

/* Escape values before displaying them in HTML. */
function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

/* Return the CSS class that matches an order status. */
function statusClass($status)
{
    switch ($status) {

        case 'Pending':
            return 'pending';

        case 'Processing':
            return 'processing';

        case 'Shipped':
            return 'shipped';

        case 'Delivered':
            return 'delivered';

        case 'Cancelled':
            return 'cancelled';

        default:
            return 'default';
    }
}

/* Update an order status when the staff submits the status form. */
$message = "";
$messageType = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';

    if ($action === 'update_status') {

        $orderId = (int)($_POST['order_id'] ?? 0);
        $newStatus = $_POST['order_status'] ?? '';

        $allowedStatuses = [
            'Pending',
            'Processing',
            'Shipped',
            'Delivered',
            'Cancelled'
        ];

        if ($orderId > 0 && in_array($newStatus, $allowedStatuses, true)) {

            $stmt = $conn->prepare("
                UPDATE orders
                SET order_status = ?
                WHERE id = ?
            ");

            if ($stmt) {

                $stmt->bind_param(
                    "si",
                    $newStatus,
                    $orderId
                );

                if ($stmt->execute()) {
                    $message = "Order status updated successfully.";
                    $messageType = "success";
                } else {
                    $message = "Unable to update order status.";
                    $messageType = "danger";
                }

                $stmt->close();
            }
        }
    }
}

/* Read and validate the selected order-status filter. */
$statusFilter = $_GET['status'] ?? 'All';

$allowedFilters = [
    'All',
    'Pending',
    'Processing',
    'Shipped',
    'Delivered',
    'Cancelled'
];

if (!in_array($statusFilter, $allowedFilters, true)) {
    $statusFilter = 'All';
}

/* Retrieve orders according to the selected filter. */
$orders = [];

if ($statusFilter === 'All') {

    $stmt = $conn->prepare("
        SELECT
            o.id,
            o.user_id,
            o.order_number,
            o.full_name,
            o.email,
            o.phone,
            o.delivery_address,
            o.city,
            o.payment_method,
            o.subtotal,
            o.delivery_fee,
            o.total_amount,
            o.order_status,
            o.created_at
        FROM orders o
        ORDER BY o.created_at DESC
    ");

} else {

    $stmt = $conn->prepare("
        SELECT
            o.id,
            o.user_id,
            o.order_number,
            o.full_name,
            o.email,
            o.phone,
            o.delivery_address,
            o.city,
            o.payment_method,
            o.subtotal,
            o.delivery_fee,
            o.total_amount,
            o.order_status,
            o.created_at
        FROM orders o
        WHERE o.order_status = ?
        ORDER BY o.created_at DESC
    ");
}

if ($stmt) {

    if ($statusFilter !== 'All') {
        $stmt->bind_param("s", $statusFilter);
    }

    $stmt->execute();

    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }

    $stmt->close();
}

/* Calculate order statistics for the dashboard cards. */
$totalOrders = 0;
$pendingOrders = 0;
$processingOrders = 0;
$shippedOrders = 0;
$deliveredOrders = 0;

$result = $conn->query("
    SELECT
        COUNT(*) AS total,
        SUM(order_status = 'Pending') AS pending,
        SUM(order_status = 'Processing') AS processing,
        SUM(order_status = 'Shipped') AS shipped,
        SUM(order_status = 'Delivered') AS delivered
    FROM orders
");

if ($result) {

    $row = $result->fetch_assoc();

    $totalOrders = (int)($row['total'] ?? 0);
    $pendingOrders = (int)($row['pending'] ?? 0);
    $processingOrders = (int)($row['processing'] ?? 0);
    $shippedOrders = (int)($row['shipped'] ?? 0);
    $deliveredOrders = (int)($row['delivered'] ?? 0);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Customer Orders | MediQuick Pharmacy</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css"
rel="stylesheet">

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: "Segoe UI", Arial, sans-serif;
    background: #f4f7fb;
    color: #263238;
}

.sidebar {
    width: 255px;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    background: linear-gradient(
        180deg,
        #087f8c,
        #075b66
    );
    color: white;
    padding: 25px 16px;
    z-index: 1000;
    overflow-y: auto;
}

.brand {
    text-align: center;
    margin-bottom: 30px;
}

.brand-icon {
    width: 62px;
    height: 62px;
    margin: auto;
    background: white;
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #087f8c;
    font-size: 32px;
}

.brand h2 {
    font-size: 21px;
    margin-top: 12px;
    margin-bottom: 2px;
    font-weight: 700;
}

.brand p {
    font-size: 12px;
    opacity: .8;
    margin: 0;
}

.nav-menu {
    list-style: none;
    padding: 0;
    margin: 0;
}

.nav-menu li {
    margin-bottom: 7px;
}

.nav-menu a {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 13px 15px;
    color: rgba(255,255,255,.88);
    text-decoration: none;
    border-radius: 12px;
    transition: .2s;
    font-size: 14px;
}

.nav-menu a:hover,
.nav-menu a.active {
    background: rgba(255,255,255,.16);
    color: white;
}

.nav-menu i {
    font-size: 18px;
    width: 20px;
    text-align: center;
}

.nav-title {
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 1px;
    opacity: .55;
    padding: 18px 15px 7px;
}

.notification-badge {
    margin-left: auto;
    background: #ff5252;
    color: white;
    min-width: 22px;
    height: 22px;
    padding: 0 6px;
    border-radius: 50px;
    font-size: 11px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.main {
    margin-left: 255px;
    min-height: 100vh;
    padding-bottom: 40px;
}

.topbar {
    background: white;
    min-height: 75px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 15px 32px;
    border-bottom: 1px solid #e9edf2;
}

.page-title h1 {
    font-size: 24px;
    font-weight: 700;
    margin-bottom: 2px;
}

.page-title p {
    font-size: 13px;
    color: #78909c;
    margin: 0;
}

.staff-profile {
    display: flex;
    align-items: center;
    gap: 12px;
}

.staff-avatar {
    width: 43px;
    height: 43px;
    border-radius: 50%;
    background: #e0f7fa;
    color: #087f8c;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 17px;
}

.staff-info strong {
    display: block;
    font-size: 14px;
}

.staff-info span {
    font-size: 11px;
    color: #78909c;
}

.content {
    padding: 30px;
}

.alert-box {
    border-radius: 12px;
    font-size: 13px;
    border: none;
    margin-bottom: 22px;
}

.page-intro {
    background: linear-gradient(
        135deg,
        #087f8c,
        #0b6470
    );
    color: white;
    border-radius: 20px;
    padding: 25px 28px;
    margin-bottom: 25px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    overflow: hidden;
    position: relative;
}

.page-intro::after {
    content: "";
    position: absolute;
    width: 180px;
    height: 180px;
    border-radius: 50%;
    background: rgba(255,255,255,.07);
    right: -50px;
    top: -70px;
}

.intro-content {
    position: relative;
    z-index: 2;
}

.intro-label {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    background: rgba(255,255,255,.14);
    border-radius: 20px;
    font-size: 10px;
    margin-bottom: 9px;
}

.page-intro h2 {
    font-size: 23px;
    margin-bottom: 6px;
    font-weight: 700;
}

.page-intro p {
    margin: 0;
    font-size: 12px;
    opacity: .88;
}

.intro-icon {
    width: 70px;
    height: 70px;
    border-radius: 20px;
    background: rgba(255,255,255,.12);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 34px;
    position: relative;
    z-index: 2;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 18px;
    margin-bottom: 25px;
}

.stat-card {
    background: white;
    border-radius: 17px;
    padding: 21px;
    border: 1px solid #edf0f4;
    box-shadow: 0 5px 20px rgba(30,60,90,.04);
    transition: .2s;
}

.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 9px 25px rgba(30,60,90,.08);
}

.stat-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.stat-icon {
    width: 45px;
    height: 45px;
    border-radius: 13px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #e0f7fa;
    color: #087f8c;
    font-size: 21px;
}

.stat-card h3 {
    font-size: 27px;
    margin-top: 17px;
    margin-bottom: 3px;
    font-weight: 700;
}

.stat-card p {
    color: #78909c;
    font-size: 12px;
    margin: 0;
}

.filter-panel {
    background: white;
    border-radius: 17px;
    padding: 18px 20px;
    margin-bottom: 22px;
    border: 1px solid #edf0f4;
    box-shadow: 0 5px 20px rgba(30,60,90,.035);
}

.filter-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 13px;
}

.filter-header h3 {
    font-size: 16px;
    font-weight: 700;
    margin: 0;
}

.filter-header span {
    color: #78909c;
    font-size: 11px;
}

.filters {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.filter {
    border: 1px solid #e1e8ed;
    background: white;
    color: #607d8b;
    padding: 8px 14px;
    border-radius: 9px;
    font-size: 11px;
    text-decoration: none;
    transition: .2s;
}

.filter:hover {
    color: #087f8c;
    border-color: #087f8c;
    background: #f1fbfc;
}

.filter.active {
    background: #087f8c;
    color: white;
    border-color: #087f8c;
}

.orders-heading {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 15px;
}

.orders-heading h3 {
    font-size: 19px;
    font-weight: 700;
    margin: 0;
}

.orders-heading span {
    font-size: 11px;
    color: #78909c;
}

.order-card {
    background: white;
    border: 1px solid #edf0f4;
    border-radius: 18px;
    margin-bottom: 17px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(30,60,90,.04);
    transition: .2s;
}

.order-card:hover {
    box-shadow: 0 10px 28px rgba(30,60,90,.08);
    transform: translateY(-2px);
}

.order-header {
    padding: 17px 21px;
    border-bottom: 1px solid #edf0f4;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #fcfefe;
}

.order-number {
    font-size: 15px;
    font-weight: 800;
    color: #087f8c;
}

.order-date {
    font-size: 11px;
    color: #90a4ae;
    margin-top: 3px;
}

.status {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 6px 10px;
    border-radius: 20px;
    font-size: 9px;
    font-weight: 700;
    white-space: nowrap;
}

.status::before {
    content: "";
    width: 5px;
    height: 5px;
    border-radius: 50%;
    background: currentColor;
}

.status.pending {
    background: #fff4d6;
    color: #a66b00;
}

.status.processing {
    background: #e3f2fd;
    color: #1565c0;
}

.status.shipped {
    background: #ede7f6;
    color: #5e35b1;
}

.status.delivered {
    background: #e7f7ef;
    color: #16804a;
}

.status.cancelled {
    background: #ffebee;
    color: #c62828;
}

.status.default {
    background: #edf1f5;
    color: #607d8b;
}

.order-body {
    padding: 21px;
}

.customer {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 19px;
}

.customer-avatar {
    width: 45px;
    height: 45px;
    border-radius: 13px;
    background: #e0f7fa;
    color: #087f8c;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 16px;
}

.customer strong {
    display: block;
    font-size: 14px;
}

.customer small {
    display: block;
    color: #90a4ae;
    font-size: 10px;
    margin-top: 4px;
}

.order-info {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 13px;
}

.info-box {
    background: #f8fafc;
    border: 1px solid #f0f3f5;
    border-radius: 12px;
    padding: 13px;
    min-height: 68px;
}

.info-box span {
    display: block;
    color: #90a4ae;
    font-size: 9px;
    text-transform: uppercase;
    letter-spacing: .4px;
    margin-bottom: 6px;
}

.info-box strong {
    font-size: 12px;
    color: #40546b;
    line-height: 1.45;
    word-break: break-word;
}

.order-footer {
    border-top: 1px solid #edf0f4;
    padding: 15px 21px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #fcfefe;
}

.total {
    font-size: 17px;
    font-weight: 800;
    color: #263b55;
}

.total-label {
    color: #78909c;
    font-size: 11px;
    font-weight: 500;
    margin-right: 4px;
}

.status-form {
    display: flex;
    gap: 8px;
    align-items: center;
}

.status-form select {
    border: 1px solid #dfe7ed;
    background: white;
    border-radius: 9px;
    padding: 8px 11px;
    font-size: 11px;
    color: #40546b;
    outline: none;
    min-width: 130px;
}

.status-form select:focus {
    border-color: #087f8c;
    box-shadow: 0 0 0 2px rgba(8,127,140,.08);
}

.update-btn {
    border: 0;
    background: #087f8c;
    color: white;
    border-radius: 9px;
    padding: 8px 14px;
    font-size: 11px;
    font-weight: 600;
    transition: .2s;
}

.update-btn:hover {
    background: #075f69;
    transform: translateY(-1px);
}

.empty {
    background: white;
    border-radius: 18px;
    padding: 70px 20px;
    text-align: center;
    color: #90a4ae;
    border: 1px solid #edf0f4;
}

.empty i {
    font-size: 48px;
    display: block;
    margin-bottom: 13px;
    color: #cbd6dd;
}

.empty h5 {
    color: #40546b;
    font-size: 17px;
    font-weight: 700;
    margin-bottom: 5px;
}

.empty p {
    margin: 0;
    font-size: 12px;
}

@media(max-width:1200px) {

    .stats-grid {
        grid-template-columns: repeat(2, 1fr);
    }

    .order-info {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media(max-width:900px) {

    .sidebar {
        width: 75px;
        padding: 20px 9px;
    }

    .brand h2,
    .brand p,
    .nav-menu span,
    .nav-title {
        display: none;
    }

    .brand-icon {
        width: 50px;
        height: 50px;
        font-size: 25px;
    }

    .nav-menu a {
        justify-content: center;
        padding: 13px 8px;
    }

    .notification-badge {
        position: absolute;
        margin-left: 25px;
        margin-top: -25px;
    }

    .main {
        margin-left: 75px;
    }

    .content {
        padding: 22px;
    }

    .page-intro {
        padding: 22px;
    }
}

@media(max-width:700px) {

    .content {
        padding: 18px;
    }

    .topbar {
        padding: 14px 18px;
    }

    .page-title h1 {
        font-size: 21px;
    }

    .staff-info {
        display: none;
    }

    .page-intro {
        min-height: 170px;
        padding: 22px;
    }

    .page-intro h2 {
        font-size: 21px;
    }

    .intro-icon {
        display: none;
    }

    .stats-grid {
        grid-template-columns: 1fr 1fr;
        gap: 12px;
    }

    .stat-card {
        padding: 16px;
    }

    .stat-card h3 {
        font-size: 23px;
    }

    .filter-header {
        align-items: flex-start;
        gap: 5px;
        flex-direction: column;
    }

    .order-header {
        align-items: flex-start;
        gap: 10px;
        flex-direction: column;
    }

    .order-info {
        grid-template-columns: 1fr 1fr;
    }

    .order-footer {
        align-items: flex-start;
        gap: 14px;
        flex-direction: column;
    }

    .status-form {
        width: 100%;
    }

    .status-form select {
        flex: 1;
    }

    .update-btn {
        min-width: 80px;
    }
}

@media(max-width:450px) {

    .sidebar {
        width: 60px;
    }

    .main {
        margin-left: 60px;
    }

    .content {
        padding: 12px;
    }

    .stats-grid {
        grid-template-columns: 1fr;
    }

    .order-info {
        grid-template-columns: 1fr;
    }

    .topbar {
        min-height: 65px;
    }

    .page-title p {
        display: none;
    }

    .order-body {
        padding: 16px;
    }

    .order-footer {
        padding: 14px 16px;
    }

    .status-form {
        flex-direction: column;
        align-items: stretch;
    }

    .status-form select,
    .update-btn {
        width: 100%;
    }
}

</style>

</head>

<body>

<!-- Staff navigation sidebar. -->
<aside class="sidebar">

    <div class="brand">

        <div class="brand-icon">
            <i class="bi bi-heart-pulse-fill"></i>
        </div>

        <h2>MediQuick</h2>

        <p>Pharmacy Management</p>

    </div>

    <ul class="nav-menu">

        <li>
            <a href="staff-dashboard.php">
                <i class="bi bi-grid-1x2-fill"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <div class="nav-title">
            Management
        </div>

        <li>
            <a href="staff-orders.php" class="active">
                <i class="bi bi-bag-check-fill"></i>
                <span>Customer Orders</span>
            </a>
        </li>

        <li>
            <a href="staff-prescriptions.php">
                <i class="bi bi-file-medical-fill"></i>
                <span>Prescriptions</span>
            </a>
        </li>

        <li>
            <a href="staff-products.php">
                <i class="bi bi-capsule"></i>
                <span>Products</span>
            </a>
        </li>

        <li>
            <a href="staff-notifications.php">
                <i class="bi bi-bell-fill"></i>
                <span>Notifications</span>
            </a>
        </li>

        <div class="nav-title">
            Account
        </div>

        <li>
            <a href="../profile.php">
                <i class="bi bi-person-circle"></i>
                <span>My Profile</span>
            </a>
        </li>

        <li>
            <a href="../contact.php">
                <i class="bi bi-headset"></i>
                <span>Contact</span>
            </a>
        </li>

        <li>
            <a href="../logout.php">
                <i class="bi bi-box-arrow-right"></i>
                <span>Logout</span>
            </a>
        </li>

    </ul>

</aside>

<!-- Main staff order-management area. -->
<main class="main">

    <header class="topbar">

        <div class="page-title">

            <h1>Customer Orders</h1>

            <p>
                View and manage orders placed by customers.
            </p>

        </div>

        <div class="staff-profile">

            <div class="staff-avatar">

                <?php
                echo e(
                    strtoupper(
                        substr(trim($staffName), 0, 1)
                    )
                );
                ?>

            </div>

            <div class="staff-info">

                <strong>
                    <?php echo e($staffName); ?>
                </strong>

                <span>
                    Pharmacy Staff
                </span>

            </div>

        </div>

    </header>

    <section class="content">

        <!-- Page introduction section. -->
        <div class="page-intro">

            <div class="intro-content">

                <span class="intro-label">

                    <i class="bi bi-bag-check-fill"></i>

                    Staff Order Management

                </span>

                <h2>
                    Manage Customer Orders
                </h2>

                <p>
                    Review customer orders, check delivery information
                    and update order statuses from one place.
                </p>

            </div>

            <div class="intro-icon">
                <i class="bi bi-clipboard-check"></i>
            </div>

        </div>

        <!-- Display the result of an order-status update. -->
        <?php if ($message !== ""): ?>

            <div class="alert alert-<?php echo e($messageType); ?> alert-box">

                <i class="bi bi-check-circle-fill me-2"></i>

                <?php echo e($message); ?>

            </div>

        <?php endif; ?>

        <!-- Display order statistics. -->
        <div class="stats-grid">

            <div class="stat-card">

                <div class="stat-top">

                    <div>

                        <h3>
                            <?php echo $totalOrders; ?>
                        </h3>

                        <p>
                            Total Orders
                        </p>

                    </div>

                    <div class="stat-icon">
                        <i class="bi bi-bag-check-fill"></i>
                    </div>

                </div>

            </div>

            <div class="stat-card">

                <div class="stat-top">

                    <div>

                        <h3>
                            <?php echo $pendingOrders; ?>
                        </h3>

                        <p>
                            Pending Orders
                        </p>

                    </div>

                    <div class="stat-icon">
                        <i class="bi bi-hourglass-split"></i>
                    </div>

                </div>

            </div>

            <div class="stat-card">

                <div class="stat-top">

                    <div>

                        <h3>
                            <?php echo $processingOrders; ?>
                        </h3>

                        <p>
                            Processing Orders
                        </p>

                    </div>

                    <div class="stat-icon">
                        <i class="bi bi-arrow-repeat"></i>
                    </div>

                </div>

            </div>

            <div class="stat-card">

                <div class="stat-top">

                    <div>

                        <h3>
                            <?php echo $deliveredOrders; ?>
                        </h3>

                        <p>
                            Delivered Orders
                        </p>

                    </div>

                    <div class="stat-icon">
                        <i class="bi bi-check-circle-fill"></i>
                    </div>

                </div>

            </div>

        </div>

        <!-- Order-status filter controls. -->
        <div class="filter-panel">

            <div class="filter-header">

                <h3>

                    <i class="bi bi-funnel-fill me-2"></i>

                    Filter Orders

                </h3>

                <span>
                    Showing:
                    <?php echo e($statusFilter); ?>
                </span>

            </div>

            <div class="filters">

                <?php foreach ($allowedFilters as $filter): ?>

                    <a
                        href="staff-orders.php?status=<?php echo urlencode($filter); ?>"
                        class="filter <?php echo $statusFilter === $filter ? 'active' : ''; ?>"
                    >

                        <?php if ($filter === 'All'): ?>

                            <i class="bi bi-grid me-1"></i>

                        <?php elseif ($filter === 'Pending'): ?>

                            <i class="bi bi-hourglass-split me-1"></i>

                        <?php elseif ($filter === 'Processing'): ?>

                            <i class="bi bi-arrow-repeat me-1"></i>

                        <?php elseif ($filter === 'Shipped'): ?>

                            <i class="bi bi-truck me-1"></i>

                        <?php elseif ($filter === 'Delivered'): ?>

                            <i class="bi bi-check-circle me-1"></i>

                        <?php elseif ($filter === 'Cancelled'): ?>

                            <i class="bi bi-x-circle me-1"></i>

                        <?php endif; ?>

                        <?php echo e($filter); ?>

                    </a>

                <?php endforeach; ?>

            </div>

        </div>

        <!-- Display the number of orders returned by the selected filter. -->
        <div class="orders-heading">

            <h3>

                <i class="bi bi-list-check me-2"></i>

                Customer Orders

            </h3>

            <span>

                <?php echo count($orders); ?>

                order(s) found

            </span>

        </div>

        <!-- Display customer orders. -->
        <?php if (count($orders) > 0): ?>

            <?php foreach ($orders as $order): ?>

                <div class="order-card">

                    <div class="order-header">

                        <div>

                            <div class="order-number">

                                <i class="bi bi-receipt me-1"></i>

                                #

                                <?php
                                echo e(
                                    $order['order_number']
                                );
                                ?>

                            </div>

                            <div class="order-date">

                                <i class="bi bi-calendar3 me-1"></i>

                                <?php
                                echo date(
                                    'd M Y, h:i A',
                                    strtotime(
                                        $order['created_at']
                                    )
                                );
                                ?>

                            </div>

                        </div>

                        <span class="status <?php echo e(
                            statusClass(
                                $order['order_status']
                            )
                        ); ?>">

                            <?php
                            echo e(
                                $order['order_status']
                            );
                            ?>

                        </span>

                    </div>

                    <div class="order-body">

                        <div class="customer">

                            <div class="customer-avatar">

                                <?php
                                echo e(
                                    strtoupper(
                                        substr(
                                            trim(
                                                $order['full_name']
                                            ),
                                            0,
                                            1
                                        )
                                    )
                                );
                                ?>

                            </div>

                            <div>

                                <strong>

                                    <?php
                                    echo e(
                                        $order['full_name']
                                    );
                                    ?>

                                </strong>

                                <small>

                                    <i class="bi bi-envelope me-1"></i>

                                    <?php
                                    echo e(
                                        $order['email']
                                    );
                                    ?>

                                    <?php if (!empty($order['phone'])): ?>

                                        <span class="mx-1">•</span>

                                        <i class="bi bi-telephone me-1"></i>

                                        <?php
                                        echo e(
                                            $order['phone']
                                        );
                                        ?>

                                    <?php endif; ?>

                                </small>

                            </div>

                        </div>

                        <div class="order-info">

                            <div class="info-box">

                                <span>
                                    <i class="bi bi-geo-alt-fill me-1"></i>
                                    Delivery Address
                                </span>

                                <strong>

                                    <?php
                                    echo e(
                                        $order['delivery_address']
                                    );
                                    ?>

                                    <?php if (!empty($order['city'])): ?>

                                        ,
                                        <?php
                                        echo e(
                                            $order['city']
                                        );
                                        ?>

                                    <?php endif; ?>

                                </strong>

                            </div>

                            <div class="info-box">

                                <span>

                                    <i class="bi bi-credit-card-fill me-1"></i>

                                    Payment

                                </span>

                                <strong>

                                    <?php
                                    echo e(
                                        $order['payment_method']
                                    );
                                    ?>

                                </strong>

                            </div>

                            <div class="info-box">

                                <span>

                                    <i class="bi bi-cart3 me-1"></i>

                                    Subtotal

                                </span>

                                <strong>

                                    Rs.

                                    <?php
                                    echo number_format(
                                        (float)$order['subtotal'],
                                        2
                                    );
                                    ?>

                                </strong>

                            </div>

                            <div class="info-box">

                                <span>

                                    <i class="bi bi-truck me-1"></i>

                                    Delivery Fee

                                </span>

                                <strong>

                                    Rs.

                                    <?php
                                    echo number_format(
                                        (float)$order['delivery_fee'],
                                        2
                                    );
                                    ?>

                                </strong>

                            </div>

                        </div>

                    </div>

                    <div class="order-footer">

                        <div class="total">

                            <span class="total-label">
                                Total:
                            </span>

                            Rs.

                            <?php
                            echo number_format(
                                (float)$order['total_amount'],
                                2
                            );
                            ?>

                        </div>

                        <!-- Staff can update the current order status. -->
                        <form
                            method="POST"
                            class="status-form"
                        >

                            <input
                                type="hidden"
                                name="action"
                                value="update_status"
                            >

                            <input
                                type="hidden"
                                name="order_id"
                                value="<?php echo (int)$order['id']; ?>"
                            >

                            <select
                                name="order_status"
                            >

                                <?php foreach (
                                    [
                                        'Pending',
                                        'Processing',
                                        'Shipped',
                                        'Delivered',
                                        'Cancelled'
                                    ] as $status
                                ): ?>

                                    <option
                                        value="<?php echo e($status); ?>"
                                        <?php
                                        echo $order['order_status'] === $status
                                            ? 'selected'
                                            : '';
                                        ?>
                                    >

                                        <?php echo e($status); ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>

                            <button
                                type="submit"
                                class="update-btn"
                            >

                                <i class="bi bi-check2-circle me-1"></i>

                                Update

                            </button>

                        </form>

                    </div>

                </div>

            <?php endforeach; ?>

        <?php else: ?>

            <div class="empty">

                <i class="bi bi-bag-x"></i>

                <h5>
                    No Orders Found
                </h5>

                <p>
                    There are no customer orders under this filter.
                </p>

            </div>

        <?php endif; ?>

    </section>

</main>

<script>

/* Reload the page when the browser restores it from its back-forward cache. */
window.addEventListener("pageshow", function(event) {

    if (event.persisted) {
        window.location.reload();
    }

});

</script>

</body>
</html>