<?php

/* Include the common website header so the navigation bar and shared
   website elements are displayed at the top of the About Us page. */
include 'includes/header.php';

?>

<section class="about-page">

    <!--
        Hero Section
        Displays the main title and a short introduction to
        the MediQuick Pharmacy About Us page.
    -->
    <div class="about-hero">

        <div class="about-container">

            <span class="about-small-title">
                MEDIQUICK PHARMACY
            </span>

            <h1>
                About Us
            </h1>

            <p>
                Your trusted partner for convenient,
                reliable and quality healthcare.
            </p>

        </div>

    </div>


    <!--
        Who We Are Section
        Provides information about MediQuick Pharmacy,
        the services offered and the main benefits provided
        to customers through the online pharmacy platform.
    -->
    <section class="about-section">

        <div class="about-container">

            <div class="about-intro">

                <!--
                    Pharmacy Logo
                    Displays the MediQuick Pharmacy logo using
                    the image stored in the project's assets folder.
                -->
                <div class="about-image-box">

                    <img
                        src="assets/images/Icon.png"
                        alt="MediQuick Pharmacy"
                    >

                </div>


                <!--
                    Pharmacy Introduction
                    Contains the main description of MediQuick Pharmacy
                    and the key service highlights.
                -->
                <div class="about-content">

                    <span class="section-label">
                        WHO WE ARE
                    </span>

                    <h2>
                        Your Health,
                        Our Priority
                    </h2>

                    <p>
                        MediQuick Pharmacy is a modern
                        online pharmacy designed to make
                        healthcare shopping simple,
                        convenient and accessible.
                    </p>

                    <p>
                        We provide a wide range of
                        healthcare products including
                        medicines, wellness products,
                        personal care products, medical
                        devices and baby care essentials.
                    </p>

                    <p>
                        Our platform allows customers to
                        browse products, manage their cart,
                        place orders and upload prescriptions
                        conveniently from home.
                    </p>


                    <!--
                        Service Highlights
                        Displays the main advantages of using
                        MediQuick Pharmacy.
                    -->
                    <div class="about-highlights">

                        <!-- Trusted service highlight -->
                        <div class="highlight-item">

                            <i class="bi bi-shield-check"></i>

                            <div>

                                <strong>
                                    Trusted Service
                                </strong>

                                <span>
                                    Reliable healthcare support
                                </span>

                            </div>

                        </div>


                        <!-- Quality healthcare highlight -->
                        <div class="highlight-item">

                            <i class="bi bi-heart-pulse"></i>

                            <div>

                                <strong>
                                    Quality Healthcare
                                </strong>

                                <span>
                                    Products for everyday needs
                                </span>

                            </div>

                        </div>


                        <!-- Convenient access highlight -->
                        <div class="highlight-item">

                            <i class="bi bi-clock-history"></i>

                            <div>

                                <strong>
                                    Convenient Access
                                </strong>

                                <span>
                                    Easy online shopping
                                </span>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </section>


    <!--
        Mission, Vision and Values Section
        Presents the three main principles that describe
        the purpose and direction of MediQuick Pharmacy.
    -->
    <section class="mission-section">

        <div class="about-container">

            <div class="mission-grid">


                <!-- Mission Card -->
                <div class="mission-card">

                    <div class="mission-icon">
                        <i class="bi bi-bullseye"></i>
                    </div>

                    <h3>
                        Our Mission
                    </h3>

                    <p>
                        To provide customers with a
                        convenient and reliable way to
                        access quality healthcare products
                        while delivering a simple and
                        user-friendly online pharmacy
                        experience.
                    </p>

                </div>


                <!-- Vision Card -->
                <div class="mission-card">

                    <div class="mission-icon">
                        <i class="bi bi-eye"></i>
                    </div>

                    <h3>
                        Our Vision
                    </h3>

                    <p>
                        To become a trusted digital pharmacy
                        that makes healthcare more accessible,
                        convenient and easier for individuals
                        and families.
                    </p>

                </div>


                <!-- Values Card -->
                <div class="mission-card">

                    <div class="mission-icon">
                        <i class="bi bi-stars"></i>
                    </div>

                    <h3>
                        Our Values
                    </h3>

                    <p>
                        We focus on trust, convenience,
                        quality, customer care and responsible
                        healthcare service in everything we do.
                    </p>

                </div>

            </div>

        </div>

    </section>


    <!--
        Why Choose Us Section
        Displays the main features and benefits that make
        MediQuick Pharmacy convenient for customers.
    -->
    <section class="why-section">

        <div class="about-container">

            <!-- Section heading -->
            <div class="section-heading">

                <span class="section-label">
                    WHY MEDIQUICK?
                </span>

                <h2>
                    Why Choose MediQuick Pharmacy?
                </h2>

                <p>
                    We make your healthcare shopping
                    experience simple and convenient.
                </p>

            </div>


            <!--
                Feature Grid
                Contains individual cards describing
                important pharmacy platform features.
            -->
            <div class="why-grid">


                <!-- Wide product range -->
                <div class="why-card">

                    <div class="why-icon">
                        <i class="bi bi-capsule"></i>
                    </div>

                    <h3>
                        Wide Product Range
                    </h3>

                    <p>
                        Browse medicines, wellness,
                        personal care, medical devices
                        and baby care products in one place.
                    </p>

                </div>


                <!-- Prescription support -->
                <div class="why-card">

                    <div class="why-icon">
                        <i class="bi bi-file-medical"></i>
                    </div>

                    <h3>
                        Prescription Support
                    </h3>

                    <p>
                        Upload your prescription online
                        for a convenient way to manage
                        prescription medicine requests.
                    </p>

                </div>


                <!-- Easy ordering -->
                <div class="why-card">

                    <div class="why-icon">
                        <i class="bi bi-cart-check"></i>
                    </div>

                    <h3>
                        Easy Ordering
                    </h3>

                    <p>
                        Add products to your cart,
                        provide your delivery details
                        and complete your order easily.
                    </p>

                </div>


                <!-- Customer-focused service -->
                <div class="why-card">

                    <div class="why-icon">
                        <i class="bi bi-person-heart"></i>
                    </div>

                    <h3>
                        Customer Focused
                    </h3>

                    <p>
                        Our platform is designed around
                        making healthcare shopping easier
                        for customers and families.
                    </p>

                </div>

            </div>

        </div>

    </section>


    <!--
        Call To Action Section
        Provides direct links for customers to browse
        products or upload a prescription.
    -->
    <section class="about-cta">

        <div class="about-container">

            <div class="cta-content">

                <span class="section-label">
                    MEDIQUICK PHARMACY
                </span>

                <h2>
                    Take Care of Your Health With Us
                </h2>

                <p>
                    Explore our healthcare products and
                    enjoy a simple online pharmacy experience.
                </p>


                <!-- CTA navigation buttons -->
                <div class="cta-buttons">

                    <!-- Link to the product catalogue -->
                    <a
                        href="products.php"
                        class="cta-primary"
                    >

                        <i class="bi bi-cart3"></i>

                        Browse Products

                    </a>


                    <!-- Link to the customer prescription upload page -->
                    <a
                        href="prescription.php"
                        class="cta-secondary"
                    >

                        <i class="bi bi-file-medical"></i>

                        Upload Prescription

                    </a>

                </div>

            </div>

        </div>

    </section>

</section>


<style>

/*
    About Page
    Defines the main background colour for the complete
    About Us page.
*/
.about-page {
    background: #f6fbfd;
}


/*
    Container
    Keeps the page content within a fixed maximum width
    and provides horizontal spacing on smaller screens.
*/
.about-container {
    width: 100%;
    max-width: 1150px;
    margin: 0 auto;
    padding-left: 20px;
    padding-right: 20px;
}


/*
    Hero Section
    Creates the introductory banner at the top of the page.
*/
.about-hero {
    background:
        linear-gradient(
            135deg,
            #e9f8fb,
            #f6fbfd
        );

    padding: 75px 0;
    text-align: center;
    border-bottom: 1px solid #e2eef1;
}


.about-small-title {
    color: #087f9b;
    font-size: 12px;
    font-weight: 800;
    letter-spacing: 2px;
}


.about-hero h1 {
    color: #174f68;
    font-size: 42px;
    margin: 10px 0;
    font-weight: 700;
}


.about-hero p {
    color: #6f7f85;
    margin: 0 auto;
    max-width: 650px;
    line-height: 1.7;
}


/*
    General About Section
    Provides spacing around the main pharmacy introduction.
*/
.about-section {
    padding: 75px 0;
}


.about-intro {
    display: grid;
    grid-template-columns: 0.9fr 1.1fr;
    gap: 65px;
    align-items: center;
}


/*
    About Image
    Creates a card-style container for the pharmacy logo.
*/
.about-image-box {
    min-height: 370px;
    background: white;
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 40px;

    box-shadow:
        0 8px 30px
        rgba(0, 80, 110, 0.08);
}


.about-image-box img {
    width: 75%;
    max-width: 280px;
    height: auto;
    object-fit: contain;
}


/*
    Content Typography
    Defines the colours, sizes and spacing used
    throughout the About Us content.
*/
.section-label {
    color: #087f9b;
    font-size: 12px;
    font-weight: 800;
    letter-spacing: 2px;
}


.about-content h2 {
    color: #174f68;
    font-size: 34px;
    margin: 10px 0 20px;
}


.about-content p {
    color: #687980;
    line-height: 1.8;
    font-size: 15px;
    margin-bottom: 15px;
}


/*
    About Highlights
    Arranges the service benefit items vertically
    below the main pharmacy description.
*/
.about-highlights {
    margin-top: 25px;
    display: grid;
    gap: 14px;
}


.highlight-item {
    display: flex;
    align-items: center;
    gap: 13px;
}


.highlight-item > i {
    width: 42px;
    height: 42px;
    border-radius: 10px;
    background: #e8f7fa;
    color: #087f9b;

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 19px;
    flex-shrink: 0;
}


.highlight-item strong {
    display: block;
    color: #174f68;
    font-size: 14px;
}


.highlight-item span {
    display: block;
    color: #829197;
    font-size: 12px;
    margin-top: 2px;
}


/*
    Mission Section
    Provides a separate white background for the
    mission, vision and values cards.
*/
.mission-section {
    background: white;
    padding: 70px 0;
}


.mission-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 24px;
}


/*
    Mission Card
    Styles each mission, vision and values information card.
*/
.mission-card {
    background: #f8fcfd;
    border: 1px solid #e4eff2;
    border-radius: 16px;
    padding: 30px;
    text-align: center;
    transition: 0.2s;
}


/*
    Adds a small upward animation and shadow
    when the user moves the mouse over a card.
*/
.mission-card:hover {
    transform: translateY(-5px);

    box-shadow:
        0 10px 25px
        rgba(0, 80, 110, 0.08);
}


.mission-icon {
    width: 60px;
    height: 60px;
    margin: 0 auto 18px;
    border-radius: 50%;
    background: #e8f7fa;
    color: #087f9b;

    display: flex;
    align-items: center;
    justify-content: center;
}


.mission-icon i {
    font-size: 26px;
}


.mission-card h3 {
    color: #174f68;
    font-size: 20px;
    margin-bottom: 12px;
}


.mission-card p {
    color: #718087;
    font-size: 14px;
    line-height: 1.7;
    margin: 0;
}


/*
    Why Choose Us Section
    Provides spacing for the main feature section.
*/
.why-section {
    padding: 75px 0;
}


/*
    Section Heading
    Centers the heading and description above
    the feature cards.
*/
.section-heading {
    text-align: center;
    margin-bottom: 40px;
}


.section-heading h2 {
    color: #174f68;
    font-size: 32px;
    margin: 10px 0;
}


.section-heading p {
    color: #77858b;
    margin: 0;
}


/*
    Feature Grid
    Displays the four feature cards in a responsive grid.
*/
.why-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 20px;
}


/*
    Feature Card
    Styles each individual benefit provided by
    the MediQuick Pharmacy platform.
*/
.why-card {
    background: white;
    border-radius: 15px;
    padding: 25px;

    box-shadow:
        0 5px 20px
        rgba(0, 80, 110, 0.07);
}


.why-icon {
    width: 48px;
    height: 48px;
    border-radius: 10px;
    background: #e8f7fa;
    color: #087f9b;

    display: flex;
    align-items: center;
    justify-content: center;

    margin-bottom: 18px;
}


.why-icon i {
    font-size: 22px;
}


.why-card h3 {
    color: #174f68;
    font-size: 17px;
    margin-bottom: 10px;
}


.why-card p {
    color: #74838a;
    font-size: 13px;
    line-height: 1.7;
    margin: 0;
}


/*
    Call To Action Section
    Creates the final promotional section with
    navigation buttons for customers.
*/
.about-cta {
    background:
        linear-gradient(
            135deg,
            #087f9b,
            #056b83
        );

    padding: 65px 0;
}


.cta-content {
    text-align: center;
    color: white;
}


.cta-content .section-label {
    color: #d8f6fa;
}


.cta-content h2 {
    font-size: 32px;
    margin: 10px 0;
}


.cta-content p {
    color: #e1f3f5;
    max-width: 600px;
    margin: 0 auto 25px;
    line-height: 1.7;
}


/*
    CTA Buttons
    Arranges the product and prescription buttons
    horizontally and allows them to wrap on smaller screens.
*/
.cta-buttons {
    display: flex;
    justify-content: center;
    gap: 12px;
    flex-wrap: wrap;
}


.cta-primary,
.cta-secondary {
    display: inline-flex;
    align-items: center;
    gap: 8px;

    padding: 12px 20px;
    border-radius: 8px;

    text-decoration: none;
    font-weight: 700;

    transition: 0.2s;
}


.cta-primary {
    background: white;
    color: #087f9b;
}


.cta-primary:hover {
    background: #f0fafb;
    color: #056b83;
}


.cta-secondary {
    color: white;
    border: 1px solid rgba(255,255,255,0.7);
}


.cta-secondary:hover {
    background: rgba(255,255,255,0.12);
    color: white;
}


/*
    Responsive Design
    Changes the page layout for tablets and smaller screens
    so that the content remains readable and user-friendly.
*/
@media (max-width: 950px) {

    .about-intro {
        grid-template-columns: 1fr;
        gap: 40px;
    }

    .about-image-box {
        min-height: 300px;
    }

    .why-grid {
        grid-template-columns: repeat(2, 1fr);
    }

}


/*
    Tablet and Small Screen Layout
    Converts the mission cards into a single column
    and reduces heading sizes.
*/
@media (max-width: 750px) {

    .mission-grid {
        grid-template-columns: 1fr;
    }

    .about-hero {
        padding: 55px 0;
    }

    .about-hero h1 {
        font-size: 34px;
    }

    .about-content h2 {
        font-size: 29px;
    }

}


/*
    Mobile Layout
    Optimizes spacing, typography and buttons
    for small mobile device screens.
*/
@media (max-width: 550px) {

    .about-section,
    .why-section,
    .mission-section {
        padding: 50px 0;
    }

    .why-grid {
        grid-template-columns: 1fr;
    }

    .about-image-box {
        min-height: 240px;
        padding: 25px;
    }

    .about-image-box img {
        max-width: 220px;
    }

    .section-heading h2 {
        font-size: 27px;
    }

    .cta-content h2 {
        font-size: 27px;
    }

    .cta-buttons {
        flex-direction: column;
        align-items: stretch;
    }

    .cta-primary,
    .cta-secondary {
        justify-content: center;
    }

}

</style>


<?php

/* Include the common website footer so the shared footer
   content is displayed at the bottom of the About Us page. */
include 'includes/footer.php';

?>