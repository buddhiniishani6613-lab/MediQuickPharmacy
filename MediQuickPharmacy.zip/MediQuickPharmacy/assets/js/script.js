document.addEventListener("DOMContentLoaded", function () {

    const searchInput = document.getElementById("productSearch");
    const categoryFilter = document.getElementById("categoryFilter");
    const sortProducts = document.getElementById("sortProducts");

    const productGrid = document.getElementById("productGrid");
    const noProducts = document.getElementById("noProducts");
    const productCount = document.getElementById("productCount");


    function filterProducts() {

        const searchValue =
            searchInput.value.toLowerCase().trim();

        const selectedCategory =
            categoryFilter.value;

        const products =
            Array.from(
                document.querySelectorAll(".product-item")
            );


        let visibleProducts = [];


        products.forEach(function (product) {

            const productName =
                product.dataset.name.toLowerCase();

            const productCategory =
                product.dataset.category;


            const matchesSearch =
                productName.includes(searchValue);

            const matchesCategory =
                selectedCategory === "all" ||
                productCategory === selectedCategory;


            if (matchesSearch && matchesCategory) {

                product.style.display = "";

                visibleProducts.push(product);

            } else {

                product.style.display = "none";

            }

        });


        productCount.textContent =
            visibleProducts.length;


        if (visibleProducts.length === 0) {

            noProducts.style.display = "block";

        } else {

            noProducts.style.display = "none";

        }

    }


    if (searchInput) {

        searchInput.addEventListener(
            "input",
            filterProducts
        );

    }


    if (categoryFilter) {

        categoryFilter.addEventListener(
            "change",
            filterProducts
        );

    }


    if (sortProducts) {

        sortProducts.addEventListener(
            "change",
            function () {

                const products =
                    Array.from(
                        document.querySelectorAll(".product-item")
                    );


                const sortValue =
                    sortProducts.value;


                if (sortValue === "low") {

                    products.sort(function (a, b) {

                        return (
                            Number(a.dataset.price) -
                            Number(b.dataset.price)
                        );

                    });

                }


                if (sortValue === "high") {

                    products.sort(function (a, b) {

                        return (
                            Number(b.dataset.price) -
                            Number(a.dataset.price)
                        );

                    });

                }


                if (sortValue === "name") {

                    products.sort(function (a, b) {

                        return a.dataset.name.localeCompare(
                            b.dataset.name
                        );

                    });

                }


                products.forEach(function (product) {

                    productGrid.appendChild(product);

                });


                filterProducts();

            }
        );

    }

});


/* =====================================================
   ADD TO CART
===================================================== */

function addToCart(productName, productPrice) {

    let cart =
        JSON.parse(
            localStorage.getItem("mediquickCart")
        ) || [];


    const existingProduct =
        cart.find(
            item => item.name === productName
        );


    if (existingProduct) {

        existingProduct.quantity++;

    } else {

        cart.push({

            name: productName,

            price: productPrice,

            quantity: 1

        });

    }


    localStorage.setItem(
        "mediquickCart",
        JSON.stringify(cart)
    );


    alert(
        productName +
        " has been added to your cart."
    );


    updateCartCount();

}


/* =====================================================
   CART COUNT
===================================================== */

function updateCartCount() {

    const cart =
        JSON.parse(
            localStorage.getItem("mediquickCart")
        ) || [];


    let totalQuantity = 0;


    cart.forEach(function (item) {

        totalQuantity += item.quantity;

    });


    const cartCount =
        document.querySelector(".cart-count");


    if (cartCount) {

        cartCount.textContent =
            totalQuantity;

    }

}


document.addEventListener(
    "DOMContentLoaded",
    updateCartCount
);