<?php

/* Include the database connection so product information
   can be retrieved from the MediQuick Pharmacy database. */
include 'config/database.php';

/* Include the common website header containing the
   navigation bar and other shared website elements. */
include 'includes/header.php';


/*
    Find Product Image From Image Folder

    This function searches for product images directly inside
    the assets/images/products/ folder and its sub-folders.

    The database image column is not used for displaying
    product images on the shopping cart.

    Example:
    Product: Baby Shampoo
    Image: assets/images/products/Baby Care/Baby Shampoo.jpg

    The function also supports slightly different product
    names and image filenames by using normalized matching.
*/


/*
    Normalize Image Name

    Converts a product name or image filename into a standard
    format so that different naming styles can be compared.

    The function:
    - Converts text to lowercase.
    - Removes image file extensions.
    - Replaces special characters with spaces.
    - Removes unnecessary spaces.
*/
function normalizeImageName($name)
{
    /* Convert the supplied name to lowercase and remove
       unnecessary spaces at the beginning and end. */
    $name = strtolower(trim($name));

    /* Remove common image file extensions. */
    $name = preg_replace(
        '/\.(jpg|jpeg|png|webp)$/i',
        '',
        $name
    );

    /* Replace special characters with spaces. */
    $name = preg_replace(
        '/[^a-z0-9]+/',
        ' ',
        $name
    );

    /* Replace multiple spaces with a single space. */
    $name = preg_replace(
        '/\s+/',
        ' ',
        $name
    );

    return trim($name);
}


/*
    Get Product Image From Folder

    Searches the complete product image directory,
    including all category sub-folders.

    The function returns a browser-friendly relative path
    when a matching image is found.
*/
function getProductImageFromFolder($productName)
{
    /*
        Define the main product image folder.

        Since cart.php is located in the project root,
        the correct server-side folder is:

        assets/images/products/
    */
    $baseFolder =
        __DIR__ .
        DIRECTORY_SEPARATOR .
        'assets' .
        DIRECTORY_SEPARATOR .
        'images' .
        DIRECTORY_SEPARATOR .
        'products';


    /* Check whether the product image directory exists. */
    if (!is_dir($baseFolder)) {
        return '';
    }


    /* Normalize the product name before comparing it
       with the available image filenames. */
    $normalizedProduct =
        normalizeImageName($productName);


    /*
        Search all files inside the product image directory
        and its category sub-folders.
    */
    try {

        $iterator =
            new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator(
                    $baseFolder,
                    FilesystemIterator::SKIP_DOTS
                )
            );

    }
    catch (Exception $e) {

        /* Return an empty path if the directory
           cannot be read safely. */
        return '';
    }


    /* Store the best possible matching image paths. */
    $exactMatch = '';
    $partialMatch = '';


    /*
        Loop through all files found inside the
        product image directory.
    */
    foreach ($iterator as $file) {

        /* Ignore folders and process only actual files. */
        if (!$file->isFile()) {
            continue;
        }


        /* Get the file extension and convert it to lowercase. */
        $extension =
            strtolower(
                $file->getExtension()
            );


        /* Only supported image file formats are considered. */
        if (
            !in_array(
                $extension,
                [
                    'jpg',
                    'jpeg',
                    'png',
                    'webp'
                ]
            )
        ) {
            continue;
        }


        /* Get the image filename without its extension. */
        $fileName =
            pathinfo(
                $file->getFilename(),
                PATHINFO_FILENAME
            );


        /* Normalize the image filename before comparison. */
        $normalizedFileName =
            normalizeImageName(
                $fileName
            );


        /*
            Exact Match

            If the normalized product name and image filename
            are exactly the same, this is considered the best
            possible match.
        */
        if (
            $normalizedFileName ===
            $normalizedProduct
        ) {

            $exactMatch =
                $file->getPathname();

            /* Stop searching because the exact image
               has already been found. */
            break;
        }


        /*
            Partial Match - Product Starts With Filename

            Example:

            Product:
            Salbutamol 2mg

            Image:
            Salbutamol.jpg
        */
        if (
            strpos(
                $normalizedProduct,
                $normalizedFileName
            ) === 0
        ) {

            if ($partialMatch === '') {

                $partialMatch =
                    $file->getPathname();
            }
        }


        /*
            Partial Match - Filename Starts With Product

            This supports situations where the image filename
            contains additional information after the product name.
        */
        if (
            strpos(
                $normalizedFileName,
                $normalizedProduct
            ) === 0
        ) {

            if ($partialMatch === '') {

                $partialMatch =
                    $file->getPathname();
            }
        }
    }


    /*
        Select the best matching image.

        An exact match has priority over a partial match.
    */
    $foundFile = '';

    if ($exactMatch !== '') {

        $foundFile =
            $exactMatch;

    }
    elseif ($partialMatch !== '') {

        $foundFile =
            $partialMatch;
    }


    /*
        Return an empty value when no matching image
        could be found.
    */
    if ($foundFile === '') {
        return '';
    }


    /*
        Convert the server-side file path into a path
        that can be used by the browser.

        The browser path starts from:
        assets/images/products/
    */
    $relativePath =
        str_replace(
            $baseFolder,
            '',
            $foundFile
        );


    /* Remove unnecessary leading slashes and convert
       Windows backslashes into browser-friendly slashes. */
    $relativePath =
        ltrim(
            str_replace(
                '\\',
                '/',
                $relativePath
            ),
            '/'
        );


    /*
        URL Encode Each Path Part

        Product folders and filenames may contain spaces.
        Each part is therefore encoded separately so that
        the browser can correctly load the image.
    */
    $parts =
        explode(
            '/',
            $relativePath
        );

    $encodedParts = [];

    foreach ($parts as $part) {

        $encodedParts[] =
            rawurlencode($part);
    }


    /*
        Return the final browser path.

        Example:
        assets/images/products/Baby%20Care/Baby%20Shampoo.jpg
    */
    return
        'assets/images/products/' .
        implode(
            '/',
            $encodedParts
        );
}


/*
    Get Available Products

    Retrieves all currently available products from the
    products table.

    Only products with the status "Available" are loaded
    into the cart data used by JavaScript.
*/
$productMap = [];

$sql = "
    SELECT
        id,
        name,
        category,
        price,
        stock_quantity,
        status
    FROM products
    WHERE status = 'Available'
    ORDER BY id ASC
";


/* Execute the product query. */
$result =
    $conn->query($sql);


/*
    Database Error Handling

    Stop the page and display the database error if
    the product query cannot be executed.
*/
if (!$result) {

    die(
        "Database query failed: " .
        htmlspecialchars(
            $conn->error
        )
    );
}


/*
    Build Product Map

    Creates an associative PHP array containing the
    available products.

    The product ID is used as the key so that JavaScript
    can quickly find product information when repairing
    or synchronizing the shopping cart.
*/
while (
    $row =
    $result->fetch_assoc()
) {

    $id =
        (int)$row['id'];

    $productName =
        $row['name'];


    /*
        Get the product image directly from the image folder.

        The database image column is intentionally not used.
    */
    $imagePath =
        getProductImageFromFolder(
            $productName
        );


    /* Store the product information for JavaScript. */
    $productMap[$id] = [

        'id' =>
            $id,

        'name' =>
            $productName,

        'category' =>
            $row['category'],

        'price' =>
            (float)$row['price'],

        'stock' =>
            (int)$row['stock_quantity'],

        'image' =>
            $imagePath
    ];
}

?>

<!--
    Cart Section

    Displays the complete shopping cart page including
    cart items, product quantities and order summary.
-->
<section class="cart-section">

    <div class="cart-container">

        <!--
            Cart Heading

            Displays the page title and a short description
            for the customer.
        -->
        <div class="cart-heading">

            <span>
                MEDIQUICK PHARMACY
            </span>

            <h1>
                Your Shopping Cart
            </h1>

            <p>
                Review your selected healthcare products.
            </p>

        </div>


        <!--
            Cart Layout

            Contains the main cart area and the order
            summary panel.
        -->
        <div class="cart-layout">


            <!--
                Cart Main

                Displays selected products and provides
                the option to clear the complete cart.
            -->
            <div class="cart-main">

                <div class="cart-top">

                    <h2>
                        Cart Items
                    </h2>


                    <!-- Button for removing all products -->
                    <button
                        type="button"
                        onclick="clearCart()"
                        class="clear-button"
                    >

                        <i class="bi bi-trash"></i>

                        Clear Cart

                    </button>

                </div>


                <!--
                    JavaScript dynamically inserts cart products
                    into this container.
                -->
                <div
                    id="cartItems"
                    class="cart-items"
                ></div>


                <!--
                    Empty Cart Message

                    This section is displayed when there are
                    no products stored in the customer's cart.
                -->
                <div
                    id="emptyCart"
                    class="empty-cart"
                >

                    <i class="bi bi-cart-x"></i>

                    <h2>
                        Your cart is empty
                    </h2>

                    <p>
                        Add some healthcare products
                        to continue shopping.
                    </p>


                    <!-- Link back to the product catalogue -->
                    <a
                        href="products.php"
                        class="shop-button"
                    >
                        Continue Shopping
                    </a>

                </div>

            </div>


            <!--
                Order Summary

                Displays the number of items, subtotal,
                delivery charge and final order total.
            -->
            <div class="summary-box">

                <h2>
                    Order Summary
                </h2>


                <!-- Total number of products -->
                <div class="summary-line">

                    <span>
                        Items
                    </span>

                    <span id="itemCount">
                        0
                    </span>

                </div>


                <!-- Product subtotal -->
                <div class="summary-line">

                    <span>
                        Subtotal
                    </span>

                    <span>
                        Rs.

                        <span id="subtotal">
                            0.00
                        </span>
                    </span>

                </div>


                <!-- Delivery charge -->
                <div class="summary-line">

                    <span>
                        Delivery
                    </span>

                    <span>
                        Rs.

                        <span id="delivery">
                            0.00
                        </span>
                    </span>

                </div>


                <hr>


                <!-- Final order total -->
                <div class="total-line">

                    <span>
                        Total
                    </span>

                    <strong>
                        Rs.

                        <span id="total">
                            0.00
                        </span>
                    </strong>

                </div>


                <!--
                    Checkout button

                    Sends the customer to the checkout page
                    after confirming that the cart contains items.
                -->
                <button
                    type="button"
                    class="checkout-button"
                    onclick="checkout()"
                >

                    Proceed to Checkout

                    <i class="bi bi-arrow-right"></i>

                </button>


                <!-- Return to the product catalogue -->
                <a
                    href="products.php"
                    class="back-products"
                >

                    <i class="bi bi-arrow-left"></i>

                    Continue Shopping

                </a>

            </div>

        </div>

    </div>

</section>


<style>

/*
    Cart Section

    Defines the main background, minimum height and
    spacing for the shopping cart page.
*/
.cart-section {

    background: #f6fbfd;

    min-height: 70vh;

    padding: 60px 20px;
}


.cart-container {

    max-width: 1200px;

    margin: auto;

}


/*
    Cart Heading

    Centers the shopping cart title and description.
*/
.cart-heading {

    text-align: center;

    margin-bottom: 45px;

}


.cart-heading span {

    color: #087f9b;

    font-size: 13px;

    font-weight: 700;

    letter-spacing: 2px;

}


.cart-heading h1 {

    color: #174f68;

    margin: 8px 0;

    font-size: 34px;

}


.cart-heading p {

    color: #777;

}


/*
    Cart Layout

    Creates two columns:
    - Main cart section
    - Order summary section
*/
.cart-layout {

    display: grid;

    grid-template-columns:
        1fr 350px;

    gap: 30px;

}


/*
    Cart Main

    Provides the white card containing the selected
    shopping cart products.
*/
.cart-main {

    background: white;

    border-radius: 16px;

    padding: 25px;

    box-shadow:
        0 5px 20px
        rgba(0,80,110,0.08);

}


.cart-top {

    display: flex;

    justify-content: space-between;

    align-items: center;

    padding-bottom: 18px;

    border-bottom:
        1px solid #e7eef1;

}


.cart-top h2 {

    color: #174f68;

    font-size: 22px;

    margin: 0;

}


/*
    Clear Cart Button

    Allows the customer to remove all products
    from the shopping cart.
*/
.clear-button {

    border: none;

    background: none;

    color: #dc3545;

    cursor: pointer;

    font-weight: 600;

}


.clear-button:hover {

    color: #a71d2a;

}


/*
    Cart Item

    Defines the layout for each individual product
    displayed inside the shopping cart.
*/
.cart-item {

    display: flex;

    align-items: center;

    gap: 20px;

    padding: 20px 0;

    border-bottom:
        1px solid #edf1f3;

}


/*
    Cart Image Box

    Creates a fixed-size container for each product image.
*/
.cart-image-box {

    width: 105px;

    height: 105px;

    min-width: 105px;

    background: #f5fafc;

    border-radius: 12px;

    display: flex;

    align-items: center;

    justify-content: center;

    overflow: hidden;

}


/*
    Product Image

    Keeps product images contained inside the image box
    without distorting their original proportions.
*/
.cart-image {

    width: 100%;

    height: 100%;

    object-fit: contain;

    padding: 8px;

    display: block;

}


/*
    Image Not Available

    Displays a simple message when a product image
    cannot be found.
*/
.image-not-available {

    color: #9aaeb5;

    font-size: 12px;

    text-align: center;

    padding: 10px;

}


/*
    Product Details

    Displays the product name, price and available stock.
*/
.cart-details {

    flex: 1;

}


.cart-details h3 {

    color: #174f68;

    font-size: 17px;

    margin:
        0 0 6px;

}


.cart-details p {

    color: #777;

    font-size: 14px;

    margin:
        0 0 7px;

}


.cart-stock {

    color: #16834b;

    font-size: 12px;

    font-weight: 700;

}


/*
    Quantity Control

    Provides plus and minus buttons for changing
    the quantity of a selected product.
*/
.quantity-control {

    display: flex;

    align-items: center;

    border:
        1px solid #d8e5e9;

    border-radius: 8px;

    overflow: hidden;

}


.quantity-control button {

    width: 35px;

    height: 35px;

    border: none;

    background: #eef8fb;

    color: #087f9b;

    font-size: 18px;

    cursor: pointer;

}


.quantity-control button:hover {

    background: #dff3f7;

}


.quantity-control button:disabled {

    color: #aaa;

    cursor: not-allowed;

}


.quantity-control span {

    width: 38px;

    text-align: center;

    font-weight: 600;

}


/*
    Item Total

    Displays the calculated total price for
    an individual cart item.
*/
.item-total {

    color: #087f9b;

    font-weight: 700;

    min-width: 95px;

    text-align: right;

}


/*
    Remove Button

    Allows the customer to remove one selected
    product from the cart.
*/
.remove-button {

    border: none;

    background: transparent;

    color: #dc3545;

    font-size: 18px;

    cursor: pointer;

}


.remove-button:hover {

    color: #a71d2a;

}


/*
    Summary Box

    Displays the complete order calculation
    inside a separate white card.
*/
.summary-box {

    background: white;

    border-radius: 16px;

    padding: 25px;

    height: fit-content;

    box-shadow:
        0 5px 20px
        rgba(0,80,110,0.08);

}


.summary-box h2 {

    color: #174f68;

    font-size: 22px;

    margin-bottom: 25px;

}


.summary-line {

    display: flex;

    justify-content: space-between;

    margin-bottom: 16px;

    color: #555;

}


.summary-box hr {

    border: none;

    border-top:
        1px solid #e5edef;

}


/*
    Total Line

    Highlights the final amount that the customer
    needs to pay.
*/
.total-line {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin: 20px 0;

}


.total-line span {

    font-size: 18px;

    font-weight: 600;

}


.total-line strong {

    color: #087f9b;

    font-size: 21px;

}


/*
    Checkout Button

    Provides the main action for proceeding
    from the cart to checkout.
*/
.checkout-button {

    width: 100%;

    padding: 14px;

    border: none;

    border-radius: 9px;

    background: #087f9b;

    color: white;

    font-weight: 600;

    cursor: pointer;

    font-size: 15px;

}


.checkout-button:hover {

    background: #056b83;

}


.back-products {

    display: block;

    text-align: center;

    margin-top: 18px;

    color: #087f9b;

    text-decoration: none;

    font-weight: 600;

}


/*
    Empty Cart

    Centers the message and icon displayed when
    there are no products in the shopping cart.
*/
.empty-cart {

    text-align: center;

    padding: 70px 20px;

}


.empty-cart i {

    font-size: 60px;

    color: #8bbbc7;

}


.empty-cart h2 {

    color: #174f68;

}


.empty-cart p {

    color: #777;

}


/*
    Continue Shopping Button

    Allows customers to return to the product catalogue
    when the cart is empty.
*/
.shop-button {

    display: inline-block;

    margin-top: 15px;

    background: #087f9b;

    color: white;

    padding: 12px 22px;

    border-radius: 8px;

    text-decoration: none;

    font-weight: 600;

}


/*
    Tablet Responsive Layout

    Changes the cart and summary from two columns
    to one column on smaller screens.
*/
@media (max-width: 850px) {

    .cart-layout {

        grid-template-columns: 1fr;

    }

}


/*
    Mobile Responsive Layout

    Allows cart item elements to wrap when the
    available screen width is limited.
*/
@media (max-width: 650px) {

    .cart-item {

        flex-wrap: wrap;

    }


    .cart-details {

        min-width: 180px;

    }


    .item-total {

        text-align: left;

    }

}

</style>


<script>

/*
    Database Products

    Converts the PHP product map into a JavaScript object.

    This allows the cart system to compare localStorage
    cart data with the latest product information from
    the database.
*/
const databaseProducts =
<?php

echo json_encode(
    $productMap,
    JSON_UNESCAPED_SLASHES |
    JSON_UNESCAPED_UNICODE
);

?>;


/*
    Get Cart

    Reads the customer's cart from browser localStorage.

    The function safely handles missing or invalid
    localStorage data.
*/
function getCart()
{
    try {

        const storedCart =
            localStorage.getItem(
                "mediquickCart"
            );


        /* Return an empty cart when no data is stored. */
        if (!storedCart) {

            return [];

        }


        /* Convert the stored JSON data into a JavaScript array. */
        const cart =
            JSON.parse(
                storedCart
            );


        /* Make sure the returned value is actually an array. */
        return Array.isArray(cart)
            ? cart
            : [];

    }
    catch (error) {

        /* Log the error and return an empty cart
           if the stored data cannot be read. */
        console.error(
            "Cart loading error:",
            error
        );

        return [];
    }
}


/*
    Repair / Sync Cart

    Synchronizes the customer's localStorage cart
    with the latest database product information.

    This prevents outdated product names, prices, images
    and stock quantities from remaining in the cart.
*/
function repairCart()
{
    let cart =
        getCart();

    let changed =
        false;


    cart.forEach(
        function(item)
        {

            /*
                Get Product ID

                Supports both the current product_id field
                and older cart data that may use the id field.
            */
            const productId =
                Number(
                    item.product_id ||
                    item.id
                );


            /*
                Find Product By ID

                If the product exists in the latest database
                product map, synchronize its information.
            */
            if (
                productId &&
                databaseProducts[productId]
            ) {

                const product =
                    databaseProducts[
                        productId
                    ];


                /*
                    Synchronize product information
                    with the current database values.
                */
                item.product_id =
                    product.id;

                item.name =
                    product.name;

                item.price =
                    product.price;

                item.stock =
                    product.stock;


                /*
                    Product Image

                    Always use the image path generated by PHP
                    from the current assets/images/products folder.

                    Old localStorage image values are ignored.
                */
                item.image =
                    product.image;


                /*
                    Get and validate the current quantity.
                */
                let quantity =
                    Number(
                        item.quantity
                    ) || 1;


                /*
                    Remove the quantity when there is
                    no remaining stock.
                */
                if (
                    product.stock <= 0
                ) {

                    quantity = 0;

                }


                /*
                    Prevent the cart quantity from being
                    greater than the available database stock.
                */
                else if (
                    quantity >
                    product.stock
                ) {

                    quantity =
                        product.stock;

                }


                item.quantity =
                    quantity;

                changed =
                    true;

                return;
            }


            /*
                Old Cart Without ID

                Attempts to identify old cart products
                by comparing their product names.
            */
            const productIdByName =
                Object.keys(
                    databaseProducts
                ).find(
                    function(key)
                    {

                        const databaseName =
                            String(
                                databaseProducts[
                                    key
                                ].name
                            )
                            .trim()
                            .toLowerCase();


                        const cartName =
                            String(
                                item.name ||
                                ""
                            )
                            .trim()
                            .toLowerCase();


                        return (
                            databaseName ===
                            cartName
                        );
                    }
                );


            /*
                Product Found By Name

                Updates the old cart item using
                the latest database product details.
            */
            if (
                productIdByName
            ) {

                const product =
                    databaseProducts[
                        productIdByName
                    ];


                item.product_id =
                    product.id;

                item.name =
                    product.name;

                item.price =
                    product.price;

                item.stock =
                    product.stock;


                /* Get the current product image from PHP. */
                item.image =
                    product.image;


                /* Read and validate the stored quantity. */
                let quantity =
                    Number(
                        item.quantity
                    ) || 1;


                /* Remove the quantity when the product is out of stock. */
                if (
                    product.stock <= 0
                ) {

                    quantity = 0;

                }

                /* Limit quantity according to current stock. */
                else if (
                    quantity >
                    product.stock
                ) {

                    quantity =
                        product.stock;

                }


                item.quantity =
                    quantity;

                changed =
                    true;
            }
        }
    );


    /*
        Remove Invalid Products

        Products with zero quantity are removed from
        the customer's localStorage cart.
    */
    cart =
        cart.filter(
            function(item)
            {

                return (
                    Number(
                        item.quantity
                    ) > 0
                );

            }
        );


    /*
        Save Repaired Cart

        Save the synchronized cart back to localStorage
        only when changes have been made.
    */
    if (changed) {

        localStorage.setItem(
            "mediquickCart",
            JSON.stringify(
                cart
            )
        );

    }


    return cart;
}


/*
    Display Cart

    Builds the visible cart interface using the latest
    synchronized cart data.
*/
function displayCart()
{
    const cart =
        repairCart();


    const cartItems =
        document.getElementById(
            "cartItems"
        );


    const emptyCart =
        document.getElementById(
            "emptyCart"
        );


    /*
        Empty Cart

        Displays the empty-cart message when no valid
        products are available.
    */
    if (
        cart.length === 0
    ) {

        cartItems.innerHTML =
            "";

        emptyCart.style.display =
            "block";

        updateSummary();

        return;
    }


    /* Hide the empty-cart message when products exist. */
    emptyCart.style.display =
        "none";


    /* Clear the previous cart HTML before rebuilding it. */
    cartItems.innerHTML =
        "";


    /*
        Display Products

        Creates one cart item element for every product
        stored in the customer's cart.
    */
    cart.forEach(
        function(item, index)
        {

            const quantity =
                Number(
                    item.quantity
                ) || 1;


            const price =
                Number(
                    item.price
                ) || 0;


            const stock =
                Number(
                    item.stock
                ) || 0;


            /* Calculate the total price for this product. */
            const itemTotal =
                price *
                quantity;


            /* Create a new HTML container for the cart item. */
            const cartItem =
                document.createElement(
                    "div"
                );


            cartItem.className =
                "cart-item";


            /*
                Image Path

                Gets the product image path synchronized
                from the PHP-generated product map.
            */
            let imagePath =
                String(
                    item.image || ""
                ).trim();


            /* Remove ./ when it exists at the beginning of the path. */
            if (
                imagePath.startsWith("./")
            ) {

                imagePath =
                    imagePath.substring(2);

            }


            /*
                The PHP function already URL-encodes image
                folder and file names.

                Therefore encodeURI() must not be called again.
            */
            const safeName =
                escapeHtml(
                    item.name ||
                    ""
                );


            /*
                Image HTML

                Creates the image element when a valid
                product image path is available.
            */
            let imageHTML = "";


            if (
                imagePath !== ""
            ) {

                imageHTML = `

                    <img
                        src="${imagePath}"
                        alt="${safeName}"
                        class="cart-image"
                        onerror="
                            this.style.display='none';
                            this.nextElementSibling.style.display='block';
                        "
                    >

                    <div
                        class="image-not-available"
                        style="display:none;"
                    >
                        Image not available
                    </div>

                `;

            }
            else {

                /* Display a fallback message when no image
                   path was found by the PHP image search. */
                imageHTML = `

                    <div
                        class="image-not-available"
                    >
                        Image not available
                    </div>

                `;
            }


            /*
                Cart HTML

                Builds the complete visual structure of
                each product inside the shopping cart.
            */
            cartItem.innerHTML = `

                <div class="cart-image-box">

                    ${imageHTML}

                </div>


                <div class="cart-details">

                    <h3>
                        ${safeName}
                    </h3>

                    <p>
                        Rs.
                        ${price.toFixed(2)}
                        each
                    </p>

                    <div class="cart-stock">
                        ${stock}
                        in stock
                    </div>

                </div>


                <div class="quantity-control">

                    <button
                        type="button"
                        onclick="
                            decreaseQuantity(${index})
                        "
                    >
                        −
                    </button>


                    <span>
                        ${quantity}
                    </span>


                    <button
                        type="button"
                        ${
                            quantity >= stock
                                ? "disabled"
                                : ""
                        }
                        onclick="
                            increaseQuantity(${index})
                        "
                    >
                        +
                    </button>

                </div>


                <div class="item-total">

                    Rs.
                    ${itemTotal.toFixed(2)}

                </div>


                <button
                    type="button"
                    class="remove-button"
                    onclick="
                        removeItem(${index})
                    "
                >

                    <i class="bi bi-trash"></i>

                </button>

            `;


            /* Add the newly created cart item to the page. */
            cartItems.appendChild(
                cartItem
            );

        }
    );


    /* Refresh the order summary after displaying the products. */
    updateSummary();
}


/*
    Escape HTML

    Converts special HTML characters into safe HTML entities
    before product names are inserted into dynamically
    generated HTML.
*/
function escapeHtml(text)
{
    const div =
        document.createElement(
            "div"
        );


    div.textContent =
        text;


    return div.innerHTML;
}


/*
    Increase Quantity

    Increases the selected product quantity by one,
    provided that the available stock limit has not
    been reached.
*/
function increaseQuantity(index)
{
    let cart =
        repairCart();


    /* Stop if the requested cart item does not exist. */
    if (!cart[index]) {
        return;
    }


    const stock =
        Number(
            cart[index].stock
        ) || 0;


    const current =
        Number(
            cart[index].quantity
        ) || 0;


    /*
        Prevent customers from adding more products
        than the available database stock.
    */
    if (
        current >= stock
    ) {

        alert(
            "You cannot add more than the available stock."
        );

        return;
    }


    /* Increase the selected product quantity. */
    cart[index].quantity =
        current + 1;


    /* Save the updated cart. */
    localStorage.setItem(
        "mediquickCart",
        JSON.stringify(
            cart
        )
    );


    /* Refresh the cart display. */
    displayCart();
}


/*
    Decrease Quantity

    Reduces the selected product quantity by one.

    When the quantity reaches one and the customer
    decreases it again, the item is removed.
*/
function decreaseQuantity(index)
{
    let cart =
        repairCart();


    if (!cart[index]) {
        return;
    }


    const quantity =
        Number(
            cart[index].quantity
        ) || 1;


    if (
        quantity > 1
    ) {

        /* Reduce the quantity by one. */
        cart[index].quantity =
            quantity - 1;

    }
    else {

        /* Remove the product completely when
           the quantity reaches zero. */
        cart.splice(
            index,
            1
        );
    }


    /* Save the modified cart. */
    localStorage.setItem(
        "mediquickCart",
        JSON.stringify(
            cart
        )
    );


    /* Refresh the cart interface. */
    displayCart();
}


/*
    Remove Item

    Removes one selected product from the shopping cart.
*/
function removeItem(index)
{
    let cart =
        repairCart();


    if (!cart[index]) {
        return;
    }


    /* Remove the selected product from the array. */
    cart.splice(
        index,
        1
    );


    /* Save the updated cart in localStorage. */
    localStorage.setItem(
        "mediquickCart",
        JSON.stringify(
            cart
        )
    );


    /* Refresh the cart display and totals. */
    displayCart();
}


/*
    Clear Cart

    Removes all products from the shopping cart
    after receiving confirmation from the customer.
*/
function clearCart()
{
    const cart =
        getCart();


    /* Do nothing when the cart is already empty. */
    if (
        cart.length === 0
    ) {

        return;
    }


    /*
        Ask the customer for confirmation before
        permanently clearing the browser cart.
    */
    if (
        confirm(
            "Are you sure you want to clear your cart?"
        )
    ) {

        localStorage.removeItem(
            "mediquickCart"
        );


        /* Refresh the cart after removing all items. */
        displayCart();
    }
}


/*
    Update Summary

    Calculates:
    - Total item quantity
    - Product subtotal
    - Delivery charge
    - Final total

    The values are then displayed in the order
    summary section.
*/
function updateSummary()
{
    const cart =
        repairCart();


    let itemCount =
        0;


    let subtotal =
        0;


    /*
        Calculate the quantity and subtotal
        for all cart products.
    */
    cart.forEach(
        function(item)
        {

            const quantity =
                Number(
                    item.quantity
                ) || 0;


            const price =
                Number(
                    item.price
                ) || 0;


            itemCount +=
                quantity;


            subtotal +=
                price *
                quantity;

        }
    );


    /*
        Delivery Charge

        A delivery fee of Rs. 350 is applied when
        the cart contains products.
    */
    const delivery =
        subtotal > 0
            ? 350
            : 0;


    /* Calculate the final order amount. */
    const total =
        subtotal +
        delivery;


    /* Update the item count displayed to the customer. */
    document.getElementById(
        "itemCount"
    ).textContent =
        itemCount;


    /* Update the subtotal. */
    document.getElementById(
        "subtotal"
    ).textContent =
        subtotal.toFixed(2);


    /* Update the delivery charge. */
    document.getElementById(
        "delivery"
    ).textContent =
        delivery.toFixed(2);


    /* Update the final order total. */
    document.getElementById(
        "total"
    ).textContent =
        total.toFixed(2);
}


/*
    Checkout

    Checks whether the cart contains products before
    redirecting the customer to the checkout page.
*/
function checkout()
{
    const cart =
        repairCart();


    /* Prevent checkout when there are no products. */
    if (
        cart.length === 0
    ) {

        alert(
            "Please add products to your cart first."
        );

        return;
    }


    /* Navigate to the checkout page in the project root. */
    window.location.href =
        "Customer/checkout.php";
}


/*
    Page Load

    Loads and displays the shopping cart after
    the HTML document has finished loading.
*/
document.addEventListener(
    "DOMContentLoaded",
    function()
    {

        displayCart();

    }
);

</script>


<?php

/* Include the common website footer so the shared
   footer content is displayed at the bottom of the page. */
include 'includes/footer.php';

?>