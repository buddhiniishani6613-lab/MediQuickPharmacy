<?php

/*
 * Database server configuration.
 * These variables contain the details required
 * to connect the PHP application with MySQL.
 */
$host = "localhost";
$username = "root";
$password = "";
$database = "MediQuickPharmacy";


/*
 * Create a new MySQLi database connection.
 *
 * The connection uses the server address,
 * username, password and database name defined above.
 */
$conn = new mysqli(
    $host,
    $username,
    $password,
    $database
);


/*
 * Check whether the database connection was successful.
 *
 * If the connection fails, the application stops
 * and displays the connection error.
 */
if ($conn->connect_error) {

    die(
        "Database connection failed: " .
        $conn->connect_error
    );

}


/*
 * Set the database character encoding to UTF-8.
 *
 * utf8mb4 supports a wide range of characters
 * and helps store text correctly in the database.
 */
$conn->set_charset("utf8mb4");

?>