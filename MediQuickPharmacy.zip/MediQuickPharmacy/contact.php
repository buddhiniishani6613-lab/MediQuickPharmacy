<?php

// Load the common website header.
include 'includes/header.php';

?>

<section class="contact-section">

    <div class="contact-container">

        <!-- Page heading -->
        <div class="contact-heading">

            <span class="small-title">
                MEDIQUICK PHARMACY
            </span>

            <h1>Contact Us</h1>

            <p>
                We are here to help you with your healthcare needs.
                Get in touch with MediQuick Pharmacy today.
            </p>

        </div>

        <!-- Main contact content -->
        <div class="contact-layout">

            <!-- Contact information card -->
            <div class="contact-info-card">

                <h2>
                    <i class="bi bi-headset"></i>
                    Get In Touch
                </h2>

                <p class="contact-intro">
                    If you have any questions about our products,
                    prescriptions, orders or pharmacy services,
                    feel free to contact us.
                </p>

                <!-- Phone information -->
                <div class="contact-info-item">

                    <div class="contact-icon">
                        <i class="bi bi-telephone-fill"></i>
                    </div>

                    <div>

                        <h3>Phone</h3>

                        <p>
                            +94 11 234 5678
                        </p>

                        <span>
                            Available 24/7
                        </span>

                    </div>

                </div>

                <!-- Email information -->
                <div class="contact-info-item">

                    <div class="contact-icon">
                        <i class="bi bi-envelope-fill"></i>
                    </div>

                    <div>

                        <h3>Email</h3>

                        <p>
                            info@mediquickpharmacy.com
                        </p>

                        <span>
                            We reply as soon as possible
                        </span>

                    </div>

                </div>

                <!-- Address information -->
                <div class="contact-info-item">

                    <div class="contact-icon">
                        <i class="bi bi-geo-alt-fill"></i>
                    </div>

                    <div>

                        <h3>Address</h3>

                        <p>
                            No. 25, Main Street,
                            Colombo, Sri Lanka
                        </p>

                        <span>
                            Visit our pharmacy
                        </span>

                    </div>

                </div>

                <!-- Opening hours -->
                <div class="contact-info-item">

                    <div class="contact-icon">
                        <i class="bi bi-clock-fill"></i>
                    </div>

                    <div>

                        <h3>Opening Hours</h3>

                        <p>
                            Open 24 Hours
                        </p>

                        <span>
                            Monday - Sunday
                        </span>

                    </div>

                </div>

            </div>

            <!-- Contact form card -->
            <div class="contact-form-card">

                <h2>
                    <i class="bi bi-chat-dots"></i>
                    Send Us a Message
                </h2>

                <p class="form-intro">
                    Fill in the form below and our team will
                    get back to you shortly.
                </p>

                <form id="contactForm">

                    <!-- Full name -->
                    <div class="form-group">

                        <label for="contactName">
                            Full Name
                        </label>

                        <div class="input-wrapper">

                            <i class="bi bi-person"></i>

                            <input
                                type="text"
                                id="contactName"
                                name="name"
                                placeholder="Enter your full name"
                                required
                            >

                        </div>

                    </div>

                    <!-- Email address -->
                    <div class="form-group">

                        <label for="contactEmail">
                            Email Address
                        </label>

                        <div class="input-wrapper">

                            <i class="bi bi-envelope"></i>

                            <input
                                type="email"
                                id="contactEmail"
                                name="email"
                                placeholder="Enter your email address"
                                required
                            >

                        </div>

                    </div>

                    <!-- Phone number -->
                    <div class="form-group">

                        <label for="contactPhone">
                            Phone Number
                        </label>

                        <div class="input-wrapper">

                            <i class="bi bi-telephone"></i>

                            <input
                                type="tel"
                                id="contactPhone"
                                name="phone"
                                placeholder="Enter your phone number"
                                required
                            >

                        </div>

                    </div>

                    <!-- Message subject -->
                    <div class="form-group">

                        <label for="contactSubject">
                            Subject
                        </label>

                        <div class="input-wrapper">

                            <i class="bi bi-chat-left-text"></i>

                            <input
                                type="text"
                                id="contactSubject"
                                name="subject"
                                placeholder="Enter message subject"
                                required
                            >

                        </div>

                    </div>

                    <!-- Message -->
                    <div class="form-group">

                        <label for="contactMessage">
                            Message
                        </label>

                        <div class="textarea-wrapper">

                            <i class="bi bi-pencil-square"></i>

                            <textarea
                                id="contactMessage"
                                name="message"
                                rows="5"
                                placeholder="Write your message here..."
                                required
                            ></textarea>

                        </div>

                    </div>

                    <!-- Submit button -->
                    <button
                        type="submit"
                        class="contact-submit-button"
                    >

                        <i class="bi bi-send"></i>

                        Send Message

                    </button>

                </form>

            </div>

        </div>

        <!-- Quick help section -->
        <div class="quick-help">

            <div>

                <i class="bi bi-question-circle"></i>

                <div>

                    <h3>Need Quick Assistance?</h3>

                    <p>
                        For urgent pharmacy inquiries,
                        please call our hotline directly.
                    </p>

                </div>

            </div>

            <a href="tel:+94112345678">

                <i class="bi bi-telephone"></i>

                Call Now

            </a>

        </div>

    </div>

</section>

<style>

/* Contact page main section */
.contact-section {

    min-height: 80vh;

    background: #f6fbfd;

    padding: 65px 20px;

}

/* Main content container */
.contact-container {

    max-width: 1100px;

    margin: auto;

}

/* Page heading */
.contact-heading {

    text-align: center;

    margin-bottom: 45px;

}

/* Small heading above the page title */
.small-title {

    color: #087f9b;

    font-size: 13px;

    font-weight: 700;

    letter-spacing: 2px;

}

/* Main page title */
.contact-heading h1 {

    color: #174f68;

    font-size: 36px;

    margin: 8px 0 10px;

}

/* Page introduction */
.contact-heading p {

    color: #777;

    max-width: 650px;

    margin: auto;

    line-height: 1.7;

}

/* Contact information and form layout */
.contact-layout {

    display: grid;

    grid-template-columns:
        0.9fr 1.1fr;

    gap: 25px;

}

/* Contact cards */
.contact-info-card,
.contact-form-card {

    background: white;

    border-radius: 16px;

    padding: 30px;

    box-shadow:
        0 5px 25px
        rgba(0, 80, 110, 0.08);

}

/* Card headings */
.contact-info-card h2,
.contact-form-card h2 {

    color: #174f68;

    font-size: 21px;

    margin: 0 0 10px;

    display: flex;

    align-items: center;

    gap: 9px;

}

/* Card heading icons */
.contact-info-card h2 i,
.contact-form-card h2 i {

    color: #087f9b;

}

/* Card introduction text */
.contact-intro,
.form-intro {

    color: #777;

    font-size: 14px;

    line-height: 1.7;

    margin-bottom: 25px;

}

/* Individual contact information item */
.contact-info-item {

    display: flex;

    gap: 15px;

    padding: 17px 0;

    border-bottom:
        1px solid #edf2f4;

}

/* Remove border from the last contact item */
.contact-info-item:last-child {

    border-bottom: none;

}

/* Contact information icon container */
.contact-icon {

    width: 45px;

    height: 45px;

    min-width: 45px;

    border-radius: 10px;

    background: #e8f7fa;

    display: flex;

    align-items: center;

    justify-content: center;

}

/* Contact information icons */
.contact-icon i {

    color: #087f9b;

    font-size: 19px;

}

/* Contact information item title */
.contact-info-item h3 {

    color: #174f68;

    font-size: 15px;

    margin: 0 0 4px;

}

/* Contact information item text */
.contact-info-item p {

    color: #555;

    font-size: 14px;

    margin: 0 0 3px;

}

/* Contact information secondary text */
.contact-info-item span {

    color: #999;

    font-size: 12px;

}

/* Form group */
.form-group {

    margin-bottom: 17px;

}

/* Form labels */
.form-group label {

    display: block;

    color: #174f68;

    font-size: 14px;

    font-weight: 600;

    margin-bottom: 7px;

}

/* Input wrapper */
.input-wrapper {

    position: relative;

}

/* Input icons */
.input-wrapper > i {

    position: absolute;

    left: 14px;

    top: 50%;

    transform: translateY(-50%);

    color: #087f9b;

    pointer-events: none;

}

/* Form input fields */
.input-wrapper input {

    width: 100%;

    box-sizing: border-box;

    padding: 12px 14px 12px 42px;

    border:
        1px solid #d8e5e9;

    border-radius: 8px;

    outline: none;

    font-family: inherit;

    font-size: 14px;

}

/* Input focus effect */
.input-wrapper input:focus {

    border-color: #087f9b;

    box-shadow:
        0 0 0 3px
        rgba(8, 127, 155, 0.08);

}

/* Textarea wrapper */
.textarea-wrapper {

    position: relative;

}

/* Textarea icon */
.textarea-wrapper > i {

    position: absolute;

    left: 14px;

    top: 14px;

    color: #087f9b;

}

/* Message textarea */
.textarea-wrapper textarea {

    width: 100%;

    box-sizing: border-box;

    padding: 12px 14px 12px 42px;

    border:
        1px solid #d8e5e9;

    border-radius: 8px;

    outline: none;

    resize: vertical;

    min-height: 120px;

    font-family: inherit;

    font-size: 14px;

}

/* Textarea focus effect */
.textarea-wrapper textarea:focus {

    border-color: #087f9b;

    box-shadow:
        0 0 0 3px
        rgba(8, 127, 155, 0.08);

}

/* Contact form submit button */
.contact-submit-button {

    width: 100%;

    border: none;

    background: #087f9b;

    color: white;

    padding: 13px;

    border-radius: 9px;

    font-size: 15px;

    font-weight: 700;

    cursor: pointer;

    transition: 0.2s;

}

/* Submit button hover effect */
.contact-submit-button:hover {

    background: #056b83;

    transform: translateY(-1px);

}

/* Quick assistance section */
.quick-help {

    margin-top: 25px;

    background: white;

    border-radius: 15px;

    padding: 20px 25px;

    box-shadow:
        0 5px 20px
        rgba(0, 80, 110, 0.07);

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 20px;

}

/* Quick assistance content */
.quick-help > div {

    display: flex;

    align-items: center;

    gap: 15px;

}

/* Quick assistance icon */
.quick-help > div > i {

    color: #087f9b;

    font-size: 32px;

}

/* Quick assistance title */
.quick-help h3 {

    color: #174f68;

    font-size: 17px;

    margin: 0 0 4px;

}

/* Quick assistance description */
.quick-help p {

    color: #777;

    font-size: 13px;

    margin: 0;

}

/* Call Now button */
.quick-help a {

    background: #087f9b;

    color: white;

    text-decoration: none;

    padding: 11px 20px;

    border-radius: 8px;

    font-weight: 600;

    white-space: nowrap;

}

/* Call Now hover effect */
.quick-help a:hover {

    background: #056b83;

}

/* Responsive layout for tablets */
@media (max-width: 800px) {

    .contact-layout {

        grid-template-columns: 1fr;

    }

}

/* Responsive layout for mobile devices */
@media (max-width: 600px) {

    .contact-section {

        padding: 45px 15px;

    }

    .contact-heading h1 {

        font-size: 29px;

    }

    .contact-info-card,
    .contact-form-card {

        padding: 22px;

    }

    .quick-help {

        flex-direction: column;

        align-items: flex-start;

    }

    .quick-help a {

        width: 100%;

        text-align: center;

    }

}

</style>

<script>

// Handle contact form submission after the page loads.
document.addEventListener(
    "DOMContentLoaded",
    function () {

        const contactForm =
            document.getElementById(
                "contactForm"
            );

        // Listen for the form submission.
        contactForm.addEventListener(
            "submit",
            function (event) {

                // Prevent the page from refreshing.
                event.preventDefault();

                // Get the user's name.
                const name =
                    document
                        .getElementById("contactName")
                        .value
                        .trim();

                // Get the user's email.
                const email =
                    document
                        .getElementById("contactEmail")
                        .value
                        .trim();

                // Get the user's phone number.
                const phone =
                    document
                        .getElementById("contactPhone")
                        .value
                        .trim();

                // Get the message subject.
                const subject =
                    document
                        .getElementById("contactSubject")
                        .value
                        .trim();

                // Get the user's message.
                const message =
                    document
                        .getElementById("contactMessage")
                        .value
                        .trim();

                // Validate all required fields.
                if (
                    !name ||
                    !email ||
                    !phone ||
                    !subject ||
                    !message
                ) {

                    alert(
                        "Please fill in all fields."
                    );

                    return;

                }

                // Get previously saved inquiries from localStorage.
                let inquiries = [];

                try {

                    inquiries =
                        JSON.parse(
                            localStorage.getItem(
                                "mediquickInquiries"
                            )
                        ) || [];

                } catch (error) {

                    // Use an empty array if saved data is invalid.
                    inquiries = [];

                }

                // Create a new inquiry object.
                const newInquiry = {

                    id:
                        "INQ" +
                        Date.now(),

                    name:
                        name,

                    email:
                        email,

                    phone:
                        phone,

                    subject:
                        subject,

                    message:
                        message,

                    date:
                        new Date().toLocaleString(),

                    status:
                        "New"

                };

                // Add the new inquiry to the existing inquiry list.
                inquiries.push(
                    newInquiry
                );

                // Save the updated inquiry list in localStorage.
                localStorage.setItem(
                    "mediquickInquiries",
                    JSON.stringify(
                        inquiries
                    )
                );

                // Show a success message to the customer.
                alert(
                    "Your message has been sent successfully. Thank you for contacting MediQuick Pharmacy!"
                );

                // Clear the form after successful submission.
                contactForm.reset();

            }
        );

    }
);

</script>

<?php

// Load the common website footer.
include 'includes/footer.php';

?>