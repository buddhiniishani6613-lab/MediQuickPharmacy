
<?php

// Calculate the correct project root path.
$scriptPath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$scriptDirectory = trim(dirname($scriptPath), '/');
$scriptFolder = $scriptDirectory === '' ? '' : basename($scriptDirectory);

$basePath = in_array($scriptFolder, ['Admin', 'Customer', 'Staff'], true)
    ? '../'
    : '';

?>

<style>

/* MediQuick footer theme */

:root {
    --mq-footer-bg: #005374;
    --mq-footer-blue: #00364b;
    --mq-footer-text: #d2dfed;
}

/* Main footer section */

.footer-section {
    width: 100%;
    padding: 65px 0 22px;
    background: var(--mq-footer-bg);
    color: var(--mq-footer-text);
    font-size: 15px;
}

.footer-section .container {
    max-width: 1320px;
}

/* Footer headings */

.footer-section h4,
.footer-section h5 {
    color: #ffffff;
    font-weight: 700;
    margin-bottom: 22px;
}

.footer-section .footer-brand {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 18px;
    font-size: 23px;
}

.footer-section .footer-brand i {
    color: #42a5ff;
    font-size: 30px;
}

/* Footer descriptions */

.footer-section p {
    color: var(--mq-footer-text);
    line-height: 1.8;
    margin-bottom: 13px;
}

/* Footer heading underline */

.footer-section h5 {
    position: relative;
    display: inline-block;
    padding-bottom: 10px;
    font-size: 18px;
}

.footer-section h5::after {
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    width: 38px;
    height: 3px;
    border-radius: 5px;
    background: var(--mq-footer-blue);
}

/* Footer navigation links */

.footer-section .footer-links {
    padding: 0;
    margin: 0;
    list-style: none;
}

.footer-section .footer-links li {
    margin-bottom: 13px;
    color: var(--mq-footer-text);
}

.footer-section .footer-links a {
    color: var(--mq-footer-text);
    text-decoration: none;
    transition: all 0.25s ease;
}

.footer-section .footer-links a:hover {
    color: #55adff;
    padding-left: 5px;
}

/* Contact information */

.footer-section .footer-contact {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    margin-bottom: 15px;
}

.footer-section .footer-contact i {
    color: #45a5ff;
    font-size: 19px;
    margin-top: 3px;
}

/* Footer divider */

.footer-section hr {
    margin: 35px 0 20px;
    border: 0;
    border-top: 1px solid rgba(255, 255, 255, 0.18);
    opacity: 1;
}

/* Copyright section */

.footer-section .copyright {
    color: #b8cce0;
    font-size: 14px;
    text-align: center;
}

.footer-section .copyright span {
    color: #55adff;
    font-weight: 600;
}

/* Tablet responsive design */

@media (max-width: 991px) {

    .footer-section {
        padding: 50px 0 20px;
    }

}

/* Mobile responsive design */

@media (max-width: 576px) {

    .footer-section {
        padding: 40px 0 20px;
        font-size: 14px;
    }

    .footer-section .footer-brand {
        font-size: 21px;
    }

    .footer-section h5 {
        margin-bottom: 17px;
    }

}

</style>


<?php

// Display the MediQuick Pharmacy footer.

?>

<footer class="footer-section">

    <div class="container">

        <div class="row g-4">

            <div class="col-lg-4 col-md-6">

                <h4 class="footer-brand">
                    <i class="bi bi-plus-circle-fill"></i>
                    MediQuick Pharmacy
                </h4>

                <p>
                    Your trusted online pharmacy providing
                    genuine medicines and healthcare products
                    with convenient and reliable delivery.
                </p>

            </div>


            <div class="col-lg-2 col-md-6">

                <h5>Quick Links</h5>

                <ul class="footer-links">

                    <li>
                        <a href="<?php echo $basePath; ?>index.php">
                            Home
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo $basePath; ?>products.php">
                            Products
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo $basePath; ?>prescription.php">
                            Prescription
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo $basePath; ?>about.php">
                            About Us
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo $basePath; ?>contact.php">
                            Contact
                        </a>
                    </li>

                </ul>

            </div>


            <div class="col-lg-3 col-md-6">

                <h5>Customer Service</h5>

                <ul class="footer-links">

                    <li>
                        <a href="<?php echo $basePath; ?>Customer/help.php">
                            Help Centre
                        </a>
                    </li>

                    <li>
                        Delivery Information
                    </li>

                    <li>
                        Privacy Policy
                    </li>

                    <li>
                        Terms & Conditions
                    </li>

                </ul>

            </div>


            <div class="col-lg-3 col-md-6" id="contact">

                <h5>Contact Us</h5>

                <div class="footer-contact">

                    <i class="bi bi-telephone"></i>

                    <p>+94 11 234 5678</p>

                </div>

                <div class="footer-contact">

                    <i class="bi bi-envelope"></i>

                    <p>support@mediquick.com</p>

                </div>

                <div class="footer-contact">

                    <i class="bi bi-geo-alt"></i>

                    <p>Colombo, Sri Lanka</p>

                </div>

                <div class="footer-contact">

                    <i class="bi bi-clock"></i>

                    <p>Open 24/7</p>

                </div>

            </div>

        </div>


        <hr>


        <div class="copyright">

            © 2026 <span>MediQuick Pharmacy.</span>
            All Rights Reserved.

        </div>

    </div>

</footer>


<?php

// Load the custom website JavaScript file.

?>

<script src="<?php echo $basePath; ?>assets/js/script.js"></script>

</body>

</html>
