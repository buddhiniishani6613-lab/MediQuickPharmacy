<?php

// Start the session if it has not already been started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get the current script path and directory
$scriptPath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$scriptDirectory = trim(dirname($scriptPath), '/');
$scriptFolder = basename($scriptDirectory);

// Set the base path according to the current folder
$basePath = in_array($scriptFolder, ['Admin', 'Customer', 'Staff'], true)
    ? '../'
    : '';

// Get the current page file name
$currentPage = basename($_SERVER['SCRIPT_NAME'] ?? 'index.php');

// Set the default customer dashboard page
$dashboardPage = 'Customer/customer-dashboard.php';

// Select the dashboard according to the logged-in user's role
if (isset($_SESSION['user_role'])) {
    if ($_SESSION['user_role'] === 'admin') {
        $dashboardPage = 'Admin/admin-dashboard.php';
    } elseif ($_SESSION['user_role'] === 'staff') {
        $dashboardPage = 'Staff/staff-dashboard.php';
    }
}

// Check whether a user is logged in
$isLoggedIn = isset($_SESSION['user_id']);

// Get the logo file path and its last modification time
$logoFile = __DIR__ . '/../assets/images/Logo.png';
$logoVersion = file_exists($logoFile) ? filemtime($logoFile) : time();

// Generate the logo URL with a version parameter
$logoPath = $basePath . 'assets/images/Logo.png?v=' . $logoVersion;

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Set the character encoding and responsive viewport -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Set the website title -->
    <title>MediQuick Pharmacy</title>

    <!-- Include Bootstrap CSS -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Include Bootstrap Icons -->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    >

    <!-- Include the main website stylesheet -->
    <link
        rel="stylesheet"
        href="<?php echo $basePath; ?>css/style.css"
    >

    <!-- Define the header styles -->
    <style>

        /* Define the main header colour variables */
        :root {
            --mq-blue: #1f93c9;
            --mq-dark-blue: #153553;
            --mq-border: #e5ebf2;
            --mq-white: #ffffff;
        }

        /* Style the main website header */
        .mq-header {
            position: relative;
            z-index: 1000;
            width: 100%;
            background: var(--mq-white);
            border-bottom: 1px solid #edf1f5;
            box-shadow: 0 3px 12px rgba(20, 50, 80, 0.04);
        }

        /* Set the navbar background and height */
        .mq-header .navbar {
            min-height: 110px;
            padding: 10px 0;
            background: #ffffff !important;
        }

        /* Set the maximum width of the header container */
        .mq-header .container {
            max-width: 1360px;
        }

        /* Arrange the website logo and brand */
        .mq-header .navbar-brand {
            display: flex;
            align-items: center;
            flex-shrink: 0;
            margin: 0;
            padding: 0;
        }

        /* Style and enlarge the website logo */
        .mq-header .website-logo {
            display: block;
            width: 300px;
            height: 105px;
            max-width: none;
            object-fit: contain;
            object-position: center;
        }

        /* Arrange the navigation menu items */
        .mq-header .navbar-nav {
            display: flex;
            align-items: center;
            gap: 27px;
            margin-left: auto;
            margin-right: auto;
        }

        /* Style the navigation links */
        .mq-header .navbar-nav .nav-link {
            position: relative;
            padding: 12px 0 !important;
            color: var(--mq-dark-blue) !important;
            font-size: 16px;
            font-weight: 500;
            white-space: nowrap;
            transition: color 0.25s ease;
        }

        /* Change navigation link colour on hover */
        .mq-header .navbar-nav .nav-link:hover {
            color: var(--mq-blue) !important;
        }

        /* Highlight the currently active navigation link */
        .mq-header .navbar-nav .nav-link.active {
            color: var(--mq-blue) !important;
            font-weight: 700;
        }

        /* Add an underline to the active navigation link */
        .mq-header .navbar-nav .nav-link.active::after {
            content: "";
            position: absolute;
            left: 0;
            bottom: 0;
            width: 100%;
            height: 3px;
            border-radius: 5px;
            background: var(--mq-blue);
        }

        /* Arrange the header action buttons */
        .mq-header .header-actions {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-shrink: 0;
        }

        /* Style the header icon buttons */
        .mq-header .header-icon-btn {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 49px;
            height: 49px;
            flex-shrink: 0;
            color: #47627f;
            background: #ffffff;
            border: 1.5px solid var(--mq-border);
            border-radius: 50%;
            text-decoration: none;
            font-size: 20px;
            transition: all 0.25s ease;
        }

        /* Change the icon button appearance on hover */
        .mq-header .header-icon-btn:hover {
            color: var(--mq-blue);
            border-color: var(--mq-blue);
            background: #f5faff;
        }

        /* Position and style the shopping cart quantity badge */
        .mq-header .cart-count {
            position: absolute;
            top: -7px;
            right: -5px;
            display: flex;
            align-items: center;
            justify-content: center;
            min-width: 24px;
            height: 24px;
            padding: 0 5px;
            color: #ffffff;
            background: var(--mq-blue);
            border-radius: 50%;
            font-size: 12px;
            font-weight: 700;
        }

        /* Style the dashboard and login buttons */
        .mq-header .dashboard-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-height: 49px;
            padding: 10px 18px;
            color: var(--mq-blue);
            background: #ffffff;
            border: 1.5px solid var(--mq-blue);
            border-radius: 11px;
            text-decoration: none;
            font-size: 16px;
            font-weight: 500;
            white-space: nowrap;
            transition: all 0.25s ease;
        }

        /* Change the dashboard button appearance on hover */
        .mq-header .dashboard-btn:hover {
            color: #ffffff;
            background: var(--mq-blue);
            border-color: var(--mq-blue);
        }

        /* Set the dashboard button icon size */
        .mq-header .dashboard-btn i {
            font-size: 21px;
        }

        /* Style the mobile navigation toggle button */
        .mq-header .navbar-toggler {
            border: 1px solid #dce6f1;
            border-radius: 9px;
            padding: 8px 11px;
            box-shadow: none !important;
        }

        /* Add focus styling to the navigation toggle button */
        .mq-header .navbar-toggler:focus {
            box-shadow: 0 0 0 3px rgb(64, 120, 184) !important;
        }

        /* Adjust header styles for medium and large screens */
        @media (max-width: 1199px) {

            /* Reduce the navigation menu spacing */
            .mq-header .navbar-nav {
                gap: 17px;
            }

            /* Adjust the logo size */
            .mq-header .website-logo {
                width: 250px;
                height: 90px;
            }

            /* Reduce spacing between header action buttons */
            .mq-header .header-actions {
                gap: 8px;
            }

            /* Adjust navigation link font size */
            .mq-header .navbar-nav .nav-link {
                font-size: 14px;
            }

            /* Adjust dashboard button size */
            .mq-header .dashboard-btn {
                padding: 9px 12px;
                font-size: 14px;
            }

        }

        /* Adjust header layout for tablet and mobile screens */
        @media (max-width: 991px) {

            /* Reduce the navbar height */
            .mq-header .navbar {
                min-height: 85px;
            }

            /* Adjust the website logo dimensions */
            .mq-header .website-logo {
                width: 240px;
                height: 75px;
            }

            /* Style the collapsed navigation menu */
            .mq-header .navbar-collapse {
                padding: 15px 0 20px;
                border-top: 1px solid #edf1f5;
                margin-top: 12px;
            }

            /* Arrange navigation links vertically */
            .mq-header .navbar-nav {
                align-items: flex-start;
                gap: 5px;
                margin: 0;
            }

            /* Adjust navigation link spacing and font size */
            .mq-header .navbar-nav .nav-link {
                padding: 10px 0 !important;
                font-size: 16px;
            }

            /* Reduce the active link underline width */
            .mq-header .navbar-nav .nav-link.active::after {
                width: 35px;
            }

            /* Arrange header action buttons on mobile screens */
            .mq-header .header-actions {
                justify-content: flex-start;
                margin-top: 15px;
            }

        }

        /* Apply additional adjustments for small mobile screens */
        @media (max-width: 576px) {

            /* Reduce the website logo dimensions */
            .mq-header .website-logo {
                width: 220px;
                height: 65px;
            }

            /* Reduce the navbar height */
            .mq-header .navbar {
                min-height: 75px;
            }

            /* Adjust the header icon button dimensions */
            .mq-header .header-icon-btn {
                width: 44px;
                height: 44px;
            }

            /* Adjust the dashboard button dimensions */
            .mq-header .dashboard-btn {
                min-height: 44px;
                padding: 8px 13px;
                font-size: 14px;
            }

        }

    </style>

</head>

<body>

<!-- Display the main website header -->
<header class="mq-header">

    <!-- Create the responsive navigation bar -->
    <nav class="navbar navbar-expand-lg">

        <div class="container">

            <!-- Link the website logo to the home page -->
            <a
                class="navbar-brand"
                href="<?php echo $basePath; ?>index.php"
            >

                <!-- Display the MediQuick Pharmacy logo -->
                <img
                    src="<?php echo htmlspecialchars($logoPath); ?>"
                    alt="MediQuick Pharmacy"
                    class="website-logo"
                >

            </a>

            <!-- Provide the mobile navigation toggle button -->
            <button
                class="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#mainNavbar"
                aria-controls="mainNavbar"
                aria-expanded="false"
                aria-label="Toggle navigation"
            >

                <span class="navbar-toggler-icon"></span>

            </button>

            <!-- Define the collapsible navigation menu -->
            <div
                class="collapse navbar-collapse"
                id="mainNavbar"
            >

                <!-- Display the main navigation links -->
                <ul class="navbar-nav">

                    <!-- Home page navigation link -->
                    <li class="nav-item">
                        <a
                            class="nav-link <?php echo $currentPage === 'index.php' ? 'active' : ''; ?>"
                            href="<?php echo $basePath; ?>index.php"
                        >
                            Home
                        </a>
                    </li>

                    <!-- Products page navigation link -->
                    <li class="nav-item">
                        <a
                            class="nav-link <?php echo $currentPage === 'products.php' ? 'active' : ''; ?>"
                            href="<?php echo $basePath; ?>products.php"
                        >
                            Products
                        </a>
                    </li>

                    <!-- Prescription page navigation link -->
                    <li class="nav-item">
                        <a
                            class="nav-link <?php echo $currentPage === 'prescription.php' ? 'active' : ''; ?>"
                            href="<?php echo $basePath; ?>prescription.php"
                        >
                            Prescription
                        </a>
                    </li>

                    <!-- Categories section navigation link -->
                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="<?php echo $basePath; ?>index.php#categories"
                        >
                            Categories
                        </a>
                    </li>

                    <!-- About Us page navigation link -->
                    <li class="nav-item">
                        <a
                            class="nav-link <?php echo $currentPage === 'about.php' ? 'active' : ''; ?>"
                            href="<?php echo $basePath; ?>about.php"
                        >
                            About Us
                        </a>
                    </li>

                    <!-- Contact page navigation link -->
                    <li class="nav-item">
                        <a
                            class="nav-link <?php echo $currentPage === 'contact.php' ? 'active' : ''; ?>"
                            href="<?php echo $basePath; ?>contact.php"
                        >
                            Contact
                        </a>
                    </li>

                </ul>

                <!-- Display the search, cart and account actions -->
                <div class="header-actions">

                    <!-- Link to the products page for searching products -->
                    <a
                        href="<?php echo $basePath; ?>products.php"
                        class="header-icon-btn"
                        title="Search Products"
                        aria-label="Search Products"
                    >
                        <i class="bi bi-search"></i>
                    </a>

                    <!-- Link to the shopping cart -->
                    <a
                        href="<?php echo $basePath; ?>cart.php"
                        class="header-icon-btn"
                        title="Shopping Cart"
                        aria-label="Shopping Cart"
                    >
                        <i class="bi bi-cart3"></i>

                        <!-- Display the total shopping cart quantity -->
                        <span
                            class="cart-count"
                            id="headerCartCount"
                        >
                            0
                        </span>
                    </a>

                    <!-- Display the dashboard link for logged-in users -->
                    <?php if ($isLoggedIn): ?>

                        <a
                            href="<?php echo $basePath . $dashboardPage; ?>"
                            class="dashboard-btn"
                        >
                            <i class="bi bi-person-circle"></i>
                            Dashboard
                        </a>

                    <!-- Display the login link for guests -->
                    <?php else: ?>

                        <a
                            href="<?php echo $basePath; ?>login.php"
                            class="dashboard-btn"
                        >
                            <i class="bi bi-person-circle"></i>
                            Login
                        </a>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </nav>

</header>

<!-- Update the shopping cart quantity displayed in the header -->
<script>

// Retrieve and update the shopping cart quantity
function updateHeaderCartCount() {

    // Initialize the cart as an empty array
    let cart = [];

    // Retrieve the cart data from local storage
    try {
        cart = JSON.parse(
            localStorage.getItem('mediquickCart')
        ) || [];
    } catch (error) {
        cart = [];
    }

    // Calculate the total quantity of cart items
    let totalQuantity = 0;

    cart.forEach(function(item) {
        totalQuantity += Number(item.quantity) || 0;
    });

    // Get the cart quantity display element
    const cartCount = document.getElementById('headerCartCount');

    // Update the displayed cart quantity
    if (cartCount) {
        cartCount.textContent = totalQuantity;
    }

}

// Update the cart quantity when the page loads
document.addEventListener('DOMContentLoaded', function() {
    updateHeaderCartCount();
});

// Update the cart quantity when local storage changes
window.addEventListener('storage', function() {
    updateHeaderCartCount();
});

</script>

<!-- Include Bootstrap JavaScript -->
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
></script>

</body>
</html>