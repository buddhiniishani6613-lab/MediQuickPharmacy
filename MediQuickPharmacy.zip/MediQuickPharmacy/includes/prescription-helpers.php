<?php
/*
MediQuick Pharmacy - Prescription Helper Functions
Shared functions used by the upload, customer, admin and staff pages.
*/

if (!function_exists('mqPrescriptionDirectory')) {
    // Return the physical directory used to store prescription files.
    function mqPrescriptionDirectory(): string
    {
        return dirname(__DIR__) . DIRECTORY_SEPARATOR
            . 'uploads' . DIRECTORY_SEPARATOR
            . 'prescriptions' . DIRECTORY_SEPARATOR;
    }
}

if (!function_exists('mqProjectBaseUrl')) {
    // Build the URL prefix for the MediQuick project folder.
    function mqProjectBaseUrl(): string
    {
        $projectRoot = realpath(dirname(__DIR__));
        $documentRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '');

        if ($projectRoot === false || $documentRoot === false) {
            return '';
        }

        $projectRoot = str_replace('\\', '/', $projectRoot);
        $documentRoot = rtrim(str_replace('\\', '/', $documentRoot), '/');

        if (stripos($projectRoot, $documentRoot) !== 0) {
            return '';
        }

        $relative = substr($projectRoot, strlen($documentRoot));
        return '/' . trim(str_replace('\\', '/', $relative), '/');
    }
}

if (!function_exists('mqFindPrescriptionFile')) {
    // Find an existing file using the stored path, then the original file name.
    function mqFindPrescriptionFile(?string $filePath, ?string $fileName = ''): ?string
    {
        $directory = mqPrescriptionDirectory();

        if (!is_dir($directory)) {
            return null;
        }

        $candidates = [];
        $path = str_replace('\\', '/', trim((string)$filePath));
        $path = rawurldecode($path);

        if ($path !== '') {
            if (preg_match('#(?:^|/)uploads/prescriptions/([^/]+)$#i', $path, $matches)) {
                $candidates[] = basename($matches[1]);
            } elseif (strpos($path, '/') === false) {
                $candidates[] = basename($path);
            }
        }

        $name = basename(str_replace('\\', '/', trim((string)$fileName)));
        if ($name !== '') {
            $candidates[] = $name;
        }

        foreach (array_unique($candidates) as $candidate) {
            if ($candidate === '' || $candidate === '.' || $candidate === '..') {
                continue;
            }

            $fullPath = $directory . $candidate;
            if (is_file($fullPath) && is_readable($fullPath)) {
                return $candidate;
            }
        }

        return null;
    }
}

if (!function_exists('mqPrescriptionFileUrl')) {
    // Return a browser URL only when the physical file exists.
    function mqPrescriptionFileUrl(?string $filePath, ?string $fileName = ''): ?string
    {
        $file = mqFindPrescriptionFile($filePath, $fileName);

        if ($file === null) {
            return null;
        }

        return mqProjectBaseUrl()
            . '/uploads/prescriptions/'
            . rawurlencode($file);
    }
}

if (!function_exists('mqPrescriptionEscape')) {
    // Escape dynamic values before displaying them in HTML.
    function mqPrescriptionEscape($value): string
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('mqPrescriptionStatusClass')) {
    // Return a CSS class for each supported database status.
    function mqPrescriptionStatusClass(string $status): string
    {
        switch ($status) {
            case 'Approved': return 'approved';
            case 'Rejected': return 'rejected';
            case 'Completed': return 'completed';
            case 'Pending':
            default: return 'pending';
        }
    }
}
?>
