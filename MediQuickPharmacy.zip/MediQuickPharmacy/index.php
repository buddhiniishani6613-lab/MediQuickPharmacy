<?php

// Include the common website header.
include 'includes/header.php';

?>

<!-- Display the main hero section -->

<section class="hero-section">

    <div class="hero-overlay"></div>

    <div class="container hero-container">

        <div class="row align-items-center">

            <div class="col-lg-6">

                <div class="hero-content">

                    <!-- Display the healthcare trust badge -->
                    <span class="hero-badge">
                        <i class="bi bi-heart-pulse-fill"></i>
                        Trusted Healthcare Partner
                    </span>

                    <!-- Display the main welcome heading -->
                    <h1>
                        Your Health,
                        <span>Our Priority.</span>
                    </h1>

                    <!-- Display the pharmacy introduction -->
                    <p>
                        Order genuine medicines and healthcare products
                        from MediQuick Pharmacy. Fast delivery and
                        trusted healthcare services at your fingertips.
                    </p>

                    <!-- Provide shopping and prescription upload buttons -->
                    <div class="hero-buttons">

                        <!-- Link to the products page -->
                        <a href="products.php" class="shop-button">

                            <i class="bi bi-bag"></i>

                            Shop Now

                            <i class="bi bi-arrow-right"></i>

                        </a>

                        <!-- Link to the prescription upload page -->
                        <a href="prescription.php"
                           class="prescription-button">

                            <i class="bi bi-upload"></i>

                            Upload Prescription

                            <i class="bi bi-arrow-right"></i>

                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- Display the available product categories -->

<section class="categories-section" id="categories">

    <div class="container">

        <!-- Display the category section heading -->
        <div class="section-heading">

            <span class="section-label">
                EXPLORE
            </span>

            <h2>Shop by Category</h2>

            <p>
                Find the healthcare products you need.
            </p>

        </div>

        <!-- Display all available product categories -->
        <div class="row g-4">

            <!-- Display the prescription medicines category -->
            <div class="col-6 col-md-4 col-lg-2">

                <a href="products.php?category=Prescription"
                   class="category-card">

                    <div class="category-image">

                        <img
                            src="assets/images/product categories/Prescription.jpg"
                            alt="Prescription Medicines"
                        >

                    </div>

                    <h5>Prescription Medicines</h5>

                </a>

            </div>


            <!-- Display the OTC products category -->
            <div class="col-6 col-md-4 col-lg-2">

                <a href="products.php?category=OTC%20Products"
                   class="category-card">

                    <div class="category-image">

                        <img
                            src="assets/images/product categories/OTC Products.jpg"
                            alt="OTC Products"
                        >

                    </div>

                    <h5>OTC Products</h5>

                </a>

            </div>


            <!-- Display the wellness products category -->
            <div class="col-6 col-md-4 col-lg-2">

                <a href="products.php?category=Wellness%20Products"
                   class="category-card">

                    <div class="category-image">

                        <img
                            src="assets/images/product categories/Wellness Products.jpg"
                            alt="Wellness Products"
                        >

                    </div>

                    <h5>Wellness Products</h5>

                </a>

            </div>


            <!-- Display the personal care category -->
            <div class="col-6 col-md-4 col-lg-2">

                <a href="products.php?category=Personal%20Care"
                   class="category-card">

                    <div class="category-image">

                        <img
                            src="assets/images/product categories/Personal Care.jpg"
                            alt="Personal Care"
                        >

                    </div>

                    <h5>Personal Care</h5>

                </a>

            </div>


            <!-- Display the medical devices category -->
            <div class="col-6 col-md-4 col-lg-2">

                <a href="products.php?category=Medical%20Devices"
                   class="category-card">

                    <div class="category-image">

                        <img
                            src="assets/images/product categories/Medical Devices.jpg"
                            alt="Medical Devices"
                        >

                    </div>

                    <h5>Medical Devices</h5>

                </a>

            </div>


            <!-- Display the baby care category -->
            <div class="col-6 col-md-4 col-lg-2">

                <a href="products.php?category=Baby%20Care"
                   class="category-card">

                    <div class="category-image">

                        <img
                            src="assets/images/product categories/Baby Care.jpg"
                            alt="Baby Care"
                        >

                    </div>

                    <h5>Baby Care</h5>

                </a>

            </div>

        </div>

    </div>

</section>


<!-- Display the main pharmacy service features -->

<section class="features-section">

    <div class="container">

        <div class="row g-4">

            <!-- Highlight the availability of genuine products -->
            <div class="col-6 col-md-3">

                <div class="feature-box">

                    <div class="feature-icon">
                        <i class="bi bi-shield-check"></i>
                    </div>

                    <h5>100% Genuine</h5>

                    <p>
                        Quality healthcare products.
                    </p>

                </div>

            </div>


            <!-- Highlight the secure payment service -->
            <div class="col-6 col-md-3">

                <div class="feature-box">

                    <div class="feature-icon">
                        <i class="bi bi-credit-card"></i>
                    </div>

                    <h5>Secure Payments</h5>

                    <p>
                        Safe and secure checkout.
                    </p>

                </div>

            </div>


            <!-- Highlight the fast delivery service -->
            <div class="col-6 col-md-3">

                <div class="feature-box">

                    <div class="feature-icon">
                        <i class="bi bi-truck"></i>
                    </div>

                    <h5>Fast Delivery</h5>

                    <p>
                        Reliable delivery service.
                    </p>

                </div>

            </div>


            <!-- Highlight the customer support service -->
            <div class="col-6 col-md-3">

                <div class="feature-box">

                    <div class="feature-icon">
                        <i class="bi bi-headset"></i>
                    </div>

                    <h5>24/7 Support</h5>

                    <p>
                        We're here to help.
                    </p>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- Define the home page styles -->

<style>

/* Define the main website colour theme */

:root {

    --primary-blue: rgb(0, 115, 160);
    --primary-blue-dark: #067e9c;
    --primary-blue-light: #e6f7fc;

    --heading-color: #102b49;
    --text-color: #355a7e;

}


/* Style the main hero section */

.hero-section {

    position: relative;

    width: 100%;

    aspect-ratio: 2 / 1;

    min-height: 0;

    display: flex;

    align-items: center;

    background-image: url('assets/images/home.png');

    background-size: 100% 100%;

    background-position: center;

    background-repeat: no-repeat;

    overflow: hidden;

}


/* Add a subtle overlay behind the hero content */

.hero-overlay {

    position: absolute;

    inset: 0;

    z-index: 1;

    background: linear-gradient(
        90deg,
        rgba(255,255,255,0.72) 0%,
        rgba(255,255,255,0.55) 30%,
        rgba(255,255,255,0.20) 45%,
        transparent 65%
    );

}


/* Set the hero content position */

.hero-container {

    position: relative;

    z-index: 2;

}


/* Style the hero content container */

.hero-content {

    max-width: 650px;

    padding: 35px 0;

}


/* Style the healthcare trust badge */

.hero-badge {

    display: inline-flex;

    align-items: center;

    gap: 9px;

    padding: 9px 24px;

    margin-bottom: 30px;

    border-radius: 30px;

    background: var(--primary-blue-light);

    border: 1px solid #a9e0ed;

    color: var(--primary-blue-dark);

    font-size: 17px;

    font-weight: 700;

}


/* Style the main hero heading */

.hero-content h1 {

    font-size: clamp(42px, 5.2vw, 76px);

    font-weight: 800;

    line-height: 1.12;

    letter-spacing: -2px;

    color: var(--heading-color);

    margin-bottom: 25px;

}


/* Highlight the important text in the hero heading */

.hero-content h1 span {

    color: var(--primary-blue);

}


/* Style the hero description */

.hero-content p {

    max-width: 590px;

    font-size: 21px;

    line-height: 1.65;

    color: #234b6e;

    font-weight: 500;

    margin-bottom: 28px;

}


/* Arrange the hero action buttons */

.hero-buttons {

    display: flex;

    flex-wrap: wrap;

    align-items: center;

    gap: 14px;

}


/* Apply common styles to both hero buttons */

.shop-button,
.prescription-button {

    display: inline-flex;

    align-items: center;

    justify-content: center;

    gap: 12px;

    min-height: 64px;

    padding: 15px 25px;

    border-radius: 12px;

    text-decoration: none;

    font-size: 18px;

    font-weight: 600;

    transition: all 0.3s ease;

}


/* Style the Shop Now button */

.shop-button {

    color: #ffffff;

    background: var(--primary-blue);

    border: 1px solid var(--primary-blue);

}


/* Add a hover effect to the Shop Now button */

.shop-button:hover {

    color: #ffffff;

    background: var(--primary-blue-dark);

    border-color: var(--primary-blue-dark);

    transform: translateY(-3px);

}


/* Style the Upload Prescription button */

.prescription-button {

    color: var(--primary-blue-dark);

    background: #ffffff;

    border: 1.5px solid var(--primary-blue);

}


/* Add a hover effect to the Upload Prescription button */

.prescription-button:hover {

    color: #ffffff;

    background: var(--primary-blue);

    border-color: var(--primary-blue);

    transform: translateY(-3px);

}


/* Style the product categories section */

.categories-section {

    padding: 80px 0;

    background: #ffffff;

}


/* Align the category section heading */

.section-heading {

    text-align: center;

    margin-bottom: 45px;

}


/* Style the category section label */

.section-label {

    display: inline-block;

    color: var(--primary-blue);

    font-size: 14px;

    font-weight: 700;

    letter-spacing: 2px;

    margin-bottom: 10px;

}


/* Style the category section main heading */

.section-heading h2 {

    color: var(--heading-color);

    font-size: 36px;

    font-weight: 750;

    margin-bottom: 12px;

}


/* Style the category section description */

.section-heading p {

    color: #637b92;

    font-size: 16px;

    margin-bottom: 0;

}


/* Style the individual category cards */

.category-card {

    display: block;

    height: 100%;

    padding: 17px;

    text-align: center;

    text-decoration: none;

    background: #ffffff;

    border: 1px solid #e8eef5;

    border-radius: 16px;

    transition: all 0.3s ease;

}


/* Add a hover effect to category cards */

.category-card:hover {

    transform: translateY(-7px);

    border-color: var(--primary-blue);

    box-shadow: 0 10px 28px rgba(7,152,185,0.12);

}


/* Set the category image container dimensions */

.category-image {

    display: flex;

    align-items: center;

    justify-content: center;

    width: 100%;

    height: 125px;

    margin-bottom: 15px;

}


/* Adjust the category images */

.category-image img {

    max-width: 100%;

    max-height: 115px;

    object-fit: contain;

}


/* Style the category titles */

.category-card h5 {

    color: #23435f;

    font-size: 14px;

    font-weight: 600;

    line-height: 1.5;

    margin-bottom: 0;

}


/* Style the pharmacy features section */

.features-section {

    padding: 65px 0;

    background: #f0f9fc;

}


/* Style individual feature boxes */

.feature-box {

    height: 100%;

    padding: 28px 15px;

    text-align: center;

    background: #ffffff;

    border: 1px solid #dceef3;

    border-radius: 15px;

    transition: all 0.3s ease;

}


/* Add a hover effect to feature boxes */

.feature-box:hover {

    transform: translateY(-5px);

    box-shadow: 0 8px 22px rgba(7,152,185,0.10);

}


/* Set the spacing around feature icons */

.feature-icon {

    margin-bottom: 15px;

}


/* Style the feature icons */

.feature-icon i {

    font-size: 40px;

    color: var(--primary-blue);

}


/* Style the feature headings */

.feature-box h5 {

    color: var(--heading-color);

    font-size: 17px;

    font-weight: 700;

    margin-bottom: 9px;

}


/* Style the feature descriptions */

.feature-box p {

    color: #637b92;

    font-size: 14px;

    margin-bottom: 0;

}


/* Apply responsive styles for tablet screens */

@media (max-width: 991px) {

    .hero-section {

        aspect-ratio: auto;

        min-height: 700px;

        background-size: cover;

        background-position: center;

    }

    .hero-content {

        max-width: 560px;

    }

    .hero-content h1 {

        font-size: 58px;

    }

    .hero-content p {

        font-size: 18px;

    }

    .hero-overlay {

        background: linear-gradient(
            90deg,
            rgba(255,255,255,0.82),
            rgba(255,255,255,0.62),
            rgba(255,255,255,0.20)
        );

    }

}


/* Apply responsive styles for mobile screens */

@media (max-width: 576px) {

    .hero-section {

        min-height: 700px;

        background-position: center;

    }

    .hero-overlay {

        background: rgba(255,255,255,0.80);

    }

    .hero-content {

        padding: 50px 0;

    }

    .hero-badge {

        font-size: 14px;

        padding: 8px 16px;

        margin-bottom: 23px;

    }

    .hero-content h1 {

        font-size: 43px;

        letter-spacing: -1px;

    }

    .hero-content p {

        font-size: 16px;

        line-height: 1.6;

    }

    .hero-buttons {

        flex-direction: column;

        align-items: stretch;

    }

    .shop-button,
    .prescription-button {

        width: 100%;

        min-height: 56px;

        font-size: 16px;

    }

    .categories-section {

        padding: 55px 0;

    }

    .section-heading h2 {

        font-size: 28px;

    }

    .category-card {

        padding: 12px;

    }

    .category-image {

        height: 100px;

    }

    .category-image img {

        max-height: 90px;

    }

    .category-card h5 {

        font-size: 13px;

    }

    .features-section {

        padding: 45px 0;

    }

    .feature-box {

        padding: 22px 10px;

    }

    .feature-icon i {

        font-size: 33px;

    }

    .feature-box h5 {

        font-size: 15px;

    }

    .feature-box p {

        font-size: 12px;

    }

}

</style>


<?php

// Include the common website footer.
include 'includes/footer.php';

?>