<?php

session_start();

// Load the database connection.
require_once 'config/database.php';

// Return all responses as JSON.
header("Content-Type: application/json; charset=UTF-8");

// Allow login requests only through POST.
if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    echo json_encode([
        "success" => false,
        "message" => "Invalid request method."
    ]);

    exit;
}

// Get the email and password submitted from the login form.
$email = trim($_POST["email"] ?? "");
$password = $_POST["password"] ?? "";

// Validate required login fields.
if ($email === "" || $password === "") {

    echo json_encode([
        "success" => false,
        "message" => "Please enter your email and password."
    ]);

    exit;
}

// Validate the email format.
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

    echo json_encode([
        "success" => false,
        "message" => "Please enter a valid email address."
    ]);

    exit;
}

// Find the user using the email address.
$stmt = $conn->prepare("
    SELECT
        id,
        full_name,
        email,
        phone,
        password,
        role
    FROM users
    WHERE email = ?
    LIMIT 1
");

if (!$stmt) {

    echo json_encode([
        "success" => false,
        "message" => "Database error. Please try again."
    ]);

    exit;
}

$stmt->bind_param("s", $email);

$stmt->execute();

$result = $stmt->get_result();

// Check whether a matching user was found.
if (!$result || $result->num_rows === 0) {

    $stmt->close();

    echo json_encode([
        "success" => false,
        "message" => "Incorrect email or password."
    ]);

    exit;
}

$user = $result->fetch_assoc();

$stmt->close();

// Verify the submitted password against the stored password hash.
if (!password_verify($password, $user["password"])) {

    echo json_encode([
        "success" => false,
        "message" => "Incorrect email or password."
    ]);

    exit;
}

// Get the authenticated user's details.
$userId    = (int) $user["id"];
$userName  = $user["full_name"];
$userEmail = $user["email"];
$userPhone = $user["phone"] ?? "";
$userRole  = strtolower(trim($user["role"]));

// Allow only the roles defined in the application.
if (
    $userRole !== "customer" &&
    $userRole !== "staff" &&
    $userRole !== "admin"
) {

    echo json_encode([
        "success" => false,
        "message" => "Your account role is invalid. Please contact the administrator."
    ]);

    exit;
}

// Set the dashboard URL according to the user's role.
if ($userRole === "customer") {

    $redirect = "Customer/customer-dashboard.php";

} elseif ($userRole === "staff") {

    $redirect = "Staff/staff-dashboard.php";

} elseif ($userRole === "admin") {

    $redirect = "Admin/admin-dashboard.php";

} else {

    $redirect = "login.php";
}

// Regenerate the session ID after successful authentication.
session_regenerate_id(true);

// Store authenticated user information in the session.
$_SESSION["user_id"]    = $userId;
$_SESSION["user_name"]  = $userName;
$_SESSION["user_email"] = $userEmail;
$_SESSION["user_phone"] = $userPhone;
$_SESSION["user_role"]  = $userRole;

$_SESSION["is_logged_in"] = true;

// Return the successful login response.
echo json_encode([

    "success" => true,

    "message" => "Login successful.",

    "redirect" => $redirect,

    "user" => [

        "id" => $userId,

        "full_name" => $userName,

        "email" => $userEmail,

        "phone" => $userPhone,

        "role" => $userRole

    ]

]);

exit;

?>