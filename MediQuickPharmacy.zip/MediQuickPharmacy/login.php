<?php

session_start();

// Load the database connection.
require_once 'config/database.php';

// Store login error and success messages.
$loginError = "";
$loginSuccess = "";

// Process the login form when it is submitted.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    // Validate required login fields.
    if ($email === "" || $password === "") {

        $loginError = "Please enter your email and password.";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        // Validate the email address format.
        $loginError = "Please enter a valid email address.";

    } else {

        // Find the user by email address.
        $sql = "
            SELECT
                id,
                full_name,
                email,
                phone,
                password,
                role
            FROM users
            WHERE email = ?
            LIMIT 1
        ";

        $stmt = $conn->prepare($sql);

        if (!$stmt) {

            $loginError = "Database error. Please try again.";

        } else {

            $stmt->bind_param("s", $email);

            if ($stmt->execute()) {

                $result = $stmt->get_result();

                // Check whether the user exists.
                if ($result && $result->num_rows === 1) {

                    $user = $result->fetch_assoc();

                    // Verify the entered password.
                    if (password_verify($password, $user["password"])) {

                        // Get the user's role from the database.
                        $role = strtolower(
                            trim($user["role"] ?? "")
                        );

                        // Allow only valid application roles.
                        if (
                            !in_array(
                                $role,
                                ["customer", "staff", "admin"],
                                true
                            )
                        ) {

                            $loginError =
                                "Invalid account role. Please contact the administrator.";

                        } else {

                            // Regenerate the session ID after successful login.
                            session_regenerate_id(true);

                            // Clear old login session values.
                            unset(
                                $_SESSION["user_id"],
                                $_SESSION["user_name"],
                                $_SESSION["user_email"],
                                $_SESSION["user_phone"],
                                $_SESSION["user_role"]
                            );

                            // Save the authenticated user's details.
                            $_SESSION["user_id"] =
                                (int) $user["id"];

                            $_SESSION["user_name"] =
                                $user["full_name"];

                            $_SESSION["user_email"] =
                                $user["email"];

                            $_SESSION["user_phone"] =
                                $user["phone"] ?? "";

                            $_SESSION["user_role"] =
                                $role;

                            $_SESSION["is_logged_in"] =
                                true;

                            // Redirect the user to the correct dashboard.
                            if ($role === "customer") {

                                header(
                                    "Location: Customer/customer-dashboard.php"
                                );

                                exit;

                            } elseif ($role === "staff") {

                                header(
                                    "Location: Staff/staff-dashboard.php"
                                );

                                exit;

                            } elseif ($role === "admin") {

                                header(
                                    "Location: Admin/admin-dashboard.php"
                                );

                                exit;
                            }
                        }

                    } else {

                        // Password verification failed.
                        $loginError =
                            "Incorrect password.";
                    }

                } else {

                    // No user was found with the entered email.
                    $loginError =
                        "No account found with this email address.";
                }

            } else {

                // Handle database execution errors.
                $loginError =
                    "Unable to process login. Please try again.";
            }

            $stmt->close();
        }
    }
}

// Load the common website header.
include 'includes/header.php';

?>

<section class="login-section">

    <div class="login-container">

        <div class="login-card">

            <!-- Login icon -->
            <div class="login-icon">

                <i class="bi bi-person-circle"></i>

            </div>

            <!-- Login heading -->
            <div class="login-heading">

                <span class="small-title">
                    MEDIQUICK PHARMACY
                </span>

                <h1>
                    Welcome Back
                </h1>

                <p>
                    Login to your MediQuick Pharmacy account.
                </p>

            </div>

            <!-- Display login error message -->
            <?php if (!empty($loginError)): ?>

                <div class="login-error">

                    <i class="bi bi-exclamation-circle-fill"></i>

                    <span>
                        <?php
                        echo htmlspecialchars(
                            $loginError,
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?>
                    </span>

                </div>

            <?php endif; ?>

            <!-- Display login success message -->
            <?php if (!empty($loginSuccess)): ?>

                <div class="login-success">

                    <i class="bi bi-check-circle-fill"></i>

                    <span>
                        <?php
                        echo htmlspecialchars(
                            $loginSuccess,
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?>
                    </span>

                </div>

            <?php endif; ?>

            <!-- Login form -->
            <form
                action="login.php"
                method="POST"
                id="loginForm"
                autocomplete="on"
            >

                <!-- Email field -->
                <div class="form-group">

                    <label for="email">
                        Email Address
                    </label>

                    <div class="input-wrapper">

                        <i class="bi bi-envelope"></i>

                        <input
                            type="email"
                            id="email"
                            name="email"
                            placeholder="Enter your email address"
                            autocomplete="email"
                            value="<?php
                                echo htmlspecialchars(
                                    $_POST["email"] ?? "",
                                    ENT_QUOTES,
                                    "UTF-8"
                                );
                            ?>"
                            required
                        >

                    </div>

                </div>

                <!-- Password field -->
                <div class="form-group">

                    <label for="password">
                        Password
                    </label>

                    <div class="input-wrapper">

                        <i class="bi bi-lock"></i>

                        <input
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Enter your password"
                            autocomplete="current-password"
                            required
                        >

                        <button
                            type="button"
                            class="password-toggle"
                            id="passwordToggle"
                            aria-label="Show password"
                        >

                            <i class="bi bi-eye"></i>

                        </button>

                    </div>

                </div>

                <!-- Remember me and forgot password options -->
                <div class="login-options">

                    <label class="remember-option">

                        <input
                            type="checkbox"
                            name="remember"
                            value="1"
                        >

                        <span>
                            Remember me
                        </span>

                    </label>

                    <a
                        href="#"
                        id="forgotPassword"
                    >
                        Forgot Password?
                    </a>

                </div>

                <!-- Login button -->
                <button
                    type="submit"
                    class="login-button"
                    id="loginButton"
                >

                    <i class="bi bi-box-arrow-in-right"></i>

                    <span id="loginButtonText">
                        Login
                    </span>

                </button>

            </form>

            <!-- Registration link -->
            <div class="register-link">

                <span>
                    Don't have an account?
                </span>

                <a href="register.php">
                    Create an account
                </a>

            </div>

        </div>

    </div>

</section>

<style>

/* Login page main section */
.login-section {

    min-height: 80vh;

    background: #f6fbfd;

    padding: 70px 20px;

    display: flex;

    align-items: center;

    justify-content: center;

}

/* Login content container */
.login-container {

    width: 100%;

    max-width: 470px;

    margin: auto;

}

/* Login card */
.login-card {

    background: #ffffff;

    border-radius: 18px;

    padding: 40px;

    box-shadow:
        0 8px 30px
        rgba(0, 80, 110, 0.10);

}

/* Login icon container */
.login-icon {

    width: 70px;

    height: 70px;

    margin: 0 auto 18px;

    border-radius: 50%;

    background: #e8f7fa;

    display: flex;

    align-items: center;

    justify-content: center;

}

/* Login icon */
.login-icon i {

    color: #087f9b;

    font-size: 38px;

}

/* Login heading */
.login-heading {

    text-align: center;

    margin-bottom: 30px;

}

/* Small title */
.small-title {

    color: #087f9b;

    font-size: 12px;

    font-weight: 700;

    letter-spacing: 2px;

}

/* Main login title */
.login-heading h1 {

    color: #174f68;

    font-size: 30px;

    margin: 8px 0;

}

/* Login description */
.login-heading p {

    color: #777;

    font-size: 14px;

    margin: 0;

}

/* Login error message */
.login-error {

    background: #fff1f1;

    border: 1px solid #f2caca;

    color: #c62828;

    border-radius: 8px;

    padding: 12px 14px;

    margin-bottom: 20px;

    font-size: 14px;

    display: flex;

    align-items: center;

    gap: 9px;

}

/* Error icon */
.login-error i {

    font-size: 17px;

}

/* Login success message */
.login-success {

    background: #eefaf3;

    border: 1px solid #c7ead5;

    color: #16834b;

    border-radius: 8px;

    padding: 12px 14px;

    margin-bottom: 20px;

    font-size: 14px;

    display: flex;

    align-items: center;

    gap: 9px;

}

/* Form group */
.form-group {

    margin-bottom: 20px;

}

/* Form labels */
.form-group label {

    display: block;

    color: #174f68;

    font-size: 14px;

    font-weight: 600;

    margin-bottom: 8px;

}

/* Input wrapper */
.input-wrapper {

    position: relative;

    display: flex;

    align-items: center;

}

/* Input icon */
.input-wrapper > i {

    position: absolute;

    left: 14px;

    color: #087f9b;

    font-size: 17px;

    pointer-events: none;

}

/* Login input */
.input-wrapper input {

    width: 100%;

    box-sizing: border-box;

    padding: 13px 45px 13px 42px;

    border: 1px solid #d8e5e9;

    border-radius: 8px;

    outline: none;

    font-family: inherit;

    font-size: 14px;

    transition: 0.2s;

}

/* Input focus effect */
.input-wrapper input:focus {

    border-color: #087f9b;

    box-shadow:
        0 0 0 3px
        rgba(8, 127, 155, 0.08);

}

/* Password visibility button */
.password-toggle {

    position: absolute;

    right: 10px;

    border: none;

    background: transparent;

    color: #777;

    cursor: pointer;

    padding: 7px;

}

/* Password toggle hover effect */
.password-toggle:hover {

    color: #087f9b;

}

/* Login options */
.login-options {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin: 5px 0 25px;

    font-size: 13px;

}

/* Remember me option */
.remember-option {

    display: flex;

    align-items: center;

    gap: 7px;

    color: #666;

    cursor: pointer;

}

/* Remember me checkbox */
.remember-option input {

    accent-color: #087f9b;

}

/* Forgot password link */
.login-options a {

    color: #087f9b;

    text-decoration: none;

    font-weight: 600;

}

/* Forgot password hover effect */
.login-options a:hover {

    text-decoration: underline;

}

/* Login button */
.login-button {

    width: 100%;

    border: none;

    background: #087f9b;

    color: white;

    padding: 14px;

    border-radius: 9px;

    font-size: 16px;

    font-weight: 700;

    cursor: pointer;

    transition: 0.2s;

    display: flex;

    align-items: center;

    justify-content: center;

    gap: 8px;

}

/* Login button hover effect */
.login-button:hover {

    background: #056b83;

    transform: translateY(-1px);

}

/* Registration link section */
.register-link {

    text-align: center;

    margin-top: 25px;

    padding-top: 22px;

    border-top: 1px solid #edf2f4;

    color: #777;

    font-size: 14px;

}

/* Registration link */
.register-link a {

    color: #087f9b;

    font-weight: 700;

    text-decoration: none;

    margin-left: 5px;

}

/* Registration link hover effect */
.register-link a:hover {

    text-decoration: underline;

}

/* Responsive login section */
@media (max-width: 500px) {

    .login-section {

        padding: 40px 15px;

    }

    .login-card {

        padding: 25px 20px;

    }

    .login-heading h1 {

        font-size: 27px;

    }

    .login-options {

        flex-direction: column;

        align-items: flex-start;

        gap: 12px;

    }

}

</style>

<script>

// Run login page JavaScript after the page has loaded.
document.addEventListener(
    "DOMContentLoaded",
    function () {

        const passwordInput =
            document.getElementById("password");

        const passwordToggle =
            document.getElementById("passwordToggle");

        const loginForm =
            document.getElementById("loginForm");

        const loginButton =
            document.getElementById("loginButton");

        const loginButtonText =
            document.getElementById("loginButtonText");

        // Toggle password visibility.
        if (
            passwordToggle &&
            passwordInput
        ) {

            passwordToggle.addEventListener(
                "click",
                function () {

                    if (
                        passwordInput.type ===
                        "password"
                    ) {

                        passwordInput.type =
                            "text";

                        passwordToggle.innerHTML =
                            '<i class="bi bi-eye-slash"></i>';

                        passwordToggle.setAttribute(
                            "aria-label",
                            "Hide password"
                        );

                    } else {

                        passwordInput.type =
                            "password";

                        passwordToggle.innerHTML =
                            '<i class="bi bi-eye"></i>';

                        passwordToggle.setAttribute(
                            "aria-label",
                            "Show password"
                        );
                    }

                }
            );

        }

        // Display the password recovery message.
        const forgotPassword =
            document.getElementById(
                "forgotPassword"
            );

        if (forgotPassword) {

            forgotPassword.addEventListener(
                "click",
                function (event) {

                    event.preventDefault();

                    alert(
                        "Password recovery will be available soon."
                    );

                }
            );

        }

        // Disable the login button while the form is being submitted.
        if (loginForm) {

            loginForm.addEventListener(
                "submit",
                function () {

                    if (loginButton) {

                        loginButton.disabled =
                            true;

                    }

                    if (loginButtonText) {

                        loginButtonText.textContent =
                            "Logging in...";

                    }

                }
            );

        }

    }
);

</script>

<?php

// Load the common website footer.
include 'includes/footer.php';

?>