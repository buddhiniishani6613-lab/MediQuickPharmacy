<?php

session_start();

// Prevent the browser from displaying a cached page after logout.
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");

// Clear all session variables.
$_SESSION = [];

// Remove the PHP session cookie from the browser.
if (ini_get("session.use_cookies")) {

    $params = session_get_cookie_params();

    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// Destroy the current PHP session.
session_destroy();

// Redirect the user to the root-level login page.
header("Location: login.php");
exit;

?>