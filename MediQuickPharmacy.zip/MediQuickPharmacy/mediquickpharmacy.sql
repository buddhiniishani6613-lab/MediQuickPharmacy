-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2026 at 01:27 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mediquickpharmacy`
--

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `type` enum('Order','Prescription','Payment','Product','System') DEFAULT 'System',
  `related_id` int(11) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `type`, `related_id`, `is_read`, `created_at`) VALUES
(1, 1, 'Welcome to MediQuick Pharmacy', 'Thank you for choosing MediQuick Pharmacy. Your healthcare journey starts here.', 'System', NULL, 1, '2026-09-04 13:11:08');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `order_number` varchar(50) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `delivery_address` text NOT NULL,
  `city` varchar(100) DEFAULT NULL,
  `payment_method` varchar(50) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `delivery_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `order_status` enum('Pending','Processing','Shipped','Delivered','Cancelled') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `order_number`, `full_name`, `email`, `phone`, `delivery_address`, `city`, `payment_method`, `subtotal`, `delivery_fee`, `total_amount`, `order_status`, `created_at`) VALUES
(1, 1, 'MQ20260904134519471', 'Nimal Fernando', 'fernando@gmail.com', '0758435701', 'ee', 'e', 'Cash on Delivery', 5070.00, 0.00, 5070.00, 'Pending', '2026-09-04 11:45:19'),
(2, 1, 'MQ20260904150438383', 'Nimal Fernando', 'fernando@gmail.com', '0758435701', 'g', 'matara', 'Card Payment', 900.00, 350.00, 1250.00, 'Shipped', '2026-09-04 13:04:38'),
(3, 4, 'MQ20261110065246940', 'Nadija I', 'nadija@gmail.com', '0702567098', 'matara', 'deniyaya', 'Card Payment', 6580.00, 0.00, 6580.00, 'Delivered', '2026-11-10 05:52:46');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(150) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `product_name`, `quantity`, `unit_price`, `total_price`) VALUES
(1, 3, 16, 'Paracetamol 500mg', 1, 150.00, 150.00),
(2, 3, 20, 'Throat Lozenges', 1, 350.00, 350.00),
(3, 3, 22, 'Vitamin C Tablets', 1, 420.00, 420.00),
(4, 3, 33, 'Moisturizing Lotion', 1, 850.00, 850.00),
(5, 3, 34, 'Facial Cleanser', 1, 650.00, 650.00),
(6, 3, 35, 'Sunscreen Lotion', 1, 1450.00, 1450.00),
(7, 3, 37, 'Conditioner', 1, 780.00, 780.00),
(8, 3, 38, 'Body Wash', 1, 720.00, 720.00),
(9, 3, 41, 'Deodorant', 1, 650.00, 650.00),
(10, 3, 42, 'Lip Balm', 1, 280.00, 280.00),
(11, 3, 56, 'Baby Soap', 1, 280.00, 280.00);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_status` enum('Pending','Paid','Failed','Refunded') DEFAULT 'Pending',
  `transaction_reference` varchar(100) DEFAULT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `order_id`, `payment_method`, `amount`, `payment_status`, `transaction_reference`, `payment_date`) VALUES
(1, 1, 'Cash on Delivery', 5070.00, 'Pending', NULL, '2026-09-04 11:45:19'),
(2, 2, 'Card Payment', 1250.00, 'Pending', NULL, '2026-09-04 13:04:38'),
(3, 3, 'Card Payment', 6580.00, 'Pending', NULL, '2026-11-10 05:52:46');

-- --------------------------------------------------------

--
-- Table structure for table `prescriptions`
--

CREATE TABLE `prescriptions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `patient_name` varchar(150) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(150) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected','Completed') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `prescriptions`
--

INSERT INTO `prescriptions` (`id`, `user_id`, `patient_name`, `phone`, `email`, `file_name`, `file_path`, `file_type`, `notes`, `status`, `created_at`) VALUES
(1, 1, 'Nimal Fernando', '0758435701', 'fernando@gmail.com', 'Nimal Prescription.png', 'uploads/prescriptions/prescription_1_20261110_131732_795027e07473a10b.png', 'image/png', 'For 2 weeks', 'Pending', '2026-11-10 12:17:32'),
(2, 4, 'Nadija I', '0702567098', 'nadija@gmail.com', 'Nadija Prescription.png', 'uploads/prescriptions/prescription_4_20261110_132342_a9ec600f74be914e.png', 'image/png', 'No', 'Pending', '2026-11-10 12:23:42');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `category` enum('Prescription','OTC Products','Wellness Products','Personal Care','Medical Devices','Baby Care') NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock_quantity` int(11) DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `requires_prescription` tinyint(1) DEFAULT 0,
  `status` enum('Available','Out of Stock','Inactive') DEFAULT 'Available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `category`, `price`, `stock_quantity`, `image`, `requires_prescription`, `status`, `created_at`) VALUES
(1, 'Amoxicillin 500mg', 'Prescription antibiotic capsules used to treat bacterial infections.', 'Prescription', 450.00, 50, 'assets/images/products/Amoxicillin.jpg', 1, 'Available', '2026-09-07 11:59:13'),
(2, 'Azithromycin 500mg', 'Prescription antibiotic medicine used to treat certain bacterial infections.', 'Prescription', 550.00, 45, 'assets/images/products/Azithromycin.jpg', 1, 'Available', '2026-09-07 11:59:13'),
(3, 'Metformin 500mg', 'Prescription medicine commonly used to manage blood sugar levels.', 'Prescription', 320.00, 60, 'assets/images/products/Metformin.jpg', 1, 'Available', '2026-09-07 11:59:13'),
(4, 'Amlodipine 5mg', 'Prescription medicine used for blood pressure management.', 'Prescription', 290.00, 55, 'assets/images/products/Amlodipine.jpg', 1, 'Available', '2026-09-07 11:59:13'),
(5, 'Losartan 50mg', 'Prescription medicine used to manage high blood pressure.', 'Prescription', 390.00, 40, 'assets/images/products/Losartan.jpg', 1, 'Available', '2026-09-07 11:59:13'),
(6, 'Atorvastatin 20mg', 'Prescription medicine used to manage cholesterol levels.', 'Prescription', 580.00, 45, 'assets/images/products/Atorvastatin.jpg', 1, 'Available', '2026-09-07 11:59:13'),
(7, 'Omeprazole 20mg', 'Prescription medicine used to reduce stomach acid and relieve acid-related conditions.', 'Prescription', 350.00, 50, 'assets/images/products/Omeprazole.jpg', 1, 'Available', '2026-09-07 11:59:13'),
(8, 'Cetirizine 10mg', 'Medicine used to relieve allergy symptoms such as sneezing and itching.', 'Prescription', 180.00, 70, 'assets/images/products/Cetirizine.jpg', 1, 'Available', '2026-09-07 11:59:13'),
(9, 'Salbutamol 2mg', 'Prescription medicine used to help relieve breathing difficulties.', 'Prescription', 420.00, 35, 'assets/images/products/Salbutamol.jpg', 1, 'Available', '2026-09-07 11:59:13'),
(10, 'Diclofenac 50mg', 'Prescription medicine used for temporary relief of pain and inflammation.', 'Prescription', 250.00, 45, 'assets/images/products/Diclofenac.jpg', 1, 'Available', '2026-09-07 11:59:13'),
(11, 'Prednisolone 5mg', 'Prescription corticosteroid medicine used for various inflammatory conditions.', 'Prescription', 300.00, 40, 'assets/images/products/Prednisolone.jpg', 1, 'Available', '2026-09-07 11:59:13'),
(12, 'Flucloxacillin 500mg', 'Prescription antibiotic used to treat certain bacterial infections.', 'Prescription', 480.00, 40, 'assets/images/products/Flucloxacillin.jpg', 1, 'Available', '2026-09-07 11:59:13'),
(13, 'Cephalexin 500mg', 'Prescription antibiotic medicine used to treat bacterial infections.', 'Prescription', 520.00, 45, 'assets/images/products/Cephalexin.jpg', 1, 'Available', '2026-09-07 11:59:13'),
(14, 'Furosemide 40mg', 'Prescription medicine used to help remove excess fluid from the body.', 'Prescription', 280.00, 35, 'assets/images/products/Furosemide.jpg', 1, 'Available', '2026-09-07 11:59:13'),
(15, 'Levothyroxine 50mcg', 'Prescription thyroid replacement medicine used to manage thyroid hormone deficiency.', 'Prescription', 420.00, 35, 'assets/images/products/Levothyroxine.jpg', 1, 'Available', '2026-09-07 11:59:13'),
(16, 'Paracetamol 500mg', 'Over-the-counter medicine for temporary relief of pain and fever.', 'OTC Products', 150.00, 99, 'assets/images/products/Paracetamol.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(17, 'Antacid Tablets', 'Chewable tablets used for occasional acidity and indigestion relief.', 'OTC Products', 180.00, 90, 'assets/images/products/Antacid Tablets.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(18, 'Oral Rehydration Salts (ORS)', 'Oral rehydration salts used to help replace fluids and electrolytes.', 'OTC Products', 80.00, 120, 'assets/images/products/Oral Rehydration Salts.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(19, 'Cough Syrup', 'Over-the-counter syrup used for temporary relief of cough symptoms.', 'OTC Products', 680.00, 50, 'assets/images/products/Cough Syrup.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(20, 'Throat Lozenges', 'Lozenges used to soothe minor throat irritation and discomfort.', 'OTC Products', 350.00, 64, 'assets/images/products/Throat Lozenges.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(21, 'Antacid Suspension', 'Liquid antacid used for relief of heartburn and indigestion.', 'OTC Products', 750.00, 45, 'assets/images/products/Antacid Suspension.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(22, 'Vitamin C Tablets', 'Vitamin C tablets for daily nutritional support.', 'OTC Products', 420.00, 74, 'assets/images/products/Vitamin C Tablets.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(23, 'Saline Nasal Spray', 'Saline nasal spray used to relieve nasal dryness and congestion.', 'OTC Products', 520.00, 45, 'assets/images/products/Saline Nasal Spray.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(24, 'Muscle Pain Relief Gel', 'Topical gel used for temporary relief of minor muscle and joint discomfort.', 'OTC Products', 850.00, 40, 'assets/images/products/Muscle Pain Relief Gel.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(25, 'Antiseptic Solution', 'Antiseptic solution for general cleansing of minor cuts and wounds.', 'OTC Products', 480.00, 55, 'assets/images/products/Antiseptic Solution.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(26, 'Multivitamin Tablets', 'Daily multivitamin supplement for general nutritional support.', 'Wellness Products', 1250.00, 50, 'assets/images/products/Multivitamin Tablets.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(27, 'Vitamin D3 Tablets', 'Vitamin D3 supplement for daily nutritional support.', 'Wellness Products', 1100.00, 55, 'assets/images/products/Vitamin D3 Tablets.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(28, 'Omega-3 Capsules', 'Omega-3 supplement containing essential fatty acids for nutritional support.', 'Wellness Products', 1450.00, 40, 'assets/images/products/Omega-3 Capsules.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(29, 'Calcium Tablets', 'Calcium supplement for daily nutritional support.', 'Wellness Products', 980.00, 45, 'assets/images/products/Calcium Tablets.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(30, 'Magnesium Tablets', 'Magnesium supplement for daily nutritional support.', 'Wellness Products', 950.00, 45, 'assets/images/products/Magnesium Tablets.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(31, 'Probiotic Capsules', 'Probiotic supplement containing beneficial bacteria for digestive wellness.', 'Wellness Products', 1600.00, 35, 'assets/images/products/Probiotic Capsules.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(32, 'Zinc Tablets', 'Zinc supplement for daily nutritional support.', 'Wellness Products', 750.00, 50, 'assets/images/products/Zinc Tablets.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(33, 'Moisturizing Lotion', 'Daily moisturizing lotion designed to help keep skin soft and hydrated.', 'Personal Care', 850.00, 44, 'assets/images/products/Moisturizing Lotion.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(34, 'Facial Cleanser', 'Gentle facial cleanser for daily skincare and cleansing.', 'Personal Care', 650.00, 54, 'assets/images/products/Facial Cleanser.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(35, 'Sunscreen Lotion', 'Daily sunscreen lotion that helps protect skin from sun exposure.', 'Personal Care', 1450.00, 39, 'assets/images/products/Sunscreen Lotion.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(36, 'Shampoo', 'Everyday shampoo for hair cleansing and care.', 'Personal Care', 750.00, 60, 'assets/images/products/Shampoo.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(37, 'Conditioner', 'Hair conditioner designed to keep hair smooth and manageable.', 'Personal Care', 780.00, 49, 'assets/images/products/Conditioner.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(38, 'Body Wash', 'Gentle body wash for everyday skin cleansing.', 'Personal Care', 720.00, 54, 'assets/images/products/Body Wash.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(39, 'Hand Wash', 'Liquid hand wash for everyday hand hygiene and cleansing.', 'Personal Care', 380.00, 85, 'assets/images/products/Hand Wash.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(40, 'Toothpaste', 'Daily fluoride toothpaste for maintaining oral hygiene.', 'Personal Care', 320.00, 100, 'assets/images/products/Toothpaste.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(41, 'Deodorant', 'Everyday deodorant for freshness and odour control.', 'Personal Care', 650.00, 59, 'assets/images/products/Deodorant.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(42, 'Lip Balm', 'Moisturizing lip balm designed to help protect dry lips.', 'Personal Care', 280.00, 69, 'assets/images/products/Lip Balm.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(43, 'Digital Thermometer', 'Digital device used for measuring body temperature.', 'Medical Devices', 1200.00, 30, 'assets/images/products/Digital Thermometer.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(44, 'Blood Pressure Monitor', 'Digital device used for monitoring blood pressure at home.', 'Medical Devices', 6500.00, 20, 'assets/images/products/Blood Pressure Monitor.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(45, 'Blood Glucose Meter', 'Medical device used to measure blood glucose levels.', 'Medical Devices', 4200.00, 20, 'assets/images/products/Blood Glucose Meter.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(46, 'Pulse Oximeter', 'Portable device used to measure oxygen saturation and pulse rate.', 'Medical Devices', 3500.00, 25, 'assets/images/products/Pulse Oximeter.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(47, 'Nebulizer', 'Device used to deliver inhaled medication as a fine mist.', 'Medical Devices', 8500.00, 15, 'assets/images/products/Nebulizer.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(48, 'Digital Weighing Scale', 'Digital scale used to measure body weight.', 'Medical Devices', 4800.00, 20, 'assets/images/products/Digital Weighing Scale.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(49, 'Hot Water Bottle', 'Reusable hot water bottle used for heat therapy and comfort.', 'Medical Devices', 950.00, 35, 'assets/images/products/Hot Water Bottle.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(50, 'Elastic Bandage', 'Elastic support bandage for basic first aid and physical support.', 'Medical Devices', 450.00, 50, 'assets/images/products/Elastic Bandage.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(51, 'Baby Diapers', 'Comfortable disposable diapers designed for babies.', 'Baby Care', 1850.00, 45, 'assets/images/products/Baby Diapers.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(52, 'Baby Wipes', 'Gentle cleansing wipes suitable for everyday baby care.', 'Baby Care', 650.00, 75, 'assets/images/products/Baby Wipes.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(53, 'Baby Shampoo', 'Gentle shampoo designed for delicate baby hair and scalp.', 'Baby Care', 650.00, 60, 'assets/images/products/Baby Shampoo.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(54, 'Baby Lotion', 'Gentle moisturizing lotion designed for baby skin.', 'Baby Care', 750.00, 55, 'assets/images/products/Baby Lotion.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(55, 'Baby Feeding Bottle', 'Feeding bottle designed for convenient baby feeding.', 'Baby Care', 950.00, 40, 'assets/images/products/Baby Feeding Bottle.jpg', 0, 'Available', '2026-09-07 11:59:13'),
(56, 'Baby Soap', 'Mild cleansing soap specially formulated for baby skin.', 'Baby Care', 280.00, 79, 'assets/images/products/Baby Soap.jpg', 0, 'Available', '2026-09-07 11:59:13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('customer','admin','staff') DEFAULT 'customer',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `phone`, `address`, `city`, `password`, `role`, `created_at`) VALUES
(1, 'Nimal Fernando', 'fernando@gmail.com', '0758435701', 'NO 5, Matara', 'matara', '$2y$10$UfMts/eIZGWkdltFHMYlFezNsjtnY5iJNyEplIhbNME/LP/mGkhuG', 'customer', '2026-08-27 14:43:33'),
(2, 'Kamal', 'kamal@gmail.com', '0758487301', NULL, NULL, '$2y$10$jA/OyA0/4kyqqefD357RjuFVk8j31Q4cT0OYzOxrevzzqRFJrWJT2', 'staff', '2026-09-04 16:11:56'),
(3, 'Ishari', 'ishari@gmail.com', '0784567324', NULL, NULL, '$2y$10$C5R15dDzR8zJQJGFOOWQveC4HXnFta8rRBaawyMFRCGqdapGTInnC', 'admin', '2026-09-04 17:30:51'),
(4, 'Nadija I', 'nadija@gmail.com', '0702567098', NULL, NULL, '$2y$10$ZkMmlEIcEy7iY4tSaCy/dOhnP/boDNZ9qT3sJFDBlEnLfqmn3Bi0m', 'customer', '2026-11-10 05:37:28');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `user_id`, `product_id`, `created_at`) VALUES
(1, 1, 1, '2026-09-07 17:28:02'),
(3, 1, 54, '2026-09-20 12:54:52');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_number` (`order_number`),
  ADD KEY `fk_orders_user` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_order_items_order` (`order_id`),
  ADD KEY `fk_order_items_product` (`product_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_payments_order` (`order_id`);

--
-- Indexes for table `prescriptions`
--
ALTER TABLE `prescriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_prescriptions_user_id` (`user_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_product` (`user_id`,`product_id`),
  ADD KEY `fk_wishlist_product` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `prescriptions`
--
ALTER TABLE `prescriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `fk_order_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_order_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `fk_payments_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `fk_wishlist_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_wishlist_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
