<?php

// Start the user session.
session_start();

// Load the database connection.
require_once __DIR__ . '/config/database.php';

// Check whether the database connection is available.
if (!isset($conn) || !($conn instanceof mysqli) || $conn->connect_error) {
    die("Database connection failed.");
}

// Set the database character encoding.
$conn->set_charset("utf8mb4");

// Redirect users who are not logged in.
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Get the logged-in user's ID.
$userId = (int) $_SESSION['user_id'];

// Retrieve the logged-in user's details.
$stmt = $conn->prepare("
    SELECT id, full_name, email, phone
    FROM users
    WHERE id = ?
    LIMIT 1
");

if (!$stmt) {
    die("User query failed: " . htmlspecialchars($conn->error, ENT_QUOTES, 'UTF-8'));
}

$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = ($result && $result->num_rows === 1) ? $result->fetch_assoc() : null;
$stmt->close();

// End the session if the user account no longer exists.
if (!$user) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}

// Store the user's existing details.
$fullName = $user['full_name'] ?? '';
$email = $user['email'] ?? '';
$phone = $user['phone'] ?? '';

// Initialize the success and error messages.
$successMessage = '';
$errorMessage = '';

// Set the default patient details using the logged-in user's information.
$patientName = $fullName;
$patientPhone = $phone;
$patientEmail = $email;
$notes = '';

// Process the prescription form when it is submitted.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Retrieve and clean the submitted form values.
    $patientName = trim($_POST['patient_name'] ?? '');
    $patientPhone = trim($_POST['phone'] ?? '');
    $patientEmail = trim($_POST['email'] ?? '');
    $notes = trim($_POST['notes'] ?? '');

    // Validate the required patient information.
    if ($patientName === '') {
        $errorMessage = "Please enter the patient name.";
    } elseif ($patientPhone === '') {
        $errorMessage = "Please enter the phone number.";
    } elseif ($patientEmail === '') {
        $errorMessage = "Please enter the email address.";
    } elseif (!filter_var($patientEmail, FILTER_VALIDATE_EMAIL)) {
        $errorMessage = "Please enter a valid email address.";
    } elseif (!isset($_FILES['prescription_file'])) {
        $errorMessage = "Please select a prescription file.";
    } elseif ($_FILES['prescription_file']['error'] !== UPLOAD_ERR_OK) {
        $uploadError = (int) $_FILES['prescription_file']['error'];
        $errorMessage = "File upload failed. Error code: " . $uploadError;
    } else {

        // Retrieve the uploaded file information.
        $file = $_FILES['prescription_file'];
        $originalName = basename($file['name']);
        $tmpName = $file['tmp_name'];
        $fileSize = (int) $file['size'];

        // Get and validate the uploaded file extension.
        $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'pdf'];
        $maxFileSize = 5 * 1024 * 1024;

        if (!in_array($extension, $allowedExtensions, true)) {
            $errorMessage = "Only JPG, JPEG, PNG and PDF files are allowed.";
        } elseif ($fileSize <= 0) {
            $errorMessage = "The selected file is empty.";
        } elseif ($fileSize > $maxFileSize) {
            $errorMessage = "File size must be less than 5MB.";
        } elseif (!is_uploaded_file($tmpName)) {
            $errorMessage = "The uploaded file could not be verified. Please try again.";
        } else {

            // Verify the actual file type instead of trusting the browser value.
            $fileType = '';
            if (function_exists('finfo_open')) {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                if ($finfo) {
                    $fileType = finfo_file($finfo, $tmpName) ?: '';
                    finfo_close($finfo);
                }
            }

            $allowedMimeTypes = [
                'jpg'  => ['image/jpeg'],
                'jpeg' => ['image/jpeg'],
                'png'  => ['image/png'],
                'pdf'  => ['application/pdf']
            ];

            if ($fileType === '' || !in_array($fileType, $allowedMimeTypes[$extension], true)) {
                $errorMessage = "The selected file type is invalid. Please upload a valid JPG, PNG or PDF file.";
            } else {

                // Build the absolute path to the prescription upload folder.
                $uploadDirectory = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'prescriptions' . DIRECTORY_SEPARATOR;

                // Create the upload folder when it does not already exist.
                if (!is_dir($uploadDirectory) && !mkdir($uploadDirectory, 0755, true)) {
                    $errorMessage = "Unable to create uploads/prescriptions folder.";
                }

                // Check whether the upload folder is writable.
                if ($errorMessage === '' && !is_writable($uploadDirectory)) {
                    $errorMessage = "The uploads/prescriptions folder is not writable.";
                }

                if ($errorMessage === '') {

                    // Generate a unique filename to prevent overwriting another customer's file.
                    try {
                        $randomString = bin2hex(random_bytes(8));
                    } catch (Exception $e) {
                        $randomString = str_replace('.', '', uniqid('', true));
                    }

                    $newFileName = 'prescription_' . $userId . '_' . date('Ymd_His') . '_' . $randomString . '.' . $extension;
                    $destination = $uploadDirectory . $newFileName;

                    // Move the uploaded file into uploads/prescriptions.
                    if (!move_uploaded_file($tmpName, $destination)) {
                        $errorMessage = "Unable to save the uploaded file. Please check the uploads/prescriptions folder permissions.";
                    } else {

                        // Store a relative path so all account pages can build the same URL.
                        $databaseFilePath = 'uploads/prescriptions/' . $newFileName;

                        // Keep the original uploaded filename in the database for display.
                        $originalName = preg_replace('/[^A-Za-z0-9._ -]/', '_', $originalName);

                        // Read the allowed Pending value from the table's ENUM definition.
                        // The current table uses Pending; this also supports an older Pending Review ENUM if present.
                        $pendingStatus = 'Pending';
                        $statusResult = $conn->query("SHOW COLUMNS FROM prescriptions LIKE 'status'");
                        if ($statusResult && ($statusColumn = $statusResult->fetch_assoc())) {
                            if (strpos($statusColumn['Type'], "'Pending'") === false && strpos($statusColumn['Type'], "'Pending Review'") !== false) {
                                $pendingStatus = 'Pending Review';
                            }
                            $statusResult->free();
                        }

                        // Insert the prescription record without changing the database structure.
                        $insert = $conn->prepare("
                            INSERT INTO prescriptions
                            (
                                user_id,
                                patient_name,
                                phone,
                                email,
                                file_name,
                                file_path,
                                file_type,
                                notes,
                                status
                            )
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ");

                        if (!$insert) {
                            // Keep the uploaded file so it is not lost if the database insert needs troubleshooting.
                            $errorMessage = "Database prepare error: " . $conn->error . " Uploaded file is saved as: " . $databaseFilePath;
                        } else {

                            // Bind the prescription details to the prepared statement.
                            $insert->bind_param(
                                "issssssss",
                                $userId,
                                $patientName,
                                $patientPhone,
                                $patientEmail,
                                $originalName,
                                $databaseFilePath,
                                $fileType,
                                $notes,
                                $pendingStatus
                            );

                            // Save the prescription record.
                            if (!$insert->execute()) {
                                // Do not delete the file when the database insert fails.
                                $errorMessage = "Database insert failed: " . $insert->error . " Uploaded file is saved as: " . $databaseFilePath;
                            } else {
                                $newPrescriptionId = $conn->insert_id;
                                $successMessage = "Prescription uploaded successfully! Your prescription ID is #" . $newPrescriptionId . ". Our pharmacy team will review it shortly.";

                                // Reset the form fields after a successful upload.
                                $patientName = $fullName;
                                $patientPhone = $phone;
                                $patientEmail = $email;
                                $notes = '';
                            }

                            $insert->close();
                        }
                    }
                }
            }
        }
    }
}

// Load the common website header.
include 'includes/header.php';

?>

<section class="prescription-section">

    <div class="prescription-container">

        <div class="prescription-heading">

            <span class="small-title">
                MEDIQUICK PHARMACY
            </span>

            <h1>
                Prescription Upload
            </h1>

            <p>
                Upload your prescription and our pharmacy team
                will review it.
            </p>

        </div>

        <?php if ($successMessage !== ''): ?>

            <div class="message success-message">

                <i class="bi bi-check-circle-fill"></i>

                <div>

                    <strong>
                        Upload Successful
                    </strong>

                    <p>
                        <?php
                        // Display the success message safely.
                        echo htmlspecialchars(
                            $successMessage,
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?>
                    </p>

                </div>

            </div>

        <?php endif; ?>

        <?php if ($errorMessage !== ''): ?>

            <div class="message error-message">

                <i class="bi bi-exclamation-circle-fill"></i>

                <div>

                    <strong>
                        Upload Failed
                    </strong>

                    <p>
                        <?php
                        // Display the error message safely.
                        echo htmlspecialchars(
                            $errorMessage,
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?>
                    </p>

                </div>

            </div>

        <?php endif; ?>

        <div class="prescription-layout">

            <div class="prescription-form-card">

                <h2>
                    Upload Prescription
                </h2>

                <p class="form-description">

                    Please provide your details and upload a clear
                    image or PDF of your prescription.

                </p>

                <form
                    id="prescriptionForm"
                    method="POST"
                    action=""
                    enctype="multipart/form-data"
                >

                    <div class="form-group">

                        <label for="patientName">

                            Full Name

                            <span>*</span>

                        </label>

                        <input
                            type="text"
                            id="patientName"
                            name="patient_name"
                            value="<?php
                            // Display the patient name safely.
                            echo htmlspecialchars(
                                $patientName,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>"
                            placeholder="Enter your full name"
                            required
                        >

                    </div>

                    <div class="form-group">

                        <label for="phone">

                            Phone Number

                            <span>*</span>

                        </label>

                        <input
                            type="tel"
                            id="phone"
                            name="phone"
                            value="<?php
                            // Display the patient phone number safely.
                            echo htmlspecialchars(
                                $patientPhone,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>"
                            placeholder="Enter your phone number"
                            required
                        >

                    </div>

                    <div class="form-group">

                        <label for="email">

                            Email Address

                            <span>*</span>

                        </label>

                        <input
                            type="email"
                            id="email"
                            name="email"
                            value="<?php
                            // Display the patient email address safely.
                            echo htmlspecialchars(
                                $patientEmail,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>"
                            placeholder="Enter your email address"
                            required
                        >

                    </div>

                    <div class="form-group">

                        <label for="prescriptionFile">

                            Prescription File

                            <span>*</span>

                        </label>

                        <div
                            class="upload-box"
                            id="uploadBox"
                        >

                            <i class="bi bi-cloud-arrow-up"></i>

                            <h3>
                                Upload your prescription
                            </h3>

                            <p>
                                JPG, PNG or PDF files only
                            </p>

                            <span>
                                Maximum file size: 5MB
                            </span>

                            <input
                                type="file"
                                id="prescriptionFile"
                                name="prescription_file"
                                accept=".jpg,.jpeg,.png,.pdf"
                                required
                            >

                            <label
                                for="prescriptionFile"
                                class="choose-file-button"
                            >

                                Choose File

                            </label>

                            <div
                                id="selectedFile"
                                class="selected-file"
                            ></div>

                        </div>

                    </div>

                    <div class="form-group">

                        <label for="notes">

                            Additional Notes

                            <small>
                                Optional
                            </small>

                        </label>

                        <textarea
                            id="notes"
                            name="notes"
                            rows="5"
                            placeholder="Enter any additional information..."
                        ><?php
                        // Display the additional notes safely.
                        echo htmlspecialchars(
                            $notes,
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?></textarea>

                    </div>

                    <button
                        type="submit"
                        class="upload-button"
                        id="uploadButton"
                    >

                        <i class="bi bi-upload"></i>

                        Submit Prescription

                    </button>

                </form>

            </div>

            <div class="prescription-info-card">

                <div class="info-icon">

                    <i class="bi bi-file-earmark-medical"></i>

                </div>

                <h2>
                    How It Works
                </h2>

                <div class="order-process-image">

                    <img
                        src="assets/images/Order Process.jpg"
                        alt="MediQuick Pharmacy Order Process"
                    >

                </div>

                <div class="info-step">

                    <div class="step-number">
                        1
                    </div>

                    <div>

                        <h3>
                            Visit Our Website
                        </h3>

                        <p>
                            Visit the MediQuick Pharmacy website
                            to access our healthcare services.
                        </p>

                    </div>

                </div>

                <div class="info-step">

                    <div class="step-number">
                        2
                    </div>

                    <div>

                        <h3>
                            Upload Prescription
                        </h3>

                        <p>
                            Upload a clear photo or PDF of
                            your prescription and submit it
                            for review.
                        </p>

                    </div>

                </div>

                <div class="info-step">

                    <div class="step-number">
                        3
                    </div>

                    <div>

                        <h3>
                            Pharmacy Review
                        </h3>

                        <p>
                            Our pharmacy team will review
                            your prescription and contact
                            you if necessary.
                        </p>

                    </div>

                </div>

                <div class="info-step">

                    <div class="step-number">
                        4
                    </div>

                    <div>

                        <h3>
                            Get Your Medicines
                        </h3>

                        <p>
                            Once your prescription is confirmed,
                            your medicines can be prepared
                            for delivery.
                        </p>

                    </div>

                </div>

                <div class="prescription-note">

                    <i class="bi bi-shield-check"></i>

                    <div>

                        <strong>
                            Your information is secure
                        </strong>

                        <p>
                            Your prescription details are securely
                            stored and accessed only by authorized
                            pharmacy staff.
                        </p>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>

<style>

/* Main prescription page layout. */
.prescription-section {

    background: #f6fbfd;

    min-height: 80vh;

    padding: 60px 20px;

}

/* Center the page content. */
.prescription-container {

    max-width: 1100px;

    margin: auto;

}

/* Prescription page heading. */
.prescription-heading {

    text-align: center;

    margin-bottom: 40px;

}

.small-title {

    color: #087f9b;

    font-size: 13px;

    font-weight: 700;

    letter-spacing: 2px;

}

.prescription-heading h1 {

    color: #174f68;

    margin: 8px 0;

    font-size: 38px;

}

.prescription-heading p {

    color: #777;

    margin: 0;

}

/* Success and error message styles. */
.message {

    display: flex;

    align-items: flex-start;

    gap: 12px;

    padding: 15px 18px;

    border-radius: 10px;

    margin-bottom: 25px;

}

.message > i {

    font-size: 21px;

}

.message strong {

    display: block;

    font-size: 14px;

}

.message p {

    margin: 4px 0 0;

    font-size: 13px;

}

.success-message {

    background: #eaf8f0;

    border: 1px solid #c9ead8;

    color: #1d7d50;

}

.error-message {

    background: #fff1f1;

    border: 1px solid #f0cccc;

    color: #c62828;

}

/* Arrange the form and information cards. */
.prescription-layout {

    display: grid;

    grid-template-columns: 1.45fr 1fr;

    gap: 30px;

}

/* Shared card styles. */
.prescription-form-card,
.prescription-info-card {

    background: white;

    border-radius: 16px;

    padding: 30px;

    box-shadow:
        0 5px 25px
        rgba(0, 80, 110, 0.08);

}

.prescription-form-card h2,
.prescription-info-card h2 {

    color: #174f68;

    margin-top: 0;

}

.form-description {

    color: #777;

    font-size: 14px;

    line-height: 1.6;

    margin-bottom: 25px;

}

/* Prescription form field styles. */
.form-group {

    margin-bottom: 20px;

}

.form-group label {

    display: block;

    margin-bottom: 8px;

    color: #174f68;

    font-weight: 600;

    font-size: 14px;

}

.form-group label span {

    color: #e74c3c;

}

.form-group label small {

    color: #999;

    font-weight: 400;

    margin-left: 5px;

}

.form-group input[type="text"],
.form-group input[type="tel"],
.form-group input[type="email"],
.form-group textarea {

    width: 100%;

    box-sizing: border-box;

    padding: 13px 14px;

    border: 1px solid #d8e5e9;

    border-radius: 8px;

    background: white;

    font-family: inherit;

    font-size: 14px;

    outline: none;

    transition: 0.2s;

}

.form-group textarea {

    resize: vertical;

}

/* Highlight form fields when they are selected. */
.form-group input:focus,
.form-group textarea:focus {

    border-color: #087f9b;

    box-shadow:
        0 0 0 3px
        rgba(8, 127, 155, 0.08);

}

/* Prescription file upload area. */
.upload-box {

    position: relative;

    border: 2px dashed #c9dfe5;

    border-radius: 12px;

    background: #f9fcfd;

    text-align: center;

    padding: 30px 20px;

    transition: 0.2s;

}

.upload-box:hover {

    border-color: #087f9b;

    background: #f5fbfc;

}

.upload-box.dragover {

    border-color: #087f9b;

    background: #f1fafb;

}

.upload-box > i {

    display: block;

    color: #087f9b;

    font-size: 42px;

    margin-bottom: 10px;

}

.upload-box h3 {

    color: #174f68;

    font-size: 17px;

    margin: 5px 0;

}

.upload-box p {

    color: #777;

    margin: 5px 0;

    font-size: 13px;

}

.upload-box span {

    display: block;

    color: #999;

    font-size: 12px;

    margin-bottom: 18px;

}

#prescriptionFile {

    display: none;

}

/* File selection button. */
.choose-file-button {

    display: inline-block !important;

    background: #087f9b;

    color: white !important;

    padding: 10px 18px;

    border-radius: 8px;

    cursor: pointer;

    font-size: 13px !important;

    font-weight: 600 !important;

    margin: 0 !important;

}

.choose-file-button:hover {

    background: #056b83;

}

/* Display the selected file information. */
.selected-file {

    margin-top: 15px;

    color: #087f9b;

    font-size: 13px;

    font-weight: 600;

    word-break: break-word;

}

/* Prescription submission button. */
.upload-button {

    width: 100%;

    border: none;

    background: #087f9b;

    color: white;

    padding: 15px;

    border-radius: 9px;

    font-size: 16px;

    font-weight: 700;

    cursor: pointer;

    transition: 0.2s;

}

.upload-button:hover {

    background: #056b83;

    transform: translateY(-1px);

}

.upload-button:disabled {

    opacity: 0.7;

    cursor: not-allowed;

    transform: none;

}

/* Information card icon. */
.info-icon {

    width: 55px;

    height: 55px;

    border-radius: 12px;

    background: #e8f7fa;

    display: flex;

    align-items: center;

    justify-content: center;

    margin-bottom: 15px;

}

.info-icon i {

    color: #087f9b;

    font-size: 28px;

}

/* Order process image. */
.order-process-image {

    width: 100%;

    margin-bottom: 28px;

    border-radius: 12px;

    overflow: hidden;

    background: #f5fafc;

}

.order-process-image img {

    display: block;

    width: 100%;

    height: auto;

    object-fit: contain;

}

/* Steps explaining the prescription process. */
.info-step {

    display: flex;

    gap: 15px;

    margin-bottom: 22px;

}

.step-number {

    min-width: 34px;

    width: 34px;

    height: 34px;

    border-radius: 50%;

    background: #087f9b;

    color: white;

    display: flex;

    align-items: center;

    justify-content: center;

    font-weight: 700;

    font-size: 14px;

}

.info-step h3 {

    color: #174f68;

    margin: 0 0 5px;

    font-size: 15px;

}

.info-step p {

    color: #777;

    margin: 0;

    font-size: 13px;

    line-height: 1.5;

}

/* Prescription security information. */
.prescription-note {

    display: flex;

    gap: 12px;

    align-items: flex-start;

    background: #f1fafb;

    border-radius: 10px;

    padding: 15px;

    margin-top: 25px;

}

.prescription-note > i {

    color: #087f9b;

    font-size: 22px;

}

.prescription-note strong {

    color: #174f68;

    font-size: 13px;

}

.prescription-note p {

    color: #777;

    font-size: 12px;

    line-height: 1.5;

    margin: 5px 0 0;

}

/* Responsive layout for smaller screens. */
@media (max-width: 850px) {

    .prescription-layout {

        grid-template-columns: 1fr;

    }

}

@media (max-width: 600px) {

    .prescription-section {

        padding: 40px 15px;

    }

    .prescription-form-card,
    .prescription-info-card {

        padding: 20px;

    }

    .prescription-heading h1 {

        font-size: 30px;

    }

}

</style>

<script>

// Run the prescription upload interactions after the page loads.
document.addEventListener(
    "DOMContentLoaded",
    function () {

        // Get the prescription form elements.
        const fileInput =
            document.getElementById(
                "prescriptionFile"
            );

        const selectedFile =
            document.getElementById(
                "selectedFile"
            );

        const uploadBox =
            document.getElementById(
                "uploadBox"
            );

        const form =
            document.getElementById(
                "prescriptionForm"
            );

        const uploadButton =
            document.getElementById(
                "uploadButton"
            );

        // Validate the selected file and display its details.
        if (fileInput) {

            fileInput.addEventListener(
                "change",
                function () {

                    // Clear the displayed file name when no file is selected.
                    if (!this.files.length) {

                        selectedFile.textContent = "";

                        return;

                    }

                    // Retrieve the selected file.
                    const file =
                        this.files[0];

                    // Check the selected file size.
                    if (
                        file.size >
                        5 * 1024 * 1024
                    ) {

                        alert(
                            "File size must be less than 5MB."
                        );

                        this.value = "";

                        selectedFile.textContent =
                            "";

                        return;

                    }

                    // Define the permitted file extensions.
                    const fileName =
                        file.name.toLowerCase();

                    const allowedExtensions = [

                        ".jpg",
                        ".jpeg",
                        ".png",
                        ".pdf"

                    ];

                    // Check whether the selected file has an allowed extension.
                    const validExtension =
                        allowedExtensions.some(
                            function (extension) {

                                return fileName.endsWith(
                                    extension
                                );

                            }
                        );

                    // Reject files with unsupported extensions.
                    if (!validExtension) {

                        alert(
                            "Please upload a JPG, JPEG, PNG or PDF file."
                        );

                        this.value = "";

                        selectedFile.textContent =
                            "";

                        return;

                    }

                    // Convert the file size into megabytes.
                    const sizeMB =
                        (
                            file.size /
                            (1024 * 1024)
                        ).toFixed(2);

                    // Display the selected file name and size.
                    selectedFile.innerHTML =

                        '<i class="bi bi-check-circle-fill"></i> ' +

                        file.name +

                        ' (' +

                        sizeMB +

                        ' MB)';

                }
            );

        }

        // Enable drag-and-drop file selection.
        if (uploadBox) {

            // Highlight the upload area when a file is dragged over it.
            uploadBox.addEventListener(
                "dragover",
                function (event) {

                    event.preventDefault();

                    uploadBox.classList.add(
                        "dragover"
                    );

                }
            );

            // Remove the highlight when the dragged file leaves the upload area.
            uploadBox.addEventListener(
                "dragleave",
                function () {

                    uploadBox.classList.remove(
                        "dragover"
                    );

                }
            );

            // Process the file when it is dropped into the upload area.
            uploadBox.addEventListener(
                "drop",
                function (event) {

                    event.preventDefault();

                    uploadBox.classList.remove(
                        "dragover"
                    );

                    const files =
                        event.dataTransfer.files;

                    if (!files.length) {

                        return;

                    }

                    // Assign the dropped file to the file input.
                    try {

                        fileInput.files =
                            files;

                        fileInput.dispatchEvent(
                            new Event("change")
                        );

                    } catch (error) {

                        console.log(error);

                    }

                }
            );

        }

        // Handle the prescription form submission.
        if (form) {

            form.addEventListener(
                "submit",
                function () {

                    // Ensure a prescription file has been selected.
                    if (
                        !fileInput.files.length
                    ) {

                        alert(
                            "Please select your prescription file."
                        );

                        return;

                    }

                    // Disable the button and show the upload status.
                    if (uploadButton) {

                        uploadButton.disabled =
                            true;

                        uploadButton.innerHTML =

                            '<i class="bi bi-arrow-repeat"></i> Uploading...';

                    }

                }
            );

        }

    }
);

</script>

<?php

// Load the common website footer.
include 'includes/footer.php';

?>