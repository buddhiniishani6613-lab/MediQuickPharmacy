<?php

include 'config/database.php';

/*
 * Convert the database category name into the matching
 * product image folder name.
 */
function getCategoryFolder($categoryName)
{
    $folders = [
        "Prescription"           => "Prescription Medicines",
        "Prescription Medicines" => "Prescription Medicines",
        "OTC Products"           => "OTC Products",
        "Wellness Products"      => "Wellness Products",
        "Personal Care"          => "Personal Care",
        "Medical Devices"        => "Medical Devices",
        "Baby Care"              => "Baby Care"
    ];

    return $folders[$categoryName] ?? $categoryName;
}

/*
 * Find the product image from the current assets/images/products
 * folder structure.
 *
 * Current image structure:
 *
 * assets/images/products/Baby Care/Baby Shampoo.jpg
 * assets/images/products/Baby Care/Baby Wipes.jpg
 * assets/images/products/OTC Products/Paracetamol.jpg
 * assets/images/products/Prescription Medicines/Amoxicillin.jpg
 *
 * The database image field may contain either a filename or
 * an older path. The function extracts the filename and checks
 * the correct category folder.
 */
function getProductImage($categoryName, $databaseImage, $productName)
{
    /*
     * Get the correct category folder.
     */
    $folder = getCategoryFolder($categoryName);

    /*
     * Build the server-side folder path.
     *
     * __DIR__ points to the root MediQuickPharmacy folder
     * because product-details.php is located there.
     */
    $serverFolder =
        __DIR__ .
        DIRECTORY_SEPARATOR .
        "assets" .
        DIRECTORY_SEPARATOR .
        "images" .
        DIRECTORY_SEPARATOR .
        "products" .
        DIRECTORY_SEPARATOR .
        $folder .
        DIRECTORY_SEPARATOR;

    /*
     * Build the browser URL for the same folder.
     *
     * rawurlencode() safely handles spaces in folder names
     * and file names.
     */
    $webFolder =
        "assets/images/products/" .
        rawurlencode($folder) .
        "/";

    /*
     * 1. Check the image path stored in the database.
     */
    if (!empty($databaseImage)) {

        $databaseImage = trim($databaseImage);

        /*
         * Extract only the filename.
         *
         * Example:
         * assets/images/products/Baby Shampoo.jpg
         *
         * becomes:
         * Baby Shampoo.jpg
         */
        $fileName = basename($databaseImage);

        /*
         * Check whether the file exists inside the
         * correct category folder.
         */
        $fullPath =
            $serverFolder .
            $fileName;

        if (file_exists($fullPath)) {

            return
                $webFolder .
                rawurlencode($fileName);
        }
    }

    /*
     * 2. Check the exact product name with .jpg extension.
     */
    $jpgFile =
        $productName .
        ".jpg";

    if (
        file_exists(
            $serverFolder .
            $jpgFile
        )
    ) {

        return
            $webFolder .
            rawurlencode($jpgFile);
    }

    /*
     * 3. Check the exact product name with .jpeg extension.
     */
    $jpegFile =
        $productName .
        ".jpeg";

    if (
        file_exists(
            $serverFolder .
            $jpegFile
        )
    ) {

        return
            $webFolder .
            rawurlencode($jpegFile);
    }

    /*
     * 4. Check the exact product name with .png extension.
     */
    $pngFile =
        $productName .
        ".png";

    if (
        file_exists(
            $serverFolder .
            $pngFile
        )
    ) {

        return
            $webFolder .
            rawurlencode($pngFile);
    }

    /*
     * 5. Remove dosage information from the product name.
     *
     * Example:
     * Amoxicillin 500mg
     *
     * becomes:
     * Amoxicillin
     *
     * This allows the system to find:
     * Amoxicillin.jpg
     */
    $cleanName =
        preg_replace(
            '/\s+\d+(?:\.\d+)?\s*(?:mg|mcg|g|ml|l|%)\b/i',
            '',
            $productName
        );

    $cleanName = trim($cleanName);

    /*
     * Only continue if the product name was actually changed.
     */
    if ($cleanName !== $productName) {

        /*
         * Check cleaned product name with .jpg.
         */
        $cleanJpg =
            $cleanName .
            ".jpg";

        if (
            file_exists(
                $serverFolder .
                $cleanJpg
            )
        ) {

            return
                $webFolder .
                rawurlencode($cleanJpg);
        }

        /*
         * Check cleaned product name with .jpeg.
         */
        $cleanJpeg =
            $cleanName .
            ".jpeg";

        if (
            file_exists(
                $serverFolder .
                $cleanJpeg
            )
        ) {

            return
                $webFolder .
                rawurlencode($cleanJpeg);
        }

        /*
         * Check cleaned product name with .png.
         */
        $cleanPng =
            $cleanName .
            ".png";

        if (
            file_exists(
                $serverFolder .
                $cleanPng
            )
        ) {

            return
                $webFolder .
                rawurlencode($cleanPng);
        }
    }

    /*
     * No product image was found.
     *
     * Return an empty string so the page can display
     * the "Image not available" message.
     */
    return "";
}

/*
 * Get the product ID from the URL.
 */
$productId =
    isset($_GET['id'])
        ? (int) $_GET['id']
        : 0;

/*
 * Redirect to the products page if an invalid
 * product ID was supplied.
 */
if ($productId <= 0) {

    header("Location: products.php");
    exit;
}

/*
 * Get the selected product from the database.
 *
 * The current products table uses:
 * name
 * category
 * stock_quantity
 *
 * It does not use:
 * product_name
 * category_id
 */
$stmt = $conn->prepare(
    "
    SELECT
        id,
        name,
        description,
        category,
        price,
        stock_quantity,
        image,
        requires_prescription,
        status
    FROM products
    WHERE id = ?
    AND status = 'Available'
    LIMIT 1
    "
);

if (!$stmt) {

    die(
        "Database prepare failed: " .
        htmlspecialchars(
            $conn->error
        )
    );
}

/*
 * Bind the product ID to the prepared statement.
 */
$stmt->bind_param(
    "i",
    $productId
);

/*
 * Execute the product query.
 */
$stmt->execute();

$result =
    $stmt->get_result();

/*
 * Redirect if the product does not exist
 * or is not currently available.
 */
if (
    !$result ||
    $result->num_rows === 0
) {

    header("Location: products.php");
    exit;
}

/*
 * Get the product information.
 */
$product =
    $result->fetch_assoc();

$name =
    $product['name'];

$category =
    $product['category'];

$description =
    $product['description'] ?? "";

$price =
    (float) $product['price'];

$stock =
    (int) $product['stock_quantity'];

$databaseImage =
    $product['image'] ?? "";

/*
 * Find the actual product image.
 */
$imagePath =
    getProductImage(
        $category,
        $databaseImage,
        $name
    );

/*
 * Load the common website header.
 */
include 'includes/header.php';
?>

<!-- Product details section -->
<section class="details-section">

    <div class="details-container">

        <!-- Back to products link -->
        <a
            href="products.php"
            class="back-link"
        >
            <i class="bi bi-arrow-left"></i>
            Back to Products
        </a>

        <!-- Product details card -->
        <div class="details-card">

            <!-- Product image area -->
            <div class="details-image-box">

                <?php if (!empty($imagePath)): ?>

                    <img
                        src="<?php
                            echo htmlspecialchars(
                                $imagePath,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                        ?>"
                        alt="<?php
                            echo htmlspecialchars(
                                $name,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                        ?>"
                        class="details-image"
                        onerror="
                            this.style.display='none';
                            this.nextElementSibling.style.display='flex';
                        "
                    >

                    <div
                        class="image-not-available"
                        style="display:none;"
                    >
                        <i class="bi bi-image"></i>

                        <span>
                            Image not available
                        </span>
                    </div>

                <?php else: ?>

                    <div class="image-not-available">

                        <i class="bi bi-image"></i>

                        <span>
                            Image not available
                        </span>

                    </div>

                <?php endif; ?>

            </div>

            <!-- Product information -->
            <div class="details-content">

                <!-- Category -->
                <span class="details-category">

                    <?php
                    echo htmlspecialchars(
                        $category,
                        ENT_QUOTES,
                        'UTF-8'
                    );
                    ?>

                </span>

                <!-- Product name -->
                <h1>

                    <?php
                    echo htmlspecialchars(
                        $name,
                        ENT_QUOTES,
                        'UTF-8'
                    );
                    ?>

                </h1>

                <!-- Product price -->
                <div class="details-price">

                    Rs.

                    <?php
                    echo number_format(
                        $price,
                        2
                    );
                    ?>

                </div>

                <!-- Product stock -->
                <div class="details-stock">

                    <?php if ($stock > 0): ?>

                        <span class="stock-available">

                            <i class="bi bi-check-circle-fill"></i>

                            Available

                        </span>

                        <small>

                            <?php
                            echo $stock;
                            ?>

                            in stock

                        </small>

                    <?php else: ?>

                        <span class="stock-unavailable">

                            <i class="bi bi-x-circle-fill"></i>

                            Out of Stock

                        </span>

                    <?php endif; ?>

                </div>

                <!-- Product description -->
                <div class="details-description">

                    <h3>
                        Product Description
                    </h3>

                    <p>

                        <?php
                        echo nl2br(
                            htmlspecialchars(
                                $description,
                                ENT_QUOTES,
                                'UTF-8'
                            )
                        );
                        ?>

                    </p>

                </div>

                <!-- Product actions -->
                <?php if ($stock > 0): ?>

                    <div class="details-actions">

                        <label>
                            Quantity
                        </label>

                        <div class="quantity-box">

                            <button
                                type="button"
                                onclick="decreaseDetailQuantity()"
                            >
                                −
                            </button>

                            <span id="detailQuantity">
                                1
                            </span>

                            <button
                                type="button"
                                onclick="increaseDetailQuantity()"
                            >
                                +
                            </button>

                        </div>

                        <button
                            type="button"
                            class="detail-cart-button"
                            onclick="addDetailToCart()"
                        >
                            <i class="bi bi-cart-plus"></i>
                            Add to Cart
                        </button>

                    </div>

                <?php else: ?>

                    <button
                        type="button"
                        class="detail-cart-button disabled"
                        disabled
                    >
                        <i class="bi bi-cart-x"></i>
                        Out of Stock
                    </button>

                <?php endif; ?>

            </div>

        </div>

    </div>

</section>

<!-- Product details page styling -->
<style>

.details-section {
    background: #f6fbfd;
    min-height: 80vh;
    padding: 55px 20px 70px;
}

.details-container {
    max-width: 1100px;
    margin: auto;
}

.back-link {
    display: inline-block;
    color: #087f9b;
    text-decoration: none;
    font-weight: 600;
    margin-bottom: 20px;
}

.back-link:hover {
    color: #056b83;
}

.details-card {
    background: white;
    border-radius: 18px;
    overflow: hidden;
    display: grid;
    grid-template-columns: 1fr 1fr;
    box-shadow:
        0 8px 30px
        rgba(
            0,
            80,
            110,
            0.08
        );
}

.details-image-box {
    min-height: 500px;
    background: #f5fafc;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
}

.details-image {
    width: 100%;
    height: 100%;
    max-height: 500px;
    object-fit: contain;
    padding: 45px;
    display: block;
}

.image-not-available {
    width: 100%;
    height: 100%;
    min-height: 500px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 10px;
    color: #9aaeb5;
    font-size: 15px;
}

.image-not-available i {
    font-size: 55px;
    color: #b9cdd3;
}

.details-content {
    padding: 55px 45px;
}

.details-category {
    color: #087f9b;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.details-content h1 {
    color: #174f68;
    font-size: 32px;
    margin: 12px 0 15px;
}

.details-price {
    color: #087f9b;
    font-size: 28px;
    font-weight: 700;
}

.details-stock {
    margin-top: 15px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.stock-available {
    color: #16834b;
    font-weight: 700;
}

.stock-unavailable {
    color: #dc3545;
    font-weight: 700;
}

.details-stock small {
    color: #777;
}

.details-description {
    margin-top: 35px;
}

.details-description h3 {
    color: #174f68;
    font-size: 19px;
    margin-bottom: 10px;
}

.details-description p {
    color: #666;
    line-height: 1.7;
    margin: 0;
}

.details-actions {
    margin-top: 35px;
}

.details-actions label {
    display: block;
    color: #174f68;
    font-weight: 600;
    margin-bottom: 8px;
}

.quantity-box {
    display: inline-flex;
    align-items: center;
    border: 1px solid #d8e5e9;
    border-radius: 8px;
    overflow: hidden;
}

.quantity-box button {
    width: 40px;
    height: 40px;
    border: none;
    background: #eef8fb;
    color: #087f9b;
    font-size: 20px;
    cursor: pointer;
}

.quantity-box button:hover {
    background: #dff3f7;
}

.quantity-box span {
    width: 45px;
    text-align: center;
    font-weight: 700;
}

.detail-cart-button {
    display: block;
    width: 100%;
    margin-top: 18px;
    padding: 14px;
    border: none;
    border-radius: 9px;
    background: #087f9b;
    color: white;
    font-weight: 700;
    cursor: pointer;
    font-size: 15px;
}

.detail-cart-button:hover {
    background: #056b83;
}

.detail-cart-button.disabled {
    background: #b8c4c8;
    cursor: not-allowed;
}

@media (max-width: 750px) {

    .details-card {
        grid-template-columns: 1fr;
    }

    .details-image-box {
        min-height: 350px;
    }

    .image-not-available {
        min-height: 350px;
    }

    .details-content {
        padding: 30px;
    }

    .details-content h1 {
        font-size: 27px;
    }
}

</style>

<!-- Product details cart functionality -->
<script>

/*
 * Current product information passed from PHP to JavaScript.
 */
const detailProduct = {

    id:
        <?php
        echo (int) $productId;
        ?>,

    name:
        <?php
        echo json_encode(
            $name,
            JSON_UNESCAPED_UNICODE |
            JSON_UNESCAPED_SLASHES
        );
        ?>,

    price:
        <?php
        echo json_encode($price);
        ?>,

    image:
        <?php
        echo json_encode(
            $imagePath,
            JSON_UNESCAPED_UNICODE |
            JSON_UNESCAPED_SLASHES
        );
        ?>,

    stock:
        <?php
        echo (int) $stock;
        ?>

};

/*
 * Default product quantity.
 */
let detailQuantity = 1;

/*
 * Increase the selected quantity while respecting
 * the available stock.
 */
function increaseDetailQuantity()
{
    if (
        detailQuantity <
        detailProduct.stock
    ) {

        detailQuantity++;

        document.getElementById(
            "detailQuantity"
        ).textContent =
            detailQuantity;

    } else {

        alert(
            "You cannot add more than the available stock."
        );
    }
}

/*
 * Decrease the selected quantity.
 */
function decreaseDetailQuantity()
{
    if (
        detailQuantity > 1
    ) {

        detailQuantity--;

        document.getElementById(
            "detailQuantity"
        ).textContent =
            detailQuantity;
    }
}

/*
 * Add the current product to the browser cart.
 */
function addDetailToCart()
{
    /*
     * Start with an empty cart.
     */
    let cart = [];

    /*
     * Load the existing cart from localStorage.
     */
    try {

        const storedCart =
            localStorage.getItem(
                "mediquickCart"
            );

        if (storedCart) {

            const parsedCart =
                JSON.parse(
                    storedCart
                );

            if (
                Array.isArray(
                    parsedCart
                )
            ) {

                cart =
                    parsedCart;
            }
        }

    } catch (error) {

        console.error(
            "Cart loading error:",
            error
        );

        cart = [];
    }

    /*
     * Find the current product if it already exists
     * in the cart.
     */
    let existing =
        cart.find(
            function(item)
            {
                return Number(
                    item.product_id ||
                    item.id
                ) ===
                detailProduct.id;
            }
        );

    /*
     * Update the existing product quantity.
     */
    if (existing) {

        const oldQuantity =
            Number(
                existing.quantity
            ) || 0;

        const newQuantity =
            oldQuantity +
            detailQuantity;

        /*
         * Prevent the cart quantity from exceeding
         * the available stock.
         */
        if (
            newQuantity >
            detailProduct.stock
        ) {

            alert(
                "You cannot add more than the available stock."
            );

            return;
        }

        /*
         * Update the existing cart item.
         */
        existing.product_id =
            detailProduct.id;

        existing.name =
            detailProduct.name;

        existing.price =
            detailProduct.price;

        existing.image =
            detailProduct.image;

        existing.stock =
            detailProduct.stock;

        existing.quantity =
            newQuantity;

    } else {

        /*
         * Add the product as a new cart item.
         */
        cart.push({

            product_id:
                detailProduct.id,

            name:
                detailProduct.name,

            price:
                detailProduct.price,

            image:
                detailProduct.image,

            stock:
                detailProduct.stock,

            quantity:
                detailQuantity
        });
    }

    /*
     * Save the updated cart.
     */
    localStorage.setItem(
        "mediquickCart",
        JSON.stringify(
            cart
        )
    );

    /*
     * Show a confirmation message.
     */
    alert(
        detailProduct.name +
        " has been added to your cart."
    );

    /*
     * Reset the quantity after adding the product.
     */
    detailQuantity = 1;

    document.getElementById(
        "detailQuantity"
    ).textContent = "1";
}

</script>

<?php

include 'includes/footer.php';

?>