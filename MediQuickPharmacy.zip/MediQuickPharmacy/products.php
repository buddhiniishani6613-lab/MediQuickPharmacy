<?php

include 'config/database.php';

include 'includes/header.php';

/*
 * Convert the database category name into the matching
 * product image folder name.
 */
function getCategoryFolder($categoryName)
{
    $folders = [
        "Prescription"           => "Prescription Medicines",
        "Prescription Medicines" => "Prescription Medicines",
        "OTC Products"           => "OTC Products",
        "Wellness Products"      => "Wellness Products",
        "Personal Care"          => "Personal Care",
        "Medical Devices"        => "Medical Devices",
        "Baby Care"              => "Baby Care"
    ];

    return $folders[$categoryName] ?? $categoryName;
}

/*
 * Find the product image from the current
 * assets/images/products folder structure.
 */
function getProductImage($categoryName, $databaseImage, $productName)
{
    /*
     * Get the correct category folder.
     */
    $folder = getCategoryFolder($categoryName);

    /*
     * Build the server-side folder path.
     *
     * __DIR__ points to the root MediQuickPharmacy folder
     * because products.php is located there.
     */
    $serverFolder =
        __DIR__ .
        DIRECTORY_SEPARATOR .
        "assets" .
        DIRECTORY_SEPARATOR .
        "images" .
        DIRECTORY_SEPARATOR .
        "products" .
        DIRECTORY_SEPARATOR .
        $folder .
        DIRECTORY_SEPARATOR;

    /*
     * Build the browser URL for the same folder.
     *
     * rawurlencode() safely handles spaces in folder names
     * and file names.
     */
    $webFolder =
        "assets/images/products/" .
        rawurlencode($folder) .
        "/";

    /*
     * 1. Check the image path stored in the database.
     */
    if (!empty($databaseImage)) {

        $databaseImage = trim($databaseImage);

        /*
         * Extract only the filename.
         *
         * Example:
         * assets/images/products/Baby Care/Baby Shampoo.jpg
         *
         * becomes:
         * Baby Shampoo.jpg
         */
        $fileName = basename($databaseImage);

        /*
         * Check whether the file exists inside the
         * correct category folder.
         */
        $fullPath =
            $serverFolder .
            $fileName;

        if (file_exists($fullPath)) {

            return
                $webFolder .
                rawurlencode($fileName);
        }
    }

    /*
     * 2. Check the exact product name with .jpg extension.
     */
    $jpgFile =
        $productName .
        ".jpg";

    if (
        file_exists(
            $serverFolder .
            $jpgFile
        )
    ) {

        return
            $webFolder .
            rawurlencode($jpgFile);
    }

    /*
     * 3. Check the exact product name with .jpeg extension.
     */
    $jpegFile =
        $productName .
        ".jpeg";

    if (
        file_exists(
            $serverFolder .
            $jpegFile
        )
    ) {

        return
            $webFolder .
            rawurlencode($jpegFile);
    }

    /*
     * 4. Check the exact product name with .png extension.
     */
    $pngFile =
        $productName .
        ".png";

    if (
        file_exists(
            $serverFolder .
            $pngFile
        )
    ) {

        return
            $webFolder .
            rawurlencode($pngFile);
    }

    /*
     * 5. Remove dosage information from the product name.
     *
     * Example:
     * Amoxicillin 500mg
     *
     * becomes:
     * Amoxicillin
     */
    $cleanName =
        preg_replace(
            '/\s+\d+(?:\.\d+)?\s*(?:mg|mcg|g|ml|l|%)\b/i',
            '',
            $productName
        );

    $cleanName = trim($cleanName);

    /*
     * Only continue if the product name was actually changed.
     */
    if ($cleanName !== $productName) {

        /*
         * Check cleaned product name with .jpg.
         */
        $cleanJpg =
            $cleanName .
            ".jpg";

        if (
            file_exists(
                $serverFolder .
                $cleanJpg
            )
        ) {

            return
                $webFolder .
                rawurlencode($cleanJpg);
        }

        /*
         * Check cleaned product name with .jpeg.
         */
        $cleanJpeg =
            $cleanName .
            ".jpeg";

        if (
            file_exists(
                $serverFolder .
                $cleanJpeg
            )
        ) {

            return
                $webFolder .
                rawurlencode($cleanJpeg);
        }

        /*
         * Check cleaned product name with .png.
         */
        $cleanPng =
            $cleanName .
            ".png";

        if (
            file_exists(
                $serverFolder .
                $cleanPng
            )
        ) {

            return
                $webFolder .
                rawurlencode($cleanPng);
        }
    }

    /*
     * Return the website logo when no product image is found.
     */
    return "assets/images/Logo.png";
}

/*
 * Get the selected category from the URL.
 */
$selectedCategory =
    isset($_GET['category'])
        ? trim($_GET['category'])
        : '';

/*
 * Base product query.
 */
$sql = "
    SELECT
        p.id,
        p.name,
        p.description,
        p.category,
        p.price,
        p.stock_quantity,
        p.image,
        p.requires_prescription,
        p.status,
        p.created_at
    FROM products p
    WHERE p.status <> 'Inactive'
";

/*
 * Apply category filtering.
 */
if ($selectedCategory !== '') {

    $stmt = $conn->prepare(
        $sql .
        " AND p.category = ?
          ORDER BY p.id ASC"
    );

    if (!$stmt) {

        die(
            "Database query preparation failed: " .
            $conn->error
        );
    }

    $stmt->bind_param(
        "s",
        $selectedCategory
    );

    $stmt->execute();

    $result =
        $stmt->get_result();

} else {

    /*
     * Load all active products.
     */
    $sql .=
        " ORDER BY p.id ASC";

    $result =
        $conn->query($sql);

    if (!$result) {

        die(
            "Database query failed: " .
            $conn->error
        );
    }
}

?>

<section class="products-section">

    <div class="products-container">

        <!-- Page heading -->

        <div class="products-heading">

            <span class="small-title">
                MEDIQUICK PHARMACY
            </span>

            <h1>

                <?php

                if ($selectedCategory !== '') {

                    echo htmlspecialchars(
                        $selectedCategory
                    );

                } else {

                    echo "Our Products";
                }

                ?>

            </h1>

            <p>
                Browse our healthcare products and find what you need.
            </p>

        </div>


        <!-- Search and category controls -->

        <div class="product-controls">

            <input
                type="text"
                id="searchInput"
                placeholder="Search products..."
            >

            <select
                id="categoryFilter"
                onchange="changeCategory(this.value)"
            >

                <option value="all">
                    All Categories
                </option>

                <option
                    value="Prescription"
                    <?php

                    echo $selectedCategory === "Prescription"
                        ? "selected"
                        : "";

                    ?>
                >
                    Prescription Medicines
                </option>

                <option
                    value="OTC Products"
                    <?php

                    echo $selectedCategory === "OTC Products"
                        ? "selected"
                        : "";

                    ?>
                >
                    OTC Products
                </option>

                <option
                    value="Wellness Products"
                    <?php

                    echo $selectedCategory === "Wellness Products"
                        ? "selected"
                        : "";

                    ?>
                >
                    Wellness Products
                </option>

                <option
                    value="Personal Care"
                    <?php

                    echo $selectedCategory === "Personal Care"
                        ? "selected"
                        : "";

                    ?>
                >
                    Personal Care
                </option>

                <option
                    value="Medical Devices"
                    <?php

                    echo $selectedCategory === "Medical Devices"
                        ? "selected"
                        : "";

                    ?>
                >
                    Medical Devices
                </option>

                <option
                    value="Baby Care"
                    <?php

                    echo $selectedCategory === "Baby Care"
                        ? "selected"
                        : "";

                    ?>
                >
                    Baby Care
                </option>

            </select>

        </div>


        <!-- Products grid -->

        <div
            id="productGrid"
            class="product-grid"
        >

        <?php

        if (
            $result &&
            $result->num_rows > 0
        ):

            while (
                $product =
                $result->fetch_assoc()
            ):

                $productId =
                    (int) $product['id'];

                $productName =
                    $product['name'];

                $categoryName =
                    $product['category'];

                $price =
                    (float) $product['price'];

                $stock =
                    (int) $product['stock_quantity'];

                $description =
                    $product['description'] ?? "";

                $databaseImage =
                    $product['image'] ?? "";

                /*
                 * Find the actual product image.
                 */
                $imagePath =
                    getProductImage(
                        $categoryName,
                        $databaseImage,
                        $productName
                    );

        ?>

            <!-- Product card -->

            <div
                class="product-card"
                data-name="<?php
                    echo htmlspecialchars(
                        $productName,
                        ENT_QUOTES,
                        'UTF-8'
                    );
                ?>"
                data-category="<?php
                    echo htmlspecialchars(
                        $categoryName,
                        ENT_QUOTES,
                        'UTF-8'
                    );
                ?>"
            >

                <!-- Product image area -->

                <div class="product-image-wrapper">

                    <!-- Wishlist button -->

                    <a
                        href="Customer/add-to-wishlist.php?id=<?php echo $productId; ?>"
                        class="wishlist-heart"
                        title="Add to Wishlist"
                        aria-label="Add <?php
                            echo htmlspecialchars(
                                $productName,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                        ?> to Wishlist"
                    >

                        <i class="bi bi-heart"></i>

                    </a>


                    <!-- Product image -->

                    <img
                        src="<?php
                            echo htmlspecialchars(
                                $imagePath,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                        ?>"
                        alt="<?php
                            echo htmlspecialchars(
                                $productName,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                        ?>"
                        class="product-image"
                        onerror="
                            this.onerror=null;
                            this.src='assets/images/Logo.png';
                        "
                    >

                </div>


                <!-- Product information -->

                <div class="product-info">

                    <!-- Category -->

                    <span class="product-category">

                        <?php

                        echo htmlspecialchars(
                            $categoryName,
                            ENT_QUOTES,
                            'UTF-8'
                        );

                        ?>

                    </span>


                    <!-- Product name -->

                    <h3>

                        <?php

                        echo htmlspecialchars(
                            $productName,
                            ENT_QUOTES,
                            'UTF-8'
                        );

                        ?>

                    </h3>


                    <!-- Product description -->

                    <p class="product-description">

                        <?php

                        if (
                            strlen($description) > 75
                        ) {

                            echo htmlspecialchars(
                                substr(
                                    $description,
                                    0,
                                    75
                                ) . "..."
                            );

                        } else {

                            echo htmlspecialchars(
                                $description
                            );
                        }

                        ?>

                    </p>


                    <!-- Product price -->

                    <div class="product-price">

                        Rs.

                        <?php

                        echo number_format(
                            $price,
                            2
                        );

                        ?>

                    </div>


                    <!-- Product availability -->

                    <?php

                    if ($stock > 0):

                    ?>

                        <div
                            class="product-availability available"
                        >

                            <i class="bi bi-check-circle-fill"></i>

                            <span>
                                Available
                            </span>

                            <small>

                                (
                                <?php
                                echo $stock;
                                ?>
                                in stock)

                            </small>

                        </div>

                    <?php

                    else:

                    ?>

                        <div
                            class="product-availability out-of-stock"
                        >

                            <i class="bi bi-x-circle-fill"></i>

                            <span>
                                Out of Stock
                            </span>

                        </div>

                    <?php

                    endif;

                    ?>


                    <!-- Product buttons -->

                    <div class="product-buttons">

                        <!-- View details -->

                        <a
                            href="product-details.php?id=<?php
                                echo $productId;
                            ?>"
                            class="view-details-button"
                        >

                            <i class="bi bi-eye"></i>

                            View Details

                        </a>


                        <!-- Add to cart -->

                        <?php

                        if ($stock > 0):

                        ?>

                            <button
                                type="button"
                                class="add-cart-button"
                                data-id="<?php
                                    echo $productId;
                                ?>"
                                data-name="<?php
                                    echo htmlspecialchars(
                                        $productName,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    );
                                ?>"
                                data-price="<?php
                                    echo $price;
                                ?>"
                                data-image="<?php
                                    echo htmlspecialchars(
                                        $imagePath,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    );
                                ?>"
                                data-stock="<?php
                                    echo $stock;
                                ?>"
                            >

                                <i class="bi bi-cart-plus"></i>

                                Add to Cart

                            </button>

                        <?php

                        else:

                        ?>

                            <button
                                type="button"
                                class="add-cart-button disabled"
                                disabled
                            >

                                <i class="bi bi-cart-x"></i>

                                Out of Stock

                            </button>

                        <?php

                        endif;

                        ?>

                    </div>

                </div>

            </div>

        <?php

            endwhile;

        else:

        ?>

            <!-- Empty products state -->

            <div class="no-products">

                <i class="bi bi-box-seam"></i>

                <h2>
                    No Products Available
                </h2>

                <p>
                    There are no products in this category.
                </p>

            </div>

        <?php

        endif;

        ?>

        </div>

    </div>

</section>


<style>

/* Main products section */

.products-section {

    background: #f6fbfd;

    min-height: 80vh;

    padding: 60px 20px;

}


.products-container {

    max-width: 1200px;

    margin: auto;

}


/* Page heading */

.products-heading {

    text-align: center;

    margin-bottom: 40px;

}


.small-title {

    color: #087f9b;

    font-size: 13px;

    font-weight: 700;

    letter-spacing: 2px;

}


.products-heading h1 {

    color: #174f68;

    font-size: 34px;

    margin: 8px 0;

}


.products-heading p {

    color: #777;

}


/* Search and category controls */

.product-controls {

    display: flex;

    gap: 15px;

    margin-bottom: 35px;

}


.product-controls input,

.product-controls select {

    padding: 13px 15px;

    border: 1px solid #d8e5e9;

    border-radius: 8px;

    background: white;

    outline: none;

}


.product-controls input {

    flex: 1;

}


.product-controls select {

    width: 280px;

}


.product-controls input:focus,

.product-controls select:focus {

    border-color: #087f9b;

}


/* Product grid */

.product-grid {

    display: grid;

    grid-template-columns: repeat(4, 1fr);

    gap: 25px;

}


/* Product card */

.product-card {

    background: white;

    border-radius: 16px;

    overflow: hidden;

    box-shadow:

        0 5px 20px

        rgba(0, 80, 110, 0.08);

    transition: 0.25s;

}


.product-card:hover {

    transform: translateY(-5px);

    box-shadow:

        0 10px 30px

        rgba(0, 80, 110, 0.14);

}


/* Product image */

.product-image-wrapper {

    width: 100%;

    height: 220px;

    background: #f5fafc;

    display: flex;

    align-items: center;

    justify-content: center;

    overflow: hidden;

    position: relative;

}


.product-image {

    width: 100%;

    height: 100%;

    object-fit: contain;

    padding: 15px;

    display: block;

}


/* Wishlist heart */

.wishlist-heart {

    position: absolute;

    top: 12px;

    right: 12px;

    width: 40px;

    height: 40px;

    border-radius: 50%;

    background: rgba(255, 255, 255, 0.95);

    display: flex;

    align-items: center;

    justify-content: center;

    color: #e05268;

    text-decoration: none;

    font-size: 19px;

    z-index: 10;

    box-shadow:

        0 3px 12px

        rgba(0, 0, 0, 0.12);

    transition: all 0.25s ease;

}


.wishlist-heart:hover {

    background: #e05268;

    color: white;

    transform: scale(1.08);

}


.wishlist-heart:active {

    transform: scale(0.95);

}


/* Product information */

.product-info {

    padding: 18px;

}


.product-category {

    color: #087f9b;

    font-size: 11px;

    font-weight: 700;

    text-transform: uppercase;

}


.product-info h3 {

    color: #174f68;

    font-size: 17px;

    margin: 8px 0;

    min-height: 42px;

}


.product-description {

    color: #777;

    font-size: 13px;

    line-height: 1.5;

    min-height: 40px;

    margin-bottom: 8px;

}


.product-price {

    color: #087f9b;

    font-size: 19px;

    font-weight: 700;

}


/* Product availability */

.product-availability {

    display: flex;

    align-items: center;

    gap: 5px;

    margin-top: 9px;

    font-size: 13px;

    font-weight: 700;

}


.product-availability.available {

    color: #16834b;

}


.product-availability.available small {

    color: #777;

    font-size: 11px;

    font-weight: 500;

}


.product-availability.out-of-stock {

    color: #dc3545;

}


/* Product buttons */

.product-buttons {

    display: flex;

    gap: 8px;

    margin-top: 17px;

}


.view-details-button,

.add-cart-button {

    flex: 1;

    padding: 10px 8px;

    border-radius: 8px;

    font-size: 12px;

    font-weight: 600;

    text-align: center;

    cursor: pointer;

    text-decoration: none;

    box-sizing: border-box;

}


.view-details-button {

    border: 1px solid #087f9b;

    color: #087f9b;

    background: white;

}


.view-details-button:hover {

    background: #eaf7fa;

}


.add-cart-button {

    border: none;

    background: #087f9b;

    color: white;

}


.add-cart-button:hover {

    background: #056b83;

}


.add-cart-button.disabled,

.add-cart-button:disabled {

    background: #b8c4c8;

    cursor: not-allowed;

}


/* Empty products state */

.no-products {

    grid-column: 1 / -1;

    background: white;

    padding: 70px 20px;

    text-align: center;

    border-radius: 16px;

}


.no-products i {

    font-size: 50px;

    color: #8bbbc7;

}


.no-products h2 {

    color: #174f68;

}


.no-products p {

    color: #777;

}


/* Responsive layout */

@media (max-width: 1050px) {

    .product-grid {

        grid-template-columns: repeat(3, 1fr);

    }

}


@media (max-width: 750px) {

    .product-grid {

        grid-template-columns: repeat(2, 1fr);

    }

    .product-controls {

        flex-direction: column;

    }

    .product-controls select {

        width: 100%;

    }

}


@media (max-width: 500px) {

    .product-grid {

        grid-template-columns: 1fr;

    }

}

</style>


<script>

/*
 * Change the selected product category.
 */
function changeCategory(category)
{

    if (category === "all") {

        window.location.href =
            "products.php";

        return;
    }

    window.location.href =
        "products.php?category=" +
        encodeURIComponent(category);
}


/*
 * Load product functionality after the page
 * has finished loading.
 */
document.addEventListener(
    "DOMContentLoaded",
    function ()
    {

        /*
         * Add products to cart.
         */
        const buttons =
            document.querySelectorAll(
                ".add-cart-button:not(:disabled)"
            );

        buttons.forEach(
            function (button)
            {

                button.addEventListener(
                    "click",
                    function ()
                    {

                        const id =
                            Number(
                                this.dataset.id
                            );

                        const name =
                            this.dataset.name;

                        const price =
                            Number(
                                this.dataset.price
                            );

                        const image =
                            this.dataset.image;

                        const stock =
                            Number(
                                this.dataset.stock
                            );

                        let cart = [];

                        /*
                         * Load the current cart from localStorage.
                         */
                        try {

                            cart =
                                JSON.parse(
                                    localStorage.getItem(
                                        "mediquickCart"
                                    )
                                ) || [];

                        } catch (error) {

                            cart = [];
                        }

                        /*
                         * Find an existing product in the cart.
                         */
                        const existing =
                            cart.find(
                                function (item)
                                {

                                    return Number(
                                        item.product_id ||
                                        item.id
                                    ) === id;

                                }
                            );

                        /*
                         * Update the quantity if the product
                         * already exists.
                         */
                        if (existing) {

                            const currentQuantity =
                                Number(
                                    existing.quantity
                                ) || 0;

                            /*
                             * Prevent the quantity from exceeding
                             * available stock.
                             */
                            if (
                                currentQuantity >=
                                stock
                            ) {

                                alert(
                                    "You cannot add more than the available stock."
                                );

                                return;
                            }

                            existing.quantity =
                                currentQuantity + 1;

                            existing.price =
                                price;

                            existing.image =
                                image;

                            existing.product_id =
                                id;

                            existing.stock =
                                stock;

                        } else {

                            /*
                             * Add a new product to the cart.
                             */
                            cart.push({

                                product_id:
                                    id,

                                name:
                                    name,

                                price:
                                    price,

                                image:
                                    image,

                                stock:
                                    stock,

                                quantity:
                                    1
                            });
                        }

                        /*
                         * Save the cart in localStorage.
                         */
                        localStorage.setItem(
                            "mediquickCart",
                            JSON.stringify(cart)
                        );

                        /*
                         * Show confirmation message.
                         */
                        alert(
                            name +
                            " has been added to your cart."
                        );

                    }
                );

            }
        );


        /*
         * Product search.
         */
        const searchInput =
            document.getElementById(
                "searchInput"
            );

        const productCards =
            document.querySelectorAll(
                ".product-card"
            );

        if (searchInput) {

            searchInput.addEventListener(
                "input",
                function ()
                {

                    const searchText =
                        this.value
                            .toLowerCase()
                            .trim();

                    productCards.forEach(
                        function (card)
                        {

                            const name =
                                card.dataset.name
                                    .toLowerCase();

                            const category =
                                card.dataset.category
                                    .toLowerCase();

                            /*
                             * Display products matching
                             * the search text.
                             */
                            if (
                                name.includes(
                                    searchText
                                ) ||
                                category.includes(
                                    searchText
                                )
                            ) {

                                card.style.display =
                                    "";

                            } else {

                                card.style.display =
                                    "none";
                            }

                        }
                    );

                }
            );

        }

    }
);

</script>


<?php

include 'includes/footer.php';

?>