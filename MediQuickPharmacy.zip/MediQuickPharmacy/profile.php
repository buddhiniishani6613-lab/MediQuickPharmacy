
<?php

session_start();

require_once __DIR__ . '/config/database.php';

/* Check whether the customer is logged in */

if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {

    header("Location: login.php");
    exit();

}

$userId = (int) $_SESSION['user_id'];

$message = "";
$messageType = "";


/* Escape output before displaying it */

function e($value)
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}


/* Update the customer profile */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $fullName = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');

    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';


    /* Validate profile information */

    if ($fullName === '' || $email === '') {

        $message = "Full name and email are required.";
        $messageType = "danger";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $message = "Please enter a valid email address.";
        $messageType = "danger";

    } elseif ($newPassword !== '' && strlen($newPassword) < 6) {

        $message = "New password must contain at least 6 characters.";
        $messageType = "danger";

    } elseif ($newPassword !== $confirmPassword) {

        $message = "New password and confirm password do not match.";
        $messageType = "danger";

    } else {

        /* Check whether another account uses this email */

        $emailCheck = $conn->prepare("
            SELECT id
            FROM users
            WHERE email = ?
            AND id != ?
            LIMIT 1
        ");

        if (!$emailCheck) {

            $message = "Unable to check email address.";
            $messageType = "danger";

        } else {

            $emailCheck->bind_param("si", $email, $userId);
            $emailCheck->execute();

            $emailResult = $emailCheck->get_result();

            if ($emailResult->num_rows > 0) {

                $message = "This email address is already used by another account.";
                $messageType = "danger";

            } else {

                /* Update profile with a new password */

                if ($newPassword !== '') {

                    $hashedPassword = password_hash(
                        $newPassword,
                        PASSWORD_DEFAULT
                    );

                    $update = $conn->prepare("
                        UPDATE users
                        SET
                            full_name = ?,
                            email = ?,
                            phone = ?,
                            password = ?
                        WHERE id = ?
                    ");

                    if ($update) {

                        $update->bind_param(
                            "ssssi",
                            $fullName,
                            $email,
                            $phone,
                            $hashedPassword,
                            $userId
                        );

                    }

                }

                /* Update profile without changing password */

                else {

                    $update = $conn->prepare("
                        UPDATE users
                        SET
                            full_name = ?,
                            email = ?,
                            phone = ?
                        WHERE id = ?
                    ");

                    if ($update) {

                        $update->bind_param(
                            "sssi",
                            $fullName,
                            $email,
                            $phone,
                            $userId
                        );

                    }

                }


                /* Execute the update query */

                if (!isset($update) || !$update) {

                    $message = "Unable to prepare profile update.";
                    $messageType = "danger";

                } elseif ($update->execute()) {

                    $message = "Profile updated successfully.";
                    $messageType = "success";

                } else {

                    $message = "Failed to update profile.";
                    $messageType = "danger";

                }

                if (isset($update) && $update) {
                    $update->close();
                }

            }

            $emailCheck->close();

        }

    }

}


/* Get the current user's information */

$stmt = $conn->prepare("
    SELECT
        id,
        full_name,
        email,
        phone,
        role,
        created_at
    FROM users
    WHERE id = ?
    LIMIT 1
");

if (!$stmt) {
    die("Unable to load user information.");
}

$stmt->bind_param("i", $userId);
$stmt->execute();

$result = $stmt->get_result();


/* Check whether the user account exists */

if ($result->num_rows === 0) {

    session_unset();
    session_destroy();

    header("Location: login.php");
    exit();

}

$user = $result->fetch_assoc();

$stmt->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>My Profile | MediQuick Pharmacy</title>

    <!-- Bootstrap CSS -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <!-- Bootstrap Icons -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
        rel="stylesheet"
    >

    <style>

        body {
            background: #f6f9fc;
            font-family: Arial, Helvetica, sans-serif;
        }

        /* Profile page banner */

        .profile-header {
            background: linear-gradient(
                135deg,
                #006391,
                #0dcaf0
            );

            color: white;
            padding: 45px 20px;
            border-radius: 0 0 25px 25px;
            margin-bottom: 35px;
        }

        .profile-header h1 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .profile-header p {
            margin: 0;
            opacity: 0.9;
            font-size: 14px;
        }

        .profile-banner-icon {
            font-size: 48px;
        }

        /* Main profile page */

        .profile-page {
            padding-bottom: 65px;
            min-height: 70vh;
        }

        /* Profile cards */

        .profile-card {
            background: white;
            border-radius: 18px;
            border: 1px solid #e5edf0;
            padding: 28px;

            box-shadow:
                0 5px 25px rgba(0, 0, 0, 0.06);
        }

        /* Card headings */

        .section-title {
            font-size: 19px;
            font-weight: 700;
            color: #174f68;
            margin-bottom: 22px;
            padding-bottom: 13px;
            border-bottom: 1px solid #edf0f2;
        }

        /* Account information */

        .account-info {
            background: #f6fafc;
            border-radius: 14px;
            padding: 18px;
        }

        .info-item {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 17px;
        }

        .info-item:last-child {
            margin-bottom: 0;
        }

        .info-icon {
            width: 42px;
            height: 42px;
            min-width: 42px;
            border-radius: 11px;

            background: #e8f5fa;
            color: #087f9b;

            display: flex;
            align-items: center;
            justify-content: center;

            font-size: 18px;
        }

        .info-label {
            font-size: 12px;
            color: #87959b;
            margin-bottom: 3px;
        }

        .info-value {
            font-size: 14px;
            font-weight: 600;
            color: #33474e;
            overflow-wrap: anywhere;
        }

        /* Form labels */

        .form-label {
            font-size: 14px;
            font-weight: 600;
            color: #40535a;
        }

        /* Form input fields */

        .form-control {
            border: 1px solid #dce6e9;
            border-radius: 9px;
            padding: 11px 13px;
            font-size: 14px;
        }

        .form-control:focus {
            border-color: #078b91;

            box-shadow:
                0 0 0 0.2rem rgba(7, 139, 145, 0.12);
        }

        .input-group-text {
            background: #f2f8fa;
            border: 1px solid #dce6e9;
            color: #087f9b;
        }

        .input-group .form-control {
            min-width: 0;
        }

        /* Profile update button */

        .btn-update {
            background: #087f9b;
            color: white;
            border: none;
            border-radius: 9px;
            padding: 11px 23px;
            font-size: 14px;
            font-weight: 600;
            transition: 0.2s;
        }

        .btn-update:hover {
            background: #056b83;
            color: white;
        }

        /* Reset button */

        .btn-reset {
            background: white;
            color: #64757b;
            border: 1px solid #d8e2e5;
            border-radius: 9px;
            padding: 11px 22px;
            font-size: 14px;
            font-weight: 600;
        }

        .btn-reset:hover {
            background: #f3f7f9;
            color: #40535a;
        }

        /* Password information */

        .password-info {
            background: #fff9e8;
            border: 1px solid #f2e3b0;
            border-radius: 10px;
            padding: 13px 15px;
            color: #806b2a;
            font-size: 13px;
        }

        /* Responsive layout */

        @media (max-width: 767px) {

            .profile-header {
                padding: 32px 18px;
            }

            .profile-header h1 {
                font-size: 26px;
            }

            .profile-banner-icon {
                font-size: 38px;
            }

            .profile-card {
                padding: 20px;
            }

            .profile-page {
                padding-bottom: 45px;
            }

            .profile-actions {
                flex-direction: column;
            }

            .btn-update,
            .btn-reset {
                width: 100%;
            }

        }

    </style>

</head>

<body>

<?php

/* Include the common website header */

include __DIR__ . '/includes/header.php';

?>


<!-- Profile Page Banner -->

<section class="profile-header">

    <div class="container">

        <div class="d-flex align-items-center gap-3">

            <div class="profile-banner-icon">

                <i class="bi bi-person-circle"></i>

            </div>

            <div>

                <h1>My Profile</h1>

                <p>
                    Manage your personal information and account settings.
                </p>

            </div>

        </div>

    </div>

</section>


<div class="container profile-page">


    <!-- Display success or error messages -->

    <?php if ($message !== ''): ?>

        <div
            class="alert alert-<?= e($messageType); ?> alert-dismissible fade show"
            role="alert"
        >

            <?php if ($messageType === 'success'): ?>

                <i class="bi bi-check-circle-fill me-2"></i>

            <?php else: ?>

                <i class="bi bi-exclamation-circle-fill me-2"></i>

            <?php endif; ?>

            <?= e($message); ?>

            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="alert"
            ></button>

        </div>

    <?php endif; ?>


    <div class="row g-4">


        <!-- Account Information Card -->

        <div class="col-lg-4">

            <div class="profile-card">

                <h3 class="section-title">

                    <i class="bi bi-person-vcard me-2"></i>

                    Account Information

                </h3>


                <div class="account-info">


                    <!-- Customer name -->

                    <div class="info-item">

                        <div class="info-icon">

                            <i class="bi bi-person"></i>

                        </div>

                        <div>

                            <div class="info-label">
                                Full Name
                            </div>

                            <div class="info-value">
                                <?= e($user['full_name']); ?>
                            </div>

                        </div>

                    </div>


                    <!-- Customer email -->

                    <div class="info-item">

                        <div class="info-icon">

                            <i class="bi bi-envelope"></i>

                        </div>

                        <div>

                            <div class="info-label">
                                Email Address
                            </div>

                            <div class="info-value">
                                <?= e($user['email']); ?>
                            </div>

                        </div>

                    </div>


                    <!-- Customer phone -->

                    <div class="info-item">

                        <div class="info-icon">

                            <i class="bi bi-telephone"></i>

                        </div>

                        <div>

                            <div class="info-label">
                                Phone Number
                            </div>

                            <div class="info-value">

                                <?= !empty($user['phone'])
                                    ? e($user['phone'])
                                    : 'Not provided'; ?>

                            </div>

                        </div>

                    </div>


                    <!-- Account role -->

                    <div class="info-item">

                        <div class="info-icon">

                            <i class="bi bi-shield-check"></i>

                        </div>

                        <div>

                            <div class="info-label">
                                Account Type
                            </div>

                            <div class="info-value">

                                <?= e(ucfirst($user['role'])); ?>

                            </div>

                        </div>

                    </div>


                    <!-- Account creation date -->

                    <div class="info-item">

                        <div class="info-icon">

                            <i class="bi bi-calendar-check"></i>

                        </div>

                        <div>

                            <div class="info-label">
                                Member Since
                            </div>

                            <div class="info-value">

                                <?= !empty($user['created_at'])
                                    ? e(date(
                                        'd M Y',
                                        strtotime($user['created_at'])
                                    ))
                                    : 'N/A'; ?>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- Edit Profile Card -->

        <div class="col-lg-8">

            <div class="profile-card">

                <h3 class="section-title">

                    <i class="bi bi-pencil-square me-2"></i>

                    Edit Profile

                </h3>


                <form
                    method="POST"
                    action=""
                    autocomplete="off"
                >


                    <!-- Full name -->

                    <div class="mb-3">

                        <label
                            for="full_name"
                            class="form-label"
                        >
                            Full Name
                        </label>

                        <div class="input-group">

                            <span class="input-group-text">

                                <i class="bi bi-person"></i>

                            </span>

                            <input
                                type="text"
                                class="form-control"
                                id="full_name"
                                name="full_name"
                                value="<?= e($user['full_name']); ?>"
                                required
                            >

                        </div>

                    </div>


                    <!-- Email address -->

                    <div class="mb-3">

                        <label
                            for="email"
                            class="form-label"
                        >
                            Email Address
                        </label>

                        <div class="input-group">

                            <span class="input-group-text">

                                <i class="bi bi-envelope"></i>

                            </span>

                            <input
                                type="email"
                                class="form-control"
                                id="email"
                                name="email"
                                value="<?= e($user['email']); ?>"
                                required
                            >

                        </div>

                    </div>


                    <!-- Phone number -->

                    <div class="mb-4">

                        <label
                            for="phone"
                            class="form-label"
                        >
                            Phone Number
                        </label>

                        <div class="input-group">

                            <span class="input-group-text">

                                <i class="bi bi-telephone"></i>

                            </span>

                            <input
                                type="text"
                                class="form-control"
                                id="phone"
                                name="phone"
                                value="<?= e($user['phone']); ?>"
                                placeholder="Enter your phone number"
                            >

                        </div>

                    </div>


                    <!-- Password section -->

                    <h3 class="section-title mt-4">

                        <i class="bi bi-lock me-2"></i>

                        Change Password

                    </h3>


                    <!-- New password -->

                    <div class="mb-3">

                        <label
                            for="new_password"
                            class="form-label"
                        >
                            New Password
                        </label>

                        <div class="input-group">

                            <span class="input-group-text">

                                <i class="bi bi-lock"></i>

                            </span>

                            <input
                                type="password"
                                class="form-control"
                                id="new_password"
                                name="new_password"
                                placeholder="Enter new password"
                                minlength="6"
                            >

                            <button
                                type="button"
                                class="btn btn-outline-secondary"
                                onclick="togglePassword('new_password', this)"
                            >

                                <i class="bi bi-eye"></i>

                            </button>

                        </div>

                    </div>


                    <!-- Confirm password -->

                    <div class="mb-3">

                        <label
                            for="confirm_password"
                            class="form-label"
                        >
                            Confirm New Password
                        </label>

                        <div class="input-group">

                            <span class="input-group-text">

                                <i class="bi bi-lock-fill"></i>

                            </span>

                            <input
                                type="password"
                                class="form-control"
                                id="confirm_password"
                                name="confirm_password"
                                placeholder="Confirm new password"
                                minlength="6"
                            >

                            <button
                                type="button"
                                class="btn btn-outline-secondary"
                                onclick="togglePassword('confirm_password', this)"
                            >

                                <i class="bi bi-eye"></i>

                            </button>

                        </div>

                    </div>


                    <!-- Password information -->

                    <div class="password-info">

                        <i class="bi bi-info-circle me-2"></i>

                        Leave the password fields empty if you do not want
                        to change your password.

                    </div>


                    <!-- Form buttons -->

                    <div class="d-flex gap-2 mt-4 profile-actions">

                        <button
                            type="submit"
                            class="btn-update"
                        >

                            <i class="bi bi-check2-circle me-2"></i>

                            Update Profile

                        </button>


                        <button
                            type="reset"
                            class="btn-reset"
                        >

                            <i class="bi bi-arrow-counterclockwise me-2"></i>

                            Reset

                        </button>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>


<script>

/* Show or hide password fields */

function togglePassword(fieldId, button) {

    const field = document.getElementById(fieldId);

    const icon = button.querySelector('i');

    if (!field || !icon) {
        return;
    }

    if (field.type === "password") {

        field.type = "text";

        icon.classList.remove("bi-eye");
        icon.classList.add("bi-eye-slash");

    } else {

        field.type = "password";

        icon.classList.remove("bi-eye-slash");
        icon.classList.add("bi-eye");

    }

}

</script>


<!-- Bootstrap JavaScript -->

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>


<?php

/* Include the common website footer */

include __DIR__ . '/includes/footer.php';

?>

</body>
</html>
