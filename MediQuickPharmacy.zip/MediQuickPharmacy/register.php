<?php

include 'includes/header.php';
include 'config/database.php';

$message = "";
$messageType = "";

/* Handle customer registration form submission */
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $fullName = trim($_POST["full_name"] ?? "");
    $email = trim(strtolower($_POST["email"] ?? ""));
    $phone = trim($_POST["phone"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirmPassword = $_POST["confirm_password"] ?? "";

    /* Validate required fields */
    if (
        empty($fullName) ||
        empty($email) ||
        empty($phone) ||
        empty($password) ||
        empty($confirmPassword)
    ) {

        $message = "Please fill in all required fields.";
        $messageType = "error";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $message = "Please enter a valid email address.";
        $messageType = "error";

    } elseif (strlen($password) < 6) {

        $message = "Password must contain at least 6 characters.";
        $messageType = "error";

    } elseif ($password !== $confirmPassword) {

        $message = "Passwords do not match.";
        $messageType = "error";

    } else {

        /* Check whether the email already exists */
        $checkSql = "
            SELECT id
            FROM users
            WHERE email = ?
            LIMIT 1
        ";

        $checkStmt = $conn->prepare($checkSql);

        if (!$checkStmt) {

            $message = "Unable to process registration. Please try again.";
            $messageType = "error";

        } else {

            $checkStmt->bind_param(
                "s",
                $email
            );

            $checkStmt->execute();

            $checkResult = $checkStmt->get_result();

            if ($checkResult->num_rows > 0) {

                $message = "An account with this email already exists.";
                $messageType = "error";

            } else {

                /* Hash the password before storing it */
                $hashedPassword = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                /* Insert the new customer account */
                $insertSql = "
                    INSERT INTO users
                    (
                        full_name,
                        email,
                        phone,
                        password,
                        role
                    )
                    VALUES
                    (
                        ?,
                        ?,
                        ?,
                        ?,
                        'customer'
                    )
                ";

                $insertStmt = $conn->prepare($insertSql);

                if (!$insertStmt) {

                    $message = "Registration failed. Please try again.";
                    $messageType = "error";

                } else {

                    $insertStmt->bind_param(
                        "ssss",
                        $fullName,
                        $email,
                        $phone,
                        $hashedPassword
                    );

                    if ($insertStmt->execute()) {

                        echo "
                            <script>
                                alert('Account created successfully!');
                                window.location.href = 'login.php';
                            </script>
                        ";

                        exit;

                    } else {

                        $message = "Registration failed. Please try again.";
                        $messageType = "error";
                    }

                    $insertStmt->close();
                }
            }

            $checkStmt->close();
        }
    }
}
?>

<section class="register-section">

    <div class="register-container">

        <div class="register-card">

            <!-- Registration icon -->
            <div class="register-icon">
                <i class="bi bi-person-plus"></i>
            </div>

            <!-- Registration heading -->
            <div class="register-heading">

                <span class="small-title">
                    MEDIQUICK PHARMACY
                </span>

                <h1>
                    Create Account
                </h1>

                <p>
                    Register to manage your orders
                    and prescriptions.
                </p>

            </div>

            <!-- Registration message -->
            <?php if (!empty($message)): ?>

                <div
                    class="register-message <?php echo htmlspecialchars($messageType); ?>"
                >

                    <i
                        class="bi <?php
                        echo $messageType === "error"
                            ? "bi-exclamation-circle"
                            : "bi-check-circle";
                        ?>"
                    ></i>

                    <?php echo htmlspecialchars($message); ?>

                </div>

            <?php endif; ?>

            <!-- Registration form -->
            <form
                id="registerForm"
                method="POST"
                action=""
            >

                <!-- Full name -->
                <div class="form-group">

                    <label for="fullName">
                        Full Name
                    </label>

                    <div class="input-wrapper">

                        <i class="bi bi-person"></i>

                        <input
                            type="text"
                            id="fullName"
                            name="full_name"
                            placeholder="Enter your full name"
                            value="<?php
                                echo htmlspecialchars(
                                    $_POST["full_name"] ?? "",
                                    ENT_QUOTES,
                                    "UTF-8"
                                );
                            ?>"
                            required
                        >

                    </div>

                </div>

                <!-- Email -->
                <div class="form-group">

                    <label for="email">
                        Email Address
                    </label>

                    <div class="input-wrapper">

                        <i class="bi bi-envelope"></i>

                        <input
                            type="email"
                            id="email"
                            name="email"
                            placeholder="Enter your email address"
                            value="<?php
                                echo htmlspecialchars(
                                    $_POST["email"] ?? "",
                                    ENT_QUOTES,
                                    "UTF-8"
                                );
                            ?>"
                            required
                        >

                    </div>

                </div>

                <!-- Phone -->
                <div class="form-group">

                    <label for="phone">
                        Phone Number
                    </label>

                    <div class="input-wrapper">

                        <i class="bi bi-telephone"></i>

                        <input
                            type="tel"
                            id="phone"
                            name="phone"
                            placeholder="Enter your phone number"
                            value="<?php
                                echo htmlspecialchars(
                                    $_POST["phone"] ?? "",
                                    ENT_QUOTES,
                                    "UTF-8"
                                );
                            ?>"
                            required
                        >

                    </div>

                </div>

                <!-- Password -->
                <div class="form-group">

                    <label for="password">
                        Password
                    </label>

                    <div class="input-wrapper">

                        <i class="bi bi-lock"></i>

                        <input
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Create a password"
                            required
                        >

                        <button
                            type="button"
                            class="password-toggle"
                            id="passwordToggle"
                            aria-label="Show or hide password"
                        >

                            <i class="bi bi-eye"></i>

                        </button>

                    </div>

                </div>

                <!-- Confirm password -->
                <div class="form-group">

                    <label for="confirmPassword">
                        Confirm Password
                    </label>

                    <div class="input-wrapper">

                        <i class="bi bi-shield-lock"></i>

                        <input
                            type="password"
                            id="confirmPassword"
                            name="confirm_password"
                            placeholder="Confirm your password"
                            required
                        >

                    </div>

                </div>

                <!-- Terms and conditions -->
                <label class="terms-option">

                    <input
                        type="checkbox"
                        id="terms"
                        required
                    >

                    <span>
                        I agree to the MediQuick Pharmacy
                        terms and conditions.
                    </span>

                </label>

                <!-- Submit button -->
                <button
                    type="submit"
                    class="register-button"
                >

                    <i class="bi bi-person-plus"></i>

                    Create Account

                </button>

            </form>

            <!-- Login link -->
            <div class="login-link">

                <span>
                    Already have an account?
                </span>

                <a href="login.php">
                    Login
                </a>

            </div>

        </div>

    </div>

</section>

<style>

/* Registration page section */
.register-section {

    min-height: 80vh;

    background: #f6fbfd;

    padding: 60px 20px;

    display: flex;

    justify-content: center;

    align-items: center;

}

.register-container {

    width: 100%;

    max-width: 500px;

}

.register-card {

    background: white;

    border-radius: 18px;

    padding: 40px;

    box-shadow:
        0 8px 30px
        rgba(0, 80, 110, 0.10);

}

/* Registration icon */
.register-icon {

    width: 70px;

    height: 70px;

    border-radius: 50%;

    background: #e8f7fa;

    display: flex;

    align-items: center;

    justify-content: center;

    margin: 0 auto 18px;

}

.register-icon i {

    font-size: 35px;

    color: #087f9b;

}

/* Registration heading */
.register-heading {

    text-align: center;

    margin-bottom: 30px;

}

.small-title {

    color: #087f9b;

    font-size: 12px;

    font-weight: 700;

    letter-spacing: 2px;

}

.register-heading h1 {

    color: #174f68;

    margin: 8px 0;

    font-size: 30px;

}

.register-heading p {

    color: #777;

    font-size: 14px;

}

/* Registration messages */
.register-message {

    padding: 12px 15px;

    border-radius: 8px;

    margin-bottom: 20px;

    font-size: 14px;

    display: flex;

    align-items: center;

    gap: 8px;

}

.register-message.error {

    background: #fff1f1;

    color: #c0392b;

    border: 1px solid #f3c5c5;

}

/* Form fields */
.form-group {

    margin-bottom: 18px;

}

.form-group label {

    display: block;

    color: #174f68;

    font-size: 14px;

    font-weight: 600;

    margin-bottom: 8px;

}

.input-wrapper {

    position: relative;

}

.input-wrapper > i {

    position: absolute;

    left: 14px;

    top: 50%;

    transform: translateY(-50%);

    color: #087f9b;

}

.input-wrapper input {

    width: 100%;

    box-sizing: border-box;

    padding: 13px 45px;

    border:
        1px solid #d8e5e9;

    border-radius: 8px;

    outline: none;

    font-family: inherit;

}

.input-wrapper input:focus {

    border-color: #087f9b;

    box-shadow:
        0 0 0 3px
        rgba(8, 127, 155, 0.08);

}

/* Password visibility button */
.password-toggle {

    position: absolute;

    right: 8px;

    top: 50%;

    transform: translateY(-50%);

    border: none;

    background: transparent;

    color: #777;

    cursor: pointer;

    font-size: 16px;

}

/* Terms and conditions */
.terms-option {

    display: flex;

    gap: 8px;

    align-items: flex-start;

    color: #666;

    font-size: 13px;

    margin: 20px 0;

    cursor: pointer;

}

.terms-option input {

    margin-top: 3px;

    accent-color: #087f9b;

}

/* Registration button */
.register-button {

    width: 100%;

    border: none;

    background: #087f9b;

    color: white;

    padding: 14px;

    border-radius: 9px;

    font-size: 16px;

    font-weight: 700;

    cursor: pointer;

    transition: 0.2s;

}

.register-button:hover {

    background: #056b83;

}

/* Login link */
.login-link {

    text-align: center;

    margin-top: 25px;

    padding-top: 20px;

    border-top:
        1px solid #edf2f4;

    color: #777;

    font-size: 14px;

}

.login-link a {

    color: #087f9b;

    font-weight: 700;

    text-decoration: none;

    margin-left: 5px;

}

/* Responsive layout */
@media (max-width: 550px) {

    .register-card {

        padding: 25px 20px;

    }

}

</style>

<script>

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const password =
            document.getElementById(
                "password"
            );

        const toggle =
            document.getElementById(
                "passwordToggle"
            );

        if (password && toggle) {

            toggle.addEventListener(
                "click",
                function () {

                    if (
                        password.type ===
                        "password"
                    ) {

                        password.type =
                            "text";

                        this.innerHTML =
                            '<i class="bi bi-eye-slash"></i>';

                    } else {

                        password.type =
                            "password";

                        this.innerHTML =
                            '<i class="bi bi-eye"></i>';

                    }

                }
            );

        }

    }
);

</script>

<?php
include 'includes/footer.php';
?>